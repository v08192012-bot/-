/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.datagen;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Stream;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricProvidedTagBuilder;
import net.fabricmc.fabric.impl.datagen.TagBuilderHooks;
import net.minecraft.data.tag.ProvidedTagBuilder;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagBuilder;
import net.minecraft.registry.tag.TagKey;

/**
 * Extends ProvidedTagBuilder to support setting the {@code replace} and {@code fabric:remove} fields.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
@Mixin(ProvidedTagBuilder.class)
interface TagAppenderMixin<E, T> extends FabricProvidedTagBuilder<E, T> {
	@Mixin(targets = "net.minecraft.data.tags.TagAppender$1")
	abstract class ProvidedTagBuilder1Mixin<E, T> implements TagAppenderMixin<E, T> {
		// the builder param
		@Shadow
		@Final
		TagBuilder val$builder;

		@Override
		public ProvidedTagBuilder setReplace(boolean replace) {
			((TagBuilderHooks) this.val$builder).fabric_setReplace(replace);
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder<E, T> forceAddTag(TagKey<T> tag) {
			((TagBuilderHooks) this.val$builder).fabric_forceAddTag(tag.id());
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder remove(RegistryKey<T> element) {
			((TagBuilderHooks) this.val$builder).fabric_removeElement(element.getValue());
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder remove(final RegistryKey<T>... elements) {
			return removeAll(Arrays.stream(elements));
		}

		@Override
		public ProvidedTagBuilder removeAll(final Collection<RegistryKey<T>> elements) {
			elements.forEach(element -> ((TagBuilderHooks) this.val$builder).fabric_removeElement(element.getValue()));
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder removeAll(final Stream<RegistryKey<T>> elements) {
			elements.forEach(element -> ((TagBuilderHooks) this.val$builder).fabric_removeElement(element.getValue()));
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder removeTag(TagKey<T> tag) {
			((TagBuilderHooks) this.val$builder).fabric_removeTag(tag.id());
			return (ProvidedTagBuilder<E, T>) this;
		}
	}

	@Mixin(targets = "net.minecraft.data.tags.TagAppender$2")
	abstract class ProvidedTagBuilder2Mixin<E, T> implements TagAppenderMixin<E, T> {
		// ProvidedTagBuilder.this
		@Shadow
		@Final
		ProvidedTagBuilder val$original;

		@Override
		public ProvidedTagBuilder setReplace(boolean replace) {
			((FabricProvidedTagBuilder) this.val$original).setReplace(replace);
			return (ProvidedTagBuilder<E, T>) this;
		}

		@Override
		public ProvidedTagBuilder<E, T> forceAddTag(TagKey<T> tag) {
			((FabricProvidedTagBuilder) this.val$original).forceAddTag(tag);
			return (ProvidedTagBuilder<E, T>) this;
		}
	}
}
