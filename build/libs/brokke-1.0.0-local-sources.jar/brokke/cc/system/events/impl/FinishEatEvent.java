package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class FinishEatEvent extends Event {
   private final class_1657 user;
   private final class_1799 stack;

   public FinishEatEvent(class_1657 var1, class_1799 var2) {
      this.user = var1;
      this.stack = var2;
   }

   public class_1657 getUser() {
      return this.user;
   }

   public class_1799 getStack() {
      return this.stack;
   }
}
