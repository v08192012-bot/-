package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_2596;

public class EventPacket extends Event {
   private final class_2596<?> packet;

   public EventPacket(class_2596<?> var1) {
      this.packet = var1;
   }

   public class_2596<?> getPacket() {
      return this.packet;
   }
}
