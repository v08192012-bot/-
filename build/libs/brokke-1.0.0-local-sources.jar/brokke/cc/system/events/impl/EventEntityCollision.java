package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

public class EventEntityCollision extends Event {
   private final class_2248 block;
   private final class_2338 pos;

   public EventEntityCollision(class_2248 var1, class_2338 var2) {
      this.block = var1;
      this.pos = var2;
   }

   public class_2248 getBlock() {
      return this.block;
   }

   public class_2338 getPos() {
      return this.pos;
   }
}
