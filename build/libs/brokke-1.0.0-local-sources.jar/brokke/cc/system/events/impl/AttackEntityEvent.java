package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class AttackEntityEvent extends Event {
   private final class_1657 player;
   private final class_1297 target;

   public AttackEntityEvent(class_1657 var1, class_1297 var2) {
      this.player = var1;
      this.target = var2;
   }

   public class_1657 getPlayer() {
      return this.player;
   }

   public class_1297 getTarget() {
      return this.target;
   }
}
