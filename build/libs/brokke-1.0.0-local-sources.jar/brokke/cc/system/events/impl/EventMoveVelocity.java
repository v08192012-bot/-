package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_243;

public class EventMoveVelocity extends Event {
   public class_243 movement;

   public EventMoveVelocity(class_243 var1) {
      this.movement = var1;
   }

   public class_243 getMovement() {
      return this.movement;
   }

   public void setMovement(class_243 var1) {
      this.movement = var1;
   }
}
