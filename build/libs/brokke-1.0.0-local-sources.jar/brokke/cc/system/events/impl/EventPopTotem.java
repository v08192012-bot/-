package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_1657;

public class EventPopTotem extends Event {
   private final class_1657 player;

   public EventPopTotem(class_1657 var1) {
      this.player = var1;
   }

   public class_1657 getPlayer() {
      return this.player;
   }
}
