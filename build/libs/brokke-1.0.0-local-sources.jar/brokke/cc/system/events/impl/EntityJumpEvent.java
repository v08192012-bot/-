package brokke.cc.system.events.impl;

import brokke.cc.system.events.Event;
import net.minecraft.class_1297;

public class EntityJumpEvent extends Event {
   private final class_1297 entity;

   public EntityJumpEvent(class_1297 var1) {
      this.entity = var1;
   }

   public class_1297 getEntity() {
      return this.entity;
   }
}
