package brokke.cc.system.events;

import brokke.cc.system.events.impl.KeyEvent;
import brokke.cc.ui.ClickGui;
import net.minecraft.class_310;

public class EventManager {
   class_310 mc = class_310.method_1551();
   public static ClickGui clickGui = new ClickGui();

   @EventHandler
   public void Events(KeyEvent var1) {
      int var2 = var1.getKey();
      int var3 = var1.getAction();
      if (var2 == 344 && var3 == 1) {
         if (this.mc.field_1755 == clickGui) {
            if (clickGui.isClosing()) {
               clickGui.p();
            } else {
               clickGui.method_25419();
            }
         } else {
            if (this.mc.field_1755 != null && this.mc.field_1755 != clickGui) {
               clickGui.parentScreen = this.mc.field_1755;
            } else {
               clickGui.parentScreen = null;
            }

            clickGui.n();
            this.mc.method_1507(clickGui);
         }
      }
   }
}
