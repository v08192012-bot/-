package brokke.cc.rotation;

import brokke.cc.module.FunctionManager;
import brokke.cc.module.misc.ServerHelper;
import brokke.cc.util.ServerUtility;
import java.util.Comparator;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_9334;

public final class HolyWorldElytraUtil {
   private static final int CHEST_SLOT = 6;

   private HolyWorldElytraUtil() {
   }

   public static boolean a() {
      class_310 var0 = class_310.method_1551();
      return var0.field_1724 != null && var0.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
   }

   public static boolean b() {
      ServerHelper var0 = FunctionManager.a(ServerHelper.class);
      return ServerUtility.f() || var0 != null && var0.l();
   }

   public static boolean c() {
      return a(b());
   }

   public static boolean a(boolean var0) {
      class_310 var1 = class_310.method_1551();
      if (var0 && var1.field_1724 != null && var1.field_1761 != null && var1.field_1755 == null) {
         class_1735 var2 = a() ? e() : d();
         if (var2 != null) {
            int var3 = var1.field_1724.field_7512.field_7763;
            var1.field_1761.method_2906(var3, var2.field_7874, 0, class_1713.field_7790, var1.field_1724);
            var1.field_1761.method_2906(var3, 6, 0, class_1713.field_7790, var1.field_1724);
            var1.field_1761.method_2906(var3, var2.field_7874, 0, class_1713.field_7790, var1.field_1724);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static class_1735 d() {
      class_310 var0 = class_310.method_1551();
      return var0.field_1724 != null && var0.field_1724.field_7512 != null
         ? var0.field_1724
            .field_7512
            .field_7761
            .stream()
            .filter(var0x -> a(var0x.field_7874))
            .filter(var0x -> var0x.method_7677().method_31574(class_1802.field_8833))
            .findFirst()
            .orElse(null)
         : null;
   }

   private static class_1735 e() {
      class_310 var0 = class_310.method_1551();
      return var0.field_1724 != null && var0.field_1724.field_7512 != null
         ? var0.field_1724
            .field_7512
            .field_7761
            .stream()
            .filter(var0x -> a(var0x.field_7874))
            .filter(var0x -> a(var0x.method_7677()))
            .max(Comparator.comparingInt(var0x -> var0x.field_7874))
            .orElse(null)
         : null;
   }

   private static boolean a(int var0) {
      return var0 >= 36 && var0 <= 44;
   }

   public static boolean a(class_1799 var0) {
      if (var0 == null || var0.method_7960() || var0.method_31574(class_1802.field_8833)) {
         return false;
      }

      if (var0.method_58694(class_9334.field_54197) != null) {
         return false;
      }

      class_10192 var1 = var0.method_58694(class_9334.field_54196);
      return var1 != null
         ? var1.comp_3174() == class_1304.field_6174
         : var0.method_31574(class_1802.field_22028)
            || var0.method_31574(class_1802.field_8058)
            || var0.method_31574(class_1802.field_8873)
            || var0.method_31574(class_1802.field_8523)
            || var0.method_31574(class_1802.field_8678)
            || var0.method_31574(class_1802.field_8577);
   }
}
