package brokke.cc.rotation;

import brokke.cc.module.combat.Aura;
import brokke.cc.nav.BestPoint;
import brokke.cc.util.GCDUtil2;
import net.minecraft.class_1309;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class WhiteRiseRotation extends RotationsSystem {
   private final Aura aura;
   private class_1309 trackedTarget;
   private float lastYaw;
   private float lastPitch;
   private float speedAcceleration;
   private boolean back;
   private boolean initialized;
   private float jitterOffset;
   private int tickCounter;

   public WhiteRiseRotation(Aura var1) {
      this.aura = var1;
   }

   public void a() {
      this.trackedTarget = null;
      this.speedAcceleration = 0.0F;
      this.back = false;
      this.jitterOffset = 0.0F;
      this.tickCounter = 0;
      this.initialized = mc.field_1724 != null;
      if (mc.field_1724 != null) {
         this.lastYaw = mc.field_1724.method_36454();
         this.lastPitch = mc.field_1724.method_36455();
      } else {
         this.lastYaw = 0.0F;
         this.lastPitch = 0.0F;
      }
   }

   public void b() {
   }

   @Override
   public void a(class_1309 var1) {
      if (mc.field_1724 != null && var1 != null) {
         if (mc.field_1724.method_6039()) {
            this.rotate = new class_241(mc.field_1724.method_36454(), mc.field_1724.method_36455());
            this.lastYaw = this.rotate.field_1343;
            this.lastPitch = this.rotate.field_1342;
         } else {
            if (!this.initialized) {
               this.lastYaw = mc.field_1724.method_36454();
               this.lastPitch = mc.field_1724.method_36455();
               this.initialized = true;
            }

            if (this.trackedTarget != var1) {
               this.trackedTarget = var1;
               this.speedAcceleration = 0.0F;
               this.back = false;
               this.tickCounter = 0;
            }

            this.tickCounter++;
            this.jitterOffset = (float)((Math.sin(this.tickCounter * 0.17) * 0.12 + (Math.random() * 0.08 - 0.04)) * 0.7F);
            class_243 var2 = BestPoint.a(var1, 128.0);
            class_241 var3 = RotationUtils.b(var2);
            float var4 = var3.field_1343;
            float var5 = var3.field_1342;
            float var6 = Math.abs(class_3532.method_15393(var4 - this.lastYaw));
            boolean var7 = mc.field_1724.method_7261(1.0F) > 0.9F && this.aura.getTicksToAttack() <= 1;
            if (!this.back) {
               float var8 = 0.0055F;
               if (var6 > 60.0F) {
                  var8 += 0.028800001F;
               } else if (var6 > 30.0F) {
                  var8 += 0.014400001F;
               } else {
                  var8 += 0.0072000003F;
               }

               if (var7) {
                  var8 += 0.012857143F;
               }

               this.speedAcceleration = this.speedAcceleration + var8 * (1.6F + this.jitterOffset);
               if (this.speedAcceleration >= 0.22F) {
                  this.back = true;
               }
            } else {
               float var21 = var7 ? 0.045F : 0.008F;
               this.speedAcceleration = this.speedAcceleration - var21 * (2.1F + this.jitterOffset);
               if (this.speedAcceleration <= -0.04F) {
                  this.back = false;
               }
            }

            float var22 = class_3532.method_15363(this.speedAcceleration, 0.0F, mc.field_1724.method_6128() ? 0.38F : 0.26F);
            if (var7) {
               var22 = Math.min(var22 + 0.1F, mc.field_1724.method_6128() ? 0.46F : 0.34F);
            }

            float var23 = var22 + this.jitterOffset * 0.5F;
            if (this.tickCounter % 7 == 0) {
               var23 += 0.03F;
            }

            float var9 = class_3532.method_15393(var4 - this.lastYaw);
            float var10 = var5 - this.lastPitch;
            float var11 = mc.field_1724.method_6128() ? 42.0F : (var7 ? 28.0F : 20.0F);
            float var12 = mc.field_1724.method_6128() ? 12.0F : (var7 ? 4.5F : 2.8F);
            var9 = class_3532.method_15363(var9, -var11, var11);
            var10 = class_3532.method_15363(var10, -var12, var12);
            float var13 = var23 * 0.28F;
            float var14 = var23 * (0.85F + this.jitterOffset * 0.4F);
            float var15 = this.lastYaw + var9 * var14;
            float var16 = this.lastPitch + var10 * var13;
            float var17 = GCDUtil2.a();
            if (var17 > 0.0F) {
               var15 = this.lastYaw + Math.round((var15 - this.lastYaw) / var17) * var17;
               var16 = this.lastPitch + Math.round((var16 - this.lastPitch) / var17) * var17;
            }

            var16 = class_3532.method_15363(var16, -89.0F, 89.0F);
            Rotation2 var18 = new Rotation2(var15, var16);
            float var19 = mc.field_1724.method_6128() && var1.method_6128() ? 360.0F : 45.0F;
            RotationStorage.a(var18, var19, var19, var19, var19, 0, 1, Aura.clientLook.isEnabled());
            this.rotate = new class_241(var18.getYaw(), var18.getPitch());
            this.lastYaw = var18.getYaw();
            this.lastPitch = var18.getPitch();
         }
      }
   }

   private class_243 d(class_1309 var1) {
      class_243 var2 = BestPoint.b(var1);
      if (var2 == null) {
         var2 = var1.method_5829().method_1005();
      }

      return this.b(var1) ? this.a(var1, var2) : var2;
   }
}
