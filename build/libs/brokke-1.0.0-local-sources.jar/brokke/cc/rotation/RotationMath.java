package brokke.cc.rotation;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class RotationMath {
   private static final class_310 mc = class_310.method_1551();

   public static class_243 a(class_1309 var0) {
      if (mc.field_1724 != null && var0 != null) {
         class_243 var1 = mc.field_1724.method_33571();
         return new class_243(
            class_3532.method_15350(var1.field_1352, var0.method_5829().field_1323, var0.method_5829().field_1320),
            class_3532.method_15350(var1.field_1351, var0.method_5829().field_1322, var0.method_5829().field_1325),
            class_3532.method_15350(var1.field_1350, var0.method_5829().field_1321, var0.method_5829().field_1324)
         );
      } else {
         return class_243.field_1353;
      }
   }

   public static Rotation2 a(class_243 var0) {
      if (mc.field_1724 == null) {
         return Rotation2.ZERO;
      }

      double var1 = var0.method_10216();
      double var3 = var0.method_10214();
      double var5 = var0.method_10215();
      double var7 = var1 - mc.field_1724.method_23317();
      double var9 = var3 - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double var11 = var5 - mc.field_1724.method_23321();
      double var13 = Math.sqrt(var7 * var7 + var11 * var11);
      float var15 = (float)Math.toDegrees(Math.atan2(var11, var7)) - 90.0F;
      float var16 = (float)(-Math.toDegrees(Math.atan2(var9, var13)));
      return new Rotation2(var15, var16);
   }

   public static double a() {
      double var0 = mc.field_1690.method_42495().method_41753() * 0.6 + 0.2;
      double var2 = var0 * var0 * var0;
      return var2 * 8.0 * 0.15;
   }

   public static Rotation2 a(Rotation2 var0) {
      double var1 = a();
      float var3 = (float)(var0.getYaw() - var0.getYaw() % var1);
      float var4 = (float)(var0.getPitch() - var0.getPitch() % var1);
      return new Rotation2(var3, var4);
   }

   public static float a(float var0, float var1) {
      float var2 = var1 - var0;

      while (var2 > 180.0F) {
         var2 -= 360.0F;
      }

      while (var2 < -180.0F) {
         var2 += 360.0F;
      }

      return var2;
   }

   public static float b(float var0, float var1) {
      float var2 = var0 % 360.0F;
      if (var2 < 0.0F) {
         var2 += 360.0F;
      }

      float var3 = var1 % 360.0F;
      if (var3 < 0.0F) {
         var3 += 360.0F;
      }

      int var4 = (int)(var0 / 360.0F);
      if (var0 < 0.0F && var0 % 360.0F != 0.0F) {
         var4--;
      }

      float var5 = var3 + var4 * 360.0F;
      float var6 = var5 - var0;
      if (var6 > 180.0F) {
         var5 -= 360.0F;
      } else if (var6 < -180.0F) {
         var5 += 360.0F;
      }

      return var5;
   }

   private RotationMath() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
