package brokke.cc.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class MultipointUtils {
   private static final class_310 mc = class_310.method_1551();

   public static class_243 a(class_1297 var0) {
      if (mc.field_1724 != null && var0 != null) {
         class_238 var1 = var0.method_5829();
         class_243 var2 = mc.field_1724.method_33571();
         return new class_243(
            class_3532.method_15350(var2.field_1352, var1.field_1323, var1.field_1320), class_3532.method_15350(var2.field_1351, var1.field_1322, var1.field_1325), class_3532.method_15350(var2.field_1350, var1.field_1321, var1.field_1324)
         );
      } else {
         return var0 != null ? new class_243(var0.method_23317(), var0.method_23318() + var0.method_17682() * 0.5, var0.method_23321()) : class_243.field_1353;
      }
   }
}
