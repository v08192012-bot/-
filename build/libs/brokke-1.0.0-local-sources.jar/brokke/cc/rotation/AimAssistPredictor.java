package brokke.cc.rotation;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5134;

public class AimAssistPredictor {
   private final List<class_243> positions = new ArrayList<>();
   private final List<Long> timestamps = new ArrayList<>();
   private int trackedEntityId = -1;
   private class_243 predictedPosition = class_243.field_1353;
   private class_243 lastVelocity = class_243.field_1353;
   private class_243 acceleration = class_243.field_1353;

   public void a(class_1309 var1, float var2, int var3) {
      if (var1 == null) {
         this.c();
      } else {
         int var4 = var1.method_5628();
         if (var4 != this.trackedEntityId) {
            this.trackedEntityId = var4;
            this.c();
         }

         double var5 = var1.field_6038 + (var1.method_23317() - var1.field_6038) * var2;
         double var7 = var1.field_5971 + (var1.method_23318() - var1.field_5971) * var2;
         double var9 = var1.field_5989 + (var1.method_23321() - var1.field_5989) * var2;
         class_243 var11 = new class_243(var5, var7, var9);
         this.positions.add(var11);
         this.timestamps.add(System.currentTimeMillis());

         while (this.positions.size() > var3) {
            this.positions.remove(0);
            this.timestamps.remove(0);
         }

         this.d();
      }
   }

   private void d() {
      if (this.positions.size() < 2) {
         this.lastVelocity = class_243.field_1353;
         this.acceleration = class_243.field_1353;
      } else {
         ArrayList var1 = new ArrayList();

         for (int var2 = 1; var2 < this.positions.size(); var2++) {
            var1.add(this.positions.get(var2).method_1020(this.positions.get(var2 - 1)));
         }

         this.lastVelocity = (class_243)var1.get(var1.size() - 1);
         if (var1.size() >= 2) {
            ArrayList var9 = new ArrayList();

            for (int var3 = 1; var3 < var1.size(); var3++) {
               var9.add(((class_243)var1.get(var3)).method_1020((class_243)var1.get(var3 - 1)));
            }

            class_243 var10 = class_243.field_1353;
            double var4 = 0.0;

            for (int var6 = 0; var6 < var9.size(); var6++) {
               double var7 = Math.pow(0.85, var9.size() - 1 - var6);
               var10 = var10.method_1019(((class_243)var9.get(var6)).method_1021(var7));
               var4 += var7;
            }

            this.acceleration = var4 > 0.0 ? var10.method_1021(1.0 / var4) : class_243.field_1353;
         }
      }
   }

   public class_243 getLastVelocity() {
      return this.lastVelocity;
   }

   public class_243 getAcceleration() {
      return this.acceleration;
   }

   public class_243 a(class_1309 var1, int var2, float var3, boolean var4, boolean var5, int var6) {
      if (var1 != null && var2 > 0) {
         double var7 = var1.field_6038 + (var1.method_23317() - var1.field_6038) * var3;
         double var9 = var1.field_5971 + (var1.method_23318() - var1.field_5971) * var3;
         double var11 = var1.field_5989 + (var1.method_23321() - var1.field_5989) * var3;
         class_243 var13 = new class_243(var7, var9, var11);
         class_243 var14 = class_243.field_1353;
         if (var4 && this.positions.size() >= 3) {
            double var15 = var2 * 0.05;
            var14 = var14.method_1019(this.lastVelocity.method_1021(var2).method_1019(this.acceleration.method_1021(0.5 * var15 * var15)));
         }

         if (var5 && this.positions.size() >= 5) {
            class_243 var17 = this.a(var2, var6);
            if (var17 != null) {
               var14 = var14.method_1021(0.6).method_1019(var17.method_1021(0.4));
            }
         }

         class_243 var18 = this.a(var1, var2);
         if (var18 != null) {
            var14 = var14.method_1021(0.7).method_1019(var18.method_1021(0.3));
         }

         this.predictedPosition = var13.method_1019(var14);
         return this.predictedPosition;
      } else {
         return var1 != null ? new class_243(var1.method_23317(), var1.method_23318(), var1.method_23321()) : class_243.field_1353;
      }
   }

   private class_243 a(int var1, int var2) {
      int var3 = Math.min(this.positions.size(), var2);
      if (var3 < 5) {
         return null;
      }

      if (this.a(var3)) {
         return this.b(var1, var3);
      }

      if (this.c(var3)) {
         return this.lastVelocity.method_1021(var1);
      }

      class_243 var4 = class_243.field_1353;
      double var5 = 0.0;

      for (int var7 = 1; var7 < var3; var7++) {
         class_243 var8 = this.positions.get(var7).method_1020(this.positions.get(var7 - 1));
         double var9 = Math.pow(0.9, var3 - var7);
         var4 = var4.method_1019(var8.method_1021(var9));
         var5 += var9;
      }

      return var5 > 0.0 ? var4.method_1021(var1 / var5) : class_243.field_1353;
   }

   private boolean a(int var1) {
      if (var1 < 5) {
         return false;
      }

      ArrayList<Double> var2 = new ArrayList<>();

      for (int var3 = 2; var3 < var1; var3++) {
         class_243 var4 = this.positions.get(var3 - 1).method_1020(this.positions.get(var3 - 2));
         class_243 var5 = this.positions.get(var3).method_1020(this.positions.get(var3 - 1));
         double var6 = Math.atan2(var5.field_1350, var5.field_1352) - Math.atan2(var4.field_1350, var4.field_1352);
         var2.add(Math.abs(a(var6)));
      }

      double var8 = var2.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
      double var9 = var2.stream().mapToDouble(var2x -> Math.pow(var2x - var8, 2.0)).average().orElse(1.0);
      return var9 < 0.1 && var8 > 0.05;
   }

   private class_243 b(int var1, int var2) {
      class_243 var3 = this.b(var2);
      class_243 var4 = this.positions.get(var2 - 1);
      class_243 var5 = this.positions.get(var2 - 2);
      double var6 = Math.atan2(var4.field_1350 - var3.field_1350, var4.field_1352 - var3.field_1352);
      double var8 = Math.atan2(var5.field_1350 - var3.field_1350, var5.field_1352 - var3.field_1352);
      double var10 = a(var6 - var8);
      double var12 = var4.method_1020(var3).method_37267();
      double var14 = var6 + var10 * var1;
      double var16 = var3.field_1352 + var12 * Math.cos(var14);
      double var18 = var3.field_1350 + var12 * Math.sin(var14);
      double var20 = var4.field_1351 + this.lastVelocity.field_1351 * var1;
      return new class_243(var16 - var4.field_1352, var20 - var4.field_1351, var18 - var4.field_1350);
   }

   private class_243 b(int var1) {
      if (var1 < 3) {
         return this.positions.get(var1 - 1);
      }

      class_243 var2 = this.positions.get(var1 - 3);
      class_243 var3 = this.positions.get(var1 - 2);
      class_243 var4 = this.positions.get(var1 - 1);
      double var5 = 2.0 * (var2.field_1352 * (var3.field_1350 - var4.field_1350) + var3.field_1352 * (var4.field_1350 - var2.field_1350) + var4.field_1352 * (var2.field_1350 - var3.field_1350));
      if (Math.abs(var5) < 0.001) {
         return var3;
      }

      double var7 = (
            (var2.field_1352 * var2.field_1352 + var2.field_1350 * var2.field_1350) * (var3.field_1350 - var4.field_1350)
               + (var3.field_1352 * var3.field_1352 + var3.field_1350 * var3.field_1350) * (var4.field_1350 - var2.field_1350)
               + (var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350) * (var2.field_1350 - var3.field_1350)
         )
         / var5;
      double var9 = (
            (var2.field_1352 * var2.field_1352 + var2.field_1350 * var2.field_1350) * (var4.field_1352 - var3.field_1352)
               + (var3.field_1352 * var3.field_1352 + var3.field_1350 * var3.field_1350) * (var2.field_1352 - var4.field_1352)
               + (var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350) * (var3.field_1352 - var2.field_1352)
         )
         / var5;
      return new class_243(var7, var3.field_1351, var9);
   }

   private boolean c(int var1) {
      if (var1 < 3) {
         return false;
      }

      class_243 var2 = this.positions.get(var1 - 1).method_1020(this.positions.get(var1 - 2));
      class_243 var3 = this.positions.get(var1 - 2).method_1020(this.positions.get(var1 - 3));
      double var4 = var2.method_1033() * var3.method_1033() + 0.001;
      double var6 = var2.method_1026(var3);
      double var8 = Math.acos(class_3532.method_15350(var6 / var4, -1.0, 1.0));
      return var8 < 0.15;
   }

   private class_243 a(class_1309 var1, int var2) {
      if (var1 instanceof class_1657 var3) {
         double var4 = var3.method_18798().field_1352;
         double var6 = var3.method_18798().field_1351;
         double var8 = var3.method_18798().field_1350;
         boolean var10 = var3.method_24828();
         class_243 var11 = class_243.field_1353;

         for (int var12 = 0; var12 < var2; var12++) {
            var6 -= 0.08;
            if (var10) {
               var4 *= 0.546;
               var8 *= 0.546;
            } else {
               var4 *= 0.98;
               var8 *= 0.98;
            }

            var11 = var11.method_1031(var4, var6, var8);
            if (var11.field_1351 < var1.method_23318() - var1.method_17682()) {
               var10 = true;
               var6 = 0.0;
            }
         }

         return var11;
      } else {
         return null;
      }
   }

   public static void a(double[] var0, double var1, double var3, float var5, class_1309 var6, boolean var7, float var8, int var9) {
      double var10 = b(var6);
      double var12 = var6.method_18798().field_1352;
      double var14 = var6.method_18798().field_1351;
      double var16 = var6.method_18798().field_1350;
      boolean var18 = var6.method_24828();
      double var19 = var1 - var6.method_23317();
      double var21 = var3 - var6.method_23321();
      double var23 = Math.sqrt(var19 * var19 + var21 * var21);
      if (var23 > 0.001) {
         var19 /= var23;
         var21 /= var23;
      } else {
         double var25 = Math.toRadians(var5);
         var19 = -Math.sin(var25);
         var21 = Math.cos(var25);
      }

      double var42 = 0.4 * (1.0 - var10);
      double var36 = var12 / 2.0 - var19 * var42;
      double var37 = var18 ? Math.min(0.4, var14 / 2.0 + var42) : var14;
      double var39 = var16 / 2.0 - var21 * var42;
      float var27 = var8 + (var7 ? 1.0F : 0.0F);
      if (var27 > 0.0F) {
         double var28 = var27 * 0.5 * (1.0 - var10);
         double var30 = Math.toRadians(var5);
         double var32 = Math.sin(var30);
         double var34 = -Math.cos(var30);
         var36 = var36 / 2.0 - var32 * var28;
         var37 = var18 ? Math.min(0.4, var37 / 2.0 + var28) : var37;
         var39 = var39 / 2.0 - var34 * var28;
      }

      double var43 = 0.0;
      double var44 = 0.0;
      double var45 = 0.0;

      for (int var46 = 0; var46 < var9; var46++) {
         var43 += var36;
         var44 += var14 = var37 - 0.08;
         var45 += var39;
         var36 *= 0.91;
         var37 = var14 * 0.98;
         var39 *= 0.91;
         if (var44 < 0.0) {
            var44 = 0.0;
            var37 = 0.0;
         }
      }

      var0[0] = var43;
      var0[1] = var44;
      var0[2] = var45;
   }

   public static float a(class_1309 var0) {
      try {
         return (float)var0.method_45325(class_5134.field_23722);
      } catch (Exception var2) {
         return 0.0F;
      }
   }

   public static double b(class_1309 var0) {
      try {
         return Math.min(var0.method_45325(class_5134.field_23718), 1.0);
      } catch (Exception var2) {
         return 0.0;
      }
   }

   private static double a(double var0) {
      double var2 = var0 % (Math.PI * 2);
      if (var2 < -Math.PI) {
         var2 += Math.PI * 2;
      }

      if (var2 > Math.PI) {
         var2 -= Math.PI * 2;
      }

      return var2;
   }

   public void c() {
      this.positions.clear();
      this.timestamps.clear();
      this.trackedEntityId = -1;
      this.predictedPosition = class_243.field_1353;
      this.lastVelocity = class_243.field_1353;
      this.acceleration = class_243.field_1353;
   }
}
