package brokke.cc.rotation;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_640;
import net.minecraft.class_746;

public final class HolyWorldElytraPredictor {
   private static final int HORIZON_STEPS = 11;
   private static final float MAX_PITCH_DELTA = 90.0F;
   private static final int SAMPLE_COUNT = 24;
   private static final double SAMPLE_STEP = 2.0;
   private final HolyWorldTrajectoryPlanner planner = new HolyWorldTrajectoryPlanner(11);
   private final HolyWorldTerrainProfile profile = new HolyWorldTerrainProfile(24, 2.0);
   private final HolyWorldElytraPhysics.a state = new HolyWorldElytraPhysics.a();
   private boolean jumpRequested;
   private boolean sprintRequested;
   private boolean active;
   private boolean prevJump;
   private boolean inputJump;
   private int glideCooldown;
   private float targetPitch = 0.0F;

   public boolean isActive() {
      return this.active;
   }

   public boolean isJumpRequested() {
      return this.jumpRequested;
   }

   public boolean isSprintRequested() {
      return this.sprintRequested;
   }

   public float getTargetPitch() {
      return this.targetPitch;
   }

   public void e() {
      this.active = false;
      this.jumpRequested = false;
      this.sprintRequested = false;
      this.glideCooldown = 0;
      this.prevJump = false;
      this.inputJump = false;
   }

   public void a(class_310 var1) {
      this.active = false;
      this.jumpRequested = false;
      this.sprintRequested = false;
      class_746 var2 = var1.field_1724;
      if (var2 != null && var1.field_1687 != null && var2.field_3944 != null) {
         if (!this.a(var1, var2)) {
            this.prevJump = false;
            this.inputJump = false;
         } else {
            boolean var3 = var2.method_6128();
            boolean var4 = var2.method_24828();
            if (var3) {
               this.glideCooldown = 10;
            } else if (this.glideCooldown > 0) {
               this.glideCooldown--;
            }

            if (!var2.field_3913.method_20622()) {
               this.prevJump = false;
               this.inputJump = false;
            } else {
               boolean var5 = var4 || !var3 && this.a(var2);
               boolean var6 = this.inputJump ? this.prevJump : var1.field_1690.field_1903.method_1434();
               this.active = true;
               this.inputJump = true;
               this.jumpRequested = var5 && !var6;
               this.sprintRequested = true;
               this.prevJump = this.jumpRequested;
               if (var3 || this.glideCooldown > 0) {
                  this.a(var1, var2, var3, var4);
               }
            }
         }
      }
   }

   private void a(class_310 var1, class_746 var2, boolean var3, boolean var4) {
      double var5 = Math.toRadians(var2.method_36454());
      double var7 = -Math.sin(var5);
      double var9 = Math.cos(var5);
      this.a(var1, var2, var7, var9);
      this.a(var2, var3, var4, var7, var9);
      float var11 = var2.method_36455();
      int var12 = this.b(var1);
      float var13 = this.planner.a(this.state, var11, 90.0F, this.profile, var12);
      this.targetPitch = class_3532.method_15363(var13, -90.0F, 90.0F);
   }

   private void a(class_746 var1, boolean var2, boolean var3, double var4, double var6) {
      class_243 var8 = var1.method_18798();
      this.state.posX = 0.0;
      this.state.posY = var1.method_23318();
      this.state.motionX = Math.max(0.0, var8.field_1352 * var4 + var8.field_1350 * var6);
      this.state.motionY = var8.field_1351;
      this.state.isGliding = var2;
      this.state.onGround = var3;
      this.state.hasJumped = this.prevJump;
      this.state.fallCooldown = -1;
   }

   private void a(class_310 var1, class_746 var2, double var3, double var5) {
      this.profile.a();
      class_243 var7 = var2.method_73189();

      for (int var8 = 0; var8 < this.profile.b(); var8++) {
         double var9 = var8 * this.profile.getStepSize();
         double var11 = var7.field_1352 + var3 * var9;
         double var13 = var7.field_1350 + var5 * var9;
         this.profile.a(this.a(var1, var2, var11, var7.field_1351, var13));
      }
   }

   private double a(class_310 var1, class_746 var2, double var3, double var5, double var7) {
      double var9 = this.a(var1, var2, var3, var5 + 2.5, var7, 32.0);
      if (!Double.isNaN(var9)) {
         return var9;
      }

      if (var1.field_1687.method_8320(class_2338.method_49637(var3, var5 + 2.5, var7)).method_26215()) {
         return -4096.0;
      }

      double var11 = this.a(var1, var2, var3, var5 + 24.0, var7, 21.5);
      return Double.isNaN(var11) ? var5 + 24.0 : var11;
   }

   private double a(class_310 var1, class_746 var2, double var3, double var5, double var7, double var9) {
      class_243 var11 = new class_243(var3, var5, var7);
      class_243 var12 = var11.method_1031(0.0, -var9, 0.0);
      class_3965 var13 = var1.field_1687.method_17742(new class_3959(var11, var12, class_3960.field_17558, class_242.field_1347, var2));
      return var13.method_17783() == class_240.field_1333 ? Double.NaN : var13.method_17784().field_1351;
   }

   private int b(class_310 var1) {
      if (var1.method_1562() != null && var1.field_1724 != null) {
         class_640 var2 = var1.method_1562().method_2871(var1.field_1724.method_5667());
         if (var2 != null) {
            return class_3532.method_15340(1 + var2.method_2959() / 50, 1, 6);
         }
      }

      return 2;
   }

   private boolean a(class_310 var1, class_746 var2) {
      return var1.field_1755 == null
         && !var2.method_7325()
         && !var2.method_5765()
         && !var2.method_6101()
         && !var2.method_5799()
         && !var2.method_5771()
         && !var2.method_31549().field_7479
         && this.b(var2);
   }

   private boolean a(class_746 var1) {
      return !var1.method_24828() && !var1.method_5799() && this.b(var1);
   }

   private boolean b(class_746 var1) {
      for (class_1304 var3 : class_1304.field_54086) {
         class_1799 var4 = var1.method_6118(var3);
         if (class_1309.method_63624(var4, var3)) {
            return true;
         }
      }

      return false;
   }
}
