package brokke.cc.rotation;

import brokke.cc.util.GCDUtil2;
import net.minecraft.class_1297;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.jetbrains.annotations.NotNull;

public class RotationUtils {
   private static final class_310 mc = class_310.method_1551();

   public static class_239 a(double var0, float var2, float var3) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 var4 = mc.field_1724.method_5836(1.0F);
         class_243 var5 = a(var3, var2);
         class_243 var6 = var4.method_1031(var5.field_1352 * var0, var5.field_1351 * var0, var5.field_1350 * var0);
         return mc.field_1687.method_17742(new class_3959(var4, var6, class_3960.field_17559, class_242.field_1348, mc.field_1724));
      } else {
         return null;
      }
   }

   public static class_243 a(class_1297 var0) {
      if (mc.field_1724 == null) {
         return new class_243(var0.method_23317(), var0.method_23318() + var0.method_17682() * 0.5, var0.method_23321());
      }

      class_243 var1 = mc.field_1724.method_33571();
      class_238 var2 = var0.method_5829();
      double var3 = 0.1;
      class_243 var5 = null;
      double var6 = Double.MAX_VALUE;

      for (double var8 = var2.field_1323; var8 <= var2.field_1320; var8 += var3) {
         for (double var10 = var2.field_1322; var10 <= var2.field_1325; var10 += var3) {
            for (double var12 = var2.field_1321; var12 <= var2.field_1324; var12 += var3) {
               class_243 var14 = new class_243(var8, var10, var12);
               double var15 = var1.method_1022(var14);
               if (var15 < var6) {
                  var6 = var15;
                  var5 = var14;
               }
            }
         }
      }

      return var5 != null ? var5 : new class_243(var0.method_23317(), var0.method_23318() + var0.method_17682() * 0.5, var0.method_23321());
   }

   public static Rotation2 a(class_243 var0) {
      return new Rotation2(
         (float)class_3532.method_15338(Math.toDegrees(Math.atan2(var0.field_1350, var0.field_1352)) - 90.0),
         (float)class_3532.method_15338(Math.toDegrees(-Math.atan2(var0.field_1351, Math.hypot(var0.field_1352, var0.field_1350))))
      );
   }

   @NotNull
   public static class_243 a(float var0, float var1) {
      return new class_243(
         class_3532.method_15374(-var1 * (float) (Math.PI / 180.0)) * class_3532.method_15362(var0 * (float) (Math.PI / 180.0)),
         -class_3532.method_15374(var0 * (float) (Math.PI / 180.0)),
         class_3532.method_15362(-var1 * (float) (Math.PI / 180.0)) * class_3532.method_15362(var0 * (float) (Math.PI / 180.0))
      );
   }

   public static class_241 b(class_1297 var0) {
      return a(var0.method_23317(), var0.method_23318(), var0.method_23321());
   }

   public static class_241 b(class_243 var0) {
      return a(var0.field_1352, var0.field_1351, var0.field_1350);
   }

   public static class_241 a(double var0, double var2, double var4) {
      if (mc.field_1724 == null) {
         return new class_241(0.0F, 0.0F);
      }

      double var6 = var0 - mc.field_1724.method_23317();
      double var8 = var2 - mc.field_1724.method_23320();
      double var10 = var4 - mc.field_1724.method_23321();
      double var12 = class_3532.method_15355((float)(var6 * var6 + var10 * var10));
      float var14 = (float)(class_3532.method_15349(var10, var6) * (180.0 / Math.PI) - 90.0);
      float var15 = (float)(-class_3532.method_15349(var8, var12) * (180.0 / Math.PI));
      return new class_241(var14, var15);
   }

   public static float[] a(class_2350 var0) {
      if (mc.field_1724 == null) {
         return new float[]{0.0F, 0.0F};
      }

      return switch (var0) {
         case field_11033 -> new float[]{mc.field_1724.method_36454(), 90.0F};
         case field_11036 -> new float[]{mc.field_1724.method_36454(), -90.0F};
         case field_11043 -> new float[]{180.0F, mc.field_1724.method_36455()};
         case field_11035 -> new float[]{0.0F, mc.field_1724.method_36455()};
         case field_11039 -> new float[]{90.0F, mc.field_1724.method_36455()};
         case field_11034 -> new float[]{-90.0F, mc.field_1724.method_36455()};
      };
   }

   public static float[] a(float[] var0) {
      float var1 = GCDUtil2.a();
      var0[0] -= var0[0] % var1;
      var0[1] -= var0[1] % var1;
      return new float[]{var0[0], var0[1]};
   }

   public static float a(float var0) {
      return b(var0) * GCDUtil2.a();
   }

   public static float b(float var0) {
      return Math.round(var0 / GCDUtil2.a());
   }
}
