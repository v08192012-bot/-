package brokke.cc.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationUtil {
   private static final class_310 mc = class_310.method_1551();

   public static float[] a(class_1297 var0) {
      if (mc.field_1724 != null && var0 != null) {
         class_243 var1 = mc.field_1724.method_33571();
         class_243 var2 = var0.method_73189().method_1031(0.0, var0.method_17682() / 2.0, 0.0);
         double var3 = var2.field_1352 - var1.field_1352;
         double var5 = var2.field_1351 - var1.field_1351;
         double var7 = var2.field_1350 - var1.field_1350;
         double var9 = Math.sqrt(var3 * var3 + var7 * var7);
         float var11 = (float)(Math.toDegrees(Math.atan2(var7, var3)) - 90.0);
         float var12 = (float)(-Math.toDegrees(Math.atan2(var5, var9)));
         return new float[]{var11, var12};
      } else {
         return new float[]{0.0F, 0.0F};
      }
   }

   public static float[] a(double var0, double var2, double var4) {
      if (mc.field_1724 == null) {
         return new float[]{0.0F, 0.0F};
      }

      class_243 var6 = mc.field_1724.method_33571();
      double var7 = var0 - var6.field_1352;
      double var9 = var2 - var6.field_1351;
      double var11 = var4 - var6.field_1350;
      double var13 = Math.sqrt(var7 * var7 + var11 * var11);
      float var15 = (float)(Math.toDegrees(Math.atan2(var11, var7)) - 90.0);
      float var16 = (float)(-Math.toDegrees(Math.atan2(var9, var13)));
      return new float[]{var15, var16};
   }

   public static float a(float var0, float var1) {
      return class_3532.method_15393(var0 - var1);
   }

   public static float b(float var0, float var1) {
      float var2 = class_3532.method_15393(var1 - var0);
      return var0 + var2;
   }
}
