package brokke.cc.rotation;

import brokke.cc.core.FreeLookStorage;
import brokke.cc.module.combat.Aura;
import brokke.cc.nav.BestPoint;
import brokke.cc.util.GCDUtil2;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1309;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class ReallyWorldRotation extends RotationsSystem {
   private class_1309 trackedTarget;
   private float currentYaw;
   private float currentPitch;
   private boolean initialized;
   private int ticks;

   public void a() {
      this.trackedTarget = null;
      this.ticks = 0;
      this.initialized = false;
      if (mc.field_1724 != null) {
         this.currentYaw = FreeLookStorage.isActive() ? FreeLookStorage.getFreeYaw() : mc.field_1724.method_36454();
         this.currentPitch = FreeLookStorage.isActive() ? FreeLookStorage.getFreePitch() : mc.field_1724.method_36455();
      }
   }

   public void b() {
      this.ticks = 0;
   }

   @Override
   public void a(class_1309 var1) {
      if (mc.field_1724 != null && var1 != null) {
         if (!this.initialized) {
            this.currentYaw = FreeLookStorage.isActive() ? FreeLookStorage.getFreeYaw() : mc.field_1724.method_36454();
            this.currentPitch = FreeLookStorage.isActive() ? FreeLookStorage.getFreePitch() : mc.field_1724.method_36455();
            this.initialized = true;
         }

         if (this.trackedTarget != var1) {
            this.trackedTarget = var1;
            this.ticks = 0;
         }

         this.ticks++;
         class_243 var2 = BestPoint.a(var1, 128.0);
         if (var2 == null) {
            var2 = var1.method_73189().method_1031(0.0, var1.method_17682() * 0.5, 0.0);
         }

         var2 = this.a(var1, var2);
         class_241 var3 = RotationUtils.b(var2);
         float var4 = var3.field_1343;
         float var5 = var3.field_1342;
         float var6 = class_3532.method_15393(var4 - this.currentYaw);
         float var7 = var5 - this.currentPitch;
         float var8 = (float)Math.hypot(Math.abs(var6), Math.abs(var7));
         ThreadLocalRandom var9 = ThreadLocalRandom.current();
         float var10 = (float)(Math.sin(this.ticks * 0.35) * 0.15 + (var9.nextDouble() - 0.5) * 0.12);
         float var11 = (float)(Math.cos(this.ticks * 0.28) * 0.12 + (var9.nextDouble() - 0.5) * 0.08);
         float var12 = var8 > 60.0F ? 180.0F : (var8 > 25.0F ? 130.0F : 90.0F);
         float var13 = (float)(0.85 + var9.nextDouble() * 0.3);
         float var14 = Math.min(var8, var12 * var13);
         float var15 = var8 > 0.001F ? var6 / var8 * var14 : 0.0F;
         float var16 = var8 > 0.001F ? var7 / var8 * var14 : 0.0F;
         this.currentYaw = this.currentYaw + GCDUtil2.a(var15 + var10);
         this.currentPitch = class_3532.method_15363(this.currentPitch + GCDUtil2.a(var16 + var11), -90.0F, 90.0F);
         this.rotate = new class_241(this.currentYaw, this.currentPitch);
         RotationStorage.a(new Rotation2(this.currentYaw, this.currentPitch), 360.0F, 360.0F, 360.0F, 360.0F, 1, 5, Aura.clientLook.isEnabled());
      } else {
         this.a();
      }
   }
}
