package brokke.cc.rotation;

import brokke.cc.module.combat.AimAssist;
import brokke.cc.module.combat.Aura;
import net.minecraft.class_1309;
import net.minecraft.class_746;
import brokke.cc.module.FunctionManager;

public class LegitRotation extends RotationsSystem {
   private class_1309 target;
   private long lastTargetStamp;

   @Override
   public void a(class_1309 var1) {
      this.target = var1;
      this.lastTargetStamp = System.nanoTime();
   }

   public void a() {
      this.target = null;
   }

   public class_1309 b() {
      return this.c();
   }

   private class_1309 c() {
      if (this.target != null && this.target.method_5805() && !this.target.method_31481()) {
         return System.nanoTime() - this.lastTargetStamp > 400000000L ? null : this.target;
      } else {
         return null;
      }
   }

   public double[] a(class_746 var1, double var2, double var4) {
      Aura var6 = Aura.INSTANCE;
      if (var6 != null && var6.l() && var6.rotationType.isSelected("Legit")) {
         class_1309 var7 = var6.getTarget();
         if (var7 == null || !var7.method_5805() || var7.method_31481()) {
            var7 = this.c();
         }

         AimAssist var8 = FunctionManager.a(AimAssist.class);
         if ((var7 == null || !var7.method_5805() || var7.method_31481()) && var8 != null) {
            var7 = var8.l();
         }

         if (var7 == null || !var7.method_5805() || var7.method_31481()) {
            return new double[]{var2, var4};
         } else if (var8 != null) {
            float var9 = 0.6F;
            return var8.a(var1, var2, var4, var7, var9);
         } else {
            return new double[]{var2, var4};
         }
      } else {
         return new double[]{var2, var4};
      }
   }

   public double a(class_746 var1, double var2) {
      return this.a(var1, var2, 0.0)[0];
   }
}
