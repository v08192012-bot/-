package brokke.cc.rotation;

import brokke.cc.module.combat.Aura;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_1821;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import brokke.cc.module.ModuleClass;

public final class IdealHitUtils {
   private static final class_310 mc = class_310.method_1551();
   private static final int WATER_CRIT_INTENT_TICKS = 8;
   private static final int WATER_CRIT_CONTACT_TICKS = 10;
   private static final double WATER_CRIT_MIN_UPWARD_VELOCITY = 0.05;
   private static int lastWaterContactAge = Integer.MIN_VALUE;
   private static int lastWaterCritIntentAge = Integer.MIN_VALUE;
   private static int lastAirAge = Integer.MIN_VALUE;
   private static int lastGroundAge = Integer.MIN_VALUE;

   private IdealHitUtils() {
   }

   public static float a() {
      if (mc.field_1724 == null) {
         return 1.0F;
      } else if (mc.field_1724.method_6047().method_7909() == class_1802.field_8162) {
         return 1.0F;
      } else {
         return !(mc.field_1724.method_6047().method_7909() instanceof class_1743) && !(mc.field_1724.method_6047().method_7909() instanceof class_1821) ? 0.98F : 1.0F;
      }
   }

   public static boolean a(class_1309 var0) {
      Aura var1 = Aura.INSTANCE;
      boolean var2 = var1 != null && var1.smartCrit.isEnabled();
      return a(var0, var2);
   }

   public static boolean a(class_1309 var0, boolean var1) {
      if (mc.field_1724 == null) {
         return false;
      } else if (!var1) {
         return true;
      } else {
         i();
         b();
         boolean var2 = ModuleClass.packetCriticals != null && ModuleClass.packetCriticals.a();
         boolean var3 = h();
         boolean var4 = mc.field_1724.method_6059(class_1294.field_5906);
         if (var2 && var3) {
            return true;
         } else if (var2 && var4) {
            return mc.field_1724.method_18798().field_1351 < 0.0 && mc.field_1724.field_6017 > 0.0;
         } else if (d()) {
            return true;
         } else if (k()) {
            return l();
         } else if (mc.field_1724.method_6128() || mc.field_1724.method_31549().field_7479) {
            return true;
         } else if (g()) {
            return true;
         } else {
            return c() ? e() : mc.field_1724.method_24828();
         }
      }
   }

   public static void b() {
      if (mc.field_1724 == null) {
         lastAirAge = Integer.MIN_VALUE;
         lastGroundAge = Integer.MIN_VALUE;
      } else {
         if (lastAirAge > mc.field_1724.field_6012 || lastGroundAge > mc.field_1724.field_6012) {
            lastAirAge = Integer.MIN_VALUE;
            lastGroundAge = Integer.MIN_VALUE;
         }

         if (mc.field_1724.method_24828()) {
            lastGroundAge = mc.field_1724.field_6012;
         } else {
            lastAirAge = mc.field_1724.field_6012;
         }
      }
   }

   public static boolean c() {
      if (mc.field_1724 == null) {
         return false;
      } else if (!mc.field_1724.method_24828()) {
         return true;
      } else {
         return mc.field_1690 != null && mc.field_1690.field_1903.method_1434() ? true : lastAirAge != Integer.MIN_VALUE && mc.field_1724.field_6012 - lastAirAge < 3;
      }
   }

   public static boolean d() {
      if (mc.field_1724 == null) {
         return false;
      }

      if (mc.field_1724.method_5799() || mc.field_1724.method_5869()) {
         return true;
      }

      if (mc.field_1687 == null) {
         return false;
      }

      class_2338 var0 = class_2338.method_49638(mc.field_1724.method_33571());
      class_2338 var1 = class_2338.method_49638(mc.field_1724.method_73189());
      class_2338 var2 = class_2338.method_49638(mc.field_1724.method_73189().method_1031(0.0, -0.4, 0.0));
      return mc.field_1687.method_8320(var1).method_27852(class_2246.field_10382)
         || mc.field_1687.method_8320(var0).method_27852(class_2246.field_10382)
         || mc.field_1687.method_8320(var2).method_27852(class_2246.field_10382);
   }

   public static boolean e() {
      if (mc.field_1724 == null) {
         return false;
      } else if (mc.field_1724.method_24828()) {
         return false;
      } else if (mc.field_1724.method_5799() || mc.field_1724.method_5869()) {
         return false;
      } else if (mc.field_1724.method_5771() || mc.field_1724.method_6101() || mc.field_1724.method_5765() || mc.field_1724.method_31549().field_7479) {
         return false;
      } else if (mc.field_1724.method_6059(class_1294.field_5919) || mc.field_1724.method_6059(class_1294.field_5902)) {
         return false;
      } else if (mc.field_1724.method_6128()) {
         return false;
      } else {
         return h() ? false : mc.field_1724.field_6017 > 0.0 && mc.field_1724.method_18798().field_1351 < 0.0;
      }
   }

   public static boolean f() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_238 var0 = mc.field_1724.method_5829().method_1011(0.03);
         class_238 var1 = new class_238(var0.field_1323, var0.field_1325, var0.field_1321, var0.field_1320, var0.field_1325 + 0.5, var0.field_1324);

         for (class_2338 var3 : class_2338.method_10094(
            class_3532.method_15357(var1.field_1323),
            class_3532.method_15357(var1.field_1322),
            class_3532.method_15357(var1.field_1321),
            class_3532.method_15357(var1.field_1320),
            class_3532.method_15357(var1.field_1325),
            class_3532.method_15357(var1.field_1324)
         )) {
            class_2680 var4 = mc.field_1687.method_8320(var3);
            if (!var4.method_26215() && !var4.method_26220(mc.field_1687, var3).method_1110()) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static void i() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         boolean var0 = m();
         if (var0) {
            lastWaterContactAge = mc.field_1724.field_6012;
            if (j()) {
               lastWaterCritIntentAge = mc.field_1724.field_6012;
            }
         }
      } else {
         lastWaterContactAge = Integer.MIN_VALUE;
         lastWaterCritIntentAge = Integer.MIN_VALUE;
      }
   }

   private static boolean j() {
      return mc.field_1724 != null && mc.field_1690 != null
         ? mc.field_1690.field_1903.method_1434() && !mc.field_1724.method_24828() && !mc.field_1724.method_5869() && mc.field_1724.method_18798().field_1351 > 0.05
         : false;
   }

   private static boolean k() {
      return mc.field_1724 != null && mc.field_1690 != null && mc.field_1690.field_1903.method_1434()
         ? mc.field_1724.field_6012 - lastWaterCritIntentAge <= 8 && mc.field_1724.field_6012 - lastWaterContactAge <= 10
         : false;
   }

   private static boolean l() {
      return mc.field_1724 != null
         && !mc.field_1724.method_24828()
         && !mc.field_1724.method_5799()
         && !mc.field_1724.method_5869()
         && mc.field_1724.field_6017 > 0.0
         && mc.field_1724.method_18798().field_1351 < 0.0;
   }

   private static boolean m() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var0 = class_2338.method_49638(mc.field_1724.method_73189().method_1031(0.0, -0.4, 0.0));
         return mc.field_1724.method_5799() || mc.field_1724.method_5869() || mc.field_1687.method_8320(var0).method_27852(class_2246.field_10382);
      } else {
         return false;
      }
   }

   public static boolean g() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var0 = class_2338.method_49638(mc.field_1724.method_73189().method_1031(0.0, mc.field_1724.method_17682() / 2.0F, 0.0));
         return mc.field_1724.method_5771()
            || mc.field_1724.method_6101()
            || mc.field_1687.method_8320(var0).method_27852(class_2246.field_10382)
            || mc.field_1724.method_6059(class_1294.field_5902)
            || mc.field_1724.method_6059(class_1294.field_5906)
            || mc.field_1724.method_6059(class_1294.field_5919)
            || h()
            || mc.field_1724.method_6128()
            || mc.field_1724.method_5765()
            || mc.field_1724.method_31549().field_7479
            || mc.field_1724.method_5799() && !k()
            || f();
      } else {
         return true;
      }
   }

   public static boolean h() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_238 var0 = mc.field_1724.method_5829();

         for (class_2338 var2 : class_2338.method_10094(
            class_3532.method_15357(var0.field_1323),
            class_3532.method_15357(var0.field_1322),
            class_3532.method_15357(var0.field_1321),
            class_3532.method_15357(var0.field_1320),
            class_3532.method_15357(var0.field_1325),
            class_3532.method_15357(var0.field_1324)
         )) {
            if (mc.field_1687.method_8320(var2).method_27852(class_2246.field_10343)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }
}
