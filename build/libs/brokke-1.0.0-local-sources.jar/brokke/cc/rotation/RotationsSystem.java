package brokke.cc.rotation;

import brokke.cc.util.GCDUtil2;
import brokke.cc.util.PredictUtils;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;

public abstract class RotationsSystem {
   protected static final class_310 mc = class_310.method_1551();
   public class_241 rotate = class_241.field_1340;

   public abstract void a(class_1309 var1);

   public static class_241 a(float var0, float var1) {
      if (mc.field_1724 != null && (var0 == -90.0F && var1 == 90.0F || var0 == -180.0F)) {
         return new class_241(mc.field_1724.method_36454(), mc.field_1724.method_36455());
      }

      float var2 = GCDUtil2.b();
      var0 -= var0 % var2;
      var1 -= var1 % var2;
      return new class_241(var0, var1);
   }

   protected boolean b(class_1309 var1) {
      return mc.field_1724 != null && var1 != null && mc.field_1724.method_6128() && var1.method_6128();
   }

   protected class_243 a(class_1309 var1, class_243 var2) {
      return !this.b(var1) ? var2 : PredictUtils.c(var1);
   }

   protected class_238 c(class_1309 var1) {
      class_238 var2 = var1.method_5829();
      if (!this.b(var1)) {
         return var2;
      }

      class_243 var3 = var2.method_1005();
      class_243 var4 = this.a(var1, var3);
      return var2.method_997(var4.method_1020(var3));
   }
}
