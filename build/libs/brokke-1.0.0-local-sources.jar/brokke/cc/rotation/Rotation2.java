package brokke.cc.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5611;

public class Rotation2 {
   private static final class_310 mc = class_310.method_1551();
   public static final Rotation2 ZERO = new Rotation2(0.0F, 0.0F);
   private float yaw;
   private float pitch;

   public Rotation2() {
      this(0.0F, 0.0F);
   }

   public Rotation2(float var1, float var2) {
      this.yaw = var1;
      this.pitch = var2;
   }

   public Rotation2(class_1297 var1) {
      this(var1.method_36454(), var1.method_36455());
   }

   public float a(Rotation2 var1) {
      float var2 = class_3532.method_15393(var1.getYaw() - this.yaw);
      float var3 = var1.getPitch() - this.pitch;
      return (float)Math.hypot(Math.abs(var2), Math.abs(var3));
   }

   public double b(Rotation2 var1) {
      double var2 = class_3532.method_15393(var1.getYaw() - this.yaw);
      double var4 = class_3532.method_15393(var1.getPitch() - this.pitch);
      return Math.hypot(var2, var4);
   }

   public Rotation2 c(Rotation2 var1) {
      float var2 = class_3532.method_15393(this.yaw - var1.yaw);
      float var3 = class_3532.method_15393(this.pitch - var1.pitch);
      return new Rotation2(var2, var3);
   }

   public float d(Rotation2 var1) {
      float var2 = class_3532.method_15393(this.yaw - var1.yaw);
      float var3 = class_3532.method_15393(this.pitch - var1.pitch);
      return Math.abs(var2) + Math.abs(var3);
   }

   public static class_5611 a() {
      return new class_5611(b(), c());
   }

   public static float b() {
      return mc.field_1773 != null && mc.field_1773.method_19418() != null
         ? class_3532.method_15393(mc.field_1773.method_19418().method_19330() + (mc.field_1773.method_19418().method_19333() ? 180 : 0))
         : 0.0F;
   }

   public static float c() {
      return mc.field_1773 != null && mc.field_1773.method_19418() != null
         ? (mc.field_1773.method_19418().method_19333() ? -1 : 1) * mc.field_1773.method_19418().method_19329()
         : 0.0F;
   }

   public static Rotation2 a(class_1657 var0, class_1297 var1) {
      class_243 var2 = var0.method_5836(0.0F);
      class_243 var3 = new class_243(var1.method_23317(), var1.method_23318() + var1.method_17682() * 0.5, var1.method_23321());
      double var4 = var3.field_1352 - var2.field_1352;
      double var6 = var3.field_1351 - var2.field_1351;
      double var8 = var3.field_1350 - var2.field_1350;
      double var10 = Math.sqrt(var4 * var4 + var8 * var8);
      float var12 = (float)Math.toDegrees(Math.atan2(var8, var4)) - 90.0F;
      float var13 = (float)(-Math.toDegrees(Math.atan2(var6, var10)));
      return new Rotation2(var12, var13);
   }

   public final class_243 d() {
      float var1 = this.pitch * (float) (Math.PI / 180.0);
      float var2 = -this.yaw * (float) (Math.PI / 180.0);
      float var3 = class_3532.method_15362(var2);
      float var4 = class_3532.method_15374(var2);
      float var5 = class_3532.method_15362(var1);
      float var6 = class_3532.method_15374(var1);
      return new class_243(var4 * var5, -var6, var3 * var5);
   }

   public class_243 e() {
      return mc.field_1724 == null ? class_243.field_1353 : mc.field_1724.method_5631(this.pitch, this.yaw);
   }

   public void a(float var1, float var2) {
      this.yaw += var1;
      this.pitch += var2;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }
}
