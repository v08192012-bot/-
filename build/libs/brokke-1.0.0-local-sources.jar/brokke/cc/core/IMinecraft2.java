package brokke.cc.core;

import net.minecraft.class_310;

public interface IMinecraft2 {
   class_310 mc = class_310.method_1551();
}
