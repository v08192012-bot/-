package brokke.cc.core;

import java.util.List;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class InvBypass {
   private static final class_310 a = class_310.method_1551();

   private InvBypass() {
   }

   public static void a(List<class_304> var0) {
      if (a.field_1690 != null && a.field_1690.field_1867 != null) {
         a.field_1690.field_1867.method_23481(false);
      }

      if (a.field_1724 != null) {
         a.field_1724.method_5728(false);
      }

      if (var0 != null) {
         var0.forEach(var0x -> {
            if (var0x != null) {
               var0x.method_23481(false);
            }
         });
      }
   }

   public static void b(List<class_304> var0) {
      if (a.method_22683() != null && a.field_1690 != null && var0 != null) {
         for (class_304 var2 : var0) {
            if (var2 != null) {
               int var3 = var2.method_1429().method_1444();
               var2.method_23481(class_3675.method_15987(a.method_22683(), var3));
            }
         }
      }
   }
}
