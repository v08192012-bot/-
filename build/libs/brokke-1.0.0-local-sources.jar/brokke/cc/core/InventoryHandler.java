package brokke.cc.core;

import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.DeltaInventoryUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2815;
import net.minecraft.class_9334;

public class InventoryHandler extends BaseHandler {
   private final List<InventoryHandler.a> tasks = new ArrayList<>();

   public List<InventoryHandler.a> getTasks() {
      return this.tasks;
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1761 != null && !this.tasks.isEmpty()) {
         InventoryHandler.a var2 = this.tasks.getFirst();
         StopHandler var3 = HandlerProcessor.a().getStopHandler();
         if (var3.getTicks() < var2.getBypass()) {
            int var4 = this.a(var2.getFromSlot());
            int var5 = var2.isArmorMove() ? var2.getToSlot() : this.a(var2.getToSlot());
            if (mc.field_1724.field_7498.method_7611(var4).method_7677().method_57826(class_9334.field_49650)) {
               mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var4, 1, class_1713.field_7790, mc.field_1724);
               mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var5, 0, class_1713.field_7790, mc.field_1724);
               if (!mc.field_1724.field_7498.method_34255().method_7960()) {
                  mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var4, 0, class_1713.field_7790, mc.field_1724);
               }
            } else {
               int var6 = this.a(var2.getToSlot(), var5);
               if (var6 != -1) {
                  mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var4, var6, class_1713.field_7791, mc.field_1724);
               } else {
                  int var7 = this.a(var2.getFromSlot(), var4);
                  if (var7 != -1) {
                     mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var5, var7, class_1713.field_7791, mc.field_1724);
                  } else if (var4 != var5) {
                     mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var4, 0, class_1713.field_7791, mc.field_1724);
                     mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var5, 0, class_1713.field_7791, mc.field_1724);
                     mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, var4, 0, class_1713.field_7791, mc.field_1724);
                  }
               }
            }

            mc.field_1724.field_3944.method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
            this.tasks.remove(var2);
            if (!this.tasks.isEmpty()) {
               var3.setTicks(this.tasks.getFirst().getBypass());
            }
         }
      }
   }

   public void a(int var1, int var2, int var3) {
      this.a(new InventoryHandler.a(var1, var2, var3, false));
   }

   public void b(int var1, int var2, int var3) {
      this.a(new InventoryHandler.a(var1, 5 + var2, var3, true));
   }

   public void a(class_1792 var1, int var2, int var3) {
      int var4 = DeltaInventoryUtil.b(var1);
      if (var4 != -1) {
         this.a(new InventoryHandler.a(var4, var2, var3, false));
      }
   }

   public void a(class_1799 var1, int var2, int var3) {
      int var4 = DeltaInventoryUtil.a(var1, false);
      if (var4 != -1) {
         this.a(new InventoryHandler.a(var4, var2, var3, false));
      }
   }

   private void a(InventoryHandler.a var1) {
      if (var1.getFromSlot() != -1 && var1.getToSlot() != -1) {
         if (this.tasks.isEmpty() && var1.getBypass() > 0) {
            HandlerProcessor.a().getStopHandler().setTicks(var1.getBypass());
         }

         this.tasks.add(var1);
      }
   }

   private int a(int var1) {
      return var1 >= 0 && var1 <= 8 ? var1 + 36 : var1;
   }

   private int a(int var1, int var2) {
      if (var1 != 40 && var1 != 45 && var2 != 45) {
         return var2 >= 36 && var2 <= 44 ? var2 - 36 : -1;
      } else {
         return 40;
      }
   }

   public record a(int fromSlot, int toSlot, int bypass, boolean armorMove) {
      public int getFromSlot() {
         return this.fromSlot;
      }

      public int getToSlot() {
         return this.toSlot;
      }

      public int getBypass() {
         return this.bypass;
      }

      public boolean isArmorMove() {
         return this.armorMove;
      }
   }
}
