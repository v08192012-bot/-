package brokke.cc.core;

import brokke.cc.rotation.HolyWorldElytraUtil;
import java.util.Comparator;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_9285;
import net.minecraft.class_9285.class_9287;
import net.minecraft.class_9334;

public final class ElytraChestplateSwapper {
   private static final int CHEST_SLOT = 6;

   private ElytraChestplateSwapper() {
   }

   public static boolean a(class_310 var0) {
      return var0.field_1724 != null && var0.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
   }

   public static boolean b(class_310 var0) {
      if (var0.field_1724 == null || var0.field_1761 == null || var0.field_1755 != null || var0.field_1724.field_7512 == null) {
         return false;
      }

      if (a(var0)) {
         return true;
      }

      class_1735 var1 = d(var0);
      if (var1 == null) {
         return false;
      }

      a(var0, var1.field_7874);
      return true;
   }

   public static boolean c(class_310 var0) {
      if (var0.field_1724 == null || var0.field_1761 == null || var0.field_1755 != null || var0.field_1724.field_7512 == null) {
         return false;
      }

      if (!a(var0)) {
         return true;
      }

      class_1735 var1 = e(var0);
      if (var1 == null) {
         return false;
      }

      a(var0, var1.field_7874);
      return true;
   }

   private static void a(class_310 var0, int var1) {
      int var2 = var0.field_1724.field_7512.field_7763;
      var0.field_1761.method_2906(var2, var1, 0, class_1713.field_7790, var0.field_1724);
      var0.field_1761.method_2906(var2, 6, 0, class_1713.field_7790, var0.field_1724);
      var0.field_1761.method_2906(var2, var1, 0, class_1713.field_7790, var0.field_1724);
   }

   private static class_1735 d(class_310 var0) {
      return var0.field_1724 != null && var0.field_1724.field_7512 != null
         ? var0.field_1724
            .field_7512
            .field_7761
            .stream()
            .filter(var0x -> var0x.field_7874 >= 9 && var0x.field_7874 <= 44)
            .filter(var0x -> var0x.method_7677().method_31574(class_1802.field_8833))
            .findFirst()
            .orElse(null)
         : null;
   }

   private static class_1735 e(class_310 var0) {
      return var0.field_1724 != null && var0.field_1724.field_7512 != null
         ? var0.field_1724
            .field_7512
            .field_7761
            .stream()
            .filter(var0x -> var0x.field_7874 >= 9 && var0x.field_7874 <= 44)
            .filter(var0x -> a(var0x.method_7677()))
            .max(Comparator.comparingDouble(var0x -> b(var0x.method_7677())))
            .orElse(null)
         : null;
   }

   private static boolean a(class_1799 var0) {
      return HolyWorldElytraUtil.a(var0);
   }

   private static double b(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         double var1 = 0.0;
         class_9285 var3 = var0.method_58694(class_9334.field_49636);
         if (var3 != null) {
            for (class_9287 var5 : var3.comp_2393()) {
               if (var5.comp_2395() == class_5134.field_23724 || var5.comp_2395() == class_5134.field_23725) {
                  var1 += var5.comp_2396().comp_2449();
               }
            }
         }

         return var1;
      } else {
         return 0.0;
      }
   }
}
