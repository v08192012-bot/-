package brokke.cc.core;

import net.minecraft.class_1294;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5134;

public enum AutoBuyEntry {
   POPPER_POTION(
      "[★] Хлопушка",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5909, 10, 600))
         .a(new PotionCondition(class_1294.field_5904, 5, 300))
         .a(new PotionCondition(class_1294.field_5919, 10, 100))
         .a(new PotionCondition(class_1294.field_5912, 1, 3600)),
      16711680
   ),
   HOLY_WATER(
      "[★] Святая вода",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5924, 2, 900))
         .a(new PotionCondition(class_1294.field_5905, 2, 12000))
         .a(new PotionCondition(class_1294.field_5915, 2, 0)),
      16777215
   ),
   RAGE_POTION(
      "[★] Зелье Гнева",
      class_1802.field_8436,
      new PotionProcessor().a(new PotionCondition(class_1294.field_5910, 5, 600)).a(new PotionCondition(class_1294.field_5909, 4, 600)),
      10040115
   ),
   PALLADIN_POTION(
      "[★] Зелье Палладина",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5907, 1, 12000))
         .a(new PotionCondition(class_1294.field_5918, 1, 12000))
         .a(new PotionCondition(class_1294.field_5914, 3, 1200))
         .a(new PotionCondition(class_1294.field_5905, 1, 18000)),
      65535
   ),
   ASSASSIN_POTION(
      "[★] Зелье Ассасина",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5910, 4, 1200))
         .a(new PotionCondition(class_1294.field_5904, 3, 6000))
         .a(new PotionCondition(class_1294.field_5917, 1, 1200))
         .a(new PotionCondition(class_1294.field_5921, 2, 0)),
      3355443
   ),
   RADIATION_POTION(
      "[★] Зелье Радиации",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5899, 2, 300))
         .a(new PotionCondition(class_1294.field_5920, 2, 300))
         .a(new PotionCondition(class_1294.field_5909, 3, 300))
         .a(new PotionCondition(class_1294.field_5903, 5, 300))
         .a(new PotionCondition(class_1294.field_5912, 1, 300)),
      3329330
   ),
   SLEEPING_PILL(
      "[★] Снотворное",
      class_1802.field_8436,
      new PotionProcessor()
         .a(new PotionCondition(class_1294.field_5911, 2, 1800))
         .a(new PotionCondition(class_1294.field_5901, 2, 600))
         .a(new PotionCondition(class_1294.field_5920, 3, 1800))
         .a(new PotionCondition(class_1294.field_5919, 1, 600)),
      4737096
   ),
   TALISMAN_CRUSHER(
      "[★] Талисман Крушителя",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23716, 4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23721, 3.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23725, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23724, 2.0, class_1323.field_6328))
   ),
   TALISMAN_DISCORD(
      "[★] Талисман Раздора",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, 0.10000001817743467, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23723, 0.10000001817743467, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23724, -3.0, class_1323.field_6328))
   ),
   TALISMAN_TYRANT(
      "[★] Талисман Тирана",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23724, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, -4.0, class_1323.field_6328))
   ),
   TALISMAN_RAGE(
      "[★] Талисман Ярости",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 5.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, -4.0, class_1323.field_6328))
   ),
   TALISMAN_WHIRLWIND(
      "[★] Талисман Вихря",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23716, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, 0.1500000347540806, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23723, 0.1500000347540806, class_1323.field_6330))
   ),
   TALISMAN_GLOOM(
      "[★] Талисман Мрака",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23724, 1.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, 1.5, class_1323.field_6328))
   ),
   TALISMAN_DEMON(
      "[★] Талисман Демона",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 2.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23723, 0.10000001817743467, class_1323.field_6330))
   ),
   TALISMAN_PUNISHER(
      "[★] Талисман Карателя xxx",
      class_1802.field_8288,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 7.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, -4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, 0.10000001817743467, class_1323.field_6330))
   ),
   SPHERE_CHAOS(
      "[★] Сфера Хаоса",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23716, -4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23724, 1.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23721, 2.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, 0.07000004566537438, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23723, 0.13000000024761527, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_49078, 0.09000001839414021, class_1323.field_6330)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODY0MTkwMCwKICAicHJvZmlsZUlkIiA6ICIxNzRjZmRiNGEzY2I0M2I1YmZjZGU0MjRjM2JiMmM2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJtYXJhZWwxOCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lN2E3YWU3Y2RjZjYxNmU4YjdhNDIyMWE2MjFiMjQzNTc1M2M2MGVkNmEyNThlYTA2MGRhZTMwMDJmZmU5ZTI4IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="
   ),
   SPHERE_SATYR(
      "[★] Сфера Сатира",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23728, -0.10000000768432185, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23723, 0.1500000347540806, class_1323.field_6330)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODYwODUyOCwKICAicHJvZmlsZUlkIiA6ICJkMTQ4NjFiM2UwZmM0Njk5OTFlMTcyNTllMzdiZjZhZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJyYXhpdG9jbCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS83NzFhOWE0OThiNGZhNWVjNDkzNjJmOWJjODhlZGE0ZjUyYjA0ZGU0OWQ3NWFhM2NhMzMyYTFmZWExYWEwZTU3IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="
   ),
   SPHERE_BEAST(
      "[★] Сфера Бестии",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23724, 1.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, 4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, 0.10000001817743467, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_23723, 0.10000001817743467, class_1323.field_6330)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0MzgzNDkzMCwKICAicHJvZmlsZUlkIiA6ICI1MzUzNWIxN2M0ZDY0NWQ0YWUwY2U2ZjM4Zjk0NTFjYSIsCiAgInByb2ZpbGVOYW1lIiA6ICJVYml2aXMiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTQxMWFjMTczODFiOWZjZTliYWIzYzcyYWZkYjdmMTk4NTcwZGFmNDczMmJkODExZDMxYzIyN2Q4MGZhMzliMSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"
   ),
   SPHERE_ARES(
      "[★] Сфера Ареса",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 6.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23724, -2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, -2.0, class_1323.field_6328)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0Mzc3NDI1NSwKICAicHJvZmlsZUlkIiA6ICJhYWMxYjA2OWNkMjE0NWE2ODNlNzQxNzE4MDcxMGU4MiIsCiAgInByb2ZpbGVOYW1lIiA6ICJqdXNhbXUiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzE2YWRjNmJhZmNiNTdmZDcwN2RlZTdkZDZhNzM2ZmUxMjY3MTFkNTNhMWZkNmNlNzg5ZGE0MWIzYmUxM2YyYSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"
   ),
   SPHERE_HYDRA(
      "[★] Сфера Гидры",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23716, 4.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23724, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_51576, 0.5, class_1323.field_6330))
         .a(new AttributeCondition(class_5134.field_51583, 0.5, class_1323.field_6330)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODUzMjE4MywKICAicHJvZmlsZUlkIiA6ICI1OGZmZWI5NTMxNGQ0ODcwYTQwYjVjYjQyZDRlYTU5OCIsCiAgInByb2ZpbGVOYW1lIiA6ICJTa2luREJuZXQiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2UzYzExOGQ2OTZkOTEwZTU0ZGUwMmNhNGQ4MDc1NDNmOWIxOGMwMDhjOTgzOGQyZmY2OTM3NzYyMmZiMWQzMiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"
   ),
   SPHERE_ICARUS(
      "[★] Сфера Икара",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23721, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, 2.0, class_1323.field_6328)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODU4MjQ5MSwKICAicHJvZmlsZUlkIiA6ICJhZWNkODIxZTQyYzE0ZDJlOThmNTA1OTg1MWI5OWMzNyIsCiAgInByb2ZpbGVOYW1lIiA6ICJSb2RyaVgyMDc1IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2M2ODAzZTZkNTY2N2EyZDYxMDYyOGJjM2IzMmY4NjNjZGE0OTVjNDY1NjE2ZGU2NTVjYjMyOTkzM2I2MWFmNzciLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="
   ),
   SPHERE_ERIS(
      "[★] Сфера Эрида",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23726, 1.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23716, 2.0, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_47758, 1.0, class_1323.field_6328)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0Mzg2MTE4NywKICAicHJvZmlsZUlkIiA6ICJlZGUyYzdhMGFjNjM0MTNiYjA5ZDNmMGJlZTllYzhlYyIsCiAgInByb2ZpbGVOYW1lIiA6ICJ0aGVEZXZKYWRlIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzZlNGUyZjEwNDdmM2VjNmU5ZTQ1OTE4NDczOWUzM2I3YzFmYzYzYWQ4MjAyYmRhYjlmMDI0NTA4YWRkMjNlNWIiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="
   ),
   SPHERE_TITAN(
      "[★] Сфера Титана",
      class_1802.field_8575,
      new AttributeProcessor()
         .a(new AttributeCondition(class_5134.field_23724, 2.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23725, 2.5, class_1323.field_6328))
         .a(new AttributeCondition(class_5134.field_23719, -0.15000007945819008, class_1323.field_6330)),
      "ewogICJ0aW1lc3RhbXAiIDogMTc1MDM1NDQ1NTE5MiwKICAicHJvZmlsZUlkIiA6ICJkOTcwYzEzZTM4YWI0NzlhOTY1OGM1ZDQ1MjZkMTM0YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJDcmltcHlMYWNlODUxMjciLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODFlOTY5ODQ1OGI3ODQxYzk2YWU0ZjI0ZWM4NGFlMDE3MjQxMDA2NDFjNTY0ZTJhN2IxODVmNDA2ZThlZDIzIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="
   ),
   TRAP("[★] Трапка", class_1802.field_22021, new DescriptionProcessor().a("Каст: Нерушимая клетка")),
   CLEAR_DUST("[★] Явная пыль", class_1802.field_8479, new DescriptionProcessor().a("Каст: Световая вспышка")),
   SNOWBALL("[★] Снежок заморозка", class_1802.field_8543, new DescriptionProcessor().a("Каст: Ледяная сфера")),
   GOD_AURA("[★] Божья аура", class_1802.field_8614, new DescriptionProcessor().a("Каст: Божественная аура")),
   DISORIENTATION("[★] Дезориентация", class_1802.field_8449, new DescriptionProcessor().a("Каст: Звуковая волна")),
   STRATUM("[★] Пласт", class_1802.field_8551, new DescriptionProcessor().a("Каст: Нерушимая стена")),
   GOLDEN_APPLE("Золотое яблоко", class_1802.field_8463),
   ENCHANTED_GOLDEN_APPLE("Чарка", class_1802.field_8367),
   TOTEM("Тотем бессмертия", class_1802.field_8288),
   SHIELD("Щит", class_1802.field_8255),
   ENDER_PEARL("Эндер-жемчуг", class_1802.field_8634),
   CHORUS_FRUIT("Хорус", class_1802.field_8233),
   WIND_CHARGE("Заряд ветра", class_1802.field_49098);

   private final String displayName;
   private final Object profile;
   private final class_1792 item;
   private final AttributeProcessor attributeProcessor;
   private final EnchantmentProcessor enchantmentProcessor;
   private final DescriptionProcessor descriptionProcessor;
   private final PotionProcessor potionProcessor;

   AutoBuyEntry(String nullxx, class_1792 nullxxx) {
      this(nullxx, nullxxx, null, null, null, null, null);
   }

   AutoBuyEntry(String nullxx, class_1792 nullxxx, PotionProcessor nullxxxx, Object nullxxxxx) {
      this(nullxx, nullxxx, null, null, null, nullxxxx, nullxxxxx);
   }

   AutoBuyEntry(String nullxx, class_1792 nullxxx, AttributeProcessor nullxxxx) {
      this(nullxx, nullxxx, nullxxxx, null, null, null, null);
   }

   AutoBuyEntry(String nullxx, class_1792 nullxxx, AttributeProcessor nullxxxx, Object nullxxxxx) {
      this(nullxx, nullxxx, nullxxxx, null, null, null, nullxxxxx);
   }

   AutoBuyEntry(String nullxx, class_1792 nullxxx, DescriptionProcessor nullxxxx) {
      this(nullxx, nullxxx, null, null, nullxxxx, null, null);
   }

   AutoBuyEntry(
      String nullxx,
      class_1792 nullxxx,
      AttributeProcessor nullxxxx,
      EnchantmentProcessor nullxxxxx,
      DescriptionProcessor nullxxxxxx,
      PotionProcessor nullxxxxxxx,
      Object nullxxxxxxxx
   ) {
      this.displayName = nullxx;
      this.item = nullxxx;
      this.attributeProcessor = nullxxxx;
      this.enchantmentProcessor = nullxxxxx;
      this.descriptionProcessor = nullxxxxxx;
      this.potionProcessor = nullxxxxxxx;
      this.profile = nullxxxxxxxx;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public class_1792 getItem() {
      return this.item;
   }

   public boolean a(class_1799 var1) {
      return var1 != null
         && !var1.method_7960()
         && var1.method_31574(this.item)
         && (this.attributeProcessor == null || this.attributeProcessor.a(var1))
         && (this.enchantmentProcessor == null || this.enchantmentProcessor.a(var1))
         && (this.descriptionProcessor == null || this.descriptionProcessor.a(var1))
         && (this.potionProcessor == null || this.potionProcessor.a(var1));
   }
}
