package brokke.cc.core;

import brokke.cc.util.EnchantmentUtility;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class FallPredictor {
   private static final class_310 mc = class_310.method_1551();

   public static float a(class_1657 var0) {
      if (var0 != null && mc.field_1687 != null) {
         class_243 var1 = var0.method_18798();
         double var2 = var0.method_23318();
         float var4 = (float)var0.field_6017;

         while (var2 > mc.field_1687.method_31607()) {
            class_2338 var5 = class_2338.method_49637(var0.method_23317(), var2, var0.method_23321());
            if (!mc.field_1687.method_22347(var5)) {
               break;
            }

            var4 = (float)(var4 + (var1.field_1351 < 0.0 ? -var1.field_1351 : 0.0));
            var1 = new class_243(var1.field_1352, (var1.field_1351 - 0.08) * 0.98, var1.field_1350);
            var2 += var1.field_1351;
         }

         float var8 = var4 - 3.0F;
         if (var8 <= 0.0F) {
            return 0.0F;
         }

         class_1799 var6 = var0.method_6118(class_1304.field_6166);
         if (!var6.method_7960()) {
            int var7 = EnchantmentUtility.a(var6, class_1893.field_9129);
            if (var7 > 0) {
               var8 *= 1.0F - var7 * 0.12F;
            }
         }

         return class_3532.method_15363(var8, 0.0F, Float.MAX_VALUE);
      } else {
         return 0.0F;
      }
   }

   private FallPredictor() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
