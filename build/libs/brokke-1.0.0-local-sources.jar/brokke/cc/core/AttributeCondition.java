package brokke.cc.core;

import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1799;
import net.minecraft.class_6880;
import net.minecraft.class_9285;
import net.minecraft.class_9285.class_9287;
import net.minecraft.class_9334;

public record AttributeCondition(class_6880<class_1320> attribute, class_1323 operation, double amount) {
   public AttributeCondition {
      if (attribute == null) {
         throw new IllegalArgumentException("Attribute cannot be null");
      }
   }

   public AttributeCondition(class_6880<class_1320> var1, double var2, class_1323 var4) {
      this(var1, var4, var2);
   }

   public boolean a(class_6880<class_1320> var1, class_1322 var2) {
      return var1.equals(this.attribute) && Math.abs(var2.comp_2449() - this.amount) < 0.001 && var2.comp_2450() == this.operation;
   }

   public boolean a(class_1799 var1) {
      class_9285 var2 = var1.method_58695(class_9334.field_49636, class_9285.field_49326);

      for (class_9287 var4 : var2.comp_2393()) {
         if (this.a(var4.comp_2395(), var4.comp_2396())) {
            return true;
         }
      }

      return false;
   }

   public class_6880<class_1320> getAttribute() {
      return this.attribute;
   }

   public class_1323 getOperation() {
      return this.operation;
   }

   public double getAmount() {
      return this.amount;
   }
}
