package brokke.cc.core;

import brokke.cc.system.events.EventBus;
import net.minecraft.class_310;

public class BaseHandler {
   protected static final class_310 mc = class_310.method_1551();

   public BaseHandler() {
      EventBus.register(this);
   }
}
