package brokke.cc.core;

import brokke.cc.util.SwapUtil;
import net.minecraft.class_10185;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class MovementStop {
   private static final class_310 a = class_310.method_1551();

   private MovementStop() {
   }

   public static void a() {
      if (a.field_1724 != null && a.field_1690 != null) {
         SwapUtil.c().forEach(var0x -> var0x.method_23481(false));
         a.field_1724.method_5728(false);
         if (a.field_1724.field_3913 != null) {
            a.field_1724.field_3913.field_54155 = new class_10185(false, false, false, false, false, false, false);
         }

         class_243 var0 = a.field_1724.method_18798();
         a.field_1724.method_18800(0.0, var0.field_1351, 0.0);
      }
   }
}
