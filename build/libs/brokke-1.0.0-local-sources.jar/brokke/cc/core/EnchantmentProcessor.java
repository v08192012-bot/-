package brokke.cc.core;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_5321;

public class EnchantmentProcessor implements ItemFilter {
   private final List<EnchantmentCondition> conditions = new ArrayList<>();

   public List<EnchantmentCondition> getConditions() {
      return this.conditions;
   }

   public EnchantmentProcessor a(EnchantmentCondition var1) {
      this.conditions.add(var1);
      return this;
   }

   public EnchantmentProcessor a(class_5321<class_1887> var1) {
      return this.a(new EnchantmentCondition(var1));
   }

   public EnchantmentProcessor a(class_5321<class_1887> var1, int var2) {
      return this.a(new EnchantmentCondition(var1, var2));
   }

   public EnchantmentProcessor b(class_5321<class_1887> var1) {
      return this.a(new EnchantmentCondition(var1, 0, ItemType.DENY));
   }

   public EnchantmentProcessor b(class_5321<class_1887> var1, int var2) {
      return this.a(new EnchantmentCondition(var1, var2, ItemType.DENY));
   }

   public EnchantmentProcessor b() {
      return this.b(class_1893.field_9097).b(class_1893.field_9121).b(class_1893.field_9113).b(class_1893.field_9109);
   }

   @Override
   public boolean a(class_1799 var1) {
      return this.conditions.stream().allMatch(var1xx -> var1xx.a(var1));
   }
}
