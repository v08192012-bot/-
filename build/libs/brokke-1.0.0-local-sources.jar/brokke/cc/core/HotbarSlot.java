package brokke.cc.core;

import net.minecraft.class_1799;

public class HotbarSlot extends ItemSlot {
   private final int slotId;

   public HotbarSlot(int var1) {
      if (var1 >= 0 && var1 <= 8) {
         this.slotId = var1;
      } else {
         throw new IllegalArgumentException("Hotbar Slot ID must be between 0 and 8");
      }
   }

   @Override
   public class_1799 a() {
      return mc.field_1724 != null && mc.field_1724.method_31548() != null ? mc.field_1724.method_31548().method_5438(this.slotId) : class_1799.field_8037;
   }

   @Override
   public int get45() {
      return 36 + this.slotId;
   }

   public int getSlotId() {
      return this.slotId;
   }
}
