package brokke.cc.core;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_310;

public class User {
   private static final User instance = new User();
   private final Map<String, String> cache = new HashMap<>();
   private boolean nativeFailed;

   public static User getInstance() {
      return instance;
   }

   private User() {
      this.cache.put("username", "SOURSE by loverqq");
      this.cache.put("role", "local");
      this.cache.put("uid", "1");
      this.cache.put("subTime", "не используется");
   }

   public String getProfileValue(String var1) {
      return this.cache.getOrDefault(var1, "");
   }

   public String getUsername() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null) {
         if (var1.field_1724 != null && var1.field_1724.method_5477() != null && !var1.field_1724.method_5477().getString().isBlank()) {
            return var1.field_1724.method_5477().getString();
         }

         if (var1.method_1548() != null && var1.method_1548().method_1676() != null && !var1.method_1548().method_1676().isBlank()) {
            return var1.method_1548().method_1676();
         }
      }

      return this.getProfileValue("username");
   }

   public String getRole() {
      return this.getProfileValue("role");
   }

   public String getUid() {
      return this.getProfileValue("uid");
   }

   public String getSubscriptionTime() {
      return this.getProfileValue("subTime");
   }

   public boolean isNativeFailed() {
      return this.nativeFailed;
   }
}
