package brokke.cc.core;

import brokke.cc.util.HotbarUtil;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

public record SlotSearchResult(int slot, boolean found, class_1799 stack) {
   private static final class_310 mc = class_310.method_1551();
   private static final SlotSearchResult NOT_FOUND_RESULT = new SlotSearchResult(-1, false, class_1799.field_8037);

   public static SlotSearchResult getNotFoundResult() {
      return NOT_FOUND_RESULT;
   }

   @NotNull
   public static SlotSearchResult a(class_1799 var0) {
      return new SlotSearchResult(999, true, var0);
   }

   public boolean b() {
      return mc.field_1724 == null ? false : this.c() || mc.field_1724.method_31548().method_67532() == this.slot;
   }

   public boolean c() {
      return this.slot == 999;
   }

   public boolean d() {
      return this.slot >= 0 && this.slot < 9;
   }

   public void e() {
      if (this.found && this.d()) {
         HotbarUtil.b(this.slot);
      }
   }

   public void f() {
      if (this.found && this.d()) {
         HotbarUtil.c(this.slot);
      }
   }

   public int getSlot() {
      return this.slot;
   }

   public boolean isFound() {
      return this.found;
   }

   public class_1799 getStack() {
      return this.stack;
   }
}
