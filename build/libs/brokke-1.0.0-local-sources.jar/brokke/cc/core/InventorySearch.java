package brokke.cc.core;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_9279;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class InventorySearch {
   private static final class_310 a = class_310.method_1551();

   private InventorySearch() {
   }

   public static int a(class_1792 var0) {
      if (a.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         if (a.field_1724.method_31548().method_5438(var1).method_31574(var0)) {
            return var1;
         }
      }

      for (int var2 = 9; var2 < 36; var2++) {
         if (a.field_1724.method_31548().method_5438(var2).method_31574(var0)) {
            return var2;
         }
      }

      return -1;
   }

   public static int a() {
      if (a.field_1724 == null) {
         return -1;
      }

      int var0 = -1;
      int var1 = -1;

      for (int var2 = 0; var2 < 36; var2++) {
         class_1799 var3 = a.field_1724.method_31548().method_5438(var2);
         if (var3.method_31574(class_1802.field_8288)) {
            if (c(var3)) {
               var0 = var2;
               break;
            }

            if (var1 == -1) {
               var1 = var2;
            }
         }
      }

      return var0 != -1 ? var0 : var1;
   }

   public static int b(class_1792 var0) {
      return var0 == class_1802.field_8288 ? a() : a(var0);
   }

   public static int b() {
      if (a.field_1724 == null) {
         return -1;
      }

      for (int var0 = 0; var0 < 36; var0++) {
         if (b(a.field_1724.method_31548().method_5438(var0))) {
            return var0;
         }
      }

      return -1;
   }

   public static int c(class_1792 var0) {
      if (a.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 36; var1++) {
         if (a.field_1724.method_31548().method_5438(var1).method_31574(var0)) {
            return var1;
         }
      }

      return -1;
   }

   public static int c() {
      if (a.field_1724 == null) {
         return -1;
      }

      for (int var0 = 9; var0 < 36; var0++) {
         if (a.field_1724.method_31548().method_5438(var0).method_31574(class_1802.field_8833)) {
            return var0;
         }
      }

      for (int var1 = 0; var1 < 9; var1++) {
         if (a.field_1724.method_31548().method_5438(var1).method_31574(class_1802.field_8833)) {
            return var1;
         }
      }

      return -1;
   }

   public static int d() {
      if (a.field_1724 == null) {
         return -1;
      }

      for (int var0 = 9; var0 < 36; var0++) {
         if (a(a.field_1724.method_31548().method_5438(var0))) {
            return var0;
         }
      }

      for (int var1 = 0; var1 < 9; var1++) {
         if (a(a.field_1724.method_31548().method_5438(var1))) {
            return var1;
         }
      }

      return -1;
   }

   public static boolean a(class_1799 var0) {
      return var0.method_7960()
         ? false
         : var0.method_31574(class_1802.field_8058)
            || var0.method_31574(class_1802.field_22028)
            || var0.method_31574(class_1802.field_8523)
            || var0.method_31574(class_1802.field_8678)
            || var0.method_31574(class_1802.field_8873)
            || var0.method_31574(class_1802.field_8577);
   }

   public static boolean b(class_1799 var0) {
      if (!var0.method_7960() && var0.method_31574(class_1802.field_8575)) {
         class_9279 var1 = var0.method_58694(class_9334.field_49628);
         if (var1 == null) {
            return false;
         }

         class_2487 var2 = var1.method_57461();
         return var2.method_10562("SkullOwner")
            .flatMap(var0x -> var0x.method_10562("Properties"))
            .flatMap(var0x -> var0x.method_10554("textures"))
            .filter(var0x -> !var0x.isEmpty())
            .flatMap(var0x -> var0x.method_10602(0))
            .flatMap(var0x -> var0x.method_10558("Value"))
            .map(
               var0x -> var0x.equals(
                  "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYjA5NWE3ZmQ5MGRhYTFiYmU3MDY5MDg5NzQwZTA1ZDBiZmM2NjI5NmVlM2M0MGVlNzFhNGUwYTY2MTZiMmJiYyJ9fX0="
               )
            )
            .orElse(false);
      } else {
         return false;
      }
   }

   public static boolean c(class_1799 var0) {
      if (var0.method_7960()) {
         return false;
      }

      class_9304 var1 = var0.method_58694(class_9334.field_49633);
      class_9304 var2 = var0.method_58694(class_9334.field_49643);
      return var1 != null && !var1.method_57543() || var2 != null && !var2.method_57543();
   }

   public static class_2561 d(class_1799 var0) {
      return var0.method_7964();
   }
}
