package brokke.cc.core;

import java.util.Random;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1314;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132.class_5133;
import net.minecraft.class_5134;

public class FakePlayerEntity extends class_1314 {
   private String skinName = "Steve";
   private int totemPops = 0;
   public int strafeDir = 1;
   public int strafeTicks;
   public int distTicks;
   public int jumpTicks;
   public double wantDist = 3.0;
   public double baseY;

   public FakePlayerEntity(class_1299<? extends class_1314> var1, class_1937 var2) {
      super(var1, var2);
   }

   public static class_5133 a() {
      return class_1314.method_26828()
         .method_26868(class_5134.field_23716, 20.0)
         .method_26868(class_5134.field_23719, 0.0)
         .method_26868(class_5134.field_23717, 0.0)
         .method_26868(class_5134.field_23718, 0.0);
   }

   public void setSkinName(String var1) {
      this.skinName = var1;
   }

   public String getSkinName() {
      return this.skinName;
   }

   public int getTotemPops() {
      return this.totemPops;
   }

   public void a(class_1657 var1) {
      if (var1 != null && this.method_5805()) {
         class_310 var2 = class_310.method_1551();
         Random var3 = new Random();
         float var4 = (float)var1.method_45325(class_5134.field_23721);
         if (var4 <= 0.0F) {
            var4 = 8.0F;
         }

         boolean var5 = var1.field_6017 > 0.0
            && !var1.method_24828()
            && !var1.method_6101()
            && !var1.method_5799()
            && !var1.method_6059(class_1294.field_5919)
            && !var1.method_5765();
         float var6 = var5 ? var4 * 1.5F : var4;
         double var7 = this.method_23317() - var1.method_23317();
         double var9 = this.method_23321() - var1.method_23321();
         double var11 = Math.sqrt(var7 * var7 + var9 * var9);
         if (var11 > 0.001) {
            double var13 = var5 ? 0.35 : 0.25;
            this.method_18799(this.method_18798().method_1031(var7 / var11 * var13, 0.2, var9 / var11 * var13));
            this.field_64356 = true;
         }

         if (var2.field_1687 != null) {
            if (var5) {
               for (int var16 = 0; var16 < 15; var16++) {
                  var2.field_1687
                     .method_8406(
                        class_2398.field_11205,
                        this.method_23317() + (var3.nextDouble() - 0.5) * 0.6,
                        this.method_23323(0.5) + (var3.nextDouble() - 0.5) * 0.6,
                        this.method_23321() + (var3.nextDouble() - 0.5) * 0.6,
                        (var3.nextDouble() - 0.5) * 0.4,
                        var3.nextDouble() * 0.2,
                        (var3.nextDouble() - 0.5) * 0.4
                     );
               }
            } else {
               for (int var17 = 0; var17 < 6; var17++) {
                  var2.field_1687
                     .method_8406(
                        class_2398.field_11209,
                        this.method_23317() + (var3.nextDouble() - 0.5) * 0.5,
                        this.method_23323(0.5) + (var3.nextDouble() - 0.5) * 0.5,
                        this.method_23321() + (var3.nextDouble() - 0.5) * 0.5,
                        0.1,
                        0.1,
                        0.1
                     );
               }
            }
         }

         float var18 = this.method_6032();
         float var14 = var18 - var6;
         if (var14 <= 0.0F) {
            this.totemPops++;
            this.method_6033(20.0F);
            if (var2.field_1687 != null) {
               var2.field_1687.method_43128(var2.field_1724, this.method_23317(), this.method_23318(), this.method_23321(), class_3417.field_14931, class_3419.field_15248, 1.0F, 1.0F);

               for (int var15 = 0; var15 < 40; var15++) {
                  var2.field_1687
                     .method_8406(
                        class_2398.field_11220,
                        this.method_23317() + (var3.nextDouble() - 0.5) * 0.8,
                        this.method_23323(0.5) + (var3.nextDouble() - 0.5) * 0.8,
                        this.method_23321() + (var3.nextDouble() - 0.5) * 0.8,
                        (var3.nextDouble() - 0.5) * 0.6,
                        var3.nextDouble() * 0.5,
                        (var3.nextDouble() - 0.5) * 0.6
                     );
               }
            }

            this.method_5711((byte)35);
            this.method_5673(class_1304.field_6171, new class_1799(class_1802.field_8288));
         } else {
            this.method_6033(var14);
            this.field_6235 = 10;
            this.field_6254 = 10;
            this.method_5711((byte)2);
            if (var2.field_1687 != null) {
               var2.field_1687
                  .method_43128(
                     var2.field_1724,
                     this.method_23317(),
                     this.method_23318(),
                     this.method_23321(),
                     var5 ? class_3417.field_15016 : class_3417.field_15115,
                     class_3419.field_15248,
                     1.0F,
                     (var3.nextFloat() - var3.nextFloat()) * 0.2F + 1.0F
                  );
            }
         }
      }
   }
}
