package brokke.cc.core;

import brokke.cc.mixins.interfaces.IClientPlayerInteractionManager;
import brokke.cc.rotation.Rotation2;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.DeltaInventoryUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_9334;
import net.minecraft.class_9837;

public class UseableHandler extends BaseHandler {
   private final List<UseableHandler.a> tasks = new ArrayList<>();

   public List<UseableHandler.a> getTasks() {
      return this.tasks;
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1761 != null && !this.tasks.isEmpty()) {
         UseableHandler.a var2 = this.tasks.getFirst();
         int var3 = var2.getItemStack().method_7909() == class_1802.field_8436
            ? DeltaInventoryUtil.a(true)
            : DeltaInventoryUtil.a(var2.getItemStack().method_7909(), true);
         int var4 = var2.getItemStack().method_7909() == class_1802.field_8436
            ? DeltaInventoryUtil.a(false)
            : DeltaInventoryUtil.a(var2.getItemStack().method_7909(), false);
         if (var2.getTicks() == -1 && var3 == -1 && var4 == -1) {
            this.tasks.remove(var2);
            return;
         }

         var2.setTicks(var2.getTicks() + 1);
         if (var2.getTicks() == 0) {
            var2.setSelectedSlot(mc.field_1724.method_31548().method_67532());
            if (var3 != -1) {
               var2.setFromInventory(false);
               var2.setItemSlot(var3);
               if (var3 != mc.field_1724.method_31548().method_67532()) {
                  this.a(var3);
                  return;
               }

               return;
            }

            if (var4 != -1) {
               var2.setFromInventory(true);
               int var5 = DeltaInventoryUtil.a(mc.field_1724.method_31548().method_5438(var4), var2.getItemStack());
               if (var5 != -1) {
                  mc.field_1724.field_3944.method_52787(new class_9837(var4 < 9 ? 36 + var4 : var4, var5));
               }

               var2.setItemSlot(var5 != -1 && mc.field_1724.method_6047().method_7960() ? var2.getItemSlot() : var4);
               HandlerProcessor.a().getInventoryHandler().a(var4, mc.field_1724.method_31548().method_67532(), 1);
               return;
            }

            return;
         }

         if (!var2.isFromInventory()) {
            if (var2.getTicks() == 1) {
               this.a(var2);
               if (var2.getSelectedSlot() != mc.field_1724.method_31548().method_67532()) {
                  this.a(var2.getSelectedSlot());
               }

               this.tasks.remove(var2);
            }
         } else if (var2.getTicks() == 3) {
            this.a(var2);
         } else if (var2.getTicks() >= 5) {
            if (mc.field_1724.method_31548().method_5438(var2.getItemSlot()).method_57826(class_9334.field_49650)) {
               mc.field_1724.method_31548().method_5447(var2.getSelectedSlot(), class_1799.field_8037);
               HandlerProcessor.a().getInventoryHandler().a(var2.getItemSlot(), 36 + var2.getSelectedSlot(), 1);
            } else if (var2.getItemSlot() > 8) {
               HandlerProcessor.a().getInventoryHandler().a(var2.getSelectedSlot(), var2.getItemSlot(), 1);
            } else if (var2.getSelectedSlot() != mc.field_1724.method_31548().method_67532()) {
               this.a(var2.getSelectedSlot());
            }

            this.tasks.remove(var2);
         }
      }
   }

   public void a(int var1) {
      if (mc.field_1724 != null && var1 >= 0 && var1 <= 8) {
         mc.field_1724.method_31548().method_61496(var1);
         if (mc.field_1724.field_3944 != null) {
            mc.field_1724.field_3944.method_52787(new class_2868(var1));
         }
      }
   }

   public void a(UseableHandler.a var1) {
      if (mc.field_1761 != null && mc.field_1687 != null && mc.field_1724 != null) {
         float var2 = var1.getRotation() != null ? var1.getRotation().getYaw() : mc.field_1724.method_36454();
         float var3 = var1.getRotation() != null ? var1.getRotation().getPitch() : mc.field_1724.method_36455();
         if (var1.getRotation() != null) {
            mc.field_1724.method_36456(var2);
            mc.field_1724.method_36457(var3);
         }

         ((IClientPlayerInteractionManager)mc.field_1761)
            .invokeSendSequencedPacket(mc.field_1687, var2xx -> new class_2886(class_1268.field_5808, var2xx, var2, var3));
         mc.field_1724.method_6104(class_1268.field_5808);
      }
   }

   public void a(class_1799 var1) {
      this.tasks.add(new UseableHandler.a(var1));
   }

   public void a(class_1799 var1, Rotation2 var2) {
      this.tasks.add(new UseableHandler.a(var1, var2));
   }

   public static final class a {
      private final class_1799 itemStack;
      private final Rotation2 rotation;
      private int selectedSlot;
      private int itemSlot;
      private int ticks = -1;
      private boolean fromInventory;

      public a(class_1799 var1) {
         this(var1, null);
      }

      public a(class_1799 var1, Rotation2 var2) {
         this.itemStack = var1;
         this.rotation = var2;
      }

      public Rotation2 getRotation() {
         return this.rotation;
      }

      public void setSelectedSlot(int var1) {
         this.selectedSlot = var1;
      }

      public void setItemSlot(int var1) {
         this.itemSlot = var1;
      }

      public void setTicks(int var1) {
         this.ticks = var1;
      }

      public void setFromInventory(boolean var1) {
         this.fromInventory = var1;
      }

      public class_1799 getItemStack() {
         return this.itemStack;
      }

      public int getSelectedSlot() {
         return this.selectedSlot;
      }

      public int getItemSlot() {
         return this.itemSlot;
      }

      public int getTicks() {
         return this.ticks;
      }

      public boolean isFromInventory() {
         return this.fromInventory;
      }
   }
}
