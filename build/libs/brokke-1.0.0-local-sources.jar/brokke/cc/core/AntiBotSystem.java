package brokke.cc.core;

import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_638;
import net.minecraft.class_745;

public final class AntiBotSystem {
   private static final Set<UUID> BOTS = ConcurrentHashMap.newKeySet();

   private AntiBotSystem() {
   }

   public static void a(class_638 var0) {
      if (var0 == null) {
         BOTS.clear();
      } else {
         for (class_1657 var2 : var0.method_18456()) {
            a(var2);
         }
      }
   }

   public static boolean a(class_1657 var0) {
      if (var0 == null) {
         return false;
      } else if (c(var0)) {
         BOTS.add(var0.method_5667());
         return true;
      } else {
         return BOTS.contains(var0.method_5667());
      }
   }

   public static boolean b(class_1657 var0) {
      return var0 != null && BOTS.contains(var0.method_5667());
   }

   private static boolean c(class_1657 var0) {
      UUID var1 = UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0.method_5477().getString()).getBytes(StandardCharsets.UTF_8));
      return !var0.method_5667().equals(var1) && var0 instanceof class_745 && !var0.method_5477().getString().contains("-");
   }
}
