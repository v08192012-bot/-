package brokke.cc.core;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class EnchantmentCondition implements ItemFilter {
   private final class_5321<class_1887> enchantmentKey;
   private ItemType type;
   private int requiredLevel;

   public EnchantmentCondition(class_5321<class_1887> var1) {
      this(var1, 0, ItemType.ON);
   }

   public EnchantmentCondition(class_5321<class_1887> var1, int var2) {
      this(var1, var2, ItemType.ON);
   }

   public EnchantmentCondition(class_5321<class_1887> var1, int var2, ItemType var3) {
      this.enchantmentKey = var1;
      this.type = var3;
      this.requiredLevel = var2;
   }

   public class_5321<class_1887> getEnchantmentKey() {
      return this.enchantmentKey;
   }

   public ItemType getType() {
      return this.type;
   }

   public int getRequiredLevel() {
      return this.requiredLevel;
   }

   @Override
   public boolean a(class_1799 var1) {
      if (this.type == ItemType.OFF) {
         return true;
      }

      class_310 var2 = class_310.method_1551();
      if (var2.field_1687 == null) {
         return false;
      }

      class_6883 var3 = var2.field_1687.method_30349().method_30530(class_7924.field_41265).method_46747(this.enchantmentKey);
      class_9304 var4 = var1.method_58695(class_9334.field_49633, class_9304.field_49385);
      int var5 = var4.method_57536(var3);
      int var6 = this.requiredLevel == 0 ? 1 : this.requiredLevel;
      return this.type == ItemType.DENY ? var5 < var6 : !var4.method_57543() && var5 >= var6;
   }
}
