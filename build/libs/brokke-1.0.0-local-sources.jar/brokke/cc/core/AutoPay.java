package brokke.cc.core;

import brokke.cc.config.AutoBuyConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class AutoPay {
   private final class_310 mc = class_310.method_1551();
   private int timer = 0;
   private boolean waiting = false;
   private int waitTicks = 0;
   private boolean started = false;

   public void a() {
      if (this.mc.field_1724 != null) {
         AutoBuyConfig var1 = AutoBuyConfig.getInstance();
         if (!var1.autoPay) {
            this.started = false;
            this.waiting = false;
         } else {
            if (!this.started) {
               this.started = true;
               this.timer = this.a(var1);
            }

            if (this.waiting) {
               this.waitTicks--;
               if (this.waitTicks <= 0) {
                  this.waiting = false;
                  this.timer = this.a(var1);
               }
            } else if (this.timer > 0) {
               this.timer--;
            } else {
               this.mc.field_1724.field_3944.method_45730("money");
               this.waiting = true;
               this.waitTicks = 100;
            }
         }
      }
   }

   public void a(long var1) {
      if (this.waiting) {
         this.waiting = false;
         AutoBuyConfig var3 = AutoBuyConfig.getInstance();
         this.timer = this.a(var3);
         if (var3.autoPayNick != null && !var3.autoPayNick.isBlank() && var1 > var3.autoPayKeepBalance) {
            long var4 = var1 - var3.autoPayKeepBalance;
            this.mc.field_1724.field_3944.method_45730("pay " + var3.autoPayNick.trim() + " " + var4);
            if (this.mc.field_1724 != null) {
               this.mc.field_1724.method_7353(class_2561.method_43470("§a[AutoPay] Переведено §f" + var4 + "§a игроку §f" + var3.autoPayNick.trim()), false);
            }
         }
      }
   }

   private int a(AutoBuyConfig var1) {
      return Math.max(60, var1.autoPayIntervalSeconds * 20);
   }
}
