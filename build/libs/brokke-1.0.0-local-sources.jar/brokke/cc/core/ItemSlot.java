package brokke.cc.core;

import brokke.cc.util.InventoryUtility;
import java.util.function.Predicate;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public abstract class ItemSlot {
   protected static final class_310 mc = class_310.method_1551();

   public abstract class_1799 a();

   public abstract int get45();

   public int c() {
      return mc.field_1724 != null && mc.field_1724.field_7512 != null ? mc.field_1724.field_7512.field_7763 : 0;
   }

   public class_1792 d() {
      return this.a().method_7909();
   }

   public boolean e() {
      return this.a().method_7960();
   }

   public boolean a(class_1792 var1) {
      return this.a().method_7909() == var1;
   }

   public boolean a(Predicate<class_1799> var1) {
      return var1.test(this.a());
   }

   public void a(ItemSlot var1) {
      InventoryUtility.a(this, var1);
   }

   public void f() {
      InventoryUtility.a(this);
   }

   public void g() {
      if (mc.field_1761 != null && mc.field_1724 != null) {
         mc.field_1761.method_2906(this.c(), this.get45(), 0, class_1713.field_7790, mc.field_1724);
      }
   }
}
