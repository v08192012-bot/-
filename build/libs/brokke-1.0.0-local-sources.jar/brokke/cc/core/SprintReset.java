package brokke.cc.core;

import brokke.cc.module.movement.AutoSprint;
import brokke.cc.system.events.impl.EventMoveInput;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_306;
import net.minecraft.class_3675.class_307;
import org.lwjgl.glfw.GLFW;

public final class SprintReset {
   private static final class_310 mc = class_310.method_1551();
   private static int resetTicks = 0;
   private static String activeMode = "Нет";
   private static int lastTickAge = Integer.MIN_VALUE;

   private SprintReset() {
   }

   public static boolean a() {
      return resetTicks > 0;
   }

   public static void a(String var0) {
      boolean var1 = mc.field_1724 != null && mc.field_1724.method_5624();
      a(var0, var1);
   }

   public static void a(String var0, boolean var1) {
      if (mc.field_1724 != null
         && var0 != null
         && !var0.equals("Нет")
         && mc.field_1724.method_24828()
         && !mc.field_1724.method_5799()
         && !mc.field_1724.method_5869()
         && !mc.field_1724.method_6101()) {
         boolean var2 = mc.field_1690 != null && mc.field_1690.field_1867.method_1434();
         AutoSprint var3 = AutoSprint.getInstance();
         boolean var4 = var3 != null && var3.isActive();
         if (var1 || var2 || var4) {
            activeMode = var0;
            resetTicks = 1;
            if (mc.field_1690 != null) {
               mc.field_1690.field_1867.method_23481(false);
            }
         }
      }
   }

   public static void a(EventMoveInput var0) {
      if (mc.field_1724 != null && a()) {
         if (activeMode.equals("W-Tap")) {
            var0.setForward(0.0F);
            var0.setSprint(false);
         } else if (activeMode.equals("S-Tap")) {
            var0.setForward(-1.0F);
            var0.setSprint(false);
         } else if (activeMode.equals("Legit")) {
            var0.setSprint(false);
         }
      }
   }

   public static void b() {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         resetTicks = 0;
         lastTickAge = Integer.MIN_VALUE;
      } else if (lastTickAge != mc.field_1724.field_6012) {
         lastTickAge = mc.field_1724.field_6012;
         if (resetTicks > 0) {
            resetTicks--;
            if (resetTicks == 0) {
               c();
            }
         }
      }
   }

   private static void c() {
      if (mc.field_1690 != null) {
         AutoSprint var0 = AutoSprint.getInstance();
         if (var0 != null && var0.isActive() && !var0.l()) {
            mc.field_1690.field_1867.method_23481(true);
         } else if (a(mc.field_1690.field_1867) || mc.field_1690.method_42450() != null && mc.field_1690.method_42450().method_41753()) {
            mc.field_1690.field_1867.method_23481(true);
         }
      }
   }

   private static boolean a(class_304 var0) {
      if (var0 != null && mc.method_22683() != null) {
         class_1041 var1 = mc.method_22683();
         class_306 var2 = class_3675.method_15981(var0.method_1428());
         if (var2.method_1442() == class_307.field_1668) {
            return class_3675.method_15987(var1, var2.method_1444());
         } else {
            return var2.method_1442() == class_307.field_1672 ? GLFW.glfwGetMouseButton(var1.method_4490(), var2.method_1444()) == 1 : false;
         }
      } else {
         return false;
      }
   }
}
