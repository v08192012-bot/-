package brokke.cc.core;

import net.minecraft.class_1799;

public interface ItemFilter {
   boolean a(class_1799 var1);
}
