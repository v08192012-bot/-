package brokke.cc.core;

import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventRotation;
import brokke.cc.system.events.impl.Render2DEvent;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class SilentView {
   private static final class_310 mc = class_310.method_1551();
   private static final SilentView INSTANCE = new SilentView();
   private boolean enabled;
   private boolean active;
   private float viewYaw;
   private float viewPitch;
   private long lastSteerNs;

   public static SilentView getInstance() {
      return INSTANCE;
   }

   public void a(boolean var1) {
      this.enabled = var1;
      if (!var1 && this.active) {
         this.d();
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean c() {
      return this.active && this.enabled;
   }

   public void d() {
      if (this.active && mc.field_1724 != null) {
         mc.field_1724.method_36456(this.viewYaw);
         mc.field_1724.method_36457(this.viewPitch);
      }

      this.active = false;
      this.lastSteerNs = 0L;
   }

   public float e() {
      if (this.active && this.enabled) {
         return this.viewYaw;
      } else {
         return mc.field_1724 == null ? 0.0F : mc.field_1724.method_36454();
      }
   }

   public float f() {
      if (this.active && this.enabled) {
         return this.viewPitch;
      } else {
         return mc.field_1724 == null ? 0.0F : mc.field_1724.method_36455();
      }
   }

   public boolean a(double var1, double var3) {
      if (this.active && this.enabled && mc.field_1724 != null) {
         this.viewYaw += (float)var1;
         this.viewPitch = class_3532.method_15363(this.viewPitch + (float)var3, -90.0F, 90.0F);
         return true;
      } else {
         return false;
      }
   }

   public void g() {
      if (mc.field_1724 != null && this.enabled) {
         if (!this.active) {
            this.viewYaw = mc.field_1724.method_36454();
            this.viewPitch = mc.field_1724.method_36455();
            this.active = true;
         }

         this.lastSteerNs = System.nanoTime();
      }
   }

   public void a(float var1, float var2) {
      if (mc.field_1724 != null) {
         if (!this.enabled) {
            if (this.active) {
               this.d();
            }

            mc.field_1724.method_36456(var1);
            mc.field_1724.method_36457(var2);
         } else {
            this.g();
            mc.field_1724.method_36456(var1);
            mc.field_1724.method_36457(var2);
         }
      }
   }

   @EventHandler
   public void onRotation(EventRotation var1) {
      if (this.active && this.enabled) {
         if (mc.field_1724 != null && mc.method_1560() == mc.field_1724) {
            var1.setYaw(this.viewYaw);
            var1.setPitch(this.viewPitch);
         }
      } else if (mc.field_1724 != null) {
         this.viewYaw = var1.getYaw();
         this.viewPitch = var1.getPitch();
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent var1) {
      if (this.active) {
         if (mc.field_1724 != null && this.enabled) {
            long var2 = System.nanoTime();
            if (var2 - this.lastSteerNs > 150000000L) {
               this.d();
            }
         } else {
            this.d();
         }
      }
   }
}
