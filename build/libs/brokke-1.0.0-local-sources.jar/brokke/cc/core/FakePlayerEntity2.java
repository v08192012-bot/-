package brokke.cc.core;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_638;
import net.minecraft.class_745;

public class FakePlayerEntity2 extends class_745 {
   public FakePlayerEntity2(class_638 var1, GameProfile var2) {
      super(var1, var2);
   }

   public void a() {
      this.method_31482();
      ((class_638)this.method_73183()).method_53875(this);
   }

   public void b() {
      ((class_638)this.method_73183()).method_2945(this.method_5628(), class_5529.field_26999);
      this.method_36209();
   }

   @Override
   public void method_6005(double strength, double x, double z) {
   }
}
