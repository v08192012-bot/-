package brokke.cc.core;

import brokke.cc.render.FakePlayerEntityRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1299.class_1300;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class FakePlayerRegistry {
   public static class_1299<FakePlayerEntity> FAKE_PLAYER;

   public static void a() {
      class_2960 var0 = class_2960.method_60655("brokke", "fake_player");
      class_5321 var1 = class_5321.method_29179(class_7924.field_41266, var0);
      FAKE_PLAYER = class_2378.method_39197(
         class_7923.field_41177,
         var1,
         class_1300.method_5903(FakePlayerEntity::new, class_1311.field_17715).method_17687(0.6F, 1.8F).method_27299(64).method_27300(1).method_5905(var1)
      );
      FabricDefaultAttributeRegistry.register(FAKE_PLAYER, FakePlayerEntity.a().method_26866());
      EntityRendererRegistry.register(FAKE_PLAYER, FakePlayerEntityRenderer::new);
   }
}
