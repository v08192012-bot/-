package brokke.cc.core;

import brokke.cc.util.TextNormalizer;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1293;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9323;
import net.minecraft.class_9334;

public final class PriceParser {
   private static final Pattern UNIT_PRICE = Pattern.compile("(?i)Цена за 1 ед\\.?:\\s*\\$?([\\d\\s\\u00A0.,]+)");
   private static final Pattern TOTAL_PRICE = Pattern.compile("(?i)(?:^|\\n|\\r)Цена:\\s*\\$?([\\d\\s\\u00A0.,]+)");
   private static final Pattern FUNTIME_DOLLAR_PRICE = Pattern.compile("\\$([0-9][0-9\\s,._]*)");
   private static final Pattern DOLLAR_SUFFIX_PRICE = Pattern.compile("([0-9][0-9\\s,._]*)\\s*\\$");
   private static final Pattern GENERAL_PRICE = Pattern.compile("(?i)(?:цена|стоимость|price)[:\\s]*\\$?([0-9][0-9\\s,._]*)");
   private static final Pattern DURABILITY = Pattern.compile("(?:Прочность|Прочка|Durability)[^\\d]*([\\d]+)\\s*%");
   private static final Pattern SELLER = Pattern.compile("(?:Продавец|Seller|Игрок|Владелец)[:\\s]+([A-Za-z0-9_]{2,32})");
   private static final Pattern COUNT_X = Pattern.compile("(?i)(?:^|\\s)[xх]([0-9]{1,4})(?:$|\\s)");
   private static final Pattern COUNT_PCS = Pattern.compile("(?i)(?:^|\\s)([0-9]{1,4})\\s*(?:шт|pcs|ед)");
   private static final Pattern COUNT_LORE = Pattern.compile("(?i)(?:Количество|Кол-во)[:\\s]*([0-9]{1,4})");

   private PriceParser() {
   }

   public static Lot a(int var0, class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         if (var1.method_7909() == class_1802.field_8077) {
            return Lot.a(var0);
         }

         String var2 = var1.method_7964().getString();
         String var3 = d(var1);
         int var4 = b(var1, var3);
         long var5 = a(UNIT_PRICE, var3);
         long var7 = a(TOTAL_PRICE, var3);
         if (var5 <= 0L && var7 <= 0L) {
            long var9 = c(var1);
            if (var9 > 0L) {
               var7 = var9;
            }
         }

         if (var5 <= 0L && var7 <= 0L) {
            long var18 = a(FUNTIME_DOLLAR_PRICE, var3);
            if (var18 > 0L) {
               var7 = var18;
            }
         }

         if (var5 <= 0L && var7 <= 0L) {
            long var19 = a(DOLLAR_SUFFIX_PRICE, var3);
            if (var19 > 0L) {
               var7 = var19;
            }
         }

         if (var5 <= 0L && var7 <= 0L) {
            long var20 = a(GENERAL_PRICE, var3);
            if (var20 > 0L) {
               var7 = var20;
            }
         }

         if (var5 <= 0L && var7 > 0L && var4 > 0) {
            var5 = var7 / var4;
         } else if (var5 > 0L && var7 <= 0L && var4 > 0) {
            var7 = var5 * var4;
         }

         if (var5 <= 0L) {
            return null;
         }

         String var21 = class_7923.field_41178.method_10221(var1.method_7909()).toString();
         int var10 = a(var1, var3);
         String var11 = "";
         Matcher var12 = SELLER.matcher(var3);
         if (var12.find()) {
            var11 = var12.group(1);
         }

         HashMap var13 = new HashMap();
         HashSet var14 = new HashSet();
         HashMap var15 = new HashMap();
         boolean var16 = a(var1, var13, var14, var15);
         Lot var17 = new Lot(var0, var21, var2, var3, var11, var4, var5, var7, var10, false, var16, var13, var14, var15);
         var17.potionEffects = b(var1);
         var17.sharpness = c(var1, var3);
         return var17;
      } else {
         return null;
      }
   }

   public static Lot a(class_1799 var0) {
      if (var0 != null && !var0.method_7960() && var0.method_7909() != class_1802.field_8077) {
         String var1 = var0.method_7964().getString();
         String var2 = d(var0);
         String var3 = class_7923.field_41178.method_10221(var0.method_7909()).toString();
         int var4 = a(var0, var2);
         HashMap var5 = new HashMap();
         HashSet var6 = new HashSet();
         HashMap var7 = new HashMap();
         boolean var8 = a(var0, var5, var6, var7);
         Lot var9 = new Lot(-1, var3, var1, var2, "", var0.method_7947(), 0L, 0L, var4, false, var8, var5, var6, var7);
         var9.potionEffects = b(var0);
         var9.sharpness = c(var0, var2);
         return var9;
      } else {
         return null;
      }
   }

   private static Set<String> b(class_1799 var0) {
      HashSet var1 = new HashSet();

      try {
         class_1844 var2 = var0.method_58694(class_9334.field_49651);
         if (var2 != null) {
            for (class_1293 var4 : var2.method_57397()) {
               var1.add(var4.method_5579().method_55840());
            }
         }
      } catch (Throwable var5) {
      }

      return var1;
   }

   private static boolean a(class_1799 var0, Map<String, String> var1, Set<String> var2, Map<String, String> var3) {
      boolean var4 = false;

      try {
         if (var0.method_58694(class_9334.field_49631) != null) {
            var4 = true;
         }
      } catch (Throwable var16) {
      }

      try {
         class_9304 var5 = var0.method_58694(class_9334.field_49633);
         if (var5 != null && !var5.method_57543()) {
            var4 = true;
         }
      } catch (Throwable var151) {
      }

      try {
         class_9279 var19 = var0.method_58694(class_9334.field_49628);
         if (var19 == null || var19.method_57458()) {
            return var4;
         }

         var4 = true;
         class_2487 var6 = var19.method_57461();
         if (var6 == null) {
            return var4;
         }

         if (var6.method_10580("PublicBukkitValues") instanceof class_2487 var8) {
            for (String var10 : var8.method_10541()) {
               var1.put(var10, a(var8.method_10580(var10)));
            }
         }

         class_2520 var20 = var6.method_10580("Enchantments");
         if (var20 instanceof class_2499) {
            for (class_2520 var11 : (class_2499)var20) {
               if (var11 instanceof class_2487 var12) {
                  class_2520 var13 = var12.method_10580("id");
                  if (var13 != null) {
                     String var14 = a(var13);
                     if (var14 != null && !var14.isEmpty() && !var14.startsWith("minecraft:")) {
                        var2.add(var14);
                     }
                  }
               }
            }
         }

         for (String var24 : var6.method_10541()) {
            if (!var24.equals("PublicBukkitValues")
               && !var24.equals("Enchantments")
               && !var24.equals("display")
               && !var24.equals("HideFlags")
               && !var24.startsWith("VV|")) {
               class_2520 var25 = var6.method_10580(var24);
               if (var25 != null) {
                  if (var25 instanceof class_2487 var26) {
                     for (String var28 : var26.method_10541()) {
                        class_2520 var15 = var26.method_10580(var28);
                        if (var15 != null && !(var15 instanceof class_2487) && !(var15 instanceof class_2499)) {
                           var3.put(var24 + "." + var28, a(var15));
                        }
                     }
                  } else if (!(var25 instanceof class_2499)) {
                     var3.put(var24, a(var25));
                  }
               }
            }
         }
      } catch (Throwable var17) {
      }

      return var4;
   }

   private static String a(class_2520 var0) {
      if (var0 == null) {
         return "";
      }

      String var1 = var0.toString();
      if (!(var0 instanceof class_2519)) {
         if (!var1.isEmpty()) {
            char var2 = var1.charAt(var1.length() - 1);
            if ("bBsSlLfFdD".indexOf(var2) >= 0 && var1.length() > 1) {
               String var3 = var1.substring(0, var1.length() - 1);
               if (var3.matches("-?\\d+(\\.\\d+)?")) {
                  return var3;
               }
            }
         }

         return var1;
      } else {
         if (var1.length() >= 2 && var1.charAt(0) == '"' && var1.charAt(var1.length() - 1) == '"') {
            var1 = var1.substring(1, var1.length() - 1).replace("\\\"", "\"").replace("\\\\", "\\");
         } else if (var1.length() >= 2 && var1.charAt(0) == '\'' && var1.charAt(var1.length() - 1) == '\'') {
            var1 = var1.substring(1, var1.length() - 1).replace("\\'", "'").replace("\\\\", "\\");
         }

         return var1;
      }
   }

   private static int a(class_1799 var0, String var1) {
      Matcher var2 = DURABILITY.matcher(var1);
      if (var2.find()) {
         try {
            return a(Integer.parseInt(var2.group(1)));
         } catch (NumberFormatException var4) {
         }
      }

      if (var0.method_7963() && var0.method_7936() > 0) {
         int var3 = var0.method_7936() - var0.method_7919();
         return a((int)Math.round(var3 * 100.0 / var0.method_7936()));
      } else {
         return 100;
      }
   }

   private static int a(int var0) {
      return Math.max(0, Math.min(100, var0));
   }

   private static int b(class_1799 var0, String var1) {
      Matcher var2 = COUNT_X.matcher(var1);
      if (var2.find()) {
         try {
            int var3 = Integer.parseInt(var2.group(1));
            if (var3 > 0) {
               return var3;
            }
         } catch (NumberFormatException var8) {
         }
      }

      Matcher var9 = COUNT_PCS.matcher(var1);
      if (var9.find()) {
         try {
            int var4 = Integer.parseInt(var9.group(1));
            if (var4 > 0) {
               return var4;
            }
         } catch (NumberFormatException var7) {
         }
      }

      Matcher var10 = COUNT_LORE.matcher(var1);
      if (var10.find()) {
         try {
            int var5 = Integer.parseInt(var10.group(1));
            if (var5 > 0) {
               return var5;
            }
         } catch (NumberFormatException var6) {
         }
      }

      return Math.max(1, var0.method_7947());
   }

   private static long c(class_1799 var0) {
      try {
         class_9323 var1 = var0.method_57353();
         if (var1 != null) {
            String var2 = var1.toString();
            int var3 = var2.indexOf("literal{ $");
            if (var3 != -1) {
               int var4 = var2.indexOf("}[style={color=", var3);
               if (var4 != -1) {
                  String var5 = var2.substring(var3 + 10, var4).replaceAll("[^0-9]", "");
                  if (!var5.isEmpty()) {
                     long var6 = Long.parseLong(var5);
                     if (var6 > 0L) {
                        return var6;
                     }
                  }
               }
            }
         }
      } catch (Throwable var8) {
      }

      return -1L;
   }

   private static long a(Pattern var0, String var1) {
      Matcher var2 = var0.matcher(var1);
      if (!var2.find()) {
         return -1L;
      }

      String var3 = var2.group(1).replaceAll("[\\s\\u00A0.,_]+", "");
      if (var3.isEmpty()) {
         return -1L;
      }

      try {
         return Long.parseLong(var3);
      } catch (NumberFormatException var5) {
         return -1L;
      }
   }

   private static String d(class_1799 var0) {
      StringBuilder var1 = new StringBuilder();
      class_310 var2 = class_310.method_1551();

      try {
         class_9635 var3 = var2.field_1687 != null ? class_9635.method_59528(var2.field_1687) : class_9635.field_51353;
         List var4 = var0.method_7950(var3, var2.field_1724, class_1836.field_41071);
         if (var4 != null) {
            for (class_2561 var6 : (Iterable<class_2561>)(Iterable<?>)(var4)) {
               if (var6 != null) {
                  var1.append(var6.getString()).append('\n');
               }
            }
         }
      } catch (Throwable var10) {
      }

      class_9290 var11 = var0.method_58694(class_9334.field_49632);
      if (var11 != null) {
         for (class_2561 var14 : var11.comp_2400()) {
            if (var14 != null) {
               var1.append(var14.getString()).append('\n');
            }
         }
      }

      try {
         class_9304 var13 = var0.method_58694(class_9334.field_49633);
         if (var13 != null) {
            for (Entry var16 : var13.method_57539()) {
               String var7 = ((class_6880<?>)var16.getKey()).method_40230().map(var0x -> var0x.method_29177().method_12832()).orElse("");
               int var8 = var16.getIntValue();
               if (var7.contains("sharpness") || var7.contains("острота")) {
                  var1.append("Острота ").append(var8).append('\n');
                  var1.append("Острота ").append(b(var8)).append('\n');
                  var1.append("Sharpness ").append(var8).append('\n');
                  var1.append("Sharpness ").append(b(var8)).append('\n');
               }
            }
         }
      } catch (Throwable var9) {
      }

      return var1.toString();
   }

   private static int c(class_1799 var0, String var1) {
      try {
         class_9304 var2 = var0.method_58694(class_9334.field_49633);
         if (var2 != null) {
            for (Entry var4 : var2.method_57539()) {
               String var5 = ((class_6880<?>)var4.getKey()).method_40230().map(var0x -> var0x.method_29177().method_12832()).orElse("");
               if (var5.contains("sharpness") || var5.contains("острота")) {
                  return var4.getIntValue();
               }
            }
         }
      } catch (Throwable var6) {
      }

      String var7 = var1.toLowerCase(Locale.ROOT);
      String var8 = TextNormalizer.a(var1);
      if (var8.contains("острота 10")
         || var8.contains("sharpness 10")
         || var8.contains("острота x")
         || var8.contains("sharpness x")
         || var7.contains("острота 10")
         || var7.contains("sharpness 10")
         || var7.contains("острота x")
         || var7.contains("sharpness x")
         || var7.contains("острота ⅹ")
         || var7.contains("sharpness ⅹ")) {
         return 10;
      } else if (var8.contains("острота 9")
         || var8.contains("sharpness 9")
         || var8.contains("острота ix")
         || var8.contains("sharpness ix")
         || var7.contains("острота 9")
         || var7.contains("sharpness 9")
         || var7.contains("острота ix")
         || var7.contains("sharpness ix")
         || var7.contains("острота ⅸ")
         || var7.contains("sharpness ⅸ")) {
         return 9;
      } else if (var8.contains("острота 8")
         || var8.contains("sharpness 8")
         || var8.contains("острота viii")
         || var8.contains("sharpness viii")
         || var7.contains("острота 8")
         || var7.contains("sharpness 8")
         || var7.contains("острота viii")
         || var7.contains("sharpness viii")
         || var7.contains("острота ⅷ")
         || var7.contains("sharpness ⅷ")) {
         return 8;
      } else if (var8.contains("острота 7")
         || var8.contains("sharpness 7")
         || var8.contains("острота vii")
         || var8.contains("sharpness vii")
         || var7.contains("острота 7")
         || var7.contains("sharpness 7")
         || var7.contains("острота vii")
         || var7.contains("sharpness vii")
         || var7.contains("острота Ⅶ")
         || var7.contains("sharpness Ⅶ")
         || var7.contains("острота ⅶ")
         || var7.contains("sharpness ⅶ")) {
         return 7;
      } else if (var8.contains("острота 6")
         || var8.contains("sharpness 6")
         || var8.contains("острота vi")
         || var8.contains("sharpness vi")
         || var7.contains("острота 6")
         || var7.contains("sharpness 6")
         || var7.contains("острота vi")
         || var7.contains("sharpness vi")
         || var7.contains("острота ⅵ")
         || var7.contains("sharpness ⅵ")) {
         return 6;
      } else if (var8.contains("острота 5")
         || var8.contains("sharpness 5")
         || var8.contains("острота v")
         || var8.contains("sharpness v")
         || var7.contains("острота 5")
         || var7.contains("sharpness 5")
         || var7.contains("острота v")
         || var7.contains("sharpness v")
         || var7.contains("острота ⅴ")
         || var7.contains("sharpness ⅴ")) {
         return 5;
      } else if (var8.contains("острота 4")
         || var8.contains("sharpness 4")
         || var8.contains("острота iv")
         || var8.contains("sharpness iv")
         || var7.contains("острота 4")
         || var7.contains("sharpness 4")
         || var7.contains("острота iv")
         || var7.contains("sharpness iv")
         || var7.contains("острота ⅳ")
         || var7.contains("sharpness ⅳ")) {
         return 4;
      } else if (var8.contains("острота 3")
         || var8.contains("sharpness 3")
         || var8.contains("острота iii")
         || var8.contains("sharpness iii")
         || var7.contains("острота 3")
         || var7.contains("sharpness 3")
         || var7.contains("острота iii")
         || var7.contains("sharpness iii")
         || var7.contains("острота ⅲ")
         || var7.contains("sharpness ⅲ")) {
         return 3;
      } else if (!var8.contains("острота 2")
         && !var8.contains("sharpness 2")
         && !var8.contains("острота ii")
         && !var8.contains("sharpness ii")
         && !var7.contains("острота 2")
         && !var7.contains("sharpness 2")
         && !var7.contains("острота ii")
         && !var7.contains("sharpness ii")
         && !var7.contains("острота ⅱ")
         && !var7.contains("sharpness ⅱ")) {
         return !var8.contains("острота 1")
               && !var8.contains("sharpness 1")
               && !var8.contains("острота i")
               && !var8.contains("sharpness i")
               && !var7.contains("острота 1")
               && !var7.contains("sharpness 1")
               && !var7.contains("острота i")
               && !var7.contains("sharpness i")
               && !var7.contains("острота ⅰ")
               && !var7.contains("sharpness ⅰ")
            ? 0
            : 1;
      } else {
         return 2;
      }
   }

   private static String b(int var0) {
      return switch (var0) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> String.valueOf(var0);
      };
   }
}
