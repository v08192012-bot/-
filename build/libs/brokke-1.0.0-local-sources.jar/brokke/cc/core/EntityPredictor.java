package brokke.cc.core;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_5134;

public final class EntityPredictor {
   private static final class_310 mc = class_310.method_1551();

   public static float a(class_1309 var0, double var1, boolean var3, boolean var4) {
      if (mc.field_1687 != null && var0 != null) {
         float var5 = 0.0F;
         class_238 var6 = var0.method_5829().method_1014(var1);

         for (class_1297 var8 : mc.field_1687.method_8335(var0, var6)) {
            if (var3 && var8 instanceof class_1511) {
               float var10 = a(var8.method_73189(), var0);
               if (var10 > var5) {
                  var5 = var10;
               }
            } else if (var4 && var8 instanceof class_1541) {
               float var9 = a(var8.method_73189(), var0);
               if (var9 > var5) {
                  var5 = var9;
               }
            }
         }

         return var5;
      } else {
         return 0.0F;
      }
   }

   public static float a(class_243 var0, class_1309 var1) {
      if (mc.field_1687 != null && var1 != null) {
         double var2 = 12.0;
         double var4 = var0.method_1022(var1.method_73189()) / var2;
         if (var4 > 1.0) {
            return 0.0F;
         }

         double var6 = a(var0, (class_1297)var1);
         double var8 = (1.0 - var4) * var6;
         float var10 = (float)((var8 * var8 + var8) / 2.0 * 7.0 * var2 + 1.0);
         class_1282 var11 = mc.field_1687.method_48963().method_48819(null, null);
         float var12 = a(var10);
         float var13 = a(var1, var12);
         return b(var1, var13);
      } else {
         return 0.0F;
      }
   }

   private static double a(class_243 var0, class_1297 var1) {
      class_238 var2 = var1.method_5829();
      double var3 = 1.0 / (var2.method_17939() * 2.0 + 1.0);
      double var5 = 1.0 / (var2.method_17940() * 2.0 + 1.0);
      double var7 = 1.0 / (var2.method_17941() * 2.0 + 1.0);
      double var9 = (1.0 - Math.floor(1.0 / var3) * var3) / 2.0;
      double var11 = (1.0 - Math.floor(1.0 / var7) * var7) / 2.0;
      if (!(var3 < 0.0) && !(var5 < 0.0) && !(var7 < 0.0)) {
         int var13 = 0;
         int var14 = 0;

         for (double var15 = 0.0; var15 <= 1.0; var15 += var3) {
            for (double var17 = 0.0; var17 <= 1.0; var17 += var5) {
               for (double var19 = 0.0; var19 <= 1.0; var19 += var7) {
                  double var21 = class_3532.method_16436(var15, var2.field_1323, var2.field_1320);
                  double var23 = class_3532.method_16436(var17, var2.field_1322, var2.field_1325);
                  double var25 = class_3532.method_16436(var19, var2.field_1321, var2.field_1324);
                  class_243 var27 = new class_243(var21 + var9, var23, var25 + var11);
                  class_3965 var28 = mc.field_1687.method_17742(new class_3959(var0, var27, class_3960.field_17558, class_242.field_1348, var1));
                  if (var28.method_17783() == class_240.field_1333) {
                     var14++;
                  } else {
                     class_2338 var29 = var28.method_17777();
                     class_2680 var30 = mc.field_1687.method_8320(var29);
                     if (var30.method_26204() != class_2246.field_10540 && var30.method_26204() != class_2246.field_9987 && var30.method_26204() != class_2246.field_23152) {
                        var14++;
                     }
                  }

                  var13++;
               }
            }
         }

         return var13 == 0 ? 0.0 : (double)var14 / var13;
      } else {
         return 0.0;
      }
   }

   private static float a(float var0) {
      if (mc.field_1687 == null) {
         return var0;
      }

      return switch (mc.field_1687.method_8407()) {
         case field_5801 -> 0.0F;
         case field_5805 -> Math.min(var0 / 2.0F + 1.0F, var0);
         case field_5807 -> var0 * 1.5F;
         default -> var0;
      };
   }

   private static float a(class_1309 var0, float var1) {
      int var2 = var0.method_6096();
      float var3 = (float)var0.method_45325(class_5134.field_23725);
      float var4 = 2.0F + var3 / 4.0F;
      float var5 = class_3532.method_15363(var2 - var1 / var4, var2 * 0.2F, 20.0F);
      return var1 * (1.0F - var5 / 25.0F);
   }

   private static float b(class_1309 var0, float var1) {
      return var1;
   }

   private EntityPredictor() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
