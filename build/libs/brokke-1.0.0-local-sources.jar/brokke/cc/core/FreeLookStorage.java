package brokke.cc.core;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.EventPriority;
import brokke.cc.system.events.impl.EventRotation;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class FreeLookStorage {
   private static final class_310 mc = class_310.method_1551();
   private static final FreeLookStorage INSTANCE = new FreeLookStorage();
   private static boolean active;
   private static float freeYaw;
   private static float freePitch;
   private static boolean registered;

   public static FreeLookStorage a() {
      if (!registered) {
         EventBus.register(INSTANCE);
         registered = true;
      }

      return INSTANCE;
   }

   public static boolean isActive() {
      return active;
   }

   public static void a(boolean var0) {
      a();
      if (var0 && !active && mc.field_1724 != null) {
         freeYaw = mc.field_1724.method_36454();
         freePitch = mc.field_1724.method_36455();
      }

      active = var0;
   }

   public static float getFreeYaw() {
      return freeYaw;
   }

   public static void setFreeYaw(float var0) {
      freeYaw = var0;
   }

   public static float getFreePitch() {
      return freePitch;
   }

   public static void setFreePitch(float var0) {
      freePitch = var0;
   }

   public static void a(double var0, double var2) {
      freeYaw += (float)(var0 * 0.15);
      freePitch = class_3532.method_15363(freePitch + (float)(var2 * 0.15), -90.0F, 90.0F);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onRotation(EventRotation var1) {
      if (active) {
         var1.setYaw(freeYaw);
         var1.setPitch(freePitch);
      } else if (mc.field_1724 != null) {
         freeYaw = var1.getYaw();
         freePitch = var1.getPitch();
      }
   }
}
