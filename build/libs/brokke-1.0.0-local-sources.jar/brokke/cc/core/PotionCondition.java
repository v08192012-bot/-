package brokke.cc.core;

import java.util.stream.StreamSupport;
import net.minecraft.class_1291;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public record PotionCondition(class_6880<class_1291> effect, int level, int duration) {
   public PotionCondition {
      if (effect == null) {
         throw new IllegalArgumentException("Effect cannot be null");
      }
   }

   public boolean a(class_1799 var1) {
      class_1844 var2 = var1.method_58694(class_9334.field_49651);
      return var2 == null
         ? false
         : StreamSupport.stream(var2.method_57397().spliterator(), false)
            .anyMatch(var1x -> var1x.method_5579().equals(this.effect) && var1x.method_5578() + 1 == this.level && var1x.method_5584() >= this.duration);
   }

   public class_6880<class_1291> getEffect() {
      return this.effect;
   }

   public int getLevel() {
      return this.level;
   }

   public int getDuration() {
      return this.duration;
   }
}
