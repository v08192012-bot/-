package brokke.cc.core;

import net.minecraft.class_1792;
import net.minecraft.class_1802;

public enum SwapItem {
   a("Shield", class_1802.field_8255),
   b("Gapple", class_1802.field_8367),
   c("Totem", class_1802.field_8288),
   d("PlayerHead", class_1802.field_8575),
   e("Firework", class_1802.field_8639);

   private final String f;
   private final class_1792 g;

   SwapItem(String nullxx, class_1792 nullxxx) {
      this.f = nullxx;
      this.g = nullxxx;
   }

   public class_1792 getG() {
      return this.g;
   }

   @Override
   public String toString() {
      return this.f;
   }
}
