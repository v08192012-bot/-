package brokke.cc.core;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;

public final class AuraChecks {
   private AuraChecks() {
   }

   public static boolean a(class_310 var0) {
      if (var0.field_1724 == null) {
         return false;
      }

      class_1799 var1 = var0.field_1724.method_6047();
      return var1.method_7960()
         ? false
         : var1.method_31574(class_1802.field_8091)
            || var1.method_31574(class_1802.field_8528)
            || var1.method_31574(class_1802.field_8371)
            || var1.method_31574(class_1802.field_8845)
            || var1.method_31574(class_1802.field_8802)
            || var1.method_31574(class_1802.field_22022)
            || var1.method_31574(class_1802.field_8406)
            || var1.method_31574(class_1802.field_8062)
            || var1.method_31574(class_1802.field_8475)
            || var1.method_31574(class_1802.field_8825)
            || var1.method_31574(class_1802.field_8556)
            || var1.method_31574(class_1802.field_22025)
            || var1.method_31574(class_1802.field_8547)
            || var1.method_31574(class_1802.field_49814);
   }

   public static boolean b(class_310 var0) {
      if (var0.field_1724 != null && var0.field_1687 != null) {
         class_238 var1 = var0.field_1724.method_5829();
         class_238 var2 = new class_238(var1.field_1323 - 0.06, var1.field_1322 + 0.05, var1.field_1321 - 0.06, var1.field_1320 + 0.06, var1.field_1325 - 0.05, var1.field_1324 + 0.06);
         return class_2338.method_29715(var2)
            .anyMatch(
               var2xx -> {
                  class_2680 var3 = var0.field_1687.method_8320(var2xx);
                  return !var3.method_26220(var0.field_1687, var2xx).method_1110()
                     && var3.method_26220(var0.field_1687, var2xx)
                        .method_1090()
                        .stream()
                        .map(var1xx -> var1xx.method_989(var2xx.method_10263(), var2xx.method_10264(), var2xx.method_10260()))
                        .anyMatch(var2::method_994);
               }
            );
      } else {
         return false;
      }
   }

   public static boolean a(class_310 var0, class_1297 var1) {
      if (var1 != null && var0.field_1724 != null && var0.field_1687 != null) {
         class_243 var2 = var0.field_1724.method_33571();
         if (a(var0, var2, var1.method_33571())) {
            return true;
         } else if (a(var0, var2, var1.method_5829().method_1005())) {
            return true;
         } else {
            class_238 var3 = var1.method_5829();
            if (a(var0, var2, new class_243(var3.method_1005().field_1352, var3.field_1322 + var3.method_17940() * 0.75, var3.method_1005().field_1350))) {
               return true;
            } else {
               return a(var0, var2, new class_243(var3.method_1005().field_1352, var3.field_1322 + var3.method_17940() * 0.25, var3.method_1005().field_1350))
                  ? true
                  : a(var0, var2, new class_243(var3.method_1005().field_1352, var3.field_1322 + 0.1, var3.method_1005().field_1350));
            }
         }
      } else {
         return false;
      }
   }

   private static boolean a(class_310 var0, class_243 var1, class_243 var2) {
      return var0.field_1687.method_17742(new class_3959(var1, var2, class_3960.field_17558, class_242.field_1348, var0.field_1724)).method_17783() == class_240.field_1333;
   }

   public static boolean b(class_310 var0, class_1297 var1) {
      if (var1 != null && var0.field_1724 != null && var0.field_1687 != null) {
         class_3965 var2 = var0.field_1687
            .method_17742(new class_3959(var0.field_1724.method_33571(), var1.method_33571(), class_3960.field_17559, class_242.field_1348, var0.field_1724));
         if (var2.method_17783() != class_240.field_1332) {
            return false;
         }

         class_3965 var3 = var2;
         class_2680 var4 = var0.field_1687.method_8320(var3.method_17777());
         return var4.method_27852(class_2246.field_10479)
            || var4.method_27852(class_2246.field_10214)
            || var4.method_27852(class_2246.field_10112)
            || var4.method_27852(class_2246.field_10313)
            || var4.method_27852(class_2246.field_10428)
            || var4.method_27852(class_2246.field_10376)
            || var4.method_27852(class_2246.field_10238)
            || var4.method_27852(class_2246.field_9993)
            || var4.method_27852(class_2246.field_10463)
            || var4.method_27852(class_2246.field_10620)
            || var4.method_27852(class_2246.field_10020)
            || var4.method_27852(class_2246.field_10299)
            || var4.method_27852(class_2246.field_10319)
            || var4.method_27852(class_2246.field_10144)
            || var4.method_27852(class_2246.field_42747)
            || var4.method_27852(class_2246.field_10132)
            || var4.method_27852(class_2246.field_54728)
            || var4.method_27852(class_2246.field_37565)
            || var4.method_27852(class_2246.field_40290)
            || var4.method_27852(class_2246.field_22132)
            || var4.method_27852(class_2246.field_22133)
            || var4.method_27852(class_2246.field_10364);
      } else {
         return false;
      }
   }

   public static boolean c(class_310 var0) {
      if (var0.field_1724 != null && var0.field_1687 != null) {
         class_238 var1 = var0.field_1724.method_5829().method_1014(0.001);
         int var2 = class_3532.method_15357(var1.field_1323);
         int var3 = class_3532.method_15357(var1.field_1322);
         int var4 = class_3532.method_15357(var1.field_1321);
         int var5 = class_3532.method_15357(var1.field_1320);
         int var6 = class_3532.method_15357(var1.field_1325);
         int var7 = class_3532.method_15357(var1.field_1324);

         for (class_2338 var9 : class_2338.method_10094(var2, var3, var4, var5, var6, var7)) {
            if (var0.field_1687.method_8320(var9).method_27852(class_2246.field_10343)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean d(class_310 var0) {
      if (var0.field_1724 != null && var0.field_1687 != null) {
         class_238 var1 = var0.field_1724.method_5829().method_1011(0.05);
         int var2 = class_3532.method_15357(var1.field_1323);
         int var3 = class_3532.method_15357(var1.field_1322);
         int var4 = class_3532.method_15357(var1.field_1321);
         int var5 = class_3532.method_15357(var1.field_1320);
         int var6 = class_3532.method_15357(var1.field_1325);
         int var7 = class_3532.method_15357(var1.field_1324);

         for (class_2338 var9 : class_2338.method_10094(var2, var3, var4, var5, var6, var7)) {
            if (!var0.field_1687.method_8320(var9).method_26215()) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean c(class_310 var0, class_1297 var1) {
      return var1 != null && var0.field_1724 != null && var0.field_1687 != null ? !a(var0, var1) : false;
   }
}
