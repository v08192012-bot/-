package brokke.cc.core;

import net.minecraft.class_1799;

public class OffhandSlot extends ItemSlot {
   @Override
   public class_1799 a() {
      return mc.field_1724 != null ? mc.field_1724.method_6079() : class_1799.field_8037;
   }

   @Override
   public int get45() {
      return 45;
   }
}
