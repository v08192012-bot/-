package brokke.cc.core;

import net.minecraft.class_1799;

public class InventorySlot extends ItemSlot {
   private final int slotId;

   public InventorySlot(int var1) {
      if (var1 >= 0 && var1 <= 26) {
         this.slotId = var1;
      } else {
         throw new IllegalArgumentException("Inventory Slot ID must be between 0 and 26");
      }
   }

   @Override
   public class_1799 a() {
      return mc.field_1724 != null && mc.field_1724.method_31548() != null ? mc.field_1724.method_31548().method_5438(this.slotId + 9) : class_1799.field_8037;
   }

   @Override
   public int get45() {
      return this.slotId + 9;
   }

   public int getSlotId() {
      return this.slotId;
   }
}
