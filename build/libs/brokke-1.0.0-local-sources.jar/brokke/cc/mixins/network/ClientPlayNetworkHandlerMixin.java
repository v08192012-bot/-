package brokke.cc.mixins.network;

import brokke.cc.manager.CommandManager;
import brokke.cc.module.misc.ChatHelper;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.EventPopTotem;
import brokke.cc.system.events.impl.PotionEvent;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2663;
import net.minecraft.class_2664;
import net.minecraft.class_2673;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import net.minecraft.class_2739;
import net.minecraft.class_2743;
import net.minecraft.class_2767;
import net.minecraft.class_2781;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {
   private static final class_310 mc = class_310.method_1551();

   @ModifyVariable(method = "sendChatMessage(Ljava/lang/String;)V", at = @At("HEAD"), argsOnly = true)
   private String onModifySendChatMessage(String var1) {
      return ChatHelper.a(var1);
   }

   @Inject(method = "sendChatMessage(Ljava/lang/String;)V", at = @At("HEAD"), cancellable = true)
   private void onSendChatMessage(String var1, CallbackInfo var2) {
      if (var1 != null && CommandManager.c(var1)) {
         var2.cancel();
      }
   }

   @ModifyVariable(method = "sendChatCommand(Ljava/lang/String;)V", at = @At("HEAD"), argsOnly = true)
   private String onModifySendChatCommand(String var1) {
      return ChatHelper.b(var1);
   }

   @Inject(method = "onEntityStatus(Lnet/minecraft/network/packet/s2c/play/EntityStatusS2CPacket;)V", at = @At("HEAD"))
   private void onEntityStatus(class_2663 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onEntityStatus(Lnet/minecraft/network/packet/s2c/play/EntityStatusS2CPacket;)V", at = @At("TAIL"))
   private void onEntityStatusTail(class_2663 var1, CallbackInfo var2) {
      if (var1.method_11470() == 35 && mc.field_1687 != null && var1.method_11469(mc.field_1687) instanceof class_1657 var3) {
         EventBus.post(new EventPopTotem(var3));
      }
   }

   @Inject(method = "onGameMessage(Lnet/minecraft/network/packet/s2c/play/GameMessageS2CPacket;)V", at = @At("HEAD"))
   private void onGameMessagePacket(class_7439 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onChunkDeltaUpdate(Lnet/minecraft/network/packet/s2c/play/ChunkDeltaUpdateS2CPacket;)V", at = @At("HEAD"))
   private void onChunkDeltaUpdatePacket(class_2637 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onBlockUpdate(Lnet/minecraft/network/packet/s2c/play/BlockUpdateS2CPacket;)V", at = @At("HEAD"))
   private void onBlockUpdatePacket(class_2626 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onPlaySound(Lnet/minecraft/network/packet/s2c/play/PlaySoundS2CPacket;)V", at = @At("HEAD"))
   private void onPlaySoundPacket(class_2767 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onParticle(Lnet/minecraft/network/packet/s2c/play/ParticleS2CPacket;)V", at = @At("HEAD"))
   private void onParticlePacket(class_2675 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onEntityTrackerUpdate(Lnet/minecraft/network/packet/s2c/play/EntityTrackerUpdateS2CPacket;)V", at = @At("HEAD"))
   private void onEntityTrackerUpdatePacket(class_2739 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onEntityAttributes(Lnet/minecraft/network/packet/s2c/play/EntityAttributesS2CPacket;)V", at = @At("HEAD"))
   private void onEntityAttributesPacket(class_2781 var1, CallbackInfo var2) {
      EventBus.post(new EventPacket(var1));
   }

   @Inject(method = "onPlayerPositionLook(Lnet/minecraft/network/packet/s2c/play/PlayerPositionLookS2CPacket;)V", at = @At("HEAD"), cancellable = true)
   private void onPlayerPositionLookPacket(class_2708 var1, CallbackInfo var2) {
      EventPacket var3 = new EventPacket(var1);
      EventBus.post(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }

   @Inject(method = "onEntityVelocityUpdate(Lnet/minecraft/network/packet/s2c/play/EntityVelocityUpdateS2CPacket;)V", at = @At("HEAD"), cancellable = true)
   private void onEntityVelocityUpdatePacket(class_2743 var1, CallbackInfo var2) {
      if (mc.field_1687 != null
         && mc.field_1687.method_8469(var1.method_11818()) instanceof class_1542 var4
         && (
            var4.method_24828()
               || var4.field_5992
               || var4.method_73183() != null && !var4.method_73183().method_8587(var4, var4.method_5829().method_989(0.0, -0.2, 0.0))
         )) {
         class_243 var5 = var1.method_73085();
         if (Math.abs(var5.field_1351) < 0.25) {
            var2.cancel();
            return;
         }
      }

      EventPacket var6 = new EventPacket(var1);
      EventBus.post(var6);
      if (var6.isCancelled()) {
         var2.cancel();
      }
   }

   @Inject(method = "onExplosion(Lnet/minecraft/network/packet/s2c/play/ExplosionS2CPacket;)V", at = @At("HEAD"), cancellable = true)
   private void onExplosionPacket(class_2664 var1, CallbackInfo var2) {
      EventPacket var3 = new EventPacket(var1);
      EventBus.post(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }

   @Inject(method = "onWorldEvent(Lnet/minecraft/network/packet/s2c/play/WorldEventS2CPacket;)V", at = @At("HEAD"))
   private void onWorldEventPacket(class_2673 var1, CallbackInfo var2) {
      if (var1.method_11532() == 2002) {
         EventBus.post(new PotionEvent(PotionEvent.Type.PARTICLES, var1.method_11534(), var1.method_11531()));
      }
   }
}
