package brokke.cc.mixins.network;

import brokke.cc.core.SlotTracker;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.SendPacketEvent;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public abstract class ClientConnectionMixin {
   private static final class_310 mc = class_310.method_1551();
   @Unique
   private static boolean stackOverflowFix;

   @Shadow
   public abstract boolean isLocal();

   @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
   public void triggerSendPacketEvent(class_2596<?> var1, CallbackInfo var2) {
      if (var1 instanceof class_2868 var3) {
         int var4 = var3.method_12442();
         if (var4 < 0 || var4 > 8 || var4 == SlotTracker.serverHeldItemSlot) {
            var2.cancel();
            return;
         }

         SlotTracker.serverHeldItemSlot = var4;
      }

      SendPacketEvent var5 = new SendPacketEvent(var1);
      if (!stackOverflowFix) {
         EventBus.post(var5);
         if (var5.isCancelled()) {
            var2.cancel();
            return;
         }

         class_2596 var6 = var5.getPacket();
         if (var6 != var1) {
            var2.cancel();
            stackOverflowFix = true;
            if (mc.method_1562() != null) {
               mc.method_1562().method_52787(var6);
            }

            stackOverflowFix = false;
         }
      }
   }
}
