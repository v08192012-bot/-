package brokke.cc.mixins.network;

import brokke.cc.core.FakePlayerEntity;
import brokke.cc.module.combat.AutoCrystal;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.player.NoInteract;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.AttackEntityEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
   @Inject(method = "attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
   private void onAttackEntity(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      AttackEntityEvent var4 = new AttackEntityEvent(var1, var2);
      EventBus.post(var4);
      if (var4.isCancelled()) {
         var3.cancel();
      } else if (var2 instanceof FakePlayerEntity var5) {
         var5.a(var1);
      }
   }

   @Inject(method = "interactItem(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/ActionResult;", at = @At("HEAD"), cancellable = true)
   private void onInteractItem(class_1657 var1, class_1268 var2, CallbackInfoReturnable<class_1269> var3) {
      AutoCrystal var4 = AutoCrystal.INSTANCE;
      if (var4 != null && var4.isActive() && var4.l()) {
         var3.setReturnValue(class_1269.field_5811);
      }
   }

   @Inject(
      method = "interactBlock(Lnet/minecraft/client/network/ClientPlayerEntity;Lnet/minecraft/util/Hand;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ActionResult;",
      at = @At("HEAD"),
      cancellable = true
   )
   private void onInteractBlock(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable<class_1269> var4) {
      AutoCrystal var5 = AutoCrystal.INSTANCE;
      if (var5 != null && var5.isActive() && var5.l() && !var5.isPlacingInternal()) {
         var4.setReturnValue(class_1269.field_5811);
      } else if (var1 != null && var1.method_73183() != null) {
         NoInteract var6 = FunctionManager.a(NoInteract.class);
         class_2248 var7 = var1.method_73183().method_8320(var3.method_17777()).method_26204();
         if (var6 != null && var6.a(var7)) {
            var4.setReturnValue(class_1269.field_5811);
         }
      }
   }
}
