package brokke.cc.mixins.client;

import brokke.cc.core.AutoBuyEngine;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class MinecraftClientMixin {
   @Inject(method = "openGameMenu(Z)V", at = @At("HEAD"), cancellable = true)
   private void onOpenGameMenu(boolean var1, CallbackInfo var2) {
      if (AutoBuyEngine.a()) {
         var2.cancel();
      }
   }

   @Inject(method = "getWindowTitle()Ljava/lang/String;", at = @At("HEAD"), cancellable = true)
   private void brokke$setWindowTitle(CallbackInfoReturnable<String> var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.method_1548() != null && var2.method_1548().method_1676() != null && !var2.method_1548().method_1676().isBlank()) {
         var1.setReturnValue(var2.method_1548().method_1676());
      } else {
         var1.setReturnValue("Shelka new");
      }
   }
}
