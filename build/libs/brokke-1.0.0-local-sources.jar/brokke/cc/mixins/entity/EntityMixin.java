package brokke.cc.mixins.entity;

import brokke.cc.module.movement.NoPush;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityMixin {
   private static final double PLAYER_RENDER_DISTANCE = 192.0;

   @Inject(method = "shouldRender(D)Z", at = @At("HEAD"), cancellable = true)
   private void onShouldRender(double var1, CallbackInfoReturnable<Boolean> var3) {
      if ((Object)this instanceof class_1657 && var1 < PLAYER_RENDER_DISTANCE * PLAYER_RENDER_DISTANCE) {
         var3.setReturnValue(true);
      }
   }

   @Redirect(
      method = "updateMovementInFluid(Lnet/minecraft/registry/tag/TagKey;D)Z",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/fluid/FluidState;getVelocity(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/Vec3d;"
      )
   )
   private class_243 stopWaterVelocity(class_3610 var1, class_1922 var2, class_2338 var3) {
      return NoPush.Instance.isActive() && NoPush.water.isToggled() ? class_243.field_1353 : var1.method_15758(var2, var3);
   }
}
