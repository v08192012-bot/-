package brokke.cc.mixins.entity;

import brokke.cc.module.movement.NoPush;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EntityJumpEvent;
import brokke.cc.system.events.impl.EventMoveVelocity;
import brokke.cc.system.events.impl.TravelRotationEvent;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
   @Inject(method = "isPushable()Z", at = @At("HEAD"), cancellable = true)
   public void isPushable(CallbackInfoReturnable<Boolean> var1) {
      if (NoPush.Instance.isActive() && NoPush.players.isToggled()) {
         var1.setReturnValue(false);
      }
   }

   @Inject(method = "jump()V", at = @At("HEAD"))
   public void onJump(CallbackInfo var1) {
      EventBus.post(new EntityJumpEvent((class_1309)(Object)this));
   }

   @Redirect(
      method = "calcGlidingVelocity(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")
   )
   private class_243 redirectGetRotationVector(class_1309 var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 == null) {
         return var1.method_5720();
      }

      if ((Object)this instanceof class_746) {
         TravelRotationEvent var3 = new TravelRotationEvent((class_1309)(Object)this, var1.method_36455(), var1.method_36454());
         EventBus.post(var3);
         if (var3.isCancelled()) {
            float var4 = var3.getPitch() * (float) (Math.PI / 180.0);
            float var5 = -var3.getYaw() * (float) (Math.PI / 180.0);
            float var6 = class_3532.method_15362(var5);
            float var7 = class_3532.method_15374(var5);
            float var8 = class_3532.method_15362(var4);
            float var9 = class_3532.method_15374(var4);
            return new class_243(var7 * var8, -var9, var6 * var8);
         }
      }

      return var1.method_5720();
   }

   @Redirect(
      method = "calcGlidingVelocity(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getPitch()F")
   )
   private float redirectGetPitch(class_1309 var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 == null) {
         return var1.method_36455();
      }

      if (!((Object)this instanceof class_746)) {
         return var1.method_36455();
      }

      TravelRotationEvent var3 = TravelRotationEvent.getLastRotationEvent();
      return var3 != null && var3.isCancelled() ? var3.getPitch() : var1.method_36455();
   }

   @Inject(method = "calcGlidingVelocity(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;", at = @At("RETURN"), cancellable = true)
   private void onCalcGlidingVelocity(class_243 var1, CallbackInfoReturnable<class_243> var2) {
      class_310 var3 = class_310.method_1551();
      if (var3.field_1724 != null && (Object)this instanceof class_746) {
         EventMoveVelocity var4 = new EventMoveVelocity((class_243)var2.getReturnValue());
         EventBus.post(var4);
         var2.setReturnValue(var4.getMovement());
      }
   }
}
