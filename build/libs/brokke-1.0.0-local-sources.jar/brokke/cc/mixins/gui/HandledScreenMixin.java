package brokke.cc.mixins.gui;

import brokke.cc.core.AutoBuyOverlay;
import brokke.cc.core.Timer2;
import brokke.cc.module.player.AuctionHelper;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.player.ItemScroller;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EventClickSlot;
import brokke.cc.ui.InventoryButtonsOverlay;
import net.minecraft.class_1041;
import net.minecraft.class_11909;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class HandledScreenMixin<T extends class_1703> extends class_437 implements class_3936<T> {
   @Unique
   private Timer2 itemScrollerTimer;
   @Unique
   private int lastScrolledSlotId = -1;
   @Shadow
   private int x;
   @Shadow
   private int y;
   @Shadow
   protected int backgroundWidth;
   @Shadow
   protected int backgroundHeight;

   @Unique
   private Timer2 getItemScrollerTimer() {
      if (this.itemScrollerTimer == null) {
         this.itemScrollerTimer = new Timer2();
      }

      return this.itemScrollerTimer;
   }

   protected HandledScreenMixin(class_2561 var1) {
      super(var1);
   }

   @Shadow
   protected abstract void onMouseClick(class_1735 var1, int var2, int var3, class_1713 var4);

   @Shadow
   @Override
   public abstract T method_17577();

   @Shadow
   protected abstract void drawBackground(class_332 var1, float var2, int var3, int var4);

   @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V", at = @At("HEAD"), cancellable = true)
   private void onSlotClick(class_1735 var1, int var2, int var3, class_1713 var4, CallbackInfo var5) {
      if (var1 != null) {
         try {
            class_1703 var6 = this.method_17577();
            int var7 = var6 != null ? var6.field_7763 : 0;
            EventClickSlot var8 = new EventClickSlot(var7, var2, var3, var4);
            EventBus.post(var8);
            if (var8.isCancelled()) {
               var5.cancel();
            }
         } catch (Exception var9) {
         }
      }
   }

   @Inject(method = "mouseDragged(Lnet/minecraft/client/gui/Click;DD)Z", at = @At("HEAD"), cancellable = true)
   private void onItemScrollerDrag(class_11909 var1, double var2, double var4, CallbackInfoReturnable<Boolean> var6) {
      if (this.isItemScrollerActive() && ItemScroller.scrollEnabled.getValue() && var1.method_74245() == 0 && this.isShiftKeyDown()) {
         class_1735 var7 = this.findSlotAt(var1.comp_4798(), var1.comp_4799());
         if (var7 != null && var7.field_7874 != this.lastScrolledSlotId && var7.method_7681()) {
            this.lastScrolledSlotId = var7.field_7874;
            long var8 = ItemScroller.k();
            if (this.getItemScrollerTimer().a(var8)) {
               this.getItemScrollerTimer().a();
               this.onMouseClick(var7, var7.field_7874, 0, class_1713.field_7794);
            }
         }

         var6.setReturnValue(true);
      }
   }

   @Inject(method = "mouseReleased(Lnet/minecraft/client/gui/Click;)Z", at = @At("HEAD"))
   private void onItemScrollerRelease(class_11909 var1, CallbackInfoReturnable<Boolean> var2) {
      this.lastScrolledSlotId = -1;
   }

   @Unique
   private boolean isItemScrollerActive() {
      ItemScroller var1 = FunctionManager.a(ItemScroller.class);
      return var1 != null && var1.isActive();
   }

   @Unique
   private boolean isShiftKeyDown() {
      class_1041 var1 = this.field_22787 != null ? this.field_22787.method_22683() : null;
      return var1 == null ? false : class_3675.method_15987(var1, 340) || class_3675.method_15987(var1, 344);
   }

   @Unique
   @Nullable
   private class_1735 findSlotAt(double var1, double var3) {
      class_1703 var5 = this.method_17577();
      if (var5 == null) {
         return null;
      }

      for (class_1735 var7 : var5.field_7761) {
         int var8 = this.x + var7.field_7873;
         int var9 = this.y + var7.field_7872;
         if (var1 >= var8 && var1 < var8 + 16 && var3 >= var9 && var3 < var9 + 16) {
            return var7;
         }
      }

      return null;
   }

   @Inject(method = "mouseClicked(Lnet/minecraft/client/gui/Click;Z)Z", at = @At("HEAD"), cancellable = true)
   private void onHandledMouseClicked(class_11909 var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      if (InventoryButtonsOverlay.a((class_465<?>)(Object)this)
         && InventoryButtonsOverlay.a(
            (class_465<?>)(Object)this, var1.comp_4798(), var1.comp_4799(), var1.method_74245(), this.x, this.y, this.backgroundWidth, this.backgroundHeight
         )) {
         var3.setReturnValue(true);
      } else if (AutoBuyOverlay.a((class_465<?>)(Object)this)
         && AutoBuyOverlay.a(var1.comp_4798(), var1.comp_4799(), var1.method_74245(), this.x, this.y, this.backgroundWidth, this.backgroundHeight)) {
         var3.setReturnValue(true);
      }
   }

   @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true)
   private void onRenderBackground(class_332 var1, int var2, int var3, float var4, CallbackInfo var5) {
      this.drawBackground(var1, var4, var2, var3);
      var5.cancel();
   }

   @Inject(method = "renderMain(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("RETURN"))
   private void onRenderAuctionHighlights(class_332 var1, int var2, int var3, float var4, CallbackInfo var5) {
      AuctionHelper var6 = FunctionManager.a(AuctionHelper.class);
      if (var6 != null && var6.isActive()) {
         var6.a(var1, (class_465<?>)(Object)this, this.x, this.y);
      }

      if (AutoBuyOverlay.a((class_465<?>)(Object)this)) {
         AutoBuyOverlay.a((class_465<?>)(Object)this, this.x, this.y, this.backgroundWidth, this.backgroundHeight, var2, var3);
      }

      if (InventoryButtonsOverlay.a((class_465<?>)(Object)this)) {
         InventoryButtonsOverlay.a((class_465<?>)(Object)this, this.x, this.y, this.backgroundWidth, this.backgroundHeight, var2, var3);
      }
   }
}
