package brokke.cc.mixins.gui;

import brokke.cc.ui.InventoryButtonsOverlay;
import net.minecraft.class_10260;
import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_1729;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_10260.class)
public abstract class RecipeBookScreenMixin<T extends class_1729> extends class_465<T> {
   protected RecipeBookScreenMixin(T var1, class_1661 var2, class_2561 var3) {
      super(var1, var2, var3);
   }

   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("RETURN"))
   private void onRecipeBookRender(class_332 var1, int var2, int var3, float var4, CallbackInfo var5) {
      if (InventoryButtonsOverlay.a(this)) {
         InventoryButtonsOverlay.a(this, this.field_2776, this.field_2800, this.field_2792, this.field_2779, var2, var3);
      }
   }

   @Inject(method = "mouseClicked(Lnet/minecraft/client/gui/Click;Z)Z", at = @At("HEAD"), cancellable = true)
   private void onRecipeBookMouseClicked(class_11909 var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      if (InventoryButtonsOverlay.a(this)
         && InventoryButtonsOverlay.a(this, var1.comp_4798(), var1.comp_4799(), var1.method_74245(), this.field_2776, this.field_2800, this.field_2792, this.field_2779)) {
         var3.setReturnValue(true);
      }
   }
}
