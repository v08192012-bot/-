package brokke.cc.mixins.gui;

import brokke.cc.manager.NicknameManager;
import brokke.cc.module.misc.ChatHelper;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_338;
import net.minecraft.class_5250;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_338.class)
public class ChatHudMixin {
   @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("HEAD"), argsOnly = true)
   private class_2561 brokkeModifyAddMessage(class_2561 var1) {
      ChatHelper.a(var1);
      return applyNicknames(var1);
   }

   @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), argsOnly = true)
   private class_2561 brokkeModifyAddMessageSimple(class_2561 var1) {
      ChatHelper.a(var1);
      return applyNicknames(var1);
   }

   private static class_2561 applyNicknames(class_2561 var0) {
      Map var1 = NicknameManager.b();
      if (var1.isEmpty()) {
         return var0;
      }

      class_5250 var2 = class_2561.method_43473();
      var0.method_27658((var2xx, var3) -> {
         String var4 = var3;

         for (Entry var6 : (Iterable<Entry>)(Iterable<?>)(var1.entrySet())) {
            var4 = var4.replaceAll("(?i)\\b" + Pattern.quote((String)var6.getKey()) + "\\b", (String)var6.getValue());
         }

         var2.method_10852(class_2561.method_43470(var4).method_10862(var2xx));
         return Optional.empty();
      }, class_2583.field_24360);
      return var2;
   }
}
