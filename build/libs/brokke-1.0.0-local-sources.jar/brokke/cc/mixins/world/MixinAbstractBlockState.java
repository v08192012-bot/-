package brokke.cc.mixins.world;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EventEntityCollision;
import net.minecraft.class_10774;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4970.class_4971;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4971.class)
public abstract class MixinAbstractBlockState {
   @Shadow
   public abstract class_2248 getBlock();

   @Inject(
      method = "onEntityCollision(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EntityCollisionHandler;Z)V",
      at = @At("HEAD"),
      cancellable = true
   )
   public void onEntityCollision(class_1937 var1, class_2338 var2, class_1297 var3, class_10774 var4, boolean var5, CallbackInfo var6) {
      if (var3 == class_310.method_1551().field_1724) {
         EventEntityCollision var7 = new EventEntityCollision(this.getBlock(), var2);
         EventBus.post(var7);
         if (var7.isCancelled()) {
            var6.cancel();
         }
      }
   }
}
