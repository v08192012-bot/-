package brokke.cc.mixins.render;

import brokke.cc.module.movement.FreeCam;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.render.NoRender;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
public class InGameOverlayRendererMixin {
   @Inject(method = "renderFireOverlay(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/texture/Sprite;)V", at = @At("HEAD"), cancellable = true)
   private static void onRenderFireOverlay(class_4587 var0, class_4597 var1, class_1058 var2, CallbackInfo var3) {
      if (NoRender.l()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderInWallOverlay(Lnet/minecraft/client/texture/Sprite;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V", at = @At("HEAD"), cancellable = true)
   private static void onRenderInWallOverlay(class_1058 var0, class_4587 var1, class_4597 var2, CallbackInfo var3) {
      if (NoRender.m() || NoRender.n() || FunctionManager.a(FreeCam.class) != null && FunctionManager.a(FreeCam.class).isActive()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderFloatingItem(Lnet/minecraft/client/util/math/MatrixStack;FLnet/minecraft/client/render/command/OrderedRenderCommandQueue;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderFloatingItem(class_4587 var1, float var2, class_11659 var3, CallbackInfo var4) {
      if (NoRender.u()) {
         var4.cancel();
      }
   }
}
