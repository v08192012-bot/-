package brokke.cc.mixins.render;

import brokke.cc.module.misc.Optimizer;
import brokke.cc.render.RenderContext;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.Render3DEvent;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMatrixMixin {
   @Unique
   private class_4184 ez_capturedCamera;
   @Unique
   private float ez_capturedTickDelta;

   @Inject(
      method = "render(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
      at = @At("HEAD")
   )
   private void captureWorldMatrices(
      class_9922 var1,
      class_9779 var2,
      boolean var3,
      class_4184 var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      RenderContext.a(var5, var6, var9);
      this.ez_capturedCamera = var4;
      this.ez_capturedTickDelta = var2.method_60637(true);
      Optimizer.a(var4);
   }

   @Inject(
      method = "render(Lnet/minecraft/client/util/memory/ObjectAllocator;Lnet/minecraft/client/render/RenderTickCounter;ZLnet/minecraft/client/render/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
      at = @At("RETURN")
   )
   private void fireRender3DEvent(
      class_9922 var1,
      class_9779 var2,
      boolean var3,
      class_4184 var4,
      Matrix4f var5,
      Matrix4f var6,
      Matrix4f var7,
      GpuBufferSlice var8,
      Vector4f var9,
      boolean var10,
      CallbackInfo var11
   ) {
      if (this.ez_capturedCamera != null) {
         class_4587 var12 = new class_4587();
         var12.method_34425(var5);
         EventBus.post(new Render3DEvent(var12, this.ez_capturedTickDelta, this.ez_capturedCamera));
         this.ez_capturedCamera = null;
      }
   }
}
