package brokke.cc.mixins.render;

import brokke.cc.module.render.NoRender;
import net.minecraft.class_11659;
import net.minecraft.class_11944;
import net.minecraft.class_11944.class_12041;
import net.minecraft.class_11977.class_12051;
import net.minecraft.class_12075;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_11944.class)
public abstract class BillboardParticleSubmittableMixin {
   @Shadow
   private int particles;

   @Shadow
   public abstract void onFrameEnd();

   @Inject(method = "submit(Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At("HEAD"), cancellable = true)
   private void onSubmitQueue(class_11659 var1, class_12075 var2, CallbackInfo var3) {
      if (NoRender.q()) {
         this.onFrameEnd();
         var3.cancel();
      }
   }

   @Inject(method = "submit(Lnet/minecraft/client/render/command/LayeredCustomCommandRenderer$VerticesCache;)Lnet/minecraft/client/particle/BillboardParticleSubmittable$Buffers;", at = @At("HEAD"), cancellable = true)
   private void onSubmit(class_12051 var1, CallbackInfoReturnable<class_12041> var2) {
      if (NoRender.q() || this.particles <= 0 || this.particles * 4L >= 16777215L || this.particles > 100000) {
         this.onFrameEnd();
         var2.setReturnValue(null);
      }
   }
}
