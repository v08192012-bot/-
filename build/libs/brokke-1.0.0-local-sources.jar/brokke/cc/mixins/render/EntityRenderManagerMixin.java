package brokke.cc.mixins.render;

import brokke.cc.module.misc.Optimizer;
import brokke.cc.module.render.ExstraOptimizer;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_898.class)
public class EntityRenderManagerMixin {
   @Inject(method = "shouldRender(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/Frustum;DDD)Z", at = @At("HEAD"), cancellable = true)
   private <E extends class_1297> void onShouldRender(E var1, class_4604 var2, double var3, double var5, double var7, CallbackInfoReturnable<Boolean> var9) {
      if (Optimizer.a(var1, var3, var5, var7) || ExstraOptimizer.cullEntity(var1, var3, var5, var7)) {
         var9.setReturnValue(false);
      }
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/EntityRenderState;Lnet/minecraft/client/render/state/CameraRenderState;DDDLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private <S extends class_10017> void onRender(
      S var1, class_12075 var2, double var3, double var5, double var7, class_4587 var9, class_11659 var10, CallbackInfo var11
   ) {
      if (Optimizer.a(var1, var3, var5, var7) || ExstraOptimizer.cullEntityState(var1, var3, var5, var7)) {
         var11.cancel();
      }
   }
}
