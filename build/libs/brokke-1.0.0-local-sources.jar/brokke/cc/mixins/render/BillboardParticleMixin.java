package brokke.cc.mixins.render;

import brokke.cc.module.misc.Optimizer;
import brokke.cc.module.render.ExstraOptimizer;
import net.minecraft.class_11944;
import net.minecraft.class_238;
import net.minecraft.class_3940;
import net.minecraft.class_4184;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3940.class)
public class BillboardParticleMixin {
   @Inject(method = "render(Lnet/minecraft/client/particle/BillboardParticleSubmittable;Lnet/minecraft/client/render/Camera;F)V", at = @At("HEAD"), cancellable = true)
   private void onRender(class_11944 var1, class_4184 var2, float var3, CallbackInfo var4) {
      class_703 var5 = (class_703)(Object)this;
      class_238 var6 = var5.method_3064();
      double var7 = (var6.field_1323 + var6.field_1320) * 0.5;
      double var9 = (var6.field_1322 + var6.field_1325) * 0.5;
      double var11 = (var6.field_1321 + var6.field_1324) * 0.5;
      if (Optimizer.a(var7, var9, var11) || ExstraOptimizer.cullParticle(var7, var9, var11)) {
         var4.cancel();
      }
   }
}
