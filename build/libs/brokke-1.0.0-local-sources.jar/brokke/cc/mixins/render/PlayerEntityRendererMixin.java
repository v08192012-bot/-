package brokke.cc.mixins.render;

import brokke.cc.cosmetic.CosmeticFeatureRenderer;
import brokke.cc.module.render.NameTags;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin extends class_922<class_11890, class_10055, class_591> {
   public PlayerEntityRendererMixin(class_5618 var1, class_591 var2, float var3) {
      super(var1, var2, var3);
   }

   @Inject(method = "<init>(Lnet/minecraft/client/render/entity/EntityRendererFactory$Context;Z)V", at = @At("RETURN"))
   private void onInit(class_5618 var1, boolean var2, CallbackInfo var3) {
      this.method_4046(new CosmeticFeatureRenderer(this));
   }

   @Inject(method = "hasLabel(Lnet/minecraft/entity/PlayerLikeEntity;D)Z", at = @At("HEAD"), cancellable = true)
   private void onHasLabel(class_11890 var1, double var2, CallbackInfoReturnable<Boolean> var4) {
      if (NameTags.a(var1)) {
         var4.setReturnValue(false);
      }
   }
}
