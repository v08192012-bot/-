package brokke.cc.mixins.render;

import brokke.cc.core.FreeLookStorage;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.render.SwingAnimation;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.HandRenderEvent;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
   @Shadow
   public abstract void renderItem(class_1309 var1, class_1799 var2, class_811 var3, class_4587 var4, class_11659 var5, int var6);

   @Shadow
   public abstract void renderArm(class_4587 var1, class_11659 var2, int var3, class_1306 var4);

   @Shadow
   public abstract void renderArmHoldingItem(class_4587 var1, class_11659 var2, int var3, float var4, float var5, class_1306 var6);

   @ModifyVariable(
      method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
      at = @At("HEAD"),
      ordinal = 1,
      argsOnly = true
   )
   private float onModifyPitch(float var1) {
      return FreeLookStorage.isActive() ? FreeLookStorage.getFreePitch() : var1;
   }

   @Inject(
      method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private void onRenderFirstPersonItem(
      class_742 var1,
      float var2,
      float var3,
      class_1268 var4,
      float var5,
      class_1799 var6,
      float var7,
      class_4587 var8,
      class_11659 var9,
      int var10,
      CallbackInfo var11
   ) {
      boolean var12 = var4 == class_1268.field_5808;
      class_1306 var13 = var12 ? var1.method_6068() : var1.method_6068().method_5928();
      boolean var14 = var13 == class_1306.field_6183;
      var8.method_22903();
      HandRenderEvent var15 = new HandRenderEvent(var13, var5, var6, var7, var8, var4);
      EventBus.post(var15);
      if (var15.isCancelled()) {
         var11.cancel();
         if (!var6.method_7960()) {
            this.renderItem(var1, var6, var14 ? class_811.field_4322 : class_811.field_4321, var8, var9, var10);
         } else if (!var1.method_5767()) {
            this.renderArmHoldingItem(var8, var9, var10, var7, var5, var13);
         }

         var8.method_22909();
      }
   }

   @Inject(
      method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
      at = @At("RETURN")
   )
   private void onRenderFirstPersonItemEnd(
      class_742 var1,
      float var2,
      float var3,
      class_1268 var4,
      float var5,
      class_1799 var6,
      float var7,
      class_4587 var8,
      class_11659 var9,
      int var10,
      CallbackInfo var11
   ) {
      var8.method_22909();
   }

   @Inject(method = "swingArm(FLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V", at = @At("HEAD"), cancellable = true)
   private void onSwingArm(float var1, class_4587 var2, int var3, class_1306 var4, CallbackInfo var5) {
      SwingAnimation var6 = FunctionManager.a(SwingAnimation.class);
      if (var6 != null && var6.a(var2, var1, var4, var3)) {
         var5.cancel();
      }
   }

   @Redirect(method = "updateHeldItems()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getHandEquippingProgress(F)F"))
   private float onGetHandEquippingProgress(class_746 var1, float var2) {
      SwingAnimation var3 = FunctionManager.a(SwingAnimation.class);
      return var3 != null && var3.isActive() && var3.q() && var3.a(var1.method_6047()) ? 1.0F : var1.method_75194(var2);
   }

   @ModifyVariable(method = "applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V", at = @At("HEAD"), argsOnly = true)
   private float onApplyEquipOffset(float var1) {
      SwingAnimation var2 = FunctionManager.a(SwingAnimation.class);
      if (var2 != null && var2.isActive() && var2.q()) {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1724 != null && var3.field_1724.method_6055(1.0F) > 0.0F && var2.a(var3.field_1724.method_6047())) {
            return 0.0F;
         }
      }

      return var1;
   }
}
