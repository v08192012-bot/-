package brokke.cc.mixins.render;

import brokke.cc.module.render.NameTags;
import brokke.cc.module.render.SeeInvisibles;
import brokke.cc.render.Theme;
import net.minecraft.class_10042;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_583;
import net.minecraft.class_922;
import net.minecraft.class_9848;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
   @Unique
   private boolean brokke$seeInvisiblesRendering;

   @Shadow
   public abstract class_2960 getTexture(S var1);

   @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z", at = @At("HEAD"), cancellable = true)
   private void onHasLabel(class_1309 var1, double var2, CallbackInfoReturnable<Boolean> var4) {
      if (NameTags.a(var1)) {
         var4.setReturnValue(false);
      }
   }

   @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"))
   private void onUpdateRenderStateSeeInvisibles(T var1, S var2, float var3, CallbackInfo var4) {
      SeeInvisibles var5 = SeeInvisibles.k();
      if (var5 != null && var5.isActive() && var2.field_53333 && var1 instanceof class_1657 && (Object)this instanceof class_1007) {
         var2.field_53461 = false;
      }
   }

   @Inject(method = "isVisible(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;)Z", at = @At("RETURN"), cancellable = true)
   private void modifyVisibility(S var1, CallbackInfoReturnable<Boolean> var2) {
      SeeInvisibles var3 = SeeInvisibles.k();
      if (var3 != null && var3.isActive() && var1.field_53333 && (Object)this instanceof class_1007) {
         var2.setReturnValue(true);
      }
   }

   @Inject(method = "getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;", at = @At("RETURN"), cancellable = true)
   private void modifyRenderLayer(S var1, boolean var2, boolean var3, boolean var4, CallbackInfoReturnable<class_1921> var5) {
      SeeInvisibles var6 = SeeInvisibles.k();
      if (var6 != null && var6.isActive() && var1.field_53333 && (Object)this instanceof class_1007) {
         class_2960 var7 = this.getTexture(var1);
         var5.setReturnValue(class_12249.method_75980(var7, true));
      }
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At("HEAD")
   )
   private void onRenderHead(S var1, class_4587 var2, class_11659 var3, class_12075 var4, CallbackInfo var5) {
      SeeInvisibles var6 = SeeInvisibles.k();
      this.brokke$seeInvisiblesRendering = var6 != null && var6.isActive() && var1.field_53333 && (Object)this instanceof class_1007;
   }

   @Redirect(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/ColorHelper;mix(II)I")
   )
   private int brokke$modifySeeInvisiblesAlpha(int var1, int var2) {
      int var3 = class_9848.method_61322(var1, var2);
      if (this.brokke$seeInvisiblesRendering) {
         SeeInvisibles var4 = SeeInvisibles.k();
         if (var4 != null && var4.isActive()) {
            float var5 = (float)var4.getOpacity().getValue();
            int var6;
            if (var4.getColorMode().isMode("От темы")) {
               var6 = Theme.getInstance().getAccent().getRGB();
            } else {
               var6 = var4.getColor().getArgb();
            }

            int var7 = var6 >> 24 & 0xFF;
            if (var7 == 0) {
               var7 = 255;
            }

            int var8 = Math.round(var7 * var5) << 24;
            return var6 & 16777215 | var8;
         } else {
            return var3;
         }
      } else {
         return var3;
      }
   }
}
