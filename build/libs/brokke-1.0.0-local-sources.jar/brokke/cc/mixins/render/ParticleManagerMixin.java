package brokke.cc.mixins.render;

import brokke.cc.module.render.NoRender;
import net.minecraft.class_11943;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_702.class)
public class ParticleManagerMixin {
   @Inject(method = "addToBatch(Lnet/minecraft/client/render/SubmittableBatch;Lnet/minecraft/client/render/Frustum;Lnet/minecraft/client/render/Camera;F)V", at = @At("HEAD"), cancellable = true)
   private void onAddToBatch(class_11943 var1, class_4604 var2, class_4184 var3, float var4, CallbackInfo var5) {
      if (NoRender.q()) {
         var5.cancel();
      }
   }
}
