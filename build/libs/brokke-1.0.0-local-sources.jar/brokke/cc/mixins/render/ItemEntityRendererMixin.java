package brokke.cc.mixins.render;

import brokke.cc.core.IItemEntityRenderState;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.render.ItemPhysic;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10039;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
@Environment(EnvType.CLIENT)
public class ItemEntityRendererMixin {
   @Unique
   private class_10039 currentState;

   @Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V", at = @At("TAIL"))
   private void captureGround(class_1542 var1, class_10039 var2, float var3, CallbackInfo var4) {
      ((IItemEntityRenderState)var2).setOnGround(isRestingOnGround(var1));
   }

   @Unique
   private static boolean isRestingOnGround(class_1542 var0) {
      if (var0.method_24828() || var0.field_5992) {
         return true;
      }

      if (var0.method_73183() == null) {
         return false;
      }

      double var1 = var0.method_18798().field_1351;
      if (Math.abs(var1) > 0.15) {
         return false;
      }

      class_238 var3 = var0.method_5829().method_989(0.0, -0.15, 0.0);
      return !var0.method_73183().method_8587(var0, var3);
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At("HEAD")
   )
   private void captureState(class_10039 var1, class_4587 var2, class_11659 var3, class_12075 var4, CallbackInfo var5) {
      this.currentState = var1;
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At("RETURN")
   )
   private void releaseState(class_10039 var1, class_4587 var2, class_11659 var3, class_12075 var4, CallbackInfo var5) {
      this.currentState = null;
   }

   @Redirect(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V")
   )
   private void translate(class_4587 var1, float var2, float var3, float var4) {
      ItemPhysic var5 = FunctionManager.a(ItemPhysic.class);
      if (var5 != null && var5.isActive()) {
         var3 = 0.0F;
      }

      var1.method_46416(var2, var3, var4);
   }

   @Redirect(
      method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionfc;)V")
   )
   private void multiply(class_4587 var1, Quaternionfc var2) {
      ItemPhysic var3 = FunctionManager.a(ItemPhysic.class);
      if (var3 == null || !var3.isActive()) {
         var1.method_22907(var2);
      } else if (this.currentState != null && ((IItemEntityRenderState)(Object)this.currentState).isOnGround()) {
         var1.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
      } else if (this.currentState != null) {
         float var4 = class_1542.method_27314(this.currentState.field_53328, this.currentState.field_53435) * 300.0F;
         var1.method_22907(class_7833.field_40714.rotationDegrees(var4));
      } else {
         var1.method_22907(var2);
      }
   }
}
