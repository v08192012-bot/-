package brokke.cc.mixins.render;

import brokke.cc.hud.HotbarHud;
import brokke.cc.hud.ScoreboardHud;
import brokke.cc.module.render.Beautifully;
import brokke.cc.module.render.NoRender;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.HudRenderEvent;
import net.minecraft.class_10799;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1702;
import net.minecraft.class_266;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"))
   private void onRender(class_332 var1, class_9779 var2, CallbackInfo var3) {
      EventBus.post(new HudRenderEvent(var1));
   }

   @Inject(method = "renderCrosshair(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
   private void renderCrosshair(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (class_310.method_1551().field_1755 != null) {
         var3.cancel();
      }
   }

   @Inject(method = "renderVignetteOverlay(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderVignetteOverlay(class_332 var1, class_1297 var2, CallbackInfo var3) {
      if (NoRender.o()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderStatusEffectOverlay(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderStatusEffectOverlay(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (NoRender.p()) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1724 != null) {
            for (class_1293 var6 : var4.field_1724.method_6026()) {
               if (!var6.method_5579().comp_349().method_5573()) {
                  var3.cancel();
                  return;
               }
            }
         }
      }
   }

   @Inject(method = "renderHotbar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
   private void cancelVanillaHotbar(class_332 var1, class_9779 var2, CallbackInfo var3) {
      if (HotbarHud.isEnabled()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V", at = @At("HEAD"), cancellable = true)
   private void cancelVanillaScoreboard(class_332 var1, class_266 var2, CallbackInfo var3) {
      if (ScoreboardHud.isEnabled()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderFood(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/entity/player/PlayerEntity;II)V", at = @At("TAIL"))
   private void renderFoodSaturation(class_332 var1, class_1657 var2, int var3, int var4, CallbackInfo var5) {
      if (Beautifully.k()) {
         class_1702 var6 = var2.method_7344();
         float var7 = var6.method_7589();
         int var8 = var3 - 10;
         boolean var9 = var2.method_6059(class_1294.field_5903);
         class_2960 var10 = class_2960.method_60656(var9 ? "hud/food_empty_hunger" : "hud/food_empty");
         class_2960 var11 = class_2960.method_60656(var9 ? "hud/food_half_hunger" : "hud/food_half");
         class_2960 var12 = class_2960.method_60656(var9 ? "hud/food_full_hunger" : "hud/food_full");

         for (int var13 = 0; var13 < 10; var13++) {
            int var14 = var4 - var13 * 8 - 9;
            var1.method_52706(class_10799.field_56883, var10, var14, var8, 9, 9);
            float var15 = var7 - var13 * 2;
            if (var15 >= 2.0F) {
               var1.method_52706(class_10799.field_56883, var12, var14, var8, 9, 9);
            } else if (var15 >= 1.0F) {
               var1.method_52706(class_10799.field_56883, var11, var14, var8, 9, 9);
            }
         }
      }
   }
}
