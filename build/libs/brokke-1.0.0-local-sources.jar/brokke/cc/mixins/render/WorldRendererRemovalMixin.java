package brokke.cc.mixins.render;

import brokke.cc.module.render.NoRender;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_11658;
import net.minecraft.class_11661;
import net.minecraft.class_11943;
import net.minecraft.class_243;
import net.minecraft.class_4063;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9909;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_761.class)
public class WorldRendererRemovalMixin {
   @Shadow
   private class_11943 particleBatch;

   @Inject(method = "renderParticles(Lnet/minecraft/client/render/FrameGraphBuilder;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderParticles(class_9909 var1, GpuBufferSlice var2, CallbackInfo var3) {
      if (NoRender.q()) {
         if (this.particleBatch != null) {
            this.particleBatch.method_74317();
         }

         var3.cancel();
      }
   }

   @Inject(method = "renderWeather(Lnet/minecraft/client/render/FrameGraphBuilder;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderWeather(class_9909 var1, GpuBufferSlice var2, CallbackInfo var3) {
      if (NoRender.r()) {
         var3.cancel();
      }
   }

   @Inject(method = "renderClouds(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/client/option/CloudRenderMode;Lnet/minecraft/util/math/Vec3d;JFIF)V", at = @At("HEAD"), cancellable = true)
   private void onRenderClouds(class_9909 var1, class_4063 var2, class_243 var3, long var4, float var6, int var7, float var8, CallbackInfo var9) {
      if (NoRender.s()) {
         var9.cancel();
      }
   }

   @Inject(method = "renderBlockEntities(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/state/WorldRenderState;Lnet/minecraft/client/render/command/OrderedRenderCommandQueueImpl;)V", at = @At("HEAD"), cancellable = true)
   private void onRenderBlockEntities(class_4587 var1, class_11658 var2, class_11661 var3, CallbackInfo var4) {
      if (NoRender.t()) {
         var4.cancel();
      }
   }

   @Inject(method = "hasBlindnessOrDarkness(Lnet/minecraft/client/render/Camera;)Z", at = @At("HEAD"), cancellable = true)
   private void onHasBlindnessOrDarkness(class_4184 var1, CallbackInfoReturnable<Boolean> var2) {
      if (NoRender.z()) {
         var2.setReturnValue(false);
      }
   }
}
