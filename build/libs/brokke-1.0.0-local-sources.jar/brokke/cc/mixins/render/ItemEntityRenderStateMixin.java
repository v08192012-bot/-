package brokke.cc.mixins.render;

import brokke.cc.core.IItemEntityRenderState;
import net.minecraft.class_10039;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10039.class)
public abstract class ItemEntityRenderStateMixin implements IItemEntityRenderState {
   @Unique
   private boolean onGround;

   @Override
   public boolean isOnGround() {
      return this.onGround;
   }

   @Override
   public void setOnGround(boolean var1) {
      this.onGround = var1;
   }
}
