package brokke.cc.mixins.render;

import brokke.cc.core.AutoBuyEngine;
import net.minecraft.class_9919;
import net.minecraft.class_9919.class_10601;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9919.class)
public class InactivityFpsLimiterMixin {
   @Shadow
   private int maxFps;

   @Inject(method = "getLimitReason()Lnet/minecraft/client/option/InactivityFpsLimiter$LimitReason;", at = @At("RETURN"), cancellable = true)
   private void keepFpsWhileIdle(CallbackInfoReturnable<class_10601> callback) {
      class_10601 reason = (class_10601)callback.getReturnValue();
      if (reason == class_10601.field_55846 || reason == class_10601.field_55845) {
         callback.setReturnValue(class_10601.field_55843);
      }
   }

   @Inject(method = "update()I", at = @At("HEAD"), cancellable = true)
   private void onUpdate(CallbackInfoReturnable<Integer> var1) {
      if (AutoBuyEngine.a()) {
         var1.setReturnValue(Math.max(60, this.maxFps));
      }
   }

   @Inject(method = "shouldDisableProfilerTimeout()Z", at = @At("HEAD"), cancellable = true)
   private void onShouldDisableProfilerTimeout(CallbackInfoReturnable<Boolean> var1) {
      if (AutoBuyEngine.a()) {
         var1.setReturnValue(true);
      }
   }
}
