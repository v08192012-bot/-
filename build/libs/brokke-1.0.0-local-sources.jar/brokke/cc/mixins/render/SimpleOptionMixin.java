package brokke.cc.mixins.render;

import net.minecraft.class_2561;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7172.class)
public class SimpleOptionMixin<T> {
   @Shadow
   @Final
   class_2561 text;
   @Shadow
   T value;

   @Inject(method = "setValue(Ljava/lang/Object;)V", at = @At("HEAD"), cancellable = true)
   public void setGammaValue(T var1, CallbackInfo var2) {
      if (this.text.equals(class_2561.method_43471("options.gamma"))) {
         this.value = var1;
         var2.cancel();
      }
   }
}
