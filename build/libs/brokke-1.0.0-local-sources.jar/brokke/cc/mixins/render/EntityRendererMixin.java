package brokke.cc.mixins.render;

import brokke.cc.module.render.NameTags;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public class EntityRendererMixin {
   @Inject(method = "hasLabel(Lnet/minecraft/entity/Entity;D)Z", at = @At("HEAD"), cancellable = true)
   private void onHasLabel(class_1297 var1, double var2, CallbackInfoReturnable<Boolean> var4) {
      if (NameTags.a(var1)) {
         var4.setReturnValue(false);
      }
   }
}
