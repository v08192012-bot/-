package brokke.cc.mixins.render;

import brokke.cc.module.render.NoRender;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7283;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_7283.class)
public class BlindnessFogModifierMixin {
   @Inject(method = "applyStartEndModifier(Lnet/minecraft/client/render/fog/FogData;Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/world/ClientWorld;FLnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
   private void onApplyStartEndModifier(class_7285 var1, class_4184 var2, class_638 var3, float var4, class_9779 var5, CallbackInfo var6) {
      if (NoRender.z()) {
         var6.cancel();
      }
   }

   @Inject(method = "applyDarknessModifier(Lnet/minecraft/entity/LivingEntity;FF)F", at = @At("HEAD"), cancellable = true)
   private void onApplyDarknessModifier(class_1309 var1, float var2, float var3, CallbackInfoReturnable<Float> var4) {
      if (NoRender.z()) {
         var4.setReturnValue(var2);
      }
   }
}
