package brokke.cc.mixins.item;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.FinishEatEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
   @Inject(method = "finishUsing(Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;)Lnet/minecraft/item/ItemStack;", at = @At("TAIL"))
   private void onFinishUsing(class_1937 var1, class_1309 var2, CallbackInfoReturnable<class_1799> var3) {
      if (var1.method_8608() && var2 instanceof class_1657 var4) {
         EventBus.post(new FinishEatEvent(var4, (class_1799)(Object)this));
      }
   }
}
