package brokke.cc.mixins.interfaces;

import net.minecraft.class_310;
import net.minecraft.class_320;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface IMinecraftClient {
   @Accessor("itemUseCooldown")
   void setItemUseCooldown(int var1);

   @Mutable
   @Accessor("session")
   void setSession(class_320 var1);
}
