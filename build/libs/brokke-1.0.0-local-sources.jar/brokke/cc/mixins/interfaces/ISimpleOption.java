package brokke.cc.mixins.interfaces;

import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7172.class)
public interface ISimpleOption<T> {
   @Accessor("value")
   void setValueRaw(T var1);

   @Accessor("value")
   T getValueRaw();
}
