package brokke.cc.mixins.input;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.KeyEvent;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardInputMixin {
   @Inject(method = "onKey(JILnet/minecraft/client/input/KeyInput;)V", at = @At("HEAD"))
   private void onKey(long var1, int var3, class_11908 var4, CallbackInfo var5) {
      EventBus.post(new KeyEvent(var3, var4.comp_4795()));
   }
}
