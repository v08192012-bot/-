package brokke.cc.mixins.input;

import brokke.cc.core.FreeLookStorage;
import brokke.cc.core.SilentView;
import brokke.cc.module.combat.Aura;
import brokke.cc.module.render.FreeLook;
import brokke.cc.module.FunctionManager;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EventLook;
import brokke.cc.system.events.impl.EventScroll;
import brokke.cc.system.events.impl.KeyEvent;
import brokke.cc.util.GCDUtil;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {
   @Shadow
   private double cursorDeltaX;
   @Shadow
   private double cursorDeltaY;
   @Unique
   private static final double NO_POS = Double.MIN_VALUE;
   @Unique
   private double lastLookX = Double.MIN_VALUE;
   @Unique
   private double lastLookY;

   @Inject(method = "updateMouse(D)V", at = @At("HEAD"))
   private void onUpdateMouseHead(double var1, CallbackInfo var3) {
      FreeLook var4 = FunctionManager.a(FreeLook.class);
      if (var4 != null && var4.k()) {
         var4.a((float)this.cursorDeltaX, (float)this.cursorDeltaY);
         this.cursorDeltaX = 0.0;
         this.cursorDeltaY = 0.0;
      } else {
         class_310 var5 = class_310.method_1551();
         Aura var6 = Aura.INSTANCE;
         if (var6 != null
            && var6.l()
            && var6.rotationType.isSelected("SkyTime")
            && var6.skyTimeFreeCam.isEnabled()
            && FreeLookStorage.isActive()
            && var5.field_1755 == null) {
            float var7 = GCDUtil.a();
            FreeLookStorage.setFreeYaw(FreeLookStorage.getFreeYaw() + (float)this.cursorDeltaX * var7);
            FreeLookStorage.setFreePitch(class_3532.method_15363(FreeLookStorage.getFreePitch() + (float)this.cursorDeltaY * var7, -90.0F, 90.0F));
            this.cursorDeltaX = 0.0;
            this.cursorDeltaY = 0.0;
         }
      }
   }

   @Inject(method = "onCursorPos(JDD)V", at = @At("TAIL"))
   private void onCursorPosTail(long var1, double var3, double var5, CallbackInfo var7) {
      class_310 var8 = class_310.method_1551();
      if (var8.method_22683().method_4490() != var1 || !var8.method_1569()) {
         this.lastLookX = Double.MIN_VALUE;
      } else if (this.lastLookX == Double.MIN_VALUE) {
         this.lastLookX = var3;
         this.lastLookY = var5;
      } else {
         this.lastLookX = var3;
         this.lastLookY = var5;
      }
   }

   @Redirect(method = "updateMouse(D)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"))
   private void redirectLookDirection(class_746 var1, double var2, double var4) {
      EventLook var6 = new EventLook(var2, var4);
      EventBus.post(var6);
      if (!var6.isCancelled()) {
         var2 = var6.getYaw();
         var4 = var6.getPitch();
         Aura var7 = Aura.INSTANCE;
         if (var7 != null && var7.l() && var7.rotationType.isSelected("Legit")) {
            double[] var8 = var7.getLegitRotation().a(var1, var2, var4);
            var1.method_5872(var8[0], var8[1]);
         } else if (!SilentView.getInstance().a(var2, var4)) {
            var1.method_5872(var2, var4);
         }
      }
   }

   @Inject(method = "onMouseButton(JLnet/minecraft/client/input/MouseInput;I)V", at = @At("HEAD"))
   private void onMouseButton(long var1, class_11910 var3, int var4, CallbackInfo var5) {
      class_310 var6 = class_310.method_1551();
      if (var6.method_22683().method_4490() == var1) {
         EventBus.post(new KeyEvent(var4, -(var3.comp_4801() + 100)));
      }
   }

   @Inject(method = "onMouseScroll(JDD)V", at = @At("HEAD"), cancellable = true)
   private void onMouseScroll(long var1, double var3, double var5, CallbackInfo var7) {
      class_310 var8 = class_310.method_1551();
      if (var8.method_22683().method_4490() == var1) {
         EventScroll var9 = new EventScroll(var3, var5);
         EventBus.post(var9);
         if (var9.isCancelled()) {
            var7.cancel();
         }
      }
   }
}
