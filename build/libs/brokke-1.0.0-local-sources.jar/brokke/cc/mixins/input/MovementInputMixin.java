package brokke.cc.mixins.input;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.impl.EventMoveInput;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public abstract class MovementInputMixin extends class_744 {
   @Inject(method = "tick()V", at = @At("TAIL"))
   private void onTickTail(CallbackInfo var1) {
      float var2 = this.field_55868.field_1342;
      float var3 = this.field_55868.field_1343;
      boolean var4 = this.field_54155.comp_3163();
      boolean var5 = this.field_54155.comp_3164();
      boolean var6 = this.field_54155.comp_3165();
      EventMoveInput var7 = new EventMoveInput(var2, var3, var4, var5, var6);
      EventBus.post(var7);
      this.field_55868 = new class_241(var7.getStrafe(), var7.getForward());
      boolean var8 = var7.getForward() > 0.0F;
      boolean var9 = var7.getForward() < 0.0F;
      boolean var10 = var7.getStrafe() > 0.0F;
      boolean var11 = var7.getStrafe() < 0.0F;
      this.field_54155 = new class_10185(var8, var9, var10, var11, var7.isJump(), var7.isSneak(), var7.isSprint());
   }
}
