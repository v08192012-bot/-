package brokke.cc.render;

import brokke.cc.core.FakePlayerEntity;
import net.minecraft.class_10055;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_922;

public class FakePlayerEntityRenderer extends class_922<FakePlayerEntity, class_10055, class_591> {
   private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/entity/steve.png");

   public FakePlayerEntityRenderer(class_5618 var1) {
      super(var1, new class_591(var1.method_32167(class_5602.field_27577), false), 0.6F);
   }

   public class_10055 method_55269() {
      return new class_10055();
   }

   public class_2960 getTexture(class_10055 var1) {
      return TEXTURE;
   }
}
