package brokke.cc.render;

import brokke.cc.core.LegacyRenderCompat;
import brokke.cc.manager.FriendManager;
import brokke.cc.module.render.ShaderESP;
import brokke.cc.system.events.impl.Render3DEvent;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;
import net.minecraft.class_1041;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_6367;
import net.minecraft.class_898;
import org.lwjgl.system.MemoryUtil;

public final class ShaderEspRenderer {
   private static class_6367 silhouetteFb;
   private static GpuTexture blurTextureA;
   private static GpuTextureView blurTextureAView;
   private static GpuTexture blurTextureB;
   private static GpuTextureView blurTextureBView;
   private static RenderPipeline blurHPipeline;
   private static RenderPipeline blurVPipeline;
   private static RenderPipeline compositePipeline;
   private static GpuBuffer blurUniformBuffer;
   private static ByteBuffer blurUniformData;
   private static GpuBuffer compositeUniformBuffer;
   private static ByteBuffer compositeUniformData;
   private static int lastWidth = 0;
   private static int lastHeight = 0;
   private static int lastBlurWidth = 0;
   private static int lastBlurHeight = 0;
   private static boolean initialized = false;
   private static final int BLUR_UBO_SIZE = 16;
   private static final int COMPOSITE_UBO_SIZE = 64;

   private ShaderEspRenderer() {
   }

   public static void a(Render3DEvent var0, ShaderESP var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1687 != null && var2.field_1724 != null) {
         class_4184 var3 = var0.getCamera();
         if (var3 != null) {
            class_1041 var4 = var2.method_22683();
            if (var4 != null) {
               int var5 = var4.method_4489();
               int var6 = var4.method_4506();
               if (var5 > 1 && var6 > 1) {
                  ArrayList var7 = new ArrayList();
                  ArrayList var8 = new ArrayList();
                  a(var2, var1, var7, var8);
                  if (!var7.isEmpty() || !var8.isEmpty()) {
                     b();
                     a(var5, var6);
                     float var9 = var0.getTickDelta();
                     float var10 = (float)var1.getGlowRadius().getValue();
                     boolean var11 = var1.getThroughWalls().isToggled();
                     if (!var7.isEmpty()) {
                        a(var2, var7, var0.getMatrices(), var3, var9, var11);
                        a(var5, var6, var10);
                        a(var2, var5, var6, var1, false);
                     }

                     if (!var8.isEmpty()) {
                        a(var2, var8, var0.getMatrices(), var3, var9, var11);
                        a(var5, var6, var10);
                        a(var2, var5, var6, var1, true);
                     }
                  }
               }
            }
         }
      }
   }

   private static void a(class_310 var0, ShaderESP var1, List<class_1297> var2, List<class_1297> var3) {
      boolean var4 = var1.getPlayers().isToggled();
      boolean var5 = var1.getFriends().isToggled();
      boolean var6 = var1.getInvisibles().isToggled();
      boolean var7 = var1.getSelf().isToggled();
      boolean var8 = var1.getMobs().isToggled();

      for (class_1297 var11 : var8 ? var0.field_1687.method_18112() : var0.field_1687.method_18456()) {
         if (var11 != null && var11.method_5805() && !var11.method_31481()) {
            if (var11 instanceof class_1657 var12) {
               if ((var12 != var0.field_1724 || var7 && !var0.field_1690.method_31044().method_31034()) && (!var12.method_5767() || var6)) {
                  boolean var13 = FriendManager.a(var12.method_5477().getString());
                  if (var13) {
                     if (var5) {
                        var3.add(var12);
                     }
                  } else if (var4) {
                     var2.add(var12);
                  }
               }
            } else if (var8 && var11 instanceof class_1588) {
               var2.add(var11);
            }
         }
      }
   }

   private static void a(class_310 var0, List<class_1297> var1, class_4587 var2, class_4184 var3, float var4, boolean var5) {
      GuiBatch.flush();
      CommandEncoder var6 = RenderSystem.getDevice().createCommandEncoder();
      var6.clearColorAndDepthTextures(silhouetteFb.method_30277(), 0, silhouetteFb.method_30278(), 1.0);
      RenderSystem.outputColorTextureOverride = silhouetteFb.method_71639();
      RenderSystem.outputDepthTextureOverride = silhouetteFb.method_71640();
      class_898 var7 = var0.method_1561();
      class_4598 var8 = var0.method_22940().method_23000();
      class_243 var9 = var3.method_71156();

      for (class_1297 var11 : var1) {
         class_243 var12 = var11.method_30950(var4);
         var2.method_22903();
         var2.method_22904(var12.field_1352 - var9.field_1352, var12.field_1351 - var9.field_1351, var12.field_1350 - var9.field_1350);

         try {
            LegacyRenderCompat.a(var7, var11, var4, 0.0, 0.0, 0.0, var2, var8);
         } catch (Exception var15) {
         }

         var2.method_22909();
      }

      try {
         var8.method_22993();
      } catch (Exception var14) {
      }

      RenderSystem.outputColorTextureOverride = null;
      RenderSystem.outputDepthTextureOverride = null;
   }

   private static void a(int var0, int var1, float var2) {
      GuiBatch.flush();
      CommandEncoder var3 = RenderSystem.getDevice().createCommandEncoder();
      class_12137 var4 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
      float var5 = Math.max(1.0F, var2 / 3.0F);
      blurUniformData.clear();
      blurUniformData.putFloat(1.0F / lastBlurWidth);
      blurUniformData.putFloat(1.0F / lastBlurHeight);
      blurUniformData.putFloat(var5);
      blurUniformData.putFloat(0.0F);
      blurUniformData.flip();
      var3.writeToBuffer(blurUniformBuffer.slice(), blurUniformData);

      try (RenderPass var6 = var3.createRenderPass(() -> "ShaderEsp Blur H 1", blurTextureAView, OptionalInt.empty())) {
         var6.setPipeline(blurHPipeline);
         var6.setUniform("BlurUniforms", blurUniformBuffer);
         var6.bindTexture("Sampler0", silhouetteFb.method_71639(), var4);
         var6.draw(0, 6);
      }

      try (RenderPass var17 = var3.createRenderPass(() -> "ShaderEsp Blur V 1", blurTextureBView, OptionalInt.empty())) {
         var17.setPipeline(blurVPipeline);
         var17.setUniform("BlurUniforms", blurUniformBuffer);
         var17.bindTexture("Sampler0", blurTextureAView, var4);
         var17.draw(0, 6);
      }

      blurUniformData.clear();
      blurUniformData.putFloat(1.0F / lastBlurWidth);
      blurUniformData.putFloat(1.0F / lastBlurHeight);
      blurUniformData.putFloat(var5 * 2.0F);
      blurUniformData.putFloat(0.0F);
      blurUniformData.flip();
      var3.writeToBuffer(blurUniformBuffer.slice(), blurUniformData);

      try (RenderPass var18 = var3.createRenderPass(() -> "ShaderEsp Blur H 2", blurTextureAView, OptionalInt.empty())) {
         var18.setPipeline(blurHPipeline);
         var18.setUniform("BlurUniforms", blurUniformBuffer);
         var18.bindTexture("Sampler0", blurTextureBView, var4);
         var18.draw(0, 6);
      }

      try (RenderPass var19 = var3.createRenderPass(() -> "ShaderEsp Blur V 2", blurTextureBView, OptionalInt.empty())) {
         var19.setPipeline(blurVPipeline);
         var19.setUniform("BlurUniforms", blurUniformBuffer);
         var19.bindTexture("Sampler0", blurTextureAView, var4);
         var19.draw(0, 6);
      }
   }

   private static void a(class_310 var0, int var1, int var2, ShaderESP var3, boolean var4) {
      GuiBatch.flush();
      CommandEncoder var5 = RenderSystem.getDevice().createCommandEncoder();
      class_12137 var6 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
      float var7 = (float)(System.currentTimeMillis() % 1000000L / 1000.0) * (float)var3.getGradientSpeed().getValue();
      Color var8;
      Color var9;
      float var10;
      if (var4) {
         var8 = var3.getFriendColor().getColor();
         var9 = var8;
         var10 = 0.0F;
      } else {
         if (var3.getColorMode().isSelected("От темы")) {
            var8 = Theme.getInstance().getAccent();
            var9 = new Color(var8.getBlue(), var8.getRed(), var8.getGreen(), var8.getAlpha());
         } else if (var3.getColorMode().isSelected("Статичный")) {
            var8 = var3.getPrimaryColor().getColor();
            var9 = var8;
         } else {
            var8 = var3.getPrimaryColor().getColor();
            var9 = var3.getSecondaryColor().getColor();
         }

         var10 = !var3.getColorMode().isSelected("Градиент") && !var3.getColorMode().isSelected("От темы") ? 0.0F : 1.0F;
      }

      float var11 = var3.getFill().isToggled() ? (float)var3.getFillOpacity().getValue() : 0.0F;
      compositeUniformData.clear();
      compositeUniformData.putFloat(1.0F / var1);
      compositeUniformData.putFloat(1.0F / var2);
      compositeUniformData.putFloat(var7);
      compositeUniformData.putFloat(var10);
      compositeUniformData.putFloat((float)var3.getOutlineThickness().getValue());
      compositeUniformData.putFloat((float)var3.getOutlineStrength().getValue());
      compositeUniformData.putFloat((float)var3.getGlowIntensity().getValue());
      compositeUniformData.putFloat(var11);
      compositeUniformData.putFloat(var8.getRed() / 255.0F);
      compositeUniformData.putFloat(var8.getGreen() / 255.0F);
      compositeUniformData.putFloat(var8.getBlue() / 255.0F);
      compositeUniformData.putFloat(var8.getAlpha() / 255.0F);
      compositeUniformData.putFloat(var9.getRed() / 255.0F);
      compositeUniformData.putFloat(var9.getGreen() / 255.0F);
      compositeUniformData.putFloat(var9.getBlue() / 255.0F);
      compositeUniformData.putFloat(var9.getAlpha() / 255.0F);
      compositeUniformData.flip();
      var5.writeToBuffer(compositeUniformBuffer.slice(), compositeUniformData);

      try (RenderPass var12 = var5.createRenderPass(
            () -> var4 ? "ShaderEsp Composite Friends" : "ShaderEsp Composite", var0.method_1522().method_71639(), OptionalInt.empty()
         )) {
         var12.setPipeline(compositePipeline);
         var12.setUniform("CompositeUniforms", compositeUniformBuffer);
         var12.bindTexture("Sampler0", silhouetteFb.method_71639(), var6);
         var12.bindTexture("Sampler1", blurTextureBView, var6);
         var12.draw(0, 6);
      }
   }

   private static void b() {
      if (!initialized) {
         blurHPipeline = RenderPipeline.builder()
            .withLocation(class_2960.method_60655("brokke", "shader_esp_blur_h"))
            .withVertexShader(class_2960.method_60655("brokke", "shader_esp_vertex"))
            .withFragmentShader(class_2960.method_60655("brokke", "shader_esp_blur_h"))
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform("BlurUniforms", class_10789.field_60031)
            .withSampler("Sampler0")
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         blurVPipeline = RenderPipeline.builder()
            .withLocation(class_2960.method_60655("brokke", "shader_esp_blur_v"))
            .withVertexShader(class_2960.method_60655("brokke", "shader_esp_vertex"))
            .withFragmentShader(class_2960.method_60655("brokke", "shader_esp_blur_v"))
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform("BlurUniforms", class_10789.field_60031)
            .withSampler("Sampler0")
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         compositePipeline = RenderPipeline.builder()
            .withLocation(class_2960.method_60655("brokke", "shader_esp_composite"))
            .withVertexShader(class_2960.method_60655("brokke", "shader_esp_vertex"))
            .withFragmentShader(class_2960.method_60655("brokke", "shader_esp_composite"))
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform("CompositeUniforms", class_10789.field_60031)
            .withSampler("Sampler0")
            .withSampler("Sampler1")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         blurUniformBuffer = RenderSystem.getDevice().createBuffer(() -> "ShaderEsp Blur Uniforms", 136, 16L);
         blurUniformData = MemoryUtil.memAlloc(16);
         compositeUniformBuffer = RenderSystem.getDevice().createBuffer(() -> "ShaderEsp Composite Uniforms", 136, 64L);
         compositeUniformData = MemoryUtil.memAlloc(64);
         initialized = true;
      }
   }

   private static void a(int var0, int var1) {
      int var2 = Math.max(1, var0 / 2);
      int var3 = Math.max(1, var1 / 2);
      if (silhouetteFb == null
         || blurTextureA == null
         || blurTextureB == null
         || lastWidth != var0
         || lastHeight != var1
         || lastBlurWidth != var2
         || lastBlurHeight != var3) {
         c();
         silhouetteFb = new class_6367("ShaderESP Silhouette", var0, var1, true);
         blurTextureA = RenderSystem.getDevice().createTexture(() -> "brokke:shader_esp_blur_a", 13, TextureFormat.RGBA8, var2, var3, 1, 1);
         blurTextureAView = RenderSystem.getDevice().createTextureView(blurTextureA);
         blurTextureB = RenderSystem.getDevice().createTexture(() -> "brokke:shader_esp_blur_b", 13, TextureFormat.RGBA8, var2, var3, 1, 1);
         blurTextureBView = RenderSystem.getDevice().createTextureView(blurTextureB);
         lastWidth = var0;
         lastHeight = var1;
         lastBlurWidth = var2;
         lastBlurHeight = var3;
      }
   }

   private static void c() {
      if (silhouetteFb != null) {
         silhouetteFb.method_1238();
         silhouetteFb = null;
      }

      if (blurTextureAView != null) {
         blurTextureAView.close();
         blurTextureAView = null;
      }

      if (blurTextureA != null) {
         blurTextureA.close();
         blurTextureA = null;
      }

      if (blurTextureBView != null) {
         blurTextureBView.close();
         blurTextureBView = null;
      }

      if (blurTextureB != null) {
         blurTextureB.close();
         blurTextureB = null;
      }

      lastWidth = 0;
      lastHeight = 0;
      lastBlurWidth = 0;
      lastBlurHeight = 0;
   }

   public static void a() {
      c();
      if (blurUniformBuffer != null) {
         blurUniformBuffer.close();
         blurUniformBuffer = null;
      }

      if (blurUniformData != null) {
         MemoryUtil.memFree(blurUniformData);
         blurUniformData = null;
      }

      if (compositeUniformBuffer != null) {
         compositeUniformBuffer.close();
         compositeUniformBuffer = null;
      }

      if (compositeUniformData != null) {
         MemoryUtil.memFree(compositeUniformData);
         compositeUniformData = null;
      }

      initialized = false;
   }
}
