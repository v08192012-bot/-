package brokke.cc.render;

import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_287;

public final class Render3DUtil {
   private Render3DUtil() {
   }

   public static class_243 a(class_1297 var0, float var1) {
      return var0.method_30950(var1);
   }

   public static float[] a(class_243 var0) {
      return WorldToScreen.a(var0);
   }

   public static void a(class_287 var0, class_243 var1, class_243 var2, Color var3, float var4) {
      float[][] var5 = WorldToScreen.a(var1, var2);
      if (var5 != null) {
         int var6 = var3.getAlpha() << 24 | var3.getRed() << 16 | var3.getGreen() << 8 | var3.getBlue();
         ColorPipeline.a(var0, var5[0][0], var5[0][1], var5[1][0], var5[1][1], var4, var6);
      }
   }

   public static void a(class_287 var0, class_243 var1, float var2, Color var3, float var4) {
      float var5 = var2 * 0.5F;
      class_243[] var6 = new class_243[]{
         new class_243(var1.field_1352 - var5, var1.field_1351 - var5, var1.field_1350 - var5),
         new class_243(var1.field_1352 + var5, var1.field_1351 - var5, var1.field_1350 - var5),
         new class_243(var1.field_1352 + var5, var1.field_1351 - var5, var1.field_1350 + var5),
         new class_243(var1.field_1352 - var5, var1.field_1351 - var5, var1.field_1350 + var5),
         new class_243(var1.field_1352 - var5, var1.field_1351 + var5, var1.field_1350 - var5),
         new class_243(var1.field_1352 + var5, var1.field_1351 + var5, var1.field_1350 - var5),
         new class_243(var1.field_1352 + var5, var1.field_1351 + var5, var1.field_1350 + var5),
         new class_243(var1.field_1352 - var5, var1.field_1351 + var5, var1.field_1350 + var5)
      };
      int[][] var7 = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

      for (int[] var11 : var7) {
         a(var0, var6[var11[0]], var6[var11[1]], var3, var4);
      }
   }

   public static class_287 a() {
      return ColorPipeline.a();
   }

   public static void a(class_287 var0) {
      if (var0 != null) {
         ColorPipeline.a(var0, false);
      }
   }
}
