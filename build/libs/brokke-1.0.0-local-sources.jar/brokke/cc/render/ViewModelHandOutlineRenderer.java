package brokke.cc.render;

import brokke.cc.module.FunctionManager;
import brokke.cc.module.render.ViewModel;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import net.minecraft.class_1041;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_1306;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.lwjgl.system.MemoryUtil;

public final class ViewModelHandOutlineRenderer {
   private static final int UNIFORM_SIZE = 64;
   private static RenderPipeline pipeline;
   private static GpuBuffer uniformBuffer;
   private static ByteBuffer uniformData;
   private static GpuTexture depthTexture;
   private static GpuTextureView depthTextureView;
   private static int sceneWidth = 0;
   private static int sceneHeight = 0;
   private static boolean initialized = false;
   private static boolean hasDepthSnapshot = false;

   public static void a() {
      class_310 var0 = class_310.method_1551();
      if (var0 != null && var0.field_1687 != null && var0.field_1724 != null) {
         ViewModel var1 = FunctionManager.a(ViewModel.class);
         if (var1 != null && var1.isActive() && var0.field_1755 instanceof class_408) {
            float var2 = Math.max(ViewModel.rightHoldAnim, ViewModel.leftHoldAnim);
            if (var2 <= 0.01F) {
               hasDepthSnapshot = false;
            } else {
               class_1041 var3 = var0.method_22683();
               if (var3 != null) {
                  int var4 = var3.method_4489();
                  int var5 = var3.method_4506();
                  if (var4 > 1 && var5 > 1) {
                     class_276 var6 = var0.method_1522();
                     if (var6 != null && var6.method_30278() != null) {
                        try {
                           c();
                           if (!a(var4, var5)) {
                              return;
                           }

                           GpuTexture var7 = var6.method_30278();
                           if ((var7.usage() & 2) != 0) {
                              GuiBatch.flush();
                              CommandEncoder var8 = RenderSystem.getDevice().createCommandEncoder();
                              var8.copyTextureToTexture(var7, depthTexture, 0, 0, 0, 0, 0, var4, var5);
                              hasDepthSnapshot = true;
                           }
                        } catch (Throwable var9) {
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static void b() {
      if (hasDepthSnapshot) {
         hasDepthSnapshot = false;
         class_310 var0 = class_310.method_1551();
         if (var0 != null && var0.field_1687 != null && var0.field_1724 != null) {
            ViewModel var1 = FunctionManager.a(ViewModel.class);
            if (var1 != null && var1.isActive() && var0.field_1755 instanceof class_408) {
               float var2 = Math.max(ViewModel.rightHoldAnim, ViewModel.leftHoldAnim);
               if (!(var2 <= 0.01F)) {
                  class_1041 var3 = var0.method_22683();
                  if (var3 != null) {
                     int var4 = var3.method_4489();
                     int var5 = var3.method_4506();
                     if (var4 > 1 && var5 > 1) {
                        class_276 var6 = var0.method_1522();
                        if (var6 != null && var6.method_30277() != null && var6.method_30278() != null) {
                           try {
                              c();
                              if (pipeline == null || depthTextureView == null) {
                                 return;
                              }

                              float var7 = ViewModel.rightHoldAnim;
                              float var8 = ViewModel.leftHoldAnim;
                              boolean var9 = var7 > 0.01F;
                              boolean var10 = var8 > 0.01F;
                              float var11;
                              if (var9 && !var10) {
                                 var11 = 1.0F;
                              } else if (var10 && !var9) {
                                 var11 = 0.0F;
                              } else {
                                 var11 = -1.0F;
                              }

                              boolean var12 = var0.field_1724 == null || var0.field_1724.method_6068() == class_1306.field_6183;
                              float var13 = var12 ? (float)var1.getMainX().getValue() : (float)var1.getOffX().getValue();
                              float var14 = var12 ? (float)var1.getMainY().getValue() : (float)var1.getOffY().getValue();
                              float var15 = var12 ? (float)var1.getOffX().getValue() : (float)var1.getMainX().getValue();
                              float var16 = var12 ? (float)var1.getOffY().getValue() : (float)var1.getMainY().getValue();
                              float var17 = 0.7F + var13 * 0.35F;
                              float var18 = 0.58F - var14 * 0.35F;
                              float var19 = 0.3F + var15 * 0.35F;
                              float var20 = 0.58F - var16 * 0.35F;
                              float var21 = 1.0F / var4;
                              float var22 = 1.0F / var5;
                              float var23 = (float)var4 / Math.max(1, var5);
                              uniformData.clear();
                              uniformData.putFloat(var4).putFloat(var5).putFloat(var21).putFloat(var22);
                              uniformData.putFloat(var2).putFloat(2.0F).putFloat(var11).putFloat(var23);
                              uniformData.putFloat(1.0F).putFloat(1.0F).putFloat(1.0F).putFloat(var2);
                              uniformData.putFloat(var17).putFloat(var18).putFloat(var19).putFloat(var20);
                              uniformData.flip();
                              GuiBatch.flush();
                              CommandEncoder var24 = RenderSystem.getDevice().createCommandEncoder();
                              var24.writeToBuffer(uniformBuffer.slice(), uniformData);
                              class_12137 var25 = RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST);
                              class_12137 var26 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);

                              try (RenderPass var27 = var24.createRenderPass(
                                    () -> "ViewModelHandOutlineRenderer", var6.method_71639(), OptionalInt.empty()
                                 )) {
                                 var27.setPipeline(pipeline);
                                 var27.setUniform("Uniforms", uniformBuffer);
                                 var27.bindTexture("Sampler0", var6.method_71639(), var26);
                                 var27.bindTexture("Sampler1", var6.method_71640(), var25);
                                 var27.bindTexture("Sampler2", depthTextureView, var25);
                                 var27.draw(0, 6);
                              }
                           } catch (Throwable var32) {
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static void c() {
      if (!initialized) {
         pipeline = RenderPipeline.builder()
            .withLocation(class_2960.method_60655("brokke", "viewmodel_outline"))
            .withVertexShader(class_2960.method_60655("brokke", "viewmodel_outline_vertex"))
            .withFragmentShader(class_2960.method_60655("brokke", "viewmodel_outline_fragment"))
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform("Uniforms", class_10789.field_60031)
            .withSampler("Sampler0")
            .withSampler("Sampler1")
            .withSampler("Sampler2")
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "ViewModelHandOutlineRenderer Uniforms", 136, 64L);
         uniformData = MemoryUtil.memAlloc(64);
         initialized = true;
      }
   }

   private static boolean a(int var0, int var1) {
      if (depthTexture != null && sceneWidth == var0 && sceneHeight == var1) {
         return true;
      }

      d();
      depthTexture = RenderSystem.getDevice().createTexture(() -> "brokke:viewmodel_depth", 13, TextureFormat.DEPTH32, var0, var1, 1, 1);
      depthTextureView = RenderSystem.getDevice().createTextureView(depthTexture);
      sceneWidth = var0;
      sceneHeight = var1;
      return true;
   }

   private static void d() {
      if (depthTextureView != null) {
         depthTextureView.close();
         depthTextureView = null;
      }

      if (depthTexture != null) {
         depthTexture.close();
         depthTexture = null;
      }

      sceneWidth = 0;
      sceneHeight = 0;
   }
}
