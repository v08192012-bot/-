package brokke.cc.hud;

import brokke.cc.animation.Animation;
import brokke.cc.animation.Easing;
import brokke.cc.config.ConfigManager;
import brokke.cc.config.HudConfig;
import brokke.cc.cosmetic.SkinCache;
import brokke.cc.core.ServerHealth;
import brokke.cc.font.Msdf;
import brokke.cc.font.MsdfManager;
import brokke.cc.module.combat.AimAssist;
import brokke.cc.module.combat.Aura;
import brokke.cc.module.combat.FixHp;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.player.StreamerMode;
import brokke.cc.module.combat.TriggerBot;
import brokke.cc.render.GlowPipeline;
import brokke.cc.render.RenderUtil;
import brokke.cc.render.TexturePipeline;
import brokke.cc.render.Theme;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.AttackEntityEvent;
import brokke.cc.system.events.impl.EventPopTotem;
import brokke.cc.system.events.impl.HudRenderEvent;
import brokke.cc.system.events.impl.Render2DEvent;
import brokke.cc.ui.ClickGui;
import brokke.cc.util.ItemUtility;
import brokke.cc.util.ServerUtility;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1044;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import net.minecraft.class_408;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

public class TargetHud {
   private static final TargetHud INSTANCE = new TargetHud();
   private static final String ID = "target";
   private static boolean enabled = false;
   static boolean showOnHover = false;
   private final class_310 mc = class_310.method_1551();
   private static final float CARD_H = 27.0F;
   private static final float HEAD_SIZE = 21.0F;
   private static final float PAD_X = 3.0F;
   private static final float ITEM_SIZE = 8.0F;
   private static final float ITEM_GAP = 1.5F;
   private final Animation alphaAnim = new Animation();
   private final Animation hpAnim = new Animation(1.0F);
   private final Animation hpTrailAnim = new Animation(1.0F);
   private final Animation absorptionAnim = new Animation(0.0F);
   private final Animation popAnim = new Animation(0.0F);
   private class_1309 lastTarget;
   private float lastHpValue = -1.0F;
   private float x = -1.0F;
   private float y = -1.0F;
   private boolean dragging;
   private boolean wasPressed;
   private float dragDX;
   private float dragDY;
   private boolean initPos;
   private float cardW = 95.0F;
   private final List<TargetHud.a> particles = new ArrayList<>();
   private final List<TargetHud.a> particlePool = new ArrayList<>();
   private float prevCircleProgress = -1.0F;
   private long lastParticleTime = 0L;
   private static final Map<UUID, TargetHud.d> ARMOR_CACHE = new ConcurrentHashMap<>();
   private final List<TargetHud.e> targetItems = new ArrayList<>();
   private final List<TargetHud.e> targetItemPool = new ArrayList<>();
   private static String lastRawName;
   private static float lastMaxW;
   private static float lastFontSize;
   private static String cachedTrimmed;

   private TargetHud.a d() {
      return !this.particlePool.isEmpty() ? this.particlePool.remove(this.particlePool.size() - 1) : new TargetHud.a();
   }

   private void a(TargetHud.a var1) {
      if (this.particlePool.size() < 35) {
         this.particlePool.add(var1);
      }
   }

   private void e() {
      for (TargetHud.a var2 : this.particles) {
         this.a(var2);
      }

      this.particles.clear();
      this.prevCircleProgress = -1.0F;
      this.lastParticleTime = 0L;
   }

   private static int a(class_1304 var0) {
      if (var0 == null) {
         return -1;
      }

      return switch (var0) {
         case field_6166 -> 0;
         case field_6172 -> 1;
         case field_6174 -> 2;
         case field_6169 -> 3;
         default -> -1;
      };
   }

   public static boolean a(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         int var1 = var0.method_7919();
         if (var0.method_31574(class_1802.field_22027) && var1 == 203) {
            return true;
         }

         if (var0.method_31574(class_1802.field_22028) && var1 == 183) {
            return true;
         }

         if (var0.method_31574(class_1802.field_22029) && var1 == 96) {
            return true;
         }

         if (var0.method_31574(class_1802.field_22030) && var1 == 123) {
            return true;
         }

         if (!var0.method_31574(class_1802.field_8805) || var1 != 181 && var1 != 182) {
            if (var0.method_31574(class_1802.field_8058) && var1 == 264) {
               return true;
            } else {
               return !var0.method_31574(class_1802.field_8348) || var1 != 247 && var1 != 248 ? var0.method_31574(class_1802.field_8285) && (var1 == 214 || var1 == 215) : true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static class_1304 a(int var0) {
      return switch (var0) {
         case 0 -> class_1304.field_6166;
         case 1 -> class_1304.field_6172;
         case 2 -> class_1304.field_6174;
         case 3 -> class_1304.field_6169;
         default -> null;
      };
   }

   private ItemUtility.a a(class_1309 var1, class_1304 var2, class_1799 var3) {
      if (var3 != null && !var3.method_7960()) {
         int var4;
         if ((var4 = !a(var3) && !ServerUtility.f() ? 0 : 1) == 0 && ItemUtility.u(var3)) {
            ItemUtility.a var5 = ItemUtility.v(var3);
            if (var5 != null) {
               return var5;
            }
         }

         int var13;
         if ((var13 = a(var2)) != -1 && var1 != null) {
            UUID var14 = var1.method_5667();
            TargetHud.d var15 = ARMOR_CACHE.computeIfAbsent(var14, var0 -> new TargetHud.d());
            TargetHud.b var8 = var15.slots[var13];
            int var9;
            if ((var9 = ItemUtility.s(var3)) <= 0) {
               var9 = var3.method_7936();
            }

            if (var9 <= 0) {
               var9 = ItemUtility.t(var3);
            }

            class_1792 var10 = var3.method_7909();
            if (var8.item != var10 || var8.max <= 0) {
               var8.item = var10;
               var8.max = var9;
               var8.cur = var9;
               var8.tracked = false;
            }

            if (var1.field_6235 > 0 && var1.field_6235 != var15.lastHurt) {
               var15.lastHurt = var1.field_6235;
               long var11;
               if ((var11 = System.currentTimeMillis()) - var15.lastHurtTs > 300L) {
                  var15.lastHurtTs = var11;
                  a(var1, 2);
               }
            }

            if (var1 instanceof class_1657 && var1 != this.mc.field_1724) {
               return new ItemUtility.a(Math.max(1, var8.cur), var8.max);
            }

            if (var4 != 0) {
               return new ItemUtility.a(Math.max(1, var8.cur), var8.max);
            }

            ItemUtility.a var16 = ItemUtility.v(var3);
            return var16 != null ? var16 : new ItemUtility.a(Math.max(1, var8.cur), var8.max);
         } else {
            ItemUtility.a var6 = ItemUtility.v(var3);
            if (var6 != null) {
               return var6;
            }

            int var7;
            return (var7 = ItemUtility.s(var3)) > 0 ? new ItemUtility.a(var7, var7) : null;
         }
      } else {
         return null;
      }
   }

   private static void a(class_1309 var0, int var1) {
      if (var0 != null) {
         TargetHud.d var2 = ARMOR_CACHE.computeIfAbsent(var0.method_5667(), var0x -> new TargetHud.d());

         for (int var3 = 0; var3 < 4; var3++) {
            TargetHud.b var4 = var2.slots[var3];
            if (var4.item == null) {
               class_1304 var5 = a(var3);
               if (var5 != null) {
                  class_1799 var6 = var0.method_6118(var5);
                  if (!var6.method_7960()) {
                     var4.item = var6.method_7909();
                     var4.max = ItemUtility.s(var6);
                     if (var4.max <= 0) {
                        var4.max = var6.method_7936();
                     }

                     if (var4.max <= 0) {
                        var4.max = ItemUtility.t(var6);
                     }

                     var4.cur = var4.max;
                  }
               }
            }

            if (var4.item != null) {
               var4.cur = Math.max(1, var4.cur - var1);
               var4.tracked = true;
            }
         }
      }
   }

   @EventHandler
   public void onAttackEntity(AttackEntityEvent var1) {
      if (var1.getTarget() instanceof class_1309 var2 && this.mc.field_1724 != null) {
         class_1799 var10 = this.mc.field_1724.method_6047();
         int var4 = 2;
         if (!var10.method_7960()) {
            if (var10.method_31573(class_3489.field_42612)) {
               var4 = 4;
            } else if (var10.method_31573(class_3489.field_42611)) {
               var4 = 3;
            } else if (var10.method_31574(class_1802.field_49814)) {
               var4 = 5;
            }
         }

         if (this.mc.field_1724.field_6017 > 0.0 && !this.mc.field_1724.method_24828()) {
            var4++;
         }

         TargetHud.d var5 = ARMOR_CACHE.computeIfAbsent(var2.method_5667(), var0 -> new TargetHud.d());
         var5.lastHurtTs = System.currentTimeMillis();

         for (int var6 = 0; var6 < 4; var6++) {
            TargetHud.b var7 = var5.slots[var6];
            if (var7.item == null) {
               class_1304 var8 = a(var6);
               if (var8 != null) {
                  class_1799 var9 = var2.method_6118(var8);
                  if (!var9.method_7960()) {
                     var7.item = var9.method_7909();
                     var7.max = ItemUtility.s(var9);
                     if (var7.max <= 0) {
                        var7.max = var9.method_7936();
                     }

                     if (var7.max <= 0) {
                        var7.max = ItemUtility.t(var9);
                     }

                     var7.cur = var7.max;
                  }
               }
            }

            if (var7.item != null) {
               int var11 = var4;
               if (var6 == 3 && var10.method_31573(class_3489.field_42612)) {
                  var11 += 2;
               }

               var7.cur = Math.max(1, var7.cur - var11);
               var7.tracked = true;
            }
         }
      }
   }

   @EventHandler
   public void onPopTotem(EventPopTotem var1) {
      class_1657 var2 = var1.getPlayer();
      if (var2 != null) {
         a(var2, 12);
      }
   }

   private void a(class_1799 var1, float var2, class_1304 var3) {
      int var4;
      if ((var4 = this.targetItems.size()) < this.targetItemPool.size()) {
         TargetHud.e var5 = this.targetItemPool.get(var4);
         var5.a(var1, var2, var3);
         this.targetItems.add(var5);
      } else {
         TargetHud.e var6 = new TargetHud.e(var1, var2, var3);
         this.targetItemPool.add(var6);
         this.targetItems.add(var6);
      }
   }

   public static float[] a() {
      if (INSTANCE.initPos && !(INSTANCE.x < 0.0F) && !(INSTANCE.y < 0.0F)) {
         return new float[]{INSTANCE.x, INSTANCE.y};
      }

      float var0 = RenderUtil.a();
      float var1 = RenderUtil.b();
      return new float[]{(var0 - 95.0F) * 0.5F, var1 * 0.5F + 35.0F};
   }

   public static void a(float var0, float var1) {
      if (var0 >= 0.0F && var1 >= 0.0F) {
         INSTANCE.x = var0;
         INSTANCE.y = var1;
         INSTANCE.initPos = true;
      }
   }

   public static boolean isEnabled() {
      return enabled;
   }

   public static void setEnabled(boolean var0) {
      enabled = var0;
   }

   public static void a(JsonObject var0) {
      var0.addProperty("enabled", enabled);
      var0.addProperty("showOnHover", showOnHover);
   }

   public static void b(JsonObject var0) {
      if (var0.has("enabled")) {
         enabled = var0.get("enabled").getAsBoolean();
      }

      if (var0.has("showOnHover")) {
         showOnHover = var0.get("showOnHover").getAsBoolean();
      }
   }

   public static void c() {
      EventBus.register(INSTANCE);
      ArrayList var0 = new ArrayList();
      var0.add(new HudConfig.b() {
         @Override
         public String a() {
            return "Показывать при наводке";
         }

         @Override
         public boolean b() {
            return TargetHud.showOnHover;
         }

         @Override
         public void a(boolean var1) {
            TargetHud.showOnHover = var1;
            ConfigManager.onSettingChanged();
         }
      });
      HudConfig.a("target", var0);
   }

   private class_1309 a(class_310 var1) {
      if (var1.field_1755 instanceof class_408) {
         return var1.field_1724;
      } else {
         Aura var2 = FunctionManager.a(Aura.class);
         if (var2 != null && var2.isActive() && var2.getTarget() != null && var2.getTarget().method_5805()) {
            return var2.getTarget();
         } else {
            TriggerBot var3 = FunctionManager.a(TriggerBot.class);
            if (var3 != null && var3.isActive() && var3.k() != null && var3.k().method_5805()) {
               return var3.k();
            } else {
               AimAssist var4 = FunctionManager.a(AimAssist.class);
               if (var4 != null && var4.isActive() && var4.k() != null && var4.k().method_5805()) {
                  return var4.k();
               } else {
                  return showOnHover && var1.field_1692 instanceof class_1309 var5 && var5.method_5805() && var5 != var1.field_1724 ? var5 : null;
               }
            }
         }
      }
   }

   private void a(class_310 var1, float var2, float var3) {
      if (!(var1.field_1755 instanceof class_408)) {
         this.dragging = false;
         this.wasPressed = false;
      } else {
         double var4 = var1.method_22683().method_4495();
         float var6 = (float)(var1.field_1729.method_1603() / var4) * RenderUtil.e();
         float var7 = (float)(var1.field_1729.method_1604() / var4) * RenderUtil.e();
         int var8;
         if ((var8 = GLFW.glfwGetMouseButton(var1.method_22683().method_4490(), 0) == 1 ? 1 : 0) != 0
            && !this.wasPressed
            && !HudConfig.b(var6, var7)
            && var6 >= this.x - 2.0F
            && var6 <= this.x + var2 + 2.0F
            && var7 >= this.y - 2.0F
            && var7 <= this.y + var3 + 2.0F) {
            this.dragging = true;
            this.dragDX = var6 - this.x;
            this.dragDY = var7 - this.y;
         }

         if (var8 == 0) {
            if (this.dragging) {
               HudConfig.b();
            }

            this.dragging = false;
         }

         this.wasPressed = var8 != 0;
         if (this.dragging) {
            float[] var9 = HudConfig.b("target", var6 - this.dragDX, var7 - this.dragDY, var2, var3);
            this.x = var9[0];
            this.y = var9[1];
         }
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent var1) {
      class_310 var2 = class_310.method_1551();
      if (enabled && this.mc.field_1724 != null && !this.mc.field_1690.field_1842) {
         this.alphaAnim.setEasing(Easing.SPRING_SOFT);
         this.hpAnim.setEasing(Easing.SPRING_SOFT);
         this.hpTrailAnim.setEasing(Easing.GENTLE);
         this.absorptionAnim.setEasing(Easing.SPRING_SOFT);
         this.popAnim.setEasing(Easing.SPRING_SOFT);
         class_1309 var3 = this.a(var2);
         this.alphaAnim.animate(var3 != null && var3.method_5805() ? 1.0F : 0.0F, 0.0F, 5.5F);
         float var4;
         if ((var4 = Math.clamp(this.alphaAnim.getValue(), 0.0F, 1.0F)) <= 0.02F) {
            this.lastTarget = null;
            this.targetItems.clear();
            this.lastHpValue = -1.0F;
            this.e();
         } else {
            class_1309 var5 = var3 != null && var3.method_5805() ? var3 : this.lastTarget;
            if (var5 == null) {
               this.targetItems.clear();
               this.e();
            } else {
               if (this.lastTarget != var5) {
                  this.lastHpValue = -1.0F;
                  this.e();
               }

               this.lastTarget = var5;
               int var6 = Math.round(255.0F * var4);
                float var7 = Math.max(1.0F, var5.method_6063());
                float var8 = Math.max(0.0F, var5.method_6032());
                boolean varUnknown = false;
                if (var5 instanceof class_1657 var300) {
                   float var301 = FixHp.scoreHealth(var300);
                   if (var301 < 0.0F) {
                      var301 = ServerHealth.a(var300);
                   }
                   if (var301 >= 0.0F) {
                      var8 = var301;
                   }
                   varUnknown = FixHp.isUnknown(var300);
                }
                float var9 = Math.max(0.0F, var5.method_6067());
                float var10 = Math.clamp((var8 + var9) / var7, 0.0F, 1.0F);
                float var11 = Math.clamp(var9 / var7, 0.0F, 1.0F);
                if (varUnknown) {
                   var8 = 10.0F;
                   var9 = 0.0F;
                   var10 = 0.0F;
                   var11 = 0.0F;
                   this.hpAnim.reset(0.0F);
                   this.hpTrailAnim.reset(0.0F);
                   this.absorptionAnim.reset(0.0F);
                   this.prevCircleProgress = 0.0F;
                }
               if (this.lastHpValue < 0.0F) {
                  this.hpAnim.reset(var10);
                  this.hpTrailAnim.reset(var10);
                  this.absorptionAnim.reset(var11);
                  this.lastHpValue = var8 + var9;
                  this.prevCircleProgress = var10;
                  this.e();
               }

               this.hpAnim.animate(var10, 0.0F, 12.0F);
               this.hpTrailAnim.animate(var10, 0.0F, 4.0F);
               this.absorptionAnim.animate(var11, 0.0F, 12.0F);
               String var12 = StreamerMode.a(var5.method_5477().getString());
                 String var14 = varUnknown ? "?" : String.valueOf((int)var8);
               float var15 = 21.0F;
               float var16 = 2.0F;
               float var17 = 3.0F;
               float var18 = 4.0F;
               float var19 = this.x + 3.0F + 21.0F + var18;
               if (var3 != null && var3.method_5805()) {
                  this.targetItems.clear();
                  float var20 = var19;
                  class_1799 var21 = var5.method_6047();
                  if (!var21.method_7960()) {
                     this.a(var21, var20, null);
                     var20 += 9.5F;
                  }

                  class_1799 var22 = var5.method_6079();
                  if (!var22.method_7960()) {
                     this.a(var22, var20, null);
                     var20 += 9.5F;
                  }

                  for (class_1304 var26 : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
                     class_1799 var27 = var5.method_6118(var26);
                     if (!var27.method_7960()) {
                        this.a(var27, var20, var26);
                        var20 += 9.5F;
                     }
                  }
               }

               float var71 = Msdf.a(MsdfManager.BOLD, var12, 6.5F);
               float var72 = Math.max(
                  this.targetItems.isEmpty() ? 0.0F : this.targetItems.size() * 8.0F + Math.max(0, this.targetItems.size() - 1) * 1.5F, var71
               );
               this.cardW = Math.max(80.0F, 24.0F + var18 + var72 + 5.0F + var15 + var17);
               float var73 = HudConfig.a("target");
               float var74 = this.cardW * var73;
               float var75 = 27.0F * var73;
               this.popAnim.animate(var4, 0.0F, 5.5F);
               float var76 = Math.clamp(this.popAnim.getValue(), 0.0F, 1.0F);
               float var77 = (1.0F - var4) * 4.0F;
               float var28 = (0.94F + 0.06F * var76) * var73;
               if (!this.initPos || this.x < 0.0F || this.y < 0.0F) {
                  float var29 = RenderUtil.a();
                  float var30 = RenderUtil.b();
                  this.x = (var29 - var74) * 0.5F;
                  this.y = var30 * 0.5F + 35.0F;
                  this.initPos = true;
               }

               this.a(var2, var74, var75);
               HudConfig.c("target", this.x, this.y, var74, var75);
               float var78 = this.y + var77;
               float var79 = this.x + this.cardW - var17 - var15;
               float var31 = var78 + (27.0F - var15) / 2.0F;
               float var32 = Math.max(10.0F, var79 - var19 - 4.0F);
               String var33 = a(var12, var32, 6.5F);
               Matrix4f var34 = RenderUtil.d();
               var34.translate(this.x, var78, 0.0F);
               var34.scale(var28, var28, 1.0F);
               var34.translate(-this.x, -var78, 0.0F);
               HudConfig.a(var34, "target", this.x, var78, this.cardW, 27.0F, 5.0F, var6 << 24);
               float var35 = this.x + 3.0F;
               float var36 = var78 + 3.0F;
               int var10000 = Math.round(140.0F * var4) << 24 | 1966080 | 7680 | 40;
               var10000 = Math.round(25.0F * var4) << 24 | 16777215;
               float var39 = var5.field_6235 > 0 ? Math.clamp(var5.field_6235 / 10.0F, 0.0F, 1.0F) : 0.0F;
               if (var5 instanceof class_1657 var40) {
                  this.a(var34, var2, var40, var35, var36, 21.0F, var6, var39);
               } else {
                  this.a(var34, var2, var5, var35, var36, 21.0F, var6, var39);
               }

               float var80 = this.targetItems.isEmpty() ? var78 + 10.0F : var78 + 4.5F;
               Msdf.a(var34, MsdfManager.BOLD, var33, var19, var80, 6.5F, a(Color.WHITE, var6));
               float var41 = Math.clamp(this.hpAnim.getValue(), 0.0F, 1.0F);
               float var42 = Math.clamp(this.absorptionAnim.getValue(), 0.0F, 1.0F);
               Color var43 = Theme.getInstance().getAccent();
               Color var44 = new Color(55, 58, 72, 120);
               RenderUtil.a(var34, var79, var31, var15, var16, var41, var43, var44, var4);
               if (var42 > 0.001F) {
                  RenderUtil.a(var34, var79, var31, var15, var16, var42, new Color(255, 205, 35), new Color(0, 0, 0, 0), var4);
               }

               long var45 = System.nanoTime();
               float var47 = this.lastParticleTime > 0L ? (float)((var45 - this.lastParticleTime) / 1.0E9) : 0.016F;
               this.lastParticleTime = var45;
               if (var47 > 0.05F) {
                  var47 = 0.05F;
               }

               if (var47 < 0.001F) {
                  var47 = 0.001F;
               }

               float var48 = var47 * 60.0F;
               float var49 = var79 + var15 * 0.5F;
               float var50 = var31 + var15 * 0.5F;
               float var51 = (var15 - var16) * 0.5F;
               if (this.prevCircleProgress < 0.0F) {
                  this.prevCircleProgress = var41;
               } else if (!(this.prevCircleProgress > var41)) {
                  this.prevCircleProgress = var41;
               } else {
                  float var52;
                  if ((var52 = this.prevCircleProgress - var41) > 3.0E-4F) {
                     int var53 = Math.clamp((int)(var52 * 140.0F) + 1, 1, 3);
                     Color var54 = var42 > 0.001F && var41 <= var42 ? new Color(255, 215, 60) : var43;

                     for (int var55 = 0; var55 < var53 && this.particles.size() < 28; var55++) {
                        float var56 = var41 + (float)Math.random() * Math.min(var52, 0.025F);
                        float var57;
                        float var58 = (float)Math.cos(var57 = (float) (-Math.PI / 2) + var56 * (float) (Math.PI * 2));
                        float var59 = (float)Math.sin(var57);
                        float var60 = var51 + ((float)Math.random() - 0.5F) * 0.6F;
                        float var61 = 0.22F + (float)Math.random() * 0.22F;
                        float var62 = 0.2F + (float)Math.random() * 0.2F;
                        float var63 = ((float)Math.random() - 0.5F) * 0.12F;
                        float var64 = ((float)Math.random() - 0.5F) * 0.12F;
                        TargetHud.a var65 = this.d();
                        var65.relX = var58 * var60;
                        var65.relY = var59 * var60;
                        var65.vx = -var59 * var61 + var58 * var62 + var63;
                        var65.vy = var58 * var61 + var59 * var62 + var64;
                        var65.life = 0.0F;
                        var65.maxLife = 0.22F + (float)Math.random() * 0.14F;
                        var65.coreSize = 0.7F + (float)Math.random() * 0.4F;
                        var65.glowSize = 1.8F + (float)Math.random() * 0.8F;
                        var65.color = var54;
                        this.particles.add(var65);
                     }
                  }

                  this.prevCircleProgress = var41;
               }

               for (int var81 = this.particles.size() - 1; var81 >= 0; var81--) {
                  TargetHud.a var85 = this.particles.get(var81);
                  var85.life += var47;
                  if (var85.life >= var85.maxLife) {
                     this.particles.remove(var81);
                     this.a(var85);
                  } else {
                     var85.relX = var85.relX + var85.vx * var48;
                     var85.relY = var85.relY + var85.vy * var48;
                     var85.vx = var85.vx * (float)Math.pow(0.88, var48);
                     var85.vy = var85.vy * (float)Math.pow(0.88, var48);
                  }
               }

               if (!this.particles.isEmpty()) {
                  for (TargetHud.a var86 : this.particles) {
                     float var89 = var86.life / var86.maxLife;
                     float var93;
                     if (!((var93 = (1.0F - var89) * (1.0F - var89) * var4) <= 0.01F)) {
                        float var95 = var49 + var86.relX;
                        float var97 = var50 + var86.relY;
                        float var99 = var86.glowSize * (1.0F - var89 * 0.3F);
                        int var101 = var86.color.getRed();
                        int var103 = var86.color.getGreen();
                        int var105 = var86.color.getBlue();
                        int var108 = Math.clamp((int)(var93 * 170.0F), 0, 255) << 24 | var101 << 16 | var103 << 8 | var105;
                        GlowPipeline.a(var34, var95, var97, var99, var108, 0.0F);
                     }
                  }

                  RenderUtil.f();

                  for (TargetHud.a var87 : this.particles) {
                     float var90 = var87.life / var87.maxLife;
                     float var94;
                     if (!((var94 = (1.0F - var90) * (1.0F - var90) * var4) <= 0.01F)) {
                        float var96 = var49 + var87.relX;
                        float var98 = var50 + var87.relY;
                        float var100;
                        float var102 = (var100 = var87.coreSize * (1.0F - var90 * 0.5F)) * 2.0F;
                        int var104 = var87.color.getRed();
                        int var106 = var87.color.getGreen();
                        int var107 = var87.color.getBlue();
                        int var109 = Math.clamp((int)(var94 * 70.0F), 0, 255) << 24 | var104 << 16 | var106 << 8 | var107;
                        RenderUtil.a(var34, var96 - var102 * 0.5F, var98 - var102 * 0.5F, var102, var102, var102 * 0.5F, var109);
                        int var66 = Math.min(255, var104 + (int)((255 - var104) * 0.75F));
                        int var67 = Math.min(255, var106 + (int)((255 - var106) * 0.75F));
                        int var68 = Math.min(255, var107 + (int)((255 - var107) * 0.75F));
                        int var70 = Math.clamp((int)(var94 * 255.0F), 0, 255) << 24 | var66 << 16 | var67 << 8 | var68;
                        RenderUtil.a(var34, var96 - var100 * 0.5F, var98 - var100 * 0.5F, var100, var100, var100 * 0.5F, var70);
                     }
                  }

                  RenderUtil.g();
               }

                float var84 = var8 < 10.0F ? 8.5F : 6.25F;
                float var88 = Msdf.a(MsdfManager.BOLD, var14, var84);
                float var91 = var79 + (var15 - var88) / 2.0F;
                float var92 = var31 + var15 / 2.0F - 0.593F * var84;
                Msdf.a(var34, MsdfManager.BOLD, var14, var91, var92, var84, a(varUnknown ? new Color(170, 170, 170) : b(var8), var6));
               HudConfig.c("target");
            }
         }
      }
   }

   @EventHandler
   public void onHudRender(HudRenderEvent var1) {
      float var2;
      if (enabled
         && this.mc.field_1724 != null
         && !this.mc.field_1690.field_1842
         && !((var2 = Math.clamp(this.alphaAnim.getValue(), 0.0F, 1.0F)) <= 0.02F)
         && this.lastTarget != null) {
         class_332 var3 = var1.getContext();
         float var4 = HudConfig.a("target");
         float var5 = Math.clamp(this.popAnim.getValue(), 0.0F, 1.0F);
         float var6 = (0.94F + 0.06F * var5) * var4;
         float var7 = (1.0F - var2) * 4.0F;
         float var8 = this.y + var7;
         if (this.lastTarget != null && !(this.lastTarget instanceof class_1657) && a(this.lastTarget.method_5864()) == null) {
            class_1799 var9 = a(this.lastTarget);
            if (!var9.method_7960()) {
               float var10 = 13.0F;
               float var11 = this.x + 3.0F;
               float var12 = var8 + 3.0F;
               float var13 = var11 + (21.0F - var10) / 2.0F;
               float var14 = var12 + (21.0F - var10) / 2.0F;
               if (!ClickGui.a(var13, var14, var10, var10)) {
                  this.a(var3, var9, var13, var14, var10, var6, this.x, var8);
               }
            }
         }

         if (!this.targetItems.isEmpty()) {
            float var15 = var8 + 13.5F;

            for (TargetHud.e var17 : this.targetItems) {
               float var18 = var17.relX;
               if (!ClickGui.a(var17.relX, var15, 8.0F, 8.0F)) {
                  this.a(var3, var17.stack, var18, var15, 8.0F, var6, this.x, var8);
               }
            }
         }
      }
   }

   private static String a(String var0, float var1, float var2) {
      if (var0 != null && !var0.isEmpty() && !(var1 <= 0.0F)) {
         if (var0.equals(lastRawName) && Math.abs(var1 - lastMaxW) < 0.5F && var2 == lastFontSize) {
            return cachedTrimmed;
         }

         lastRawName = var0;
         lastMaxW = var1;
         lastFontSize = var2;
         if (Msdf.a(MsdfManager.BOLD, var0, var2) <= var1) {
            cachedTrimmed = var0;
            return var0;
         }

         String var3 = "...";
         float var4;
         if ((var4 = Msdf.a(MsdfManager.BOLD, var3, var2)) >= var1) {
            cachedTrimmed = var3;
            return var3;
         }

         float var5 = var1 - var4;
         int var6 = var0.length();

         while (var6 > 0 && Msdf.a(MsdfManager.BOLD, var0.substring(0, var6), var2) > var5) {
            var6--;
         }

         cachedTrimmed = var0.substring(0, var6) + var3;
         return cachedTrimmed;
      } else {
         return "";
      }
   }

   private static TargetHud.c a(class_1299<?> var0) {
      if (var0 == class_1299.field_6076) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/skeleton/wither_skeleton.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6137) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/skeleton/skeleton.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6098) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/skeleton/stray.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_49148) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/skeleton/bogged.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6051 || var0 == class_1299.field_6095) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/zombie/zombie.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6071) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/zombie/husk.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6123) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/zombie/drowned.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6054) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/zombie_villager/zombie_villager.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6046) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/creeper/creeper.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6079) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/spider/spider.png"), 0.5F, 0.125F, 0.625F, 0.375F);
      } else if (var0 == class_1299.field_6084) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/spider/cave_spider.png"), 0.5F, 0.125F, 0.625F, 0.375F);
      } else if (var0 == class_1299.field_6091) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/enderman/enderman.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6093) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/pig/pig.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6085) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/cow/cow.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6143) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/cow/red_mooshroom.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6115) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/sheep/sheep.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6132) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/chicken.png"), 0.0F, 0.28125F, 0.09375F, 0.46875F);
      } else if (var0 == class_1299.field_6099) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/blaze.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6069) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/slime/slime.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6102) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/slime/magmacube.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_22281) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/piglin/piglin.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_25751) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/piglin/piglin_brute.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6050) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/piglin/zombified_piglin.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6077) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/villager/villager.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_17713) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/wandering_trader.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6147) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/iron_golem/iron_golem.png"), 0.0625F, 0.078125F, 0.125F, 0.15625F);
      } else if (var0 == class_1299.field_6047) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/snow_golem.png"), 0.125F, 0.25F, 0.25F, 0.5F);
      } else if (var0 == class_1299.field_6145) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/witch.png"), 0.125F, 0.0625F, 0.25F, 0.125F);
      } else if (var0 == class_1299.field_6090) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/illager/evoker.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6117) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/illager/vindicator.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6105) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/illager/pillager.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6065) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/illager/illusioner.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6119) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/wither/wither.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6107) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/ghast/ghast.png"), 0.125F, 0.25F, 0.375F, 0.75F);
      } else if (var0 == class_1299.field_38095) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/warden/warden.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_47244) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/breeze/breeze.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6118) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/guardian.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6086) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/guardian_elder.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6055) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/wolf/wolf.png"), 0.125F, 0.25F, 0.21875F, 0.4375F);
      } else if (var0 == class_1299.field_16281 || var0 == class_1299.field_6081) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/cat/all_black.png"), 0.125F, 0.25F, 0.203125F, 0.40625F);
      } else if (var0 == class_1299.field_17943) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/fox/fox.png"), 0.125F, 0.25F, 0.25F, 0.4375F);
      } else if (var0 == class_1299.field_6108) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/bat.png"), 0.25F, 0.25F, 0.4375F, 0.4375F);
      } else if (var0 == class_1299.field_6109) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/shulker/shulker.png"), 0.125F, 0.125F, 0.25F, 0.25F);
      } else if (var0 == class_1299.field_6114) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/squid/squid.png"), 0.125F, 0.25F, 0.3125F, 0.625F);
      } else if (var0 == class_1299.field_28402) {
         return new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/squid/glow_squid.png"), 0.125F, 0.25F, 0.3125F, 0.625F);
      } else {
         return var0 == class_1299.field_6116
            ? new TargetHud.c(class_2960.method_60655("minecraft", "textures/entity/enderdragon/dragon.png"), 0.6875F, 0.171875F, 0.75F, 0.234375F)
            : null;
      }
   }

   public static class_1799 a(class_1309 var0) {
      if (var0 == null) {
         return class_1799.field_8037;
      }

      class_1299 var1 = var0.method_5864();
      if (var1 == class_1299.field_6051) {
         return new class_1799(class_1802.field_8470);
      }

      if (var1 == class_1299.field_6137) {
         return new class_1799(class_1802.field_8398);
      }

      if (var1 == class_1299.field_6076) {
         return new class_1799(class_1802.field_8791);
      }

      if (var1 == class_1299.field_6046) {
         return new class_1799(class_1802.field_8681);
      }

      if (var1 == class_1299.field_22281) {
         return new class_1799(class_1802.field_41304);
      }

      if (var1 == class_1299.field_6116) {
         return new class_1799(class_1802.field_8712);
      }

      if (var1 == class_1299.field_6147) {
         return new class_1799(class_1802.field_8773);
      }

      if (var1 == class_1299.field_6047) {
         return new class_1799(class_1802.field_17519);
      }

      class_1826 var2 = class_1826.method_8019(var1);
      return var2 != null ? new class_1799(var2) : class_1799.field_8037;
   }

   private void a(class_332 var1, class_1799 var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = 2.0F / this.mc.method_22683().method_4495();
      Matrix3x2fStack var10 = var1.method_51448();
      var10.pushMatrix();
      var10.translate(var7 * var9, var8 * var9);
      var10.scale(var6, var6);
      var10.translate((var3 - var7 + var5 * 0.5F) * var9, (var4 - var8 + var5 * 0.5F) * var9);
      float var11 = var5 / 16.0F * var9;
      var10.scale(var11, var11);
      var10.translate(-8.0F, -8.0F);
      var1.method_51427(var2, 0, 0);
      var10.popMatrix();
   }

   private void a(Matrix4f var1, class_310 var2, class_1657 var3, float var4, float var5, float var6, int var7, float var8) {
      if (var3.method_5767()) {
         String var50 = "?";
         float var51 = var6 * 0.75F;
         float var52 = Msdf.a(MsdfManager.BOLD, var50, var51);
         Msdf.b();
         Msdf.a(var1, MsdfManager.BOLD, var50, var4 + (var6 - var52) / 2.0F, var5 + var6 / 2.0F - 0.593F * var51, var51, a(Color.WHITE, var7));
         Msdf.c();
      } else {
         class_2960 var9 = SkinCache.a(var2, var3);
         if (var9 != null) {
            try {
               GpuTextureView var10 = var2.method_1531().method_4619(var9).method_71659();
               short var11 = 255;
               int var12 = (int)(255.0F * (1.0F - 0.75F * var8));
               int var13 = (int)(255.0F * (1.0F - 0.75F * var8));
               int var14 = var7 << 24 | var11 << 16 | var12 << 8 | var13;
               TexturePipeline.b(var1, var4 + 0.5F, var5 + 0.5F, var6 - 1.0F, var6 - 1.0F, var10, var14, 3.5F, 0.0F, 0.125F, 0.125F, 0.25F, 0.25F);
               TexturePipeline.b(var1, var4 + 0.5F, var5 + 0.5F, var6 - 1.0F, var6 - 1.0F, var10, var14, 3.5F, 0.0F, 0.625F, 0.125F, 0.75F, 0.25F);
            } catch (Exception var15) {
            }
         }
      }
   }

   private void a(Matrix4f var1, class_310 var2, class_1309 var3, float var4, float var5, float var6, int var7, float var8) {
      TargetHud.c var9 = a(var3.method_5864());
      if (var9 != null) {
         try {
            class_1044 var10 = var2.method_1531().method_4619(var9.getId());
            if (var10 != null) {
               GpuTextureView var11 = var10.method_71659();
               short var12 = 255;
               int var13 = (int)(255.0F * (1.0F - 0.75F * var8));
               int var14 = (int)(255.0F * (1.0F - 0.75F * var8));
               int var15 = var7 << 24 | var12 << 16 | var13 << 8 | var14;
               TexturePipeline.b(
                  var1, var4 + 0.5F, var5 + 0.5F, var6 - 1.0F, var6 - 1.0F, var11, var15, 3.5F, 0.0F, var9.getU0(), var9.getV0(), var9.getU1(), var9.getV1()
               );
            }
         } catch (Exception var16) {
         }
      }
   }

   private static int a(Color var0, int var1) {
      return Math.clamp(var1, 0, 255) << 24 | var0.getRed() << 16 | var0.getGreen() << 8 | var0.getBlue();
   }

   private static Color b(float var0) {
      if (var0 <= 5.0F) {
         return new Color(255, 85, 85);
      } else if (var0 <= 10.0F) {
         return new Color(255, 170, 0);
      } else if (var0 <= 15.0F) {
         return new Color(255, 255, 85);
      } else {
         return var0 <= 20.0F ? new Color(85, 255, 85) : new Color(0, 170, 0);
      }
   }

   private static Color a(int var0, int var1) {
      if (var1 <= 0) {
         return Color.WHITE;
      } else {
         float var2;
         if ((var2 = Math.clamp((float)var0 / var1, 0.0F, 1.0F)) >= 0.5F) {
            float var7 = (var2 - 0.5F) * 2.0F;
            int var8 = (int)(255.0F * (1.0F - var7) + 78.0F * var7);
            int var9 = (int)(200.0F * (1.0F - var7) + 205.0F * var7);
            int var10 = (int)(60.0F * (1.0F - var7) + 120.0F * var7);
            return new Color(var8, var9, var10);
         } else {
            float var3 = var2 * 2.0F;
            int var4 = (int)(240.0F * (1.0F - var3) + 255.0F * var3);
            int var5 = (int)(65.0F * (1.0F - var3) + 200.0F * var3);
            int var6 = (int)(65.0F * (1.0F - var3) + 60.0F * var3);
            return new Color(var4, var5, var6);
         }
      }
   }

   static class a {
      float relX;
      float relY;
      float vx;
      float vy;
      float life;
      float maxLife;
      float coreSize;
      float glowSize;
      Color color;
   }

   static class b {
      class_1792 item;
      int cur;
      int max;
      boolean tracked;
   }

   record c(class_2960 id, float u0, float v0, float u1, float v1) {
      public class_2960 getId() {
         return this.id;
      }

      public float getU0() {
         return this.u0;
      }

      public float getV0() {
         return this.v0;
      }

      public float getU1() {
         return this.u1;
      }

      public float getV1() {
         return this.v1;
      }
   }

   static class d {
      final TargetHud.b[] slots = new TargetHud.b[]{new TargetHud.b(), new TargetHud.b(), new TargetHud.b(), new TargetHud.b()};
      int lastHurt;
      long lastHurtTs;
   }

   static class e {
      class_1799 stack;
      float relX;
      class_1304 slot;

      e() {
      }

      e(class_1799 var1, float var2, class_1304 var3) {
         this.stack = var1;
         this.relX = var2;
         this.slot = var3;
      }

      void a(class_1799 var1, float var2, class_1304 var3) {
         this.stack = var1;
         this.relX = var2;
         this.slot = var3;
      }
   }
}
