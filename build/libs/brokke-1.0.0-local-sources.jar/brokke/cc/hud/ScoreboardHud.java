package brokke.cc.hud;

import brokke.cc.animation.Animation;
import brokke.cc.animation.Easing;
import brokke.cc.config.ConfigManager;
import brokke.cc.config.HudConfig;
import brokke.cc.core.ScoreboardAnimator;
import brokke.cc.module.player.StreamerMode;
import brokke.cc.render.RenderUtil;
import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.EventManager;
import brokke.cc.system.events.impl.HudRenderEvent;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import org.lwjgl.glfw.GLFW;

public class ScoreboardHud {
   private static final ScoreboardHud INSTANCE = new ScoreboardHud();
   private static final String ID = "scoreboard";
   private static boolean enabled = false;
   private static final float PAD_X = 7.0F;
   private static final float PAD_Y = 6.0F;
   private static final float HEADER_GAP = 5.0F;
   private static final float ROW_HEIGHT = 10.0F;
   private static final float MIN_WIDTH = 72.0F;
   private final class_310 mc = class_310.method_1551();
   private final Animation entryAnim = new Animation();
   private float x = -1.0F;
   private float y = -1.0F;
   private boolean dragging;
   private boolean wasPressed;
   private float dragDX;
   private float dragDY;
   private boolean initPos;
   private float panelW;
   private float panelH;
   private boolean visible;
   private boolean rightAnchored = true;
   private float anchorEdge = 0.0F;
   private boolean anchorReady = false;
   private class_2561 cachedTitle;
   private final List<class_2561> cachedNames = new ArrayList<>();
   private long lastScoreboardUpdate = 0L;
   private class_266 lastObjective = null;

   public static float[] a() {
      if (INSTANCE.initPos && !(INSTANCE.x < 0.0F) && !(INSTANCE.y < 0.0F)) {
         return new float[]{INSTANCE.x, INSTANCE.y};
      }

      float var0 = RenderUtil.a();
      return new float[]{Math.max(7.0F, var0 - 150.0F), 6.0F};
   }

   public static void a(float var0, float var1) {
      if (var0 >= 0.0F && var1 >= 0.0F) {
         INSTANCE.x = var0;
         INSTANCE.y = var1;
         INSTANCE.initPos = true;
         INSTANCE.anchorReady = false;
      }
   }

   public static boolean isEnabled() {
      return enabled;
   }

   public static void setEnabled(boolean var0) {
      enabled = var0;
   }

   public static void a(JsonObject var0) {
      var0.addProperty("enabled", enabled);
   }

   public static void b(JsonObject var0) {
      if (var0.has("enabled")) {
         enabled = var0.get("enabled").getAsBoolean();
      }
   }

   public static void c() {
      EventBus.register(INSTANCE);
   }

   private static class_266 a(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null) {
         class_269 var1 = var0.field_1687.method_8428();
         class_268 var2 = var1.method_1164(var0.field_1724.method_5820());
         if (var2 != null) {
            class_124 var3 = var2.method_1202();
            if (var3 != null) {
               class_8646 var4 = class_8646.method_52622(var3);
               if (var4 != null) {
                  class_266 var5 = var1.method_1189(var4);
                  if (var5 != null) {
                     return var5;
                  }
               }
            }
         }

         return var1.method_1189(class_8646.field_45157);
      } else {
         return null;
      }
   }

   private void a(class_310 var1, float var2, float var3) {
      if (!(var1.field_1755 instanceof class_408)) {
         this.dragging = false;
         this.wasPressed = false;
      } else {
         double var4 = var1.method_22683().method_4495();
         float var6 = (float)(var1.field_1729.method_1603() / var4) * RenderUtil.e();
         float var7 = (float)(var1.field_1729.method_1604() / var4) * RenderUtil.e();
         int var8;
         if ((var8 = GLFW.glfwGetMouseButton(var1.method_22683().method_4490(), 0) == 1 ? 1 : 0) != 0
            && !this.wasPressed
            && !HudConfig.b(var6, var7)
            && var6 >= this.x - 2.0F
            && var6 <= this.x + var2 + 2.0F
            && var7 >= this.y - 2.0F
            && var7 <= this.y + var3 + 2.0F) {
            this.dragging = true;
            this.dragDX = var6 - this.x;
            this.dragDY = var7 - this.y;
         }

         boolean var9 = this.dragging;
         if (var8 == 0) {
            if (this.dragging) {
               HudConfig.b();
            }

            this.dragging = false;
         }

         this.wasPressed = var8 != 0;
         if (this.dragging) {
            float[] var10 = HudConfig.b("scoreboard", var6 - this.dragDX, var7 - this.dragDY, var2, var3);
            this.x = var10[0];
            this.y = var10[1];
            float var11 = RenderUtil.a();
            this.rightAnchored = this.x + var2 / 2.0F >= var11 / 2.0F;
            this.anchorEdge = this.rightAnchored ? this.x + var2 : this.x;
            this.anchorReady = true;
         } else if (var9) {
            float var12 = RenderUtil.a();
            this.rightAnchored = this.x + var2 / 2.0F >= var12 / 2.0F;
            this.anchorEdge = this.rightAnchored ? this.x + var2 : this.x;
            this.anchorReady = true;
            ConfigManager.onSettingChanged();
         }
      }
   }

   @EventHandler
   public void onHudRender(HudRenderEvent var1) {
      class_310 var2 = class_310.method_1551();
      if (enabled && var2.field_1755 != EventManager.clickGui) {
         class_266 var3 = a(var2);
         this.visible = var2.field_1724 != null && !var2.field_1690.field_1842 && var3 != null;
         if (this.visible) {
            this.entryAnim.setEasing(Easing.SPRING);
            this.entryAnim.animate(1.0F, 0.0F, 8.0F);
            float var4 = Math.clamp(this.entryAnim.getValue(), 0.0F, 1.0F);
            float var5 = (1.0F - var4) * 6.0F;
            class_332 var6 = var1.getContext();
            float var7 = 2.0F / var2.method_22683().method_4495();
            float var8 = HudConfig.a("scoreboard");
            long var9;
            if ((var9 = System.currentTimeMillis()) - this.lastScoreboardUpdate > 100L || this.lastObjective != var3 || this.cachedTitle == null) {
               if (this.lastObjective != var3) {
                  ScoreboardAnimator.clearTRACKER();
               }

               this.lastScoreboardUpdate = var9;
               this.lastObjective = var3;
               class_269 var11 = var3.method_1117();
               List<class_9011> var12 = new ArrayList<>(var11.method_1184(var3));
               var12.removeIf(class_9011::method_55385);
               var12.sort(Comparator.comparing(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER));
               if (var12.size() > 15) {
                  var12 = new ArrayList<>(var12.subList(0, 15));
               }

               this.cachedTitle = StreamerMode.a(var3.method_1114());
               this.cachedNames.clear();

               for (class_9011 var14 : var12) {
                  class_268 var15 = var11.method_1164(var14.comp_2127());
                  class_2561 var16 = StreamerMode.a(class_268.method_1142(var15, var14.method_55387()));
                  this.cachedNames.add(var16);
               }
            }

            class_2561 var27 = this.cachedTitle;
            List var28 = this.cachedNames;
            int var29 = var28.size();
            ArrayList var30 = new ArrayList(var29);
            int var31 = var2.field_1772.method_27525(var27);

            for (int var32 = 0; var32 < var29; var32++) {
               class_2561 var17 = ScoreboardAnimator.a(var32, (class_2561)var28.get(var32), var9);
               var30.add(var17);
               int var18;
               if ((var18 = var2.field_1772.method_27525(var17)) > var31) {
                  var31 = var18;
               }
            }

            float var33 = Math.max(72.0F, var31 + 14.0F);
            float var34 = 21.0F + (var29 == 0 ? 0.0F : 5.0F + var29 * 10.0F);
            float var35;
            float var19 = (var35 = RenderUtil.a()) > 30.0F ? Math.min(1.0F, (var35 - 10.0F) / (var33 * var7 * var8)) : 1.0F;
            float var20 = var7 * var8 * var19;
            this.panelW = var33 * var20;
            this.panelH = var34 * var20;
            if ((!this.initPos || this.x < 0.0F || this.y < 0.0F) && var35 > 30.0F) {
               this.rightAnchored = true;
               this.anchorEdge = var35 - 6.0F;
               this.x = this.anchorEdge - this.panelW;
               this.y = 6.0F;
               this.initPos = true;
               this.anchorReady = true;
            }

            this.a(var2, this.panelW, this.panelH);
            HudConfig.c("scoreboard", this.x, this.y, this.panelW, this.panelH);
            if (var35 > 30.0F) {
               if (!this.anchorReady) {
                  this.rightAnchored = this.x + this.panelW / 2.0F >= var35 / 2.0F;
                  this.anchorEdge = this.rightAnchored ? this.x + this.panelW : this.x;
                  this.anchorReady = true;
               }

               if (this.dragging) {
                  this.rightAnchored = this.x + this.panelW / 2.0F >= var35 / 2.0F;
                  this.anchorEdge = this.rightAnchored ? this.x + this.panelW : this.x;
               } else {
                  this.x = this.rightAnchored ? this.anchorEdge - this.panelW : this.anchorEdge;
               }

               if (this.x > var35 - 2.0F) {
                  this.x = var35 - 2.0F;
                  if (this.rightAnchored) {
                     this.anchorEdge = this.x + this.panelW;
                  }
               } else if (this.x < 2.0F) {
                  this.x = 2.0F;
                  if (!this.rightAnchored) {
                     this.anchorEdge = this.x;
                  }
               }
            }

            HudConfig.a("scoreboard", this.x, this.y + var5, this.panelW, this.panelH - 1.0F, 6.0F, (int)(175.0F * var4) << 24);
            int var21 = var2.field_1772.method_27525(var27);
            var6.method_51448().pushMatrix();
            var6.method_51448().translate(this.x, this.y + var5);
            var6.method_51448().scale(var20, var20);
            int var22 = (int)((var33 - var21) * 0.5F);
            byte var23 = 6;
            var6.method_51439(var2.field_1772, var27, var22, var23, -1, false);
            if (var29 > 0) {
               RenderUtil.a(this.x + 7.0F * var20, this.y + 17.0F * var20, this.panelW - 14.0F * var20, 1.0F, 0.5F, 603979775);

               for (int var24 = 0; var24 < var29; var24++) {
                  int var25 = (int)(20.0F + var24 * 10.0F);
                  byte var26 = 7;
                  var6.method_51439(var2.field_1772, (class_2561)var30.get(var24), var26, var25, -1, false);
               }
            }

            var6.method_51448().popMatrix();
            HudConfig.c("scoreboard");
         }
      }
   }
}
