package brokke.cc.cosmetic;

import java.util.List;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_746;

public class CosmeticFeatureRenderer extends class_3887<class_10055, class_591> {
   public CosmeticFeatureRenderer(class_3883<class_10055, class_591> var1) {
      super(var1);
   }

   public void render(class_4587 var1, class_11659 var2, int var3, class_10055 var4, float var5, float var6) {
      class_310 var7 = class_310.method_1551();
      class_746 var8 = var7.field_1724;
      if (var8 != null && var2 != null && var4 != null && !var4.field_53542 && var4.field_53528 == var8.method_5628()) {
         List var9 = LocalCosmetics.e();
         if (!var9.isEmpty()) {
            for (Integer var11 : (Iterable<Integer>)(Iterable<?>)(var9)) {
               if (var11 != null && !"cape".equals(LocalCosmetics.b(var11))) {
                  CosmeticModel var12 = LocalCosmetics.g(var11);
                  if (var12 != null && var12.getTextureId() != null) {
                     class_1921 var13 = class_12249.method_75994(var12.getTextureId());
                     var2.method_73483(var1, var13, (var5x, var6xx) -> {
                        class_4587 var7x = new class_4587();
                        var7x.method_34425(var5x.method_23761());
                        CosmeticRenderer.a().a(var12, var8, var7x, var6xx, var3, this.method_17165(), var6);
                     });
                  }
               }
            }
         }
      }
   }
}
