package brokke.cc.cosmetic;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import net.minecraft.class_1044;
import net.minecraft.class_1068;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4844;
import net.minecraft.class_640;
import net.minecraft.class_8685;

public class SkinCache {
   private static final Map<UUID, class_2960> CACHE = new ConcurrentHashMap<>();
   private static final Map<UUID, GpuTextureView> VIEW_CACHE = new ConcurrentHashMap<>();
   private static final Map<String, Supplier<class_8685>> USER_SUPPLIERS = new ConcurrentHashMap<>();
   private static final Map<class_2960, GpuTextureView> VIEW_BY_ID = new ConcurrentHashMap<>();

   public static class_2960 a(class_310 var0, class_1657 var1) {
      UUID var2 = var1.method_5667();
      class_2960 var3 = CACHE.get(var2);
      if (var3 != null) {
         return var3;
      }

      if (var0.method_1562() != null) {
         class_640 var4 = var0.method_1562().method_2871(var2);
         if (var4 != null) {
            try {
               class_8685 var5 = var4.method_52810();
               if (var5 != null) {
                  class_2960 var6 = var5.comp_1626().comp_3627();
                  CACHE.put(var2, var6);
                  return var6;
               }
            } catch (Exception var7) {
            }
         }
      }

      return null;
   }

   public static GpuTextureView b(class_310 var0, class_1657 var1) {
      UUID var2 = var1.method_5667();
      GpuTextureView var3 = VIEW_CACHE.get(var2);
      if (var3 != null) {
         return var3;
      }

      class_2960 var4 = a(var0, var1);
      if (var4 != null && var0.method_1531() != null) {
         try {
            class_1044 var5 = var0.method_1531().method_4619(var4);
            if (var5 != null) {
               GpuTextureView var6 = var5.method_71659();
               if (var6 != null) {
                  VIEW_CACHE.put(var2, var6);
                  return var6;
               }
            }
         } catch (Exception var7) {
         }
      }

      return null;
   }

   public static GpuTextureView a(class_310 var0, String var1) {
      if (var1 != null && !var1.trim().isEmpty() && var0 != null) {
         String var2 = var1.trim();
         Supplier var3 = USER_SUPPLIERS.computeIfAbsent(var2, var1x -> {
            try {
               UUID var2x = class_4844.method_43344(var1x);
               GameProfile var3x = new GameProfile(var2x, var1x);
               if (var0.method_1582() != null) {
                  return var0.method_1582().method_73544(var3x, false);
               }
            } catch (Exception var4x) {
            }

            return null;
         });
         class_2960 var4 = null;
         if (var3 != null) {
            try {
               class_8685 var5 = (class_8685)var3.get();
               if (var5 != null && var5.comp_1626() != null) {
                  var4 = var5.comp_1626().comp_3627();
               }
            } catch (Exception var10) {
            }
         }

         if (var4 == null) {
            try {
               UUID var11 = class_4844.method_43344(var2);
               class_8685 var6 = class_1068.method_4648(var11);
               if (var6 != null && var6.comp_1626() != null) {
                  var4 = var6.comp_1626().comp_3627();
               }
            } catch (Exception var9) {
            }
         }

         if (var4 != null && var0.method_1531() != null) {
            GpuTextureView var12 = VIEW_BY_ID.get(var4);
            if (var12 != null) {
               return var12;
            }

            try {
               class_1044 var13 = var0.method_1531().method_4619(var4);
               if (var13 != null) {
                  GpuTextureView var7 = var13.method_71659();
                  if (var7 != null) {
                     VIEW_BY_ID.put(var4, var7);
                     return var7;
                  }
               }
            } catch (Exception var8) {
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static void a() {
      CACHE.clear();
      VIEW_CACHE.clear();
      USER_SUPPLIERS.clear();
      VIEW_BY_ID.clear();
   }
}
