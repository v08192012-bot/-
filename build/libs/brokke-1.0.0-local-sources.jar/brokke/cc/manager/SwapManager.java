package brokke.cc.manager;

import brokke.cc.ui.HiddenInventoryScreen;
import java.util.function.Predicate;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_310;

public final class SwapManager {
   private static final class_310 mc = class_310.method_1551();
   private static final int OFFHAND_BUTTON = 40;

   public static int a(Predicate<class_1799> var0) {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         if (var0.test(mc.field_1724.method_31548().method_5438(var1))) {
            return var1;
         }
      }

      for (int var2 = 9; var2 < 36; var2++) {
         if (var0.test(mc.field_1724.method_31548().method_5438(var2))) {
            return var2;
         }
      }

      return -1;
   }

   public static int a(class_1799 var0) {
      return var0 != null && !var0.method_7960() ? a(var1 -> a(var1, var0)) : -1;
   }

   public static boolean b(class_1799 var0) {
      if (mc.field_1724 == null || mc.field_1761 == null) {
         return false;
      }

      if (var0 != null && !var0.method_7960()) {
         if (a(mc.field_1724.method_6079(), var0)) {
            return true;
         }

         int var1 = a(var0);
         return var1 != -1 && a(var1);
      } else {
         return false;
      }
   }

   public static boolean a(int var0) {
      if (mc.field_1724 != null && mc.field_1761 != null && mc.field_1724.field_3944 != null) {
         return var0 >= 0 && var0 <= 35 ? a(var0, 40) : false;
      } else {
         return false;
      }
   }

   public static boolean a() {
      return false;
   }

   public static boolean b() {
      if (mc.field_1724 == null) {
         return false;
      } else if (mc.field_1755 instanceof HiddenInventoryScreen) {
         mc.method_1507(null);
         return true;
      } else {
         return false;
      }
   }

   public static boolean a(int var0, int var1) {
      if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1724.field_3944 == null) {
         return false;
      }

      if (var0 >= 0 && var0 <= 35) {
         int var2 = b(var0);
         if (var2 == 45 && var1 == 40) {
            return false;
         }

         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var2, var1, class_1713.field_7791, mc.field_1724);
         return true;
      } else {
         return false;
      }
   }

   public static int b(int var0) {
      return var0 < 9 ? var0 + 36 : var0;
   }

   public static boolean c() {
      if (mc.field_1724 == null || mc.field_1724.field_3944 == null) {
         return false;
      }

      if (mc.field_1724.method_7325()) {
         return false;
      }

      mc.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
      return true;
   }

   public static boolean a(class_1799 var0, class_1799 var1) {
      if (var0 == null || var1 == null || var0.method_7960() || var1.method_7960()) {
         return false;
      } else if (!var0.method_31574(var1.method_7909())) {
         return false;
      } else if (!var1.method_31574(class_1802.field_8288)) {
         return var1.method_31574(class_1802.field_8575) ? var0.method_7964().getString().equals(var1.method_7964().getString()) : true;
      } else {
         return !var1.method_7942() ? true : var0.method_7942() && var0.method_58657().equals(var1.method_58657());
      }
   }

   private SwapManager() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
