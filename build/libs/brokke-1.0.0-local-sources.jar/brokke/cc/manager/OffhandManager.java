package brokke.cc.manager;

import brokke.cc.module.player.GuiMove;
import brokke.cc.util.ItemUtility;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class OffhandManager {
   private static final class_310 mc = class_310.method_1551();
   private OffhandManager.a state = OffhandManager.a.IDLE;
   private class_1799 savedStack = class_1799.field_8037;
   private int savedSlot = -1;
   private int returnTicks = 0;

   public boolean a() {
      return this.state == OffhandManager.a.EQUIPPED;
   }

   public void b() {
      this.state = OffhandManager.a.IDLE;
      this.savedStack = class_1799.field_8037;
      this.savedSlot = -1;
      this.returnTicks = 0;
   }

   public void a(class_1792 var1, boolean var2, Predicate<class_1799> var3, BooleanSupplier var4) {
      if (mc.field_1724 != null && mc.field_1687 != null && var1 != null) {
         class_1799 var5 = mc.field_1724.method_6079();
         boolean var6 = var5.method_31574(var1);
         if (var2) {
            if (var4.getAsBoolean()) {
               this.a(var1, var6, var5, var3);
            }
         } else if (this.state != OffhandManager.a.IDLE && var4.getAsBoolean()) {
            this.b(var5);
         }
      }
   }

   private void a(class_1792 var1, boolean var2, class_1799 var3, Predicate<class_1799> var4) {
      if (var2 && var1 == class_1802.field_8288) {
         int var9 = a(var3);
         Integer var6 = this.a(true);
         if (var6 == null) {
            this.state = OffhandManager.a.EQUIPPED;
         } else {
            class_1799 var7 = this.a(var6);
            int var8 = a(var7);
            if (var8 >= var9) {
               this.state = OffhandManager.a.EQUIPPED;
            } else {
               if (this.savedStack.method_7960()) {
                  this.savedStack = var3.method_7972();
               }

               this.savedSlot = -1;
               this.b(var6);
               this.state = OffhandManager.a.EQUIPPED;
            }
         }
      } else if (var2) {
         this.state = OffhandManager.a.EQUIPPED;
      } else if (var4.test(var3)) {
         Integer var5 = this.a(true);
         if (var5 != null) {
            if (this.savedStack.method_7960()) {
               this.savedStack = var3.method_7972();
            }

            this.savedSlot = var5;
            this.b(var5);
            this.state = OffhandManager.a.EQUIPPED;
         }
      }
   }

   private void b(class_1799 var1) {
      if (this.savedStack.method_7960()) {
         Integer var5 = this.a(false);
         if (var5 != null && var1.method_31574(class_1802.field_8288)) {
            int var3 = a(var1);
            int var4 = a(this.a(var5));
            if (var4 > var3) {
               this.b(var5);
            }
         }

         this.b();
      } else if (class_1799.method_7973(var1, this.savedStack)) {
         this.b();
      } else if (var1.method_31574(class_1802.field_8288) && this.savedStack.method_31574(class_1802.field_8288) && a(var1) >= a(this.savedStack)) {
         this.b();
      } else {
         if (this.state != OffhandManager.a.RETURNING) {
            this.state = OffhandManager.a.RETURNING;
            this.returnTicks = 5;
         }

         if (this.returnTicks-- <= 0) {
            this.b();
         } else {
            Integer var2 = this.c();
            if (var2 == null) {
               this.b();
            } else {
               this.c(var2);
            }
         }
      }
   }

   private Integer c() {
      if (this.savedSlot != -1) {
         class_1799 var1 = this.a(this.savedSlot);
         if (class_1799.method_7973(var1, this.savedStack)) {
            return this.savedSlot;
         }

         this.savedSlot = -1;
      }

      for (int var3 = 9; var3 <= 44; var3++) {
         class_1799 var2 = this.a(var3);
         if (class_1799.method_7973(var2, this.savedStack)) {
            return var3;
         }
      }

      return null;
   }

   private Integer a(boolean var1) {
      Integer var2 = null;
      int var3 = var1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;

      for (int var4 = 9; var4 <= 44; var4++) {
         class_1799 var5 = this.a(var4);
         if (var5.method_31574(class_1802.field_8288)) {
            int var6 = a(var5);
            if (var1) {
               if (var6 < var3) {
                  var3 = var6;
                  var2 = var4;
               }
            } else if (var6 > var3) {
               var3 = var6;
               var2 = var4;
            }
         }
      }

      return var2;
   }

   public static int a(class_1799 var0) {
      if (var0 != null && !var0.method_7960() && var0.method_31574(class_1802.field_8288)) {
         int var1 = ItemUtility.f(var0);
         if (var1 > 1) {
            return var1 * 10;
         }

         class_9304 var2 = var0.method_58694(class_9334.field_49633);
         return var2 != null && !var2.method_57543() ? 1 : 0;
      } else {
         return Integer.MAX_VALUE;
      }
   }

   private class_1799 a(int var1) {
      if (mc.field_1724 != null && mc.field_1724.field_7498 != null) {
         return var1 >= 0 && var1 < mc.field_1724.field_7498.field_7761.size() ? mc.field_1724.field_7498.method_7611(var1).method_7677() : class_1799.field_8037;
      } else {
         return class_1799.field_8037;
      }
   }

   private void b(int var1) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var1, 40, class_1713.field_7791, mc.field_1724);
      }
   }

   private void c(int var1) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         GuiMove.bypassQueue = true;

         try {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var1, 40, class_1713.field_7791, mc.field_1724);
         } finally {
            GuiMove.bypassQueue = false;
         }
      }
   }

   public enum a {
      IDLE,
      EQUIPPED,
      RETURNING;
   }
}
