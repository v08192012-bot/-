package brokke.cc.manager;

import brokke.cc.core.FakePlayerEntity;
import brokke.cc.core.FakePlayerRegistry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class FakePlayerManager {
   private static final List<FakePlayerEntity> fakePlayers = new ArrayList<>();

   public static List<FakePlayerEntity> getFakePlayers() {
      return fakePlayers;
   }

   public static void a(class_243 var0, String var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1687 != null && var2.field_1724 != null) {
         FakePlayerEntity var3 = new FakePlayerEntity(FakePlayerRegistry.FAKE_PLAYER, var2.field_1687);
         var3.method_33574(var0);
         var3.method_5665(class_2561.method_43470(var1));
         var3.method_5880(true);
         var3.setSkinName(var1);
         var3.method_6033(20.0F);
         var3.method_5673(class_1304.field_6169, new class_1799(class_1802.field_22027));
         var3.method_5673(class_1304.field_6174, new class_1799(class_1802.field_22028));
         var3.method_5673(class_1304.field_6172, new class_1799(class_1802.field_22029));
         var3.method_5673(class_1304.field_6166, new class_1799(class_1802.field_22030));
         var3.method_5673(class_1304.field_6173, new class_1799(class_1802.field_22022));
         var3.method_5673(class_1304.field_6171, new class_1799(class_1802.field_8288));
         var2.field_1687.method_53875(var3);
         fakePlayers.add(var3);
         var2.field_1724.method_7353(class_2561.method_43470("§aФейковый игрок §f" + var1 + " §aсоздан"), false);
      }
   }

   public static void b() {
      class_310 var0 = class_310.method_1551();
      if (var0.field_1687 != null && var0.field_1724 != null) {
         FakePlayerEntity var1 = null;
         double var2 = Double.MAX_VALUE;

         for (FakePlayerEntity var5 : fakePlayers) {
            if (var5 != null && var5.method_5805() && var0.field_1724.method_5858(var5) < var2) {
               var2 = var0.field_1724.method_5858(var5);
               var1 = var5;
            }
         }

         if (var1 != null) {
            var1.method_31472();
            fakePlayers.remove(var1);
            var0.field_1724.method_7353(class_2561.method_43470("§cФейковый игрок удалён"), false);
         } else {
            var0.field_1724.method_7353(class_2561.method_43470("§cНет фейковых игроков рядом"), false);
         }
      }
   }

   public static void c() {
      for (FakePlayerEntity var1 : new ArrayList<>(fakePlayers)) {
         if (var1 != null && var1.method_5805()) {
            var1.method_31472();
         }
      }

      fakePlayers.clear();
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 != null) {
         var2.field_1724.method_7353(class_2561.method_43470("§cВсе фейковые игроки удалены"), false);
      }
   }

   public static void d() {
      fakePlayers.removeIf(var0 -> var0 == null || !var0.method_5805());
   }
}
