package brokke.cc.manager;

import brokke.cc.config.AutoBuyConfig;
import brokke.cc.core.AutoBuyEngine;
import brokke.cc.core.ItemEntry;
import brokke.cc.core.ItemMatcher;
import brokke.cc.core.Lot;
import brokke.cc.core.PriceParser;
import java.util.Locale;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_476;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class RelistManager {
   private final class_310 mc = class_310.method_1551();
   private static final String BUTTON_KEYWORD = "товары на продаже";
   private static final String LISTINGS_TITLE = "продаж";
   private static final int COLLECT_DELAY = 10;
   private static final int MAX_COLLECT = 300;
   private RelistManager.a state = RelistManager.a.IDLE;
   private int delay = 0;
   private int waitTicks = 0;
   private int collected = 0;
   private int emptyScans = 0;
   private volatile boolean pending = false;

   public void a() {
      this.pending = true;
   }

   public boolean b() {
      return this.state != RelistManager.a.IDLE;
   }

   public String c() {
      return this.state == RelistManager.a.IDLE ? "Релист: ожидание" : "Релист: снято " + this.collected;
   }

   public synchronized void d() {
      if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
         this.state = RelistManager.a.IDLE;
      } else if (this.delay > 0) {
         this.delay--;
      } else {
         switch (this.state) {
            case IDLE:
               if (!this.pending) {
                  return;
               }

               this.pending = false;
               this.collected = 0;
               this.emptyScans = 0;
               this.state = this.f() ? RelistManager.a.OPEN_LISTINGS : RelistManager.a.OPEN_AUCTION;
               break;
            case OPEN_AUCTION:
               if (this.mc.field_1755 != null) {
                  if (this.mc.field_1724 != null) {
                     this.mc.field_1724.method_7346();
                  }

                  if (this.mc.field_1755 != null) {
                     this.mc.method_1507(null);
                  }

                  this.delay = 6;
               } else {
                  this.mc.field_1724.field_3944.method_45730("ah");
                  this.state = RelistManager.a.WAIT_AUCTION;
                  this.waitTicks = 60;
               }
               break;
            case WAIT_AUCTION:
               if (this.f()) {
                  this.state = RelistManager.a.OPEN_LISTINGS;
                  this.delay = 4;
               } else if (--this.waitTicks <= 0) {
                  this.e();
               }
               break;
            case OPEN_LISTINGS:
               if (!this.f()) {
                  this.e();
                  return;
               }

               class_1707 var3 = ((class_476)this.mc.field_1755).method_17577();
               int var4 = this.a(var3);
               if (var4 < 0) {
                  this.a("§e[Релист] Эндер-сундук «Товары на продаже» не найден");
                  this.e();
                  return;
               }

               this.a(var3.field_7763, var4, 0);
               this.state = RelistManager.a.WAIT_LISTINGS;
               this.waitTicks = 60;
               break;
            case WAIT_LISTINGS:
               if (this.g()) {
                  this.state = RelistManager.a.COLLECT;
                  this.delay = 6;
                  this.emptyScans = 0;
               } else if (--this.waitTicks <= 0) {
                  this.e();
               }
               break;
            case COLLECT:
               if (!this.g()) {
                  this.e();
                  return;
               }

               class_1707 var1 = ((class_476)this.mc.field_1755).method_17577();
               int var2 = this.b(var1);
               if (var2 < 0) {
                  if (++this.emptyScans >= 3) {
                     this.e();
                  } else {
                     this.delay = 4;
                  }
               } else {
                  this.emptyScans = 0;
                  this.a(var1.field_7763, var2, 1);
                  this.collected++;
                  this.delay = 10;
                  if (this.collected >= 300) {
                     this.e();
                  }
               }
               break;
            case FINISH:
               if (this.mc.field_1755 != null) {
                  if (this.mc.field_1724 != null) {
                     this.mc.field_1724.method_7346();
                  }

                  if (this.mc.field_1755 != null) {
                     this.mc.method_1507(null);
                  }

                  this.delay = 6;
               } else {
                  if (this.collected > 0) {
                     this.a("§a[Релист] Снято лотов: §f" + this.collected + "§a — перевыставляю");
                     AutoBuyEngine.INSTANCE.seller.c();
                  } else {
                     this.a("§7[Релист] Своих лотов из списка нет");
                  }

                  this.state = RelistManager.a.IDLE;
               }
               break;
            default:
               this.state = RelistManager.a.IDLE;
         }
      }
   }

   private void e() {
      this.state = RelistManager.a.FINISH;
      this.delay = 4;
   }

   private boolean f() {
      return this.mc.field_1755 instanceof class_476 var1 && AutoBuyEngine.a(var1);
   }

   private boolean g() {
      if (this.mc.field_1755 instanceof class_476 var1) {
         String var3 = var1.method_25440().getString().toLowerCase(Locale.ROOT);
         return var3.contains("продаж");
      } else {
         return false;
      }
   }

   private int a(class_1707 var1) {
      int var2 = var1.method_17388() * 9;

      for (int var3 = 0; var3 < var2; var3++) {
         class_1799 var4 = var1.method_7611(var3).method_7677();
         if (!var4.method_7960()) {
            String var5 = class_7923.field_41178.method_10221(var4.method_7909()).toString();
            if (var5.equals("minecraft:ender_chest") && this.a(var4, "товары на продаже")) {
               return var3;
            }
         }
      }

      for (int var6 = 0; var6 < var2; var6++) {
         class_1799 var7 = var1.method_7611(var6).method_7677();
         if (!var7.method_7960() && this.a(var7, "товары на продаже")) {
            return var6;
         }
      }

      return -1;
   }

   private int b(class_1707 var1) {
      int var2 = var1.method_17388();
      int var3 = (var2 - 1) * 9;

      for (int var4 = 0; var4 < var3; var4++) {
         class_1799 var5 = var1.method_7611(var4).method_7677();
         if (!var5.method_7960()) {
            Lot var6 = PriceParser.a(var5);
            if (var6 != null) {
               for (ItemEntry var8 : AutoBuyConfig.getInstance().entries) {
                  if (ItemMatcher.a(var8, var6)) {
                     return var4;
                  }
               }
            }
         }
      }

      return -1;
   }

   private boolean a(class_1799 var1, String var2) {
      String var3 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      if (var3.contains(var2)) {
         return true;
      }

      class_9290 var4 = var1.method_58694(class_9334.field_49632);
      if (var4 != null) {
         for (class_2561 var6 : var4.comp_2400()) {
            if (var6.getString().toLowerCase(Locale.ROOT).contains(var2)) {
               return true;
            }
         }
      }

      return false;
   }

   private void a(int var1, int var2, int var3) {
      if (this.mc.field_1761 != null && this.mc.field_1724 != null) {
         this.mc.field_1761.method_2906(var1, var2, var3, class_1713.field_7790, this.mc.field_1724);
      }
   }

   private void a(String var1) {
      if (this.mc.field_1724 != null) {
         this.mc.field_1724.method_7353(class_2561.method_43470(var1), false);
      }
   }

   enum a {
      IDLE,
      OPEN_AUCTION,
      WAIT_AUCTION,
      OPEN_LISTINGS,
      WAIT_LISTINGS,
      COLLECT,
      FINISH;
   }
}
