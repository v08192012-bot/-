package brokke.cc.manager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class NbtDumpManager {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final Path FILE = FabricLoader.getInstance().getGameDir().resolve("nbt_dumps.json");
   private static final List<NbtDumpManager.a> DUMPS = new ArrayList<>();
   private static boolean loaded = false;

   private static synchronized void b() {
      if (!loaded) {
         loaded = true;
         DUMPS.clear();

         try {
            if (Files.exists(FILE)) {
               List var0 = (List)GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), (new TypeToken<List<NbtDumpManager.a>>() {}).getType());
               if (var0 != null) {
                  DUMPS.addAll(var0);
               }
            }
         } catch (Exception var1) {
         }
      }
   }

   public static synchronized void a() {
      loaded = false;
      b();
   }

   public static String a(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         b();
         if (DUMPS.isEmpty()) {
            return null;
         }

         String var1 = class_7923.field_41178.method_10221(var0.method_7909()).toString();
         String var2 = b(var0);
         String var3 = var0.method_7964().getString();
         String var4 = c(var0);

         for (NbtDumpManager.a var6 : DUMPS) {
            if (var6.itemId != null && var6.itemId.equalsIgnoreCase(var1) && var6.customDumpName != null && !var6.customDumpName.isEmpty()) {
               if (var6.customDataNbt != null && !var6.customDataNbt.isEmpty() && var2 != null && var2.toLowerCase().contains(var6.customDataNbt.toLowerCase())
                  )
                {
                  return var6.customDumpName;
               }

               if (var6.lore != null && !var6.lore.isEmpty() && var4 != null && var4.toLowerCase().contains(var6.lore.toLowerCase())) {
                  return var6.customDumpName;
               }

               if (var6.displayName != null && !var6.displayName.isEmpty() && var3.equalsIgnoreCase(var6.displayName)) {
                  return var6.customDumpName;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static String b(class_1799 var0) {
      class_9279 var1 = var0.method_58694(class_9334.field_49628);
      return var1 != null ? var1.method_57461().toString() : null;
   }

   private static String c(class_1799 var0) {
      class_9290 var1 = var0.method_58694(class_9334.field_49632);
      if (var1 == null) {
         return null;
      }

      StringBuilder var2 = new StringBuilder();

      for (class_2561 var4 : var1.comp_2400()) {
         var2.append(var4.getString()).append(' ');
      }

      String var5 = var2.toString().trim();
      return var5.isEmpty() ? null : var5;
   }

   public static class a {
      public String itemId;
      public String customDumpName;
      public String customDataNbt;
      public String lore;
      public String displayName;
   }
}
