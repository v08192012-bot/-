package brokke.cc.manager;

import brokke.cc.system.events.EventBus;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.EventPriority;
import brokke.cc.system.events.impl.EventMoveInput;
import java.util.LinkedList;
import net.minecraft.class_10185;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_2815;
import net.minecraft.class_310;

public final class TaskScheduler {
   static final class_310 mc = class_310.method_1551();
   static final LinkedList<TaskScheduler.a> taskQueue = new LinkedList<>();
   private static boolean registered = false;

   public static void a() {
      if (!registered) {
         EventBus.register(new TaskScheduler.b());
         registered = true;
      }
   }

   public static void a(Class<?> var0, Runnable var1) {
      a(var0, var1, 0);
   }

   public static void a(Class<?> var0, Runnable var1, int var2) {
      a();
      TaskScheduler.a var3 = new TaskScheduler.a(var0, var1, var2);
      synchronized (taskQueue) {
         if (var2 > d()) {
            if (taskQueue.isEmpty()) {
               taskQueue.addFirst(var3);
            } else {
               taskQueue.add(1, var3);
            }
         } else {
            taskQueue.add(var3);
         }
      }
   }

   public static boolean a(Class<?> var0) {
      synchronized (taskQueue) {
         for (TaskScheduler.a var3 : taskQueue) {
            if (var3.provider == var0) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean b(Class<?> var0) {
      return a(var0);
   }

   public static void b() {
      synchronized (taskQueue) {
         taskQueue.clear();
      }
   }

   private static int d() {
      int var0 = Integer.MIN_VALUE;

      for (TaskScheduler.a var2 : taskQueue) {
         if (var2.priority > var0) {
            var0 = var2.priority;
         }
      }

      return var0 == Integer.MIN_VALUE ? 0 : var0;
   }

   public static void c() {
      if (mc.field_1724 != null) {
         if (mc.field_1724.field_7512 instanceof class_1723) {
            if (mc.field_1724.field_3944 != null) {
               mc.field_1724.field_3944.method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
            }
         } else {
            mc.field_1724.method_7346();
         }
      }
   }

   public static void a(int var0, int var1, class_1713 var2) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var0, var1, var2, mc.field_1724);
      }
   }

   public static void a(class_1735 var0) {
      if (var0 != null && var0.field_7874 != -1 && mc.field_1724 != null) {
         a(var0.field_7874, 40, class_1713.field_7791);
      }
   }

   public static void a(int var0) {
      if (var0 >= 0 && mc.field_1724 != null) {
         a(var0, 40, class_1713.field_7791);
      }
   }

   static {
      a();
   }

   static class a {
      final Class<?> provider;
      final Runnable task;
      final int priority;

      a(Class<?> var1, Runnable var2, int var3) {
         this.provider = var1;
         this.task = var2;
         this.priority = var3;
      }
   }

   public static class b {
      @EventHandler(priority = EventPriority.HIGHEST)
      public void onMoveInput(EventMoveInput var1) {
         if (TaskScheduler.mc.field_1724 != null) {
            TaskScheduler.a var2;
            synchronized (TaskScheduler.taskQueue) {
               var2 = TaskScheduler.taskQueue.peek();
            }

            if (var2 != null) {
               var1.setForward(0.0F);
               var1.setStrafe(0.0F);
               var1.setJump(false);
               var1.setSprint(false);
               var1.setSneak(false);
               class_10185 var9 = TaskScheduler.mc.field_1724.method_71091();
               if (var9 == null
                  || !var9.comp_3163() && !TaskScheduler.mc.field_1724.method_5624() && !var9.comp_3159() && !var9.comp_3160() && !var9.comp_3161() && !var9.comp_3162()) {
                  try {
                     var2.task.run();
                     TaskScheduler.c();
                  } catch (Exception var7) {
                     var7.printStackTrace();
                  }

                  synchronized (TaskScheduler.taskQueue) {
                     TaskScheduler.taskQueue.poll();
                  }
               }
            }
         }
      }
   }
}
