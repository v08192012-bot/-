package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.rotation.RotationUtil;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_243;

@NewFunction(name = "AimBot", description = "Автоматически наводится луком/арбалетом", category = Category.COMBAT)
public class AimBot extends Function {
   private final NumberSetting distance = new NumberSetting("Дистанция", 30.0, 0.0, 100.0, 1.0);
   private final NumberSetting fov = new NumberSetting("FOV", 90.0, 1.0, 180.0, 1.0);
   private final BooleanSetting prediction = new BooleanSetting("Предсказание", true);
   private final BooleanSetting silent = new BooleanSetting("Silent Aim", false);

   public AimBot() {
      this.addSettings(this.distance, this.fov, this.prediction, this.silent);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.k()) {
         class_1297 var2 = this.l();
         if (var2 != null) {
            this.a(var2);
            float[] var4 = RotationUtil.a(var2);
            float var5 = var4[0];
            float var6 = var4[1];
            if (!(Math.abs(RotationUtil.a(var5, mc.field_1724.method_36454())) > this.fov.getValue())) {
               if (this.silent.isToggled()) {
                  mc.field_1724.method_36456(var5);
                  mc.field_1724.method_36457(var6);
                  mc.field_1724.method_5847(var5);
               } else {
                  mc.field_1724.method_36456(var5);
                  mc.field_1724.method_36457(var6);
                  mc.field_1724.method_5847(var5);
               }
            }
         }
      }
   }

   private boolean k() {
      if (mc.field_1724 == null) {
         return false;
      } else {
         class_1792 var1 = mc.field_1724.method_6047().method_7909();
         if (var1 == class_1802.field_8102) {
            return mc.field_1724.method_6115();
         } else if (var1 == class_1802.field_8399) {
            return class_1764.method_7781(mc.field_1724.method_6047());
         } else {
            return var1 == class_1802.field_8547 ? mc.field_1724.method_6115() : false;
         }
      }
   }

   private class_1297 l() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         class_1297 var1 = null;
         double var2 = this.distance.getValue();

         for (class_1297 var5 : mc.field_1687.method_18112()) {
            double var6;
            if (var5 != mc.field_1724
               && var5 instanceof class_1309
               && var5.method_5805()
               && !((var6 = mc.field_1724.method_5739(var5)) > this.distance.getValue())
               && var6 < var2) {
               var2 = var6;
               var1 = var5;
            }
         }

         return var1;
      } else {
         return null;
      }
   }

   private class_243 a(class_1297 var1) {
      class_243 var2 = var1.method_73189();
      if (!this.prediction.isToggled()) {
         return var2.method_1031(0.0, var1.method_17682() / 2.0, 0.0);
      }

      class_243 var3 = var1.method_18798().method_1021(10.0);
      return var2.method_1019(var3).method_1031(0.0, var1.method_17682() / 2.0, 0.0);
   }
}
