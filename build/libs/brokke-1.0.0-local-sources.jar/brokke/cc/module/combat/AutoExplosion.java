package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.misc.Optimizer;
import brokke.cc.core.FreeLookStorage;
import brokke.cc.manager.FriendManager;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.SendPacketEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.GCDUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_638;
import net.minecraft.class_746;

@NewFunction(name = "AutoExplosion", description = "Автоматически ставит и взрывает кристалл", category = Category.COMBAT)
public class AutoExplosion extends Function {
   private final BooleanSetting safeYourSelf = new BooleanSetting("Не взрывать себя", false);
   private final BooleanSetting safeFriend = new BooleanSetting("Не взрывать друзей", true);
   private final NumberSetting radius = new NumberSetting("Радиус", 5.0, 1.0, 10.0, 0.1);
   private final BooleanSetting comboRotate = new BooleanSetting("Ротация", true);
   private final BooleanSetting crystalSpam = new BooleanSetting("Спам кристаллами", false);
   private final NumberSetting spamRadius = new NumberSetting("Спам радиус", 5.0, 1.0, 7.0, 0.5).visibleWhen(this.crystalSpam::isToggled);
   private final NumberSetting spamDelay = new NumberSetting("Спам задержка", 1.0, 0.0, 10.0, 1.0).visibleWhen(this.crystalSpam::isToggled);
   private final NumberSetting spamMin = new NumberSetting("Спам мин урон", 4.0, 0.0, 36.0, 0.5).visibleWhen(this.crystalSpam::isToggled);
   private final NumberSetting spamSelf = new NumberSetting("Спам макс себе", 10.0, 0.0, 36.0, 0.5).visibleWhen(this.crystalSpam::isToggled);
   private final BooleanSetting spamRotate = new BooleanSetting("Спам ротация", true).visibleWhen(this.crystalSpam::isToggled);
   private final BooleanSetting spamOptimize = new BooleanSetting("Оптимизация рендера", true).visibleWhen(this.crystalSpam::isToggled);
   private static final double DIAMETER = 12.0;
   private class_2338 pos;
   private int ticksAction;
   private boolean crystalPlaced;
   private int hotSlot;
   private int spamCooldown;
   private int slotToRestore = -1;
   private int restoreTicks = 0;
   private int placementStage = 0;
   private int placementTicks = 0;
   private class_3965 pendingHit;
   private boolean packetPlace;

   public AutoExplosion() {
      this.addSettings(
         this.safeYourSelf,
         this.safeFriend,
         this.radius,
         this.comboRotate,
         this.crystalSpam,
         this.spamRadius,
         this.spamDelay,
         this.spamMin,
         this.spamSelf,
         this.spamRotate,
         this.spamOptimize
      );
   }

   @Override
   public void onDisable() {
      this.k();
      this.spamCooldown = 0;
      this.packetPlace = false;
      this.placementStage = 0;
      this.placementTicks = 0;
      this.pendingHit = null;
      if (mc.field_1724 != null && this.slotToRestore != -1) {
         mc.field_1724.method_31548().method_61496(this.slotToRestore);
         if (mc.field_1724.field_3944 != null) {
            mc.field_1724.field_3944.method_52787(new class_2868(this.slotToRestore));
         }

         this.slotToRestore = -1;
         this.restoreTicks = 0;
      }

      this.l();
      super.onDisable();
   }

   @EventHandler
   public void onPacketSend(SendPacketEvent var1) {
      if (!this.packetPlace && var1.getPacket() instanceof class_2885 var2 && mc.field_1724 != null && mc.field_1687 != null) {
         class_1799 var8 = mc.field_1724.method_6047();
         class_1799 var4 = mc.field_1724.method_6079();
         if ((var8.method_31574(class_1802.field_8281) || var8.method_31574(class_1802.field_22421) || var4.method_31574(class_1802.field_8281) || var4.method_31574(class_1802.field_22421))
            && this.pos == null) {
            this.hotSlot = this.b(mc.field_1724);
            if (this.hotSlot != -1) {
               class_3965 var5 = var2.method_12543();
               class_2338 var6 = var5.method_17777();
               class_2350 var7 = var5.method_17780();
               this.pos = var6.method_10093(var7);
               this.ticksAction = 0;
            }
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      class_746 var2 = mc.field_1724;
      class_638 var3 = mc.field_1687;
      if (var2 != null && var3 != null) {
         if (this.restoreTicks > 0) {
            this.restoreTicks--;
            if (this.restoreTicks == 0 && this.slotToRestore != -1) {
               var2.method_31548().method_61496(this.slotToRestore);
               if (var2.field_3944 != null) {
                  var2.field_3944.method_52787(new class_2868(this.slotToRestore));
               }

               this.slotToRestore = -1;
            }
         }

         if (this.placementStage == 1) {
            this.placementTicks--;
            if (this.placementTicks <= 0 && this.pendingHit != null && mc.field_1761 != null) {
               this.placementStage = 0;
               class_3965 var4 = this.pendingHit;
               this.pendingHit = null;
               this.packetPlace = true;

               try {
                  mc.field_1761.method_2896(var2, class_1268.field_5808, var4);
                  var2.method_6104(class_1268.field_5808);
               } finally {
                  this.packetPlace = false;
               }

               this.restoreTicks = 2;
            }
         }

         if (this.pos == null) {
            if (this.crystalSpam.getValue()) {
               if (this.spamCooldown > 0) {
                  this.spamCooldown--;
               } else {
                  this.spamCooldown = (int)this.spamDelay.getValue();
                  this.a(var2, var3);
               }
            }
         } else {
            if (!this.crystalPlaced) {
               class_2248 var9 = var3.method_8320(this.pos).method_26204();
               boolean var5 = var9 == class_2246.field_10540 || var9 == class_2246.field_9987 || var9 == class_2246.field_22423;
               if (!var5) {
                  this.ticksAction++;
                  if (this.ticksAction > 20) {
                     this.k();
                  }

                  return;
               }

               this.crystalPlaced = true;
               this.ticksAction = 0;
               if (this.placementStage != 0 || this.pendingHit != null || this.restoreTicks > 0 || this.slotToRestore != -1) {
                  return;
               }

               if (this.comboRotate.getValue()) {
                  this.a(var2, class_243.method_24953(this.pos.method_10084()));
               }

               class_243 var6 = new class_243(this.pos.method_10263() + 0.5, this.pos.method_10264() + 1.0, this.pos.method_10260() + 0.5);
               this.a(var2, new class_3965(var6, class_2350.field_11036, this.pos, false));
            }

            if (this.a(var2, this.pos.method_10084())) {
               this.k();
            } else {
               this.ticksAction++;
               if (this.ticksAction > 30) {
                  this.k();
               }
            }
         }
      }
   }

   private void k() {
      this.pos = null;
      this.crystalPlaced = false;
      this.ticksAction = 0;
      this.hotSlot = 0;
      if (this.comboRotate.getValue()) {
         this.l();
      }
   }

   private void a(class_746 var1, class_638 var2) {
      if (!var1.method_6115() && mc.field_1761 != null) {
         if (this.placementStage == 0 && this.pendingHit == null && this.restoreTicks <= 0 && this.slotToRestore == -1) {
            class_1657 var3 = this.b(var1, var2);
            if (var3 == null) {
               if (this.spamRotate.getValue()) {
                  this.l();
               }
            } else {
               boolean var4 = false;
               class_1511 var5 = null;
               double var6 = 0.0;

               for (class_1511 var9 : var2.method_8390(class_1511.class, var1.method_5829().method_1014(7.0), var0 -> true)) {
                  if (var9.method_5805() && !(var1.method_33571().method_1022(var9.method_73189().method_1031(0.0, 0.5, 0.0)) > 5.5)) {
                     double var10 = this.a(var9.method_73189().method_1031(0.0, 0.5, 0.0), var3, var2, var1);
                     if (!(var10 < this.spamMin.getValue())) {
                        double var12 = this.a(var9.method_73189().method_1031(0.0, 0.5, 0.0), var1, var2, var1);
                        if (!(var12 > this.spamSelf.getValue()) && var10 > var6) {
                           var6 = var10;
                           var5 = var9;
                        }
                     }
                  }
               }

               if (var5 != null && this.b(var1, var5.method_24515())) {
                  if (this.spamRotate.getValue()) {
                     this.a(var1, var5.method_73189().method_1031(0.0, 0.5, 0.0));
                  }

                  mc.field_1761.method_2918(var1, var5);
                  var1.method_6104(class_1268.field_5808);
                  this.m();
                  var4 = true;
               }

               class_2338 var31 = var1.method_24515();
               int var32 = (int)Math.ceil(this.spamRadius.getValue()) + 1;
               class_243 var33 = var1.method_33571();
               class_2338 var11 = null;
               class_2350 var34 = class_2350.field_11036;
               double var13 = 0.0;

               for (int var15 = -var32; var15 <= var32; var15++) {
                  for (int var16 = -var32; var16 <= var32; var16++) {
                     for (int var17 = -var32; var17 <= var32; var17++) {
                        class_2338 var18 = var31.method_10069(var15, var16, var17);
                        double var19 = this.spamRadius.getValue();
                        if (!(var15 * var15 + var16 * var16 + var17 * var17 > var19 * var19 + 2.0)) {
                           class_2248 var21 = var2.method_8320(var18).method_26204();
                           if (var21 == class_2246.field_10540 || var21 == class_2246.field_9987) {
                              class_2338 var22 = var18.method_10084();
                              if (var2.method_8320(var22).method_26215() && var2.method_8320(var22.method_10084()).method_26215()) {
                                 class_243 var23 = class_243.method_24953(var22);
                                 if (!(var33.method_1022(var23) > 5.5)) {
                                    class_238 var24 = new class_238(var22.method_10263(), var22.method_10264(), var22.method_10260(), var22.method_10263() + 1, var22.method_10264() + 2, var22.method_10260() + 1);
                                    boolean var25 = false;

                                    for (class_1297 var27 : var2.method_8390(class_1297.class, var24, var0 -> true)) {
                                       if (var27 != var1 && var27.method_5805() && !var27.method_7325()) {
                                          var25 = true;
                                          break;
                                       }
                                    }

                                    if (!var25) {
                                       class_2350 var38 = this.a(var2, var1, var33, var18);
                                       if (var38 != null) {
                                          double var39 = this.a(var23, var3, var2, var1);
                                          if (!(var39 < this.spamMin.getValue()) && !(var39 <= var13)) {
                                             double var29 = this.a(var23, var1, var2, var1);
                                             if (!(var29 > this.spamSelf.getValue()) && (!this.safeFriend.getValue() || !this.a(var22))) {
                                                var13 = var39;
                                                var11 = var18;
                                                var34 = var38;
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               if (var11 == null) {
                  if (var4 && this.spamRotate.getValue()) {
                     this.l();
                  }
               } else {
                  int var35 = this.b(var1);
                  if (var35 == -1) {
                     if (var4 && this.spamRotate.getValue()) {
                        this.l();
                     }
                  } else {
                     class_243 var36 = class_243.method_24953(var11.method_10084());
                     if (this.spamRotate.getValue()) {
                        this.a(var1, var36);
                     }

                     class_243 var37 = new class_243(
                        var11.method_10263() + 0.5 + var34.method_10148() * 0.5,
                        var11.method_10264() + 0.5 + var34.method_10164() * 0.5,
                        var11.method_10260() + 0.5 + var34.method_10165() * 0.5
                     );
                     this.a(var1, new class_3965(var37, var34, var11, false));
                     this.m();
                  }
               }
            }
         } else if (this.spamCooldown <= 0) {
            this.spamCooldown = (int)this.spamDelay.getValue();
         }
      }
   }

   private void a(class_746 var1, class_243 var2) {
      if (!this.a(var1)) {
         class_243 var3 = var1.method_33571();
         class_243 var4 = var2.method_1020(var3);
         double var5 = Math.sqrt(var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350);
         float var7 = (float)Math.toDegrees(Math.atan2(var4.field_1350, var4.field_1352)) - 90.0F;
         float var8 = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(var4.field_1351, var5))), -90.0F, 90.0F);
         this.a(var7, var8);
      }
   }

   private void a(float var1, float var2) {
      if (mc.field_1724 != null) {
         if (!FreeLookStorage.isActive()) {
            FreeLookStorage.a(true);
         }

         float var3 = class_3532.method_15363(var2, -90.0F, 90.0F);
         float var4 = class_3532.method_15393(var1 - mc.field_1724.method_36454());
         float var5 = var3 - mc.field_1724.method_36455();
         float var6 = GCDUtil.a();
         if (var6 >= 1.0E-4F) {
            var4 = Math.round(var4 / var6) * var6;
            var5 = Math.round(var5 / var6) * var6;
         }

         float var7 = mc.field_1724.method_36454() + var4;
         float var8 = class_3532.method_15363(mc.field_1724.method_36455() + var5, -90.0F, 90.0F);
         mc.field_1724.method_36456(var7);
         mc.field_1724.method_36457(var8);
         mc.field_1724.field_6241 = var7;
         mc.field_1724.field_6283 = var7;
      }
   }

   private void l() {
      if (mc.field_1724 != null && FreeLookStorage.isActive()) {
         mc.field_1724.method_36456(FreeLookStorage.getFreeYaw());
         mc.field_1724.method_36457(FreeLookStorage.getFreePitch());
         mc.field_1724.field_6241 = FreeLookStorage.getFreeYaw();
         mc.field_1724.field_6283 = FreeLookStorage.getFreeYaw();
      }

      FreeLookStorage.a(false);
   }

   private boolean a(class_746 var1) {
      return var1.method_6047().method_31574(class_1802.field_8301) || var1.method_6079().method_31574(class_1802.field_8301);
   }

   private void m() {
      if (this.spamOptimize.getValue()) {
         try {
            Optimizer var1 = FunctionManager.a(Optimizer.class);
            if (var1 != null && !var1.isActive()) {
               var1.setEnabled(true);
            }
         } catch (Throwable var2) {
         }
      }
   }

   private class_1657 b(class_746 var1, class_638 var2) {
      class_1657 var3 = null;
      double var4 = 64.0;

      for (class_1657 var7 : var2.method_18456()) {
         if (var7 != var1 && var7.method_5805() && !var7.method_31481() && !var7.method_7325() && !var7.method_68878() && !FriendManager.a(var7.method_5477().getString())) {
            double var8 = var1.method_5858(var7);
            if (!(var8 > var4)) {
               var4 = var8;
               var3 = var7;
            }
         }
      }

      return var3;
   }

   private class_2350 a(class_638 var1, class_746 var2, class_243 var3, class_2338 var4) {
      class_2350 var5 = null;
      double var6 = Double.MAX_VALUE;

      for (class_2350 var11 : class_2350.values()) {
         class_243 var12 = new class_243(
            var4.method_10263() + 0.5 + var11.method_10148() * 0.5, var4.method_10264() + 0.5 + var11.method_10164() * 0.5, var4.method_10260() + 0.5 + var11.method_10165() * 0.5
         );
         float[] var13 = this.a(var3, var12);
         if (this.a(var13, var4, var2)) {
            double var14 = var3.method_1025(var12);
            if (var14 < var6) {
               var6 = var14;
               var5 = var11;
            }
         }
      }

      return var5;
   }

   private float[] a(class_243 var1, class_243 var2) {
      class_243 var3 = var2.method_1020(var1);
      double var4 = Math.sqrt(var3.field_1352 * var3.field_1352 + var3.field_1350 * var3.field_1350);
      float var6 = (float)Math.toDegrees(Math.atan2(var3.field_1350, var3.field_1352)) - 90.0F;
      float var7 = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(var3.field_1351, var4))), -90.0F, 90.0F);
      return new float[]{var6, var7};
   }

   private boolean a(float[] var1, class_2338 var2, class_746 var3) {
      class_243 var4 = var3.method_33571();
      class_243 var5 = this.b(var1[0], var1[1]);
      class_243 var6 = var4.method_1019(var5.method_1021(4.5));
      return new class_238(var2).method_992(var4, var6).isPresent();
   }

   private class_243 b(float var1, float var2) {
      float var3 = var2 * (float) (Math.PI / 180.0);
      float var4 = -var1 * (float) (Math.PI / 180.0);
      float var5 = class_3532.method_15362(var4);
      float var6 = class_3532.method_15374(var4);
      float var7 = class_3532.method_15362(var3);
      float var8 = class_3532.method_15374(var3);
      return new class_243(var6 * var7, -var8, var5 * var7);
   }

   private double a(class_243 var1, class_1309 var2, class_638 var3, class_746 var4) {
      if (var2.method_73189().method_1022(var1) > 12.0) {
         return 0.0;
      }

      double var5 = this.a(var1, var2.method_5829(), var3, var4);
      if (var5 <= 0.0) {
         return 0.0;
      }

      double var7 = (1.0 - var2.method_73189().method_1022(var1) / 12.0) * var5;
      if (var7 <= 0.0) {
         return 0.0;
      }

      float var9 = (float)((var7 * var7 + var7) / 2.0 * 7.0 * 12.0 + 1.0);
      float var10 = var2.method_6096();
      float var11 = 0.0F;

      try {
         var11 = (float)var2.method_45325(class_5134.field_23725);
      } catch (Throwable var161) {
      }

      float var12 = 2.0F + var11 / 4.0F;
      float var13 = class_3532.method_15363(var10 - var9 / var12, var10 * 0.2F, 20.0F);
      float var16 = var9 * (1.0F - var13 / 25.0F);
      class_1293 var14 = var2.method_6112(class_1294.field_5907);
      if (var14 != null) {
         var16 *= 1.0F - 0.2F * (var14.method_5578() + 1);
      }

      return Math.max(var16, 0.0F);
   }

   private double a(class_243 var1, class_238 var2, class_638 var3, class_746 var4) {
      double var5 = 1.0 / ((var2.field_1320 - var2.field_1323) * 2.0 + 1.0);
      double var7 = 1.0 / ((var2.field_1325 - var2.field_1322) * 2.0 + 1.0);
      double var9 = 1.0 / ((var2.field_1324 - var2.field_1321) * 2.0 + 1.0);
      if (!(var5 < 0.0) && !(var7 < 0.0) && !(var9 < 0.0)) {
         double var11 = (1.0 - Math.floor(1.0 / var5) * var5) * 0.5;
         double var13 = (1.0 - Math.floor(1.0 / var9) * var9) * 0.5;
         int var15 = 0;
         int var16 = 0;

         for (double var17 = 0.0; var17 <= 1.0; var17 += var5) {
            for (double var19 = 0.0; var19 <= 1.0; var19 += var7) {
               for (double var21 = 0.0; var21 <= 1.0; var21 += var9) {
                  class_243 var23 = new class_243(
                     class_3532.method_16436(var17, var2.field_1323, var2.field_1320) + var11,
                     class_3532.method_16436(var19, var2.field_1322, var2.field_1325),
                     class_3532.method_16436(var21, var2.field_1321, var2.field_1324) + var13
                  );
                  class_3965 var24 = var3.method_17742(new class_3959(var23, var1, class_3960.field_17558, class_242.field_1348, var4));
                  if (var24.method_17783() == class_240.field_1333) {
                     var15++;
                  }

                  var16++;
               }
            }
         }

         return var16 == 0 ? 0.0 : (double)var15 / var16;
      } else {
         return 0.0;
      }
   }

   private void a(class_746 var1, class_3965 var2) {
      if (this.placementStage == 0 && this.pendingHit == null) {
         int var3 = this.b(var1);
         if (var3 != -1 && mc.field_1761 != null) {
            if (this.slotToRestore == -1) {
               this.slotToRestore = var1.method_31548().method_67532();
            }

            var1.method_31548().method_61496(var3);
            if (var1.field_3944 != null) {
               var1.field_3944.method_52787(new class_2868(var3));
            }

            this.pendingHit = var2;
            this.placementStage = 1;
            this.placementTicks = 1;
         }
      }
   }

   private boolean a(class_746 var1, class_2338 var2) {
      if (mc.field_1687 != null && mc.field_1761 != null) {
         for (class_1511 var4 : mc.field_1687.method_8390(class_1511.class, var1.method_5829().method_1014(6.0), var0 -> true)) {
            if (var4.method_24515().equals(var2)) {
               if (this.b(var1, var2)) {
                  if (this.comboRotate.getValue()) {
                     this.a(var1, var4.method_73189().method_1031(0.0, 0.5, 0.0));
                  }

                  mc.field_1761.method_2918(var1, var4);
                  var1.method_6104(class_1268.field_5808);
               }

               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean b(class_746 var1, class_2338 var2) {
      if (this.safeYourSelf.getValue() && mc.field_1687 != null) {
         double var3 = this.a(class_243.method_24955(var2).method_1031(0.0, 0.5, 0.0), var1, mc.field_1687, var1);
         if (var3 > 2.0) {
            return false;
         }
      }

      return !this.safeFriend.getValue() || !this.a(var2);
   }

   private boolean a(class_2338 var1) {
      if (mc.field_1687 == null) {
         return false;
      }

      double var2 = this.radius.getValue();
      class_238 var4 = new class_238(var1.method_10263() - var2, var1.method_10264() - var2, var1.method_10260() - var2, var1.method_10263() + var2, var1.method_10264() + var2, var1.method_10260() + var2);

      for (class_1297 var6 : mc.field_1687.method_8390(class_1297.class, var4, var0 -> true)) {
         if (var6 instanceof class_1657 var7 && FriendManager.a(var7.method_5477().getString())) {
            return true;
         }
      }

      return false;
   }

   private int b(class_746 var1) {
      for (int var2 = 0; var2 < 9; var2++) {
         if (var1.method_31548().method_5438(var2).method_31574(class_1802.field_8301)) {
            return var2;
         }
      }

      return -1;
   }
}
