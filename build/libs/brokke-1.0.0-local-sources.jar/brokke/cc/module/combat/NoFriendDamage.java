package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.manager.FriendManager;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.AttackEntityEvent;
import net.minecraft.class_1657;

@NewFunction(name = "No Friend Damage", description = "Не даёт ударить друга", category = Category.COMBAT)
public class NoFriendDamage extends Function {
   @EventHandler
   public void onAttack(AttackEntityEvent var1) {
      if (mc.field_1724 != null && var1.getPlayer() == mc.field_1724 && var1.getTarget() instanceof class_1657 var2 && FriendManager.a(var2.method_5477().getString())) {
         var1.setCancelled(true);
      }
   }
}
