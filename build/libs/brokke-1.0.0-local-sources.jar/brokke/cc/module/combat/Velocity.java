package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.ModeSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_243;
import net.minecraft.class_2743;

@NewFunction(name = "Velocity", description = "Изменение отбрасывания", category = Category.COMBAT)
public class Velocity extends Function {
   private final ModeSetting mode = new ModeSetting("Режим", "Отмена", "Компенсация", "Изменение");
   private final NumberSetting modifierX = new NumberSetting("Отбрасывание X", 50.0, 0.0, 100.0, 1.0);
   private final NumberSetting modifierY = new NumberSetting("Отбрасывание Y", 50.0, 0.0, 100.0, 1.0);
   private final NumberSetting modifierZ = new NumberSetting("Отбрасывание Z", 50.0, 0.0, 100.0, 1.0);
   private class_243 lastMotion = class_243.field_1353;
   private boolean gotVelocity;
   private boolean wasHurt;
   private boolean jumped;

   public Velocity() {
      this.addSettings(this.mode, this.modifierX, this.modifierY, this.modifierZ);
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (mc.field_1724 != null && !mc.field_1724.method_29504() && var1.getPacket() instanceof class_2743 var3 && var3.method_11818() == mc.field_1724.method_5628()
         )
       {
         if (this.mode.isMode("Отмена")) {
            var1.setCancelled(true);
         } else if (this.mode.isMode("Изменение")) {
            var1.setCancelled(true);
            class_243 var4 = var3.method_73085();
            mc.field_1724
               .method_18800(var4.field_1352 * this.modifierX.getValue() / 100.0, var4.field_1351 * this.modifierY.getValue() / 100.0, var4.field_1350 * this.modifierZ.getValue() / 100.0);
         } else if (this.mode.isMode("Компенсация")) {
            this.lastMotion = var3.method_73085();
            this.gotVelocity = true;
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && this.mode.isMode("Компенсация") && this.gotVelocity) {
         if (mc.field_1724.field_6235 > 0) {
            this.wasHurt = true;
         }

         if (this.wasHurt && mc.field_1724.field_6235 == 0) {
            if (mc.field_1724.method_24828()) {
               mc.field_1724.method_6043();
               this.jumped = true;
            }

            class_243 var2 = this.lastMotion.method_1029();
            class_243 var3 = var2.method_1021(-0.2);
            mc.field_1724.method_18800(var3.field_1352, var3.field_1351, var3.field_1350);
            this.wasHurt = false;
            this.gotVelocity = false;
         }

         if (this.jumped && mc.field_1724.method_24828()) {
            this.jumped = false;
         }
      }
   }
}
