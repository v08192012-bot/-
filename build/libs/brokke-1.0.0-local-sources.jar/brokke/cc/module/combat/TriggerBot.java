package brokke.cc.module.combat;

import brokke.cc.core.AntiBotSystem;
import brokke.cc.core.AuraChecks;
import brokke.cc.core.SprintReset;
import brokke.cc.core.TpsSync;
import brokke.cc.manager.FriendManager;
import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.rotation.IdealHitUtils;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.FloatSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventLook;
import brokke.cc.system.events.impl.UpdateEvent;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;

@NewFunction(name = "TriggerBot", description = "Бьёт цель под прицелом с умными критами", category = Category.COMBAT)
public class TriggerBot extends Function {
   private static final long MIN_ATTACK_INTERVAL = 50L;
   private final ModeSetting attackMode = new ModeSetting("attack_mode", "Обычный", new String[]{"Обычный"});
   private final ModeSetting targetMode = new ModeSetting("target_mode", "Невидимых", new String[]{"Невидимых", "Только игроки"});
   private final ModeSetting hitConditions = new ModeSetting("hit_conditions", "Умные криты", new String[]{"Умные криты", "Только криты", "Через траву"});
   private final BooleanSetting weaponOnly = new BooleanSetting("weapon_only", true);
   private final FloatSetting reach = new FloatSetting("reach", 3.0F, 1.0F, 6.0F, 0.1F);
   private final BooleanSetting throughEntities = new BooleanSetting("through_entities", false);
   private final BooleanSetting customCooldown = new BooleanSetting("custom_cooldown", false);
   private final FloatSetting customCooldownPercent = new FloatSetting("custom_cooldown_percent", 100.0F, 0.0F, 100.0F, 1.0F)
      .showWhen(this.customCooldown::isToggled);
   private final BooleanSetting tpsSync = new BooleanSetting("tps_sync", false);
   private final BooleanSetting comboLunge = new BooleanSetting("combo_lunge", false);
   private class_1309 target;
   private long lastAttack;

   public TriggerBot() {
      this.addSettings(
         this.attackMode,
         this.targetMode,
         this.hitConditions,
         this.weaponOnly,
         this.reach,
         this.throughEntities,
         this.customCooldown,
         this.customCooldownPercent,
         this.tpsSync,
         this.comboLunge
      );
   }

   public class_1309 k() {
      return this.target != null && this.target.method_5805() && !this.target.method_31481() && System.currentTimeMillis() - this.lastAttack < 1000L
         ? this.target
         : null;
   }

   public class_1309 l() {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         return null;
      } else {
         double var1 = this.reach.getValue();
         class_243 var3 = mc.field_1724.method_33571();
         class_243 var4 = mc.field_1724.method_5828(1.0F);
         class_243 var5 = var3.method_1019(var4.method_1021(var1));
         class_3960 var6 = this.hitConditions.isMode("Через траву") ? class_3960.field_17558 : class_3960.field_17559;
         class_3965 var7 = mc.field_1687.method_17742(new class_3959(var3, var5, var6, class_242.field_1348, mc.field_1724));
         class_243 var8 = var7.method_17783() == class_240.field_1332 ? var7.method_17784() : var5;
         class_238 var9 = mc.field_1724.method_5829().method_18804(var4.method_1021(var1)).method_1014(1.0);
         Predicate<class_1297> var10 = this.throughEntities.isToggled() ? this::a : (var1x -> var1x instanceof class_1309);
         class_3966 var11 = class_1675.method_18075(mc.field_1724, var3, var8, var9, var10, var1 * var1);
         return var11 != null && var11.method_17782() instanceof class_1309 var12 && this.a(var12) ? var12 : null;
      }
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.o();
   }

   @Override
   public void onDisable() {
      this.o();
      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         this.o();
      } else {
         IdealHitUtils.b();
         this.p();
      }
   }

   @EventHandler
   public void onLook(EventLook var1) {
      this.p();
   }

   private void p() {
      if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
         this.o();
      } else if (mc.field_1755 == null && !mc.field_1761.method_2923()) {
         Aura var1 = Aura.INSTANCE;
         boolean auraSkyTime = var1 != null && var1.l() && var1.rotationType.isSelected("SkyTime");
         if (var1 == null || !var1.l() || auraSkyTime) {
            if (this.weaponOnly.isToggled() && !AuraChecks.a(mc)) {
               this.target = null;
            } else {
               class_1309 var2 = this.l();
               if (var2 != null) {
                  long var3 = System.currentTimeMillis();
                  if (var3 - this.lastAttack >= MIN_ATTACK_INTERVAL) {
                     float var5 = this.customCooldown.isToggled() ? (float)(this.customCooldownPercent.getValue() / 100.0) : IdealHitUtils.a();
                     if (this.b(var5)
                        && this.c(var2)
                        && this.a(mc.field_1724.method_6047().method_7909() == class_1802.field_49814, var2)
                        && (!auraSkyTime || var1.skyTimeTriggerAllow())) {
                        boolean var6 = mc.field_1724.method_5624();
                        this.target = var2;
                        this.lastAttack = var3;
                        mc.field_1761.method_2918(mc.field_1724, var2);
                        mc.field_1724.method_6104(class_1268.field_5808);
                        if (this.comboLunge.isToggled()) {
                           SprintReset.a("W-Tap", var6);
                        }
                        if (auraSkyTime) {
                           var1.skyTimeTriggerAttacked();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean c(class_1309 var1) {
      if (this.hitConditions.isMode("Через траву")) {
         return true;
      } else if (this.hitConditions.isMode("Только криты")) {
         return !mc.field_1724.method_24828() && IdealHitUtils.a(var1, true);
      } else {
         return mc.field_1724.method_24828() || IdealHitUtils.a(var1, true);
      }
   }

   private boolean a(boolean var1, class_1309 var2) {
      if (!var1) {
         return true;
      } else {
         AutoMace var3 = FunctionManager.a(AutoMace.class);
         return var3 == null || !var3.isActive() || var3.a(var2, this.reach.getValue());
      }
   }

   private boolean a(class_1297 var1) {
      if (!(var1 instanceof class_1309 var2)) {
         return false;
      } else if (var2 == mc.field_1724 || !var2.method_5805() || var2.method_31481() || var2.method_6032() <= 0.0F) {
         return false;
      } else if (var2 instanceof class_1531) {
         return false;
      } else if (var2 instanceof class_1657 var3) {
         return !FriendManager.a(var3.method_5477().getString()) && !AntiBotSystem.b(var3) && !var3.method_7325();
      } else {
         return !this.targetMode.isMode("Только игроки");
      }
   }

   private boolean b(float var1) {
      if (this.tpsSync.isToggled()) {
         float var2 = (float)mc.field_1724.method_45325(class_5134.field_23723);
         if (var2 <= 0.0F) {
            return false;
         } else {
            long var3 = (long)(1000.0F / var2 * var1);
            return System.currentTimeMillis() - this.lastAttack >= TpsSync.INSTANCE.a(var3);
         }
      } else {
         return mc.field_1724.method_7261(0.0F) >= var1;
      }
   }

   private void o() {
      this.target = null;
      this.lastAttack = 0L;
   }
}
