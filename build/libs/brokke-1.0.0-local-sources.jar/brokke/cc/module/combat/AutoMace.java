package brokke.cc.module.combat;

import brokke.cc.manager.FriendManager;
import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.FloatSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@NewFunction(name = "AutoMace", description = "Берёт булаву в руку, когда под вами игрок", category = Category.COMBAT)
public class AutoMace extends Function {
   private final FloatSetting radius = new FloatSetting("Радиус", 4.0F, 1.0F, 8.0F, 0.5F);
   private final FloatSetting minHeight = new FloatSetting("Мин. высота над целью", 2.0F, 0.5F, 8.0F, 0.5F);
   private final FloatSetting maxDrop = new FloatSetting("Макс. высота над целью", 8.0F, 1.0F, 24.0F, 1.0F);
   private final BooleanSetting onlyFalling = new BooleanSetting("Только при падении", true);
   private final BooleanSetting onlyInAir = new BooleanSetting("Только в воздухе", true);
   private final BooleanSetting friends = new BooleanSetting("Учитывать друзей", false);
   private final BooleanSetting restore = new BooleanSetting("Возвращать предмет", true);
   private final BooleanSetting onlyTarget = new BooleanSetting("Только с целью (TriggerBot/AimAssist)", false);
   private int slotToRestore = -1;
   private int ourMaceSlot = -1;

   public AutoMace() {
      this.addSettings(
         this.radius,
         this.minHeight,
         this.maxDrop,
         this.onlyFalling,
         this.onlyInAir,
         this.friends,
         this.restore,
         this.onlyTarget
      );
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.o();
   }

   @Override
   public void onDisable() {
      this.o();
      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         this.o();
      } else if (!mc.field_1724.method_6115()) {
         int var2 = mc.field_1724.method_31548().method_67532();
         if (this.ourMaceSlot != -1 && var2 != this.ourMaceSlot) {
            this.slotToRestore = -1;
            this.ourMaceSlot = -1;
         }

         boolean var3 = this.d(this.ourMaceSlot != -1);
         if (var3) {
            if (this.ourMaceSlot == -1) {
               int var4 = this.g();
               if (var4 != -1 && var4 != var2) {
                  this.a(var4);
                  this.ourMaceSlot = var4;
                  this.slotToRestore = this.restore.isToggled() ? var2 : -1;
               }
            }
         } else if (this.ourMaceSlot != -1) {
            if (this.slotToRestore != -1) {
               this.a(this.slotToRestore);
            }

            this.slotToRestore = -1;
            this.ourMaceSlot = -1;
         }
      }
   }

   public boolean b(class_1309 var1) {
      if (mc.field_1724 == null || var1 == null || !var1.method_5805() || var1.method_31481()) {
         return false;
      } else if (mc.field_1724.method_6047().method_7909() != class_1802.field_49814) {
         return false;
      } else if (mc.field_1724.method_24828() || mc.field_1724.method_6128() || mc.field_1724.method_18798().field_1351 >= -0.01) {
         return false;
      } else {
         return mc.field_1724.field_6017 > 0.15F;
      }
   }

   public boolean a(class_1309 var1, double var2) {
      if (!this.b(var1) || !this.c(var1)) {
         return false;
      } else if (mc.field_1724.method_6115() || mc.field_1724.method_7261(0.5F) < 0.9F) {
         return false;
      } else if (this.a(mc.field_1724.method_33571(), var1.method_5829()) > var2) {
         return false;
      } else {
         class_243 var4 = this.f();
         if (var4 == null) {
            return false;
         } else {
            class_243 var5 = var4.method_1031(0.0, mc.field_1724.method_5751(), 0.0);
            return this.a(var5, var1.method_5829()) <= var2;
         }
      }
   }

   private boolean d(boolean var1) {
      if (this.onlyInAir.isToggled() && mc.field_1724.method_24828()) {
         return false;
      } else if (this.onlyTarget.isToggled()) {
         class_1309 var2 = this.i();
         if (var2 == null || !this.c(var2)) {
            return false;
         } else {
            return this.b(var2, var1);
         }
      } else {
         if (!var1 && this.onlyFalling.isToggled() && mc.field_1724.method_18798().field_1351 >= 0.0) {
            return false;
         }

         for (class_1657 var6 : mc.field_1687.method_18456()) {
            if (var6 != mc.field_1724
               && var6.method_5805()
               && !var6.method_7325()
               && !var6.method_68878()
               && (this.friends.isToggled() || !FriendManager.a(var6.method_5477().getString()))
               && this.b(var6, var1)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean b(class_1309 var1, boolean var2) {
      double var3 = var2 ? 0.0 : this.minHeight.getValue();
      double var5 = Math.max(this.maxDrop.getValue(), this.minHeight.getValue());
      double var7 = mc.field_1724.method_23318() - var1.method_23318();
      if (var7 <= 0.0 || var7 < var3 || var7 > var5) {
         return false;
      } else {
         double var9 = var1.method_23317() - mc.field_1724.method_23317();
         double var11 = var1.method_23321() - mc.field_1724.method_23321();
         double var13 = this.radius.getValue();
         return var9 * var9 + var11 * var11 <= var13 * var13;
      }
   }

   private boolean c(class_1309 var1) {
      if (var1 == null || var1 == mc.field_1724 || !var1.method_5805() || var1.method_7325()) {
         return false;
      } else {
         return !(var1 instanceof class_1657 var2)
            || this.friends.isToggled()
            || !FriendManager.a(var2.method_5477().getString());
      }
   }

   private class_1309 i() {
      TriggerBot var1 = FunctionManager.a(TriggerBot.class);
      if (var1 != null && var1.isActive()) {
         class_1309 var2 = var1.l();
         if (var2 != null) {
            return var2;
         }

         var2 = var1.k();
         if (var2 != null) {
            return var2;
         }
      }

      AimAssist var3 = FunctionManager.a(AimAssist.class);
      return var3 != null && var3.isActive() ? var3.k() : null;
   }

   private class_243 f() {
      if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1724.method_6128()) {
         return null;
      } else {
         double var1 = Math.max(0.0, mc.field_1724.method_23318() - mc.field_1687.method_31607());
         double var2 = Math.min(20.0, Math.max(1.0, Math.sqrt(var1 / 0.04)));
         class_243 var3 = mc.field_1724.method_18798();
         class_243 var4 = mc.field_1724.method_73189().method_1031(var3.field_1352 * var2, 0.0, var3.field_1350 * var2);
         class_243 var5 = var4.method_1031(0.0, -Math.max(4.0, this.maxDrop.getValue() + 3.0), 0.0);
         class_239 var6 = mc.field_1687.method_17742(new class_3959(var4, var5, class_3960.field_17558, class_242.field_1348, mc.field_1724));
         return var6.method_17783() == class_240.field_1332 ? var6.method_17784() : null;
      }
   }

   private double a(class_243 var1, class_238 var2) {
      double var3 = Math.max(var2.field_1323, Math.min(var1.field_1352, var2.field_1320));
      double var5 = Math.max(var2.field_1322, Math.min(var1.field_1351, var2.field_1325));
      double var7 = Math.max(var2.field_1321, Math.min(var1.field_1350, var2.field_1324));
      return var1.method_1022(new class_243(var3, var5, var7));
   }

   private int g() {
      if (mc.field_1724 == null) {
         return -1;
      } else {
         for (int var1 = 0; var1 < 9; var1++) {
            class_1799 var2 = mc.field_1724.method_31548().method_5438(var1);
            if (var2.method_7909() == class_1802.field_49814) {
               return var1;
            }
         }

         return -1;
      }
   }

   private void a(int var1) {
      mc.field_1724.method_31548().method_61496(var1);
      if (mc.field_1724.field_3944 != null) {
         mc.field_1724.field_3944.method_52787(new class_2868(var1));
      }
   }

   private void o() {
      if (this.slotToRestore != -1 && mc.field_1724 != null && mc.field_1724.method_31548().method_67532() == this.ourMaceSlot) {
         this.a(this.slotToRestore);
      }

      this.slotToRestore = -1;
      this.ourMaceSlot = -1;
   }
}
