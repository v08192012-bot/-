package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.ModuleClass;
import brokke.cc.module.NewFunction;
import brokke.cc.module.player.AutoEat;
import brokke.cc.module.player.NoRotate;
import brokke.cc.core.AuraChecks;
import brokke.cc.core.FakePlayerEntity;
import brokke.cc.core.FreeLookStorage;
import brokke.cc.core.SlotSearchResult;
import brokke.cc.core.SprintReset;
import brokke.cc.core.TpsSync;
import brokke.cc.manager.FriendManager;
import brokke.cc.manager.SwapManager;
import brokke.cc.nav.BestPoint;
import brokke.cc.rotation.AimAssistRotation;
import brokke.cc.rotation.FuntimeRotation;
import brokke.cc.rotation.Holy2Rotation;
import brokke.cc.rotation.HolyWorldRotation;
import brokke.cc.rotation.IdealHitUtils;
import brokke.cc.rotation.LegitRotation;
import brokke.cc.rotation.MultipointUtils;
import brokke.cc.rotation.ReallyWorldRotation;
import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationStorage;
import brokke.cc.rotation.RotationUtils;
import brokke.cc.rotation.RotationsSystem;
import brokke.cc.rotation.SkyTimeRotation;
import brokke.cc.rotation.SlothRotation;
import brokke.cc.rotation.TestRotation;
import brokke.cc.rotation.WhiteRiseRotation;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.FloatSetting;
import brokke.cc.setting.ListSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.EventPriority;
import brokke.cc.system.events.impl.AttackEntityEvent;
import brokke.cc.system.events.impl.EventGameUpdate;
import brokke.cc.system.events.impl.EventKeyboardInput;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.SendPacketEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.HotbarUtil;
import brokke.cc.util.MathUtils;
import brokke.cc.util.MovingUtil;
import brokke.cc.util.PredictUtils;
import brokke.cc.util.TimerUtils;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1420;
import net.minecraft.class_1431;
import net.minecraft.class_1439;
import net.minecraft.class_1531;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import net.minecraft.class_2868;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_9362;

@NewFunction(name = "Aura", description = "Автоматически наводиться и бьёт таргета", category = Category.COMBAT)
public class Aura extends Function {
   public static Aura INSTANCE;
   public final ModeSetting rotationType = new ModeSetting("Ротация", "Legit", new String[]{"Legit", "ReallyWorld", "SkyTime"});
   private final ListSetting targets = new ListSetting(
      "Таргеты", new BooleanSetting("Игроки", true), new BooleanSetting("Голые", true), new BooleanSetting("Мирные", false), new BooleanSetting("Мобы", true)
   );
   private final ModeSetting moveFix = new ModeSetting("Коррекция", "Свободная", new String[]{"Нет", "Свободная", "Сфокусированная", "Полная"});
   private final ModeSetting priority = new ModeSetting("Приоритет", "Дистанция", new String[]{"Дистанция", "Здоровье", "Угол", "Никакой"});
   private final FloatSetting range = new FloatSetting("Дистанция атаки", 3.0F, 0.0F, 6.0F, 0.05F);
   public final BooleanSetting smartCrit = new BooleanSetting("Умные криты", false);
   public final BooleanSetting onlyCrits = new BooleanSetting("Только критами", false);
   public final ModeSetting sprintReset = new ModeSetting("Сброс спринта", "Legit", new String[]{"Нет", "Legit", "W-Tap", "S-Tap"});
   private final BooleanSetting throughWalls = new BooleanSetting("Через блоки", false);
   private final BooleanSetting unpressShield = new BooleanSetting("Отжимать щит", false);
   private final BooleanSetting breakShield = new BooleanSetting("Ломать щит", true);
   private final BooleanSetting attackOnEating = new BooleanSetting("Не бить когда ешь", true);
   public static BooleanSetting clientLook = new BooleanSetting("Наводка от первого лица", true);
   private final FloatSetting skyTimeFov = new FloatSetting("Поле зрения", 120.0F, 30.0F, 180.0F, 1.0F)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   private final FloatSetting skyTimeSpeed = new FloatSetting("Скорость ротации", 70.0F, 50.0F, 100.0F, 1.0F)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   private final FloatSetting skyTimeHitChance = new FloatSetting("Шанс удара", 90.0F, 0.0F, 100.0F, 1.0F)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   private final BooleanSetting skyTimeTurnAway = new BooleanSetting("Отведение после удара", true)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   private final BooleanSetting skyTimeJitter = new BooleanSetting("Джитер хитбокса", false)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   public final BooleanSetting skyTimeFreeCam = new BooleanSetting("Свободная камера", true)
      .showWhen(() -> this.rotationType.isSelected("SkyTime"));
   private class_1309 target;
   class_241 currentRotations = new class_241(0.0F, 0.0F);
   class_241 targetRotations = new class_241(0.0F, 0.0F);
   private final TimerUtils attackTimer = new TimerUtils();
   private final TestRotation testRotation = new TestRotation();
   private final FuntimeRotation funtimeRotation = new FuntimeRotation();
   private final SlothRotation slothRotation = new SlothRotation();
   private final HolyWorldRotation holyWorldRotation = new HolyWorldRotation();
   private final Holy2Rotation holy2Rotation = new Holy2Rotation();
   private final WhiteRiseRotation whiteRiseRotation = new WhiteRiseRotation(this);
   private final LegitRotation legitRotation = new LegitRotation();
   private final ReallyWorldRotation reallyWorldRotation = new ReallyWorldRotation();
   private final AimAssistRotation aimAssistRotation = new AimAssistRotation();
   private final SkyTimeRotation skyTimeRotation = new SkyTimeRotation();
   private boolean funtimeModeActive = false;
   private boolean slothModeActive = false;
   private boolean skyTimeModeActive = false;
   private boolean holyWorldModeActive = false;
   private float lastServerYaw;
   private float lastServerPitch;
   private boolean hasServerRotation;
   private class_1309 holyWorldServerTarget;
   private boolean auraAttackInProgress;
   private long holyWorldHiddenSinceNanos;
   private final TimerUtils backTimer = new TimerUtils();
   private TpsSync tpsSync = TpsSync.INSTANCE;
   private static final int ATTACK_DELAY_MIN_TICKS = 3;
   private static final int ATTACK_DELAY_MAX_TICKS = 13;
   private int attackDelayTicks = 0;
   private int ticksToAttack = 0;
   private class_1309 lastDataTarget = null;
   private float lastYaw = 0.0F;
   private float lastPitch = 0.0F;
   public static float adjYaw;
   public static float adjPitch;
   public static float otvodkaYaw;
   public static float otvodkaPitch;
   public boolean isRotated;
   private boolean returning = false;
   private boolean hadTarget = false;
   private float naturalYaw;
   private float naturalPitch;
   private float prevAuraPlayerYaw = Float.NaN;
   private float prevAuraPlayerPitch = 0.0F;
   private float lastAppliedAuraYawDelta = 0.0F;
   private float lastAppliedAuraPitchDelta = 0.0F;
   private long lastTargetScanNanos = 0L;
   private static final class_1304[] ARMOR_SLOTS = new class_1304[]{class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169};

   public void setTarget(class_1309 var1) {
      this.target = var1;
   }

   public void a(float var1, float var2) {
      this.lastAppliedAuraYawDelta += var1;
      this.lastAppliedAuraPitchDelta += var2;
   }

   public AimAssistRotation getAimAssistRotation() {
      return this.aimAssistRotation;
   }

   private void B() {
      this.returning = false;
      this.hadTarget = false;
      this.aimAssistRotation.b();
      RotationStorage.a().j();
   }

   public Aura() {
      INSTANCE = this;
      this.addSettings(
         this.rotationType,
         this.targets,
         this.range,
         this.smartCrit,
         this.onlyCrits,
         this.sprintReset,
         this.attackOnEating,
         this.throughWalls,
         this.unpressShield,
         this.breakShield,
         clientLook,
         this.moveFix,
         this.priority,
         this.skyTimeFov,
         this.skyTimeSpeed,
         this.skyTimeHitChance,
         this.skyTimeTurnAway,
         this.skyTimeJitter,
         this.skyTimeFreeCam
      );
   }

   public boolean l() {
      return this.isActive();
   }

   /** SkyTime делегирует атаки встроенному TriggerBot (см. TriggerBot.p). */
   public boolean skyTimeTriggerBotActive() {
      if (!this.l() || !this.rotationType.isSelected("SkyTime")) {
         return false;
      }

      TriggerBot var1 = FunctionManager.a(TriggerBot.class);
      return var1 != null && var1.isActive();
   }

   /** Разрешение удара для TriggerBot: еда, задержка ауры и шанс удара SkyTime. */
   public boolean skyTimeTriggerAllow() {
      if (!this.skyTimeTriggerBotActive()) {
         return true;
      } else if (this.attackOnEating.isEnabled() && (this.N() || AutoEat.l())) {
         return false;
      } else if (this.attackDelayTicks > 0) {
         return false;
      } else {
         if (this.skyTimeHitChance.getFloatValue() < 100.0F
            && ThreadLocalRandom.current().nextFloat() * 100.0F >= this.skyTimeHitChance.getFloatValue()) {
            this.attackDelayTicks = 1;
            return false;
         }

         return true;
      }
   }

   /** TriggerBot нанёс удар в SkyTime: отведение после удара + учёт кулдауна ауры. */
   public void skyTimeTriggerAttacked() {
      if (this.skyTimeTriggerBotActive()) {
         this.skyTimeRotation.b();
         this.attackDelayTicks = this.L();
         this.ticksToAttack = this.attackDelayTicks;
         this.attackTimer.a();
      }
   }

   public class_1309 getTarget() {
      return this.target;
   }

   public class_241 getCurrentRotations() {
      return this.currentRotations;
   }

   public class_241 getTargetRotations() {
      return this.targetRotations;
   }

   public TimerUtils getAttackTimer() {
      return this.attackTimer;
   }

   @EventHandler
   public void onAttackEntity(AttackEntityEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && var1.getPlayer() == mc.field_1724 && var1.getTarget() instanceof class_1309 var2 && this.e(var2)) {
         this.target = var2;
      }
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      this.a(var1);
      SprintReset.a(var1);
      if (this.target != null && !IdealHitUtils.d() && (this.onlyCrits.isOn() || this.smartCrit.isEnabled() && !mc.field_1724.method_24828() || IdealHitUtils.e())) {
         var1.setSprint(false);
      }
   }

   private void a(EventMoveInput var1) {
      if (mc.field_1724 != null
         && this.target != null
         && !this.rotationType.isSelected("NoRotate")
         && !this.rotationType.isSelected("Legit")
         && this.moveFix.getSelectedIndex() != 0) {
         if (this.moveFix.getSelectedIndex() == 1) {
            MovingUtil.a(var1);
         } else if (this.moveFix.getSelectedIndex() == 2) {
            MovingUtil.a(var1, this.C());
         } else if (this.moveFix.getSelectedIndex() == 3) {
            this.a(var1, this.C(), this.D());
         }
      }
   }

   @EventHandler
   public void onKeyboardInput(EventKeyboardInput var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.target != null && !this.rotationType.isSelected("NoRotate") && !this.rotationType.isSelected("Legit")) {
         float var2 = this.C();
         if (this.moveFix.getSelectedIndex() == 2) {
            var1.setYaw(var2, mc.field_1724.method_36454());
         } else if (this.moveFix.getSelectedIndex() == 3) {
            var1.setYaw(var2, this.D());
         }
      }
   }

   private float C() {
      return RotationStorage.instance != null && RotationStorage.instance.getTargetRotation() != null
         ? RotationStorage.instance.getTargetRotation().getYaw()
         : mc.field_1724.method_36454();
   }

   private float D() {
      return RotationUtils.b(this.target.method_5829().method_1005()).field_1343;
   }

   private void a(EventMoveInput var1, float var2, float var3) {
      float var4 = var1.getForward();
      float var5 = var1.getStrafe();
      if (var4 != 0.0F || var5 != 0.0F) {
         double var6 = class_3532.method_15338(Math.toDegrees(MovingUtil.a(var3, var4, var5)));
         float var8 = 0.0F;
         float var9 = 0.0F;
         float var10 = Float.MAX_VALUE;

         for (float var11 = -1.0F; var11 <= 1.0F; var11++) {
            for (float var12 = -1.0F; var12 <= 1.0F; var12++) {
               if (var11 != 0.0F || var12 != 0.0F) {
                  double var13 = class_3532.method_15338(Math.toDegrees(MovingUtil.a(var2, var11, var12)));
                  double var15;
                  if ((var15 = Math.abs(class_3532.method_15338(var6 - var13))) < var10) {
                     var10 = (float)var15;
                     var8 = var11;
                     var9 = var12;
                  }
               }
            }
         }

         var1.setForward(var8);
         var1.setStrafe(var9);
      }
   }

   @EventHandler
   private void onGameUpdate(EventGameUpdate var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (this.rotationType.isSelected("Legit")) {
            if (this.target != null) {
               if (!this.d(this.target)) {
                  this.I();
               }
            } else {
               long var2;
               if ((var2 = System.nanoTime()) - this.lastTargetScanNanos > 50000000L) {
                  this.lastTargetScanNanos = var2;
                  this.I();
               }
            }
         }

         if (this.target != null) {
            this.F();
         } else if (this.returning) {
            float var5 = FreeLookStorage.isActive() ? FreeLookStorage.getFreeYaw() : this.naturalYaw;
            float var3 = FreeLookStorage.isActive() ? FreeLookStorage.getFreePitch() : this.naturalPitch;
            boolean var4;
            if (this.rotationType.isSelected("AimAssist")) {
               var4 = this.aimAssistRotation.c(var5, var3);
            } else {
               var4 = true;
            }

            if (var4) {
               this.B();
            }
         }
      }
   }

   @EventHandler
   public void onTick(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.lastYaw++;
         if (!FreeLookStorage.isActive() && !Float.isNaN(this.prevAuraPlayerYaw)) {
            float var2 = class_3532.method_15393(mc.field_1724.method_36454() - this.prevAuraPlayerYaw) - this.lastAppliedAuraYawDelta;
            float var3 = mc.field_1724.method_36455() - this.prevAuraPlayerPitch - this.lastAppliedAuraPitchDelta;
            if (Math.abs(var2) > 0.01F || Math.abs(var3) > 0.01F) {
               this.naturalYaw = class_3532.method_15393(this.naturalYaw + var2);
               this.naturalPitch = class_3532.method_15363(this.naturalPitch + var3, -90.0F, 90.0F);
               FreeLookStorage.setFreeYaw(this.naturalYaw);
               FreeLookStorage.setFreePitch(this.naturalPitch);
            }
         }

         this.prevAuraPlayerYaw = mc.field_1724.method_36454();
         this.prevAuraPlayerPitch = mc.field_1724.method_36455();
         this.lastAppliedAuraYawDelta = 0.0F;
         if (this.rotationType.isSelected("Legit")) {
            if (!clientLook.isEnabled()) {
               clientLook.setValue(true);
            }

            if (FreeLookStorage.isActive()) {
               FreeLookStorage.a(false);
            }
         }

         IdealHitUtils.b();
         SprintReset.b();
         if (this.target != null) {
            if (this.rotationType.isSelected("AimAssist")) {
               this.aimAssistRotation.d(this.target);
            }
         } else if (this.returning) {
            float var4 = FreeLookStorage.isActive() ? FreeLookStorage.getFreeYaw() : this.naturalYaw;
            float var5 = FreeLookStorage.isActive() ? FreeLookStorage.getFreePitch() : this.naturalPitch;
            if (this.rotationType.isSelected("AimAssist")) {
               this.aimAssistRotation.b(var4, var5);
            }
         }

         if (this.ticksToAttack > 0) {
            this.ticksToAttack--;
         }

         if (this.attackDelayTicks > 0) {
            this.attackDelayTicks--;
         }

         if (!ModuleClass.packetCriticals.a() || !mc.field_1724.method_6059(class_1294.field_5906)) {
            this.E();
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onPacket(SendPacketEvent var1) {
      if (!var1.isCancelled() && var1.getPacket() instanceof class_2828 var2 && var2.method_36172() && mc.field_1724 != null) {
         this.lastServerYaw = var2.method_12271(mc.field_1724.method_36454());
         this.lastServerPitch = var2.method_12270(mc.field_1724.method_36455());
         this.hasServerRotation = true;
      }
   }

   private void E() {
      this.I();
      if (this.target != null) {
         int var1 = this.attackOnEating.isEnabled() && (this.N() || AutoEat.l()) ? 1 : 0;
         if (this.S() && this.attackDelayTicks <= 0 && var1 == 0) {
            this.k(this.target);
         }

         if (this.P() && this.attackDelayTicks <= 0) {
            if (var1 != 0) {
               return;
            }

            if (this.skyTimeTriggerBotActive()) {
               return;
            }

            if (this.rotationType.isSelected("SkyTime")
               && this.skyTimeHitChance.getFloatValue() < 100.0F
               && ThreadLocalRandom.current().nextFloat() * 100.0F >= this.skyTimeHitChance.getFloatValue()) {
               this.attackDelayTicks = 1;
               return;
            }

            this.K();
            if (this.S()) {
               this.U();
            }
         }
      } else {
         this.attackDelayTicks = 0;
         this.backTimer.a();
         adjPitch = 0.0F;
         adjYaw = 0.0F;
         this.testRotation.a();
         this.W();
         this.R();
         this.X();
         this.Y();
         if (!this.returning) {
            this.aimAssistRotation.b();
         }

         this.whiteRiseRotation.a();
         this.legitRotation.a();
         this.reallyWorldRotation.a();
         this.lastDataTarget = null;
         this.ticksToAttack = 0;
      }
   }

   public void q() {
      this.F();
   }

   public void b(class_1309 var1) {
      if (var1 != null && mc.field_1724 != null) {
         class_1309 var2 = this.target;
         this.target = var1;

         try {
            this.F();
         } finally {
            if (var2 != null && var2.method_5805()) {
               this.target = var2;
            }
         }
      }
   }

   public void r() {
      if (this.rotationType.isSelected("Funtime")) {
         this.funtimeRotation.b();
      }

      if (this.rotationType.isSelected("WhiteRise")) {
         this.whiteRiseRotation.b();
      }

      if (this.rotationType.isSelected("ReallyWorld")) {
         this.reallyWorldRotation.b();
      }
   }

   private void F() {
      if (this.target != null) {
         if (!this.rotationType.isSelected("Funtime")) {
            this.R();
         }

         if (!this.rotationType.isSelected("SkyTime")) {
            this.Y();
         }

         if (!this.S()) {
            this.W();
         }

         if (!this.rotationType.isSelected("Sloth")) {
            this.X();
         }

         RotationsSystem var1;
         if (this.rotationType.isSelected("Smooth")) {
            var1 = new RotationsSystem() {
               @Override
               public void a(class_1309 var1) {
                  if (!mc.field_1724.method_6128()) {
                     class_243 var2 = var1.method_73189().method_1031(0.0, var1.method_17682() * 0.6F, 0.0).method_1020(mc.field_1724.method_33571());
                     float var3 = (float)class_3532.method_15338(Math.toDegrees(Math.atan2(var2.field_1350, var2.field_1352)) - 90.0);
                     float var4 = (float)(-Math.toDegrees(Math.atan2(var2.field_1351, Math.hypot(var2.field_1352, var2.field_1350))));
                     RotationStorage.a(new Rotation2(var3, var4), 360.0F, 360.0F, 360.0F, 360.0F, 1, 1, Aura.clientLook.isEnabled());
                  } else {
                     class_243 var8 = class_243.method_1030(var1.method_36455(), var1.method_36454());
                     class_243 var9 = var1.method_5720();
                     class_243 var10 = var1.method_73189().method_1031(0.0, var1.method_17682() * 0.6F, 0.0).method_1020(mc.field_1724.method_33571());
                     class_243 var5 = var8.method_1029().method_35590(var9, var8.method_1033());
                     float var6 = (float)class_3532.method_15338(Math.toDegrees(Math.atan2(var10.field_1350, var10.field_1352)) - 90.0);
                     float var7 = (float)(-Math.toDegrees(Math.atan2(var10.field_1351, Math.hypot(var10.field_1352, var10.field_1350))));
                     RotationStorage.a(new Rotation2(var6, var7), 360.0F, 360.0F, 360.0F, 360.0F, 1, 1, Aura.clientLook.isEnabled());
                  }
               }
            };
         } else if (this.rotationType.isSelected("Legit")) {
            var1 = this.legitRotation;
            class_243 var2 = mc.field_1724.method_33571();
            class_243 var3 = this.target.method_5829().method_1005();
            float var4 = (float)(Math.toDegrees(Math.atan2(var3.field_1350 - var2.field_1350, var3.field_1352 - var2.field_1352)) - 90.0);
            this.targetRotations = new class_241(var4, mc.field_1724.method_36455());
            this.currentRotations = new class_241(mc.field_1724.method_36454(), mc.field_1724.method_36455());
         } else if (this.rotationType.isSelected("ReallyWorld")) {
            var1 = this.reallyWorldRotation;
         } else if (this.S()) {
            if (!this.holyWorldModeActive) {
               this.V();
               this.holyWorldModeActive = true;
            }

            if (this.holyWorldServerTarget != this.target) {
               this.holyWorldServerTarget = this.target;
               this.hasServerRotation = false;
               this.holyWorldHiddenSinceNanos = 0L;
            }

            var1 = this.T();
         } else if (this.rotationType.isSelected("Test")) {
            var1 = this.testRotation;
         } else if (this.rotationType.isSelected("Funtime")) {
            if (!this.funtimeModeActive) {
               this.funtimeRotation.a();
               this.funtimeModeActive = true;
            }

            this.funtimeRotation.setVisibleAim(clientLook.isEnabled());
            this.funtimeRotation.a(this.j(this.target));
            var1 = this.funtimeRotation;
         } else if (this.rotationType.isSelected("Sloth")) {
            if (!this.slothModeActive) {
               this.slothRotation.a();
               this.slothModeActive = true;
            }

            if (this.holyWorldServerTarget != this.target) {
               this.holyWorldServerTarget = this.target;
               this.hasServerRotation = false;
               this.holyWorldHiddenSinceNanos = 0L;
            }

            this.slothRotation.setVisibleAim(false);
            this.slothRotation.a(this.j(this.target));
            var1 = this.slothRotation;
         } else if (this.rotationType.isSelected("SkyTime")) {
            if (!this.skyTimeModeActive) {
               this.skyTimeRotation.a();
               this.skyTimeModeActive = true;
            }

            this.skyTimeRotation.setVisibleAim(!this.skyTimeFreeCam.isEnabled() && clientLook.isEnabled());
            this.skyTimeRotation.setFov(this.skyTimeFov.getFloatValue());
            this.skyTimeRotation.setSpeed(this.skyTimeSpeed.getFloatValue());
            this.skyTimeRotation.setJitter(this.skyTimeJitter.isEnabled());
            this.skyTimeRotation.setTurnAway(this.skyTimeTurnAway.isEnabled());
            var1 = this.skyTimeRotation;
         } else if (this.rotationType.isSelected("AimAssist")) {
            var1 = this.aimAssistRotation;
         } else if (this.rotationType.isSelected("NoRotate")) {
            var1 = new RotationsSystem() {
               @Override
               public void a(class_1309 var1) {
                  RotationStorage.a(
                     new Rotation2(FreeLookStorage.getFreeYaw(), FreeLookStorage.getFreePitch()),
                     MathUtils.a(100.0F, 170.0F),
                     MathUtils.a(100.0F, 170.0F),
                     MathUtils.a(100.0F, 170.0F),
                     MathUtils.a(100.0F, 170.0F),
                     1,
                     6,
                     false
                  );
               }
            };
         } else if (this.rotationType.isSelected("Data")) {
            var1 = new RotationsSystem() {
               @Override
               public void a(class_1309 var1) {
                  boolean var2 = Aura.this.J();
                  class_243 var3 = Aura.this.g(var1);
                  class_241 var4 = RotationUtils.b(var3);
                  float var5 = mc.field_1724.method_36454();
                  float var6 = mc.field_1724.method_36455();
                  float var7 = Math.abs(class_3532.method_15393(var4.field_1343 - var5));
                  float var8 = Math.abs(var4.field_1342 - var6);
                  boolean var9 = var7 > 70.0F || var7 > 42.0F && mc.field_1724.method_5858(var1) < 9.0;
                  Rotation2 var10 = new Rotation2(var4.field_1343, var4.field_1342);
                  Aura.this.targetRotations = new class_241(var10.getYaw(), var10.getPitch());
                  Aura.this.currentRotations = new class_241(var5, var6);
                  float var11 = var9 ? Math.max(95.0F, Math.min(180.0F, var7 * 1.45F)) : (var2 ? 24.0F : 11.5F);
                  float var12 = var9 ? Math.max(55.0F, Math.min(110.0F, Math.max(18.0F, var8 * 1.35F))) : (var2 ? 18.0F : 9.0F);
                  float var13 = var9 ? var11 : (var2 ? 18.0F : 9.0F);
                  float var14 = var9 ? var12 : (var2 ? 14.0F : 7.0F);
                  RotationStorage.a(var10, var11, var12, var13, var14, 1, 1, Aura.clientLook.isEnabled());
               }
            };
         } else {
            final class_241 var5 = RotationUtils.b(this.a(this.target, this.target.method_30951(1.0F)));
            var1 = new RotationsSystem() {
               @Override
               public void a(class_1309 var1) {
                  Aura.this.currentRotations = new class_241(mc.field_1724.method_36454(), mc.field_1724.method_36455());
                  RotationStorage.a(new Rotation2(var5.field_1343, var5.field_1342), 360.0F, 360.0F, 360.0F, 360.0F, 1, 1, Aura.clientLook.isEnabled());
               }
            };
         }

         var1.a(this.target);
      }
   }

   public class_3966 a(float var1) {
      float var2 = mc.field_1724.method_36454();
      float var3 = mc.field_1724.method_36455();
      return this.a(var2, var3, var1);
   }

   public boolean a(class_1309 var1, float var2) {
      if (var1 != null && mc.field_1724 != null) {
         class_3966 var3 = this.a(var2);
         return var3 != null && var3.method_17782() == var1;
      } else {
         return false;
      }
   }

   private class_3966 G() {
      return this.a(this.range.getFloatValue());
   }

   private class_3966 b(float var1, float var2) {
      return this.a(var1, var2, this.range.getFloatValue());
   }

   private class_3966 a(float var1, float var2, float var3) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 var4 = mc.field_1724.method_5836(1.0F);
         class_243 var5 = class_243.method_1030(var2, var1);
         class_243 var6 = var4.method_1019(var5.method_1021(var3));
         double var7 = var3 * var3;
         if (!this.throughWalls.isEnabled()) {
            class_3965 var9 = mc.field_1687.method_17742(new class_3959(var4, var6, class_3960.field_17558, class_242.field_1348, mc.field_1724));
            if (var9 != null && var9.method_17783() != class_240.field_1333) {
               var6 = var9.method_17784();
               var7 = var4.method_1025(var6);
            }
         }

         class_238 var11 = mc.field_1724.method_5829().method_18804(var5.method_1021(var3)).method_1009(1.0, 1.0, 1.0);
         class_3966 var10 = class_1675.method_18075(mc.field_1724, var4, var6, var11, var0 -> var0 != mc.field_1724 && var0.method_5805() && !var0.method_7325(), var7);
         return var10 != null && var4.method_1022(var10.method_17784()) <= var3 ? var10 : null;
      } else {
         return null;
      }
   }

   public boolean a(float var1, float var2, class_1309 var3, float var4) {
      return this.b(var1, var2, var3, var4);
   }

   public boolean c(class_1309 var1) {
      return AuraChecks.a(mc, var1);
   }

   private class_243 a(class_1309 var1, class_243 var2) {
      return mc.field_1724 != null && var1 != null && mc.field_1724.method_6128() && var1.method_6128() ? PredictUtils.c(var1) : var2;
   }

   class_243 g(class_1309 var1) {
      if (this.h(var1)) {
         return this.a(var1, this.i(var1));
      }

      class_243 var2 = BestPoint.a(var1);
      if (var2 == null) {
         var2 = MultipointUtils.a(var1);
      }

      if (var2 == null) {
         var2 = this.i(var1);
      }

      return this.a(var1, var2);
   }

   private boolean h(class_1309 var1) {
      if (mc.field_1724 != null && var1 != null) {
         class_243 var2 = mc.field_1724.method_33571();
         class_238 var3 = var1.method_5829();
         if (var3.method_1014(0.12).method_1006(var2)) {
            return true;
         }

         class_243 var4 = this.i(var1);
         return var2.method_1025(var4) <= 2.25;
      } else {
         return false;
      }
   }

   private class_243 i(class_1309 var1) {
      class_238 var2 = var1.method_5829();
      return new class_243(var2.method_1005().field_1352, var2.field_1322 + var2.method_17940() * 0.72, var2.method_1005().field_1350);
   }

   private class_1309 H() {
      if (this.l() && mc.field_1687 != null && mc.field_1724 != null) {
         class_1309 var1 = null;
         double var2 = Double.MAX_VALUE;
         class_243 var4 = mc.field_1724.method_33571();
         float var5 = mc.field_1724.method_36454();
         float var6 = mc.field_1724.method_36455();
         String var7 = this.priority.getActiveMode();

         for (class_1297 var9 : mc.field_1687.method_18112()) {
            if (var9 instanceof class_1309 var10 && this.e(var10)) {
               double var11 = switch (var7) {
                  case "Здоровье" -> var10.method_6032();
                  case "Угол" -> {
                     class_241 var15 = RotationUtils.b(var10.method_5829().method_1005());
                     double var16 = Math.abs(class_3532.method_15393(var15.field_1343 - var5));
                     double var18 = Math.abs(class_3532.method_15393(var15.field_1342 - var6));
                     yield var16 + var18;
                  }
                  default -> var10.method_5829().method_1005().method_1025(var4);
               };
               if (var11 < var2) {
                  var2 = var11;
                  var1 = var10;
               }
            }
         }

         return var1;
      } else {
         return null;
      }
   }

   private void I() {
      this.lastTargetScanNanos = System.nanoTime();
      if (!this.l()) {
         this.target = null;
         if (this.returning) {
            this.B();
         }
      } else if (this.target == null || !this.e(this.target)) {
         class_1309 var1 = this.target;
         this.target = this.H();
         if (this.target != null) {
            if (!this.hadTarget) {
               this.hadTarget = true;
               this.returning = false;
               if (mc.field_1724 != null && !FreeLookStorage.isActive()) {
                  this.naturalYaw = mc.field_1724.method_36454();
                  this.naturalPitch = mc.field_1724.method_36455();
                  FreeLookStorage.setFreeYaw(this.naturalYaw);
                  FreeLookStorage.setFreePitch(this.naturalPitch);
               }
            }
         } else if (var1 != null || this.hadTarget) {
            this.hadTarget = false;
            if (this.rotationType.isSelected("AimAssist")) {
               this.returning = true;
            } else {
               this.B();
            }
         }
      }
   }

   public class_1309 a(double var1) {
      if (this.target != null && this.e(this.target)) {
         return this.target;
      }

      if (mc.field_1687 != null && mc.field_1724 != null) {
         class_1309 var3 = null;
         double var4 = var1 * var1;

         for (class_1297 var7 : mc.field_1687.method_18112()) {
            double var9;
            if (var7 instanceof class_1309 var8 && this.e(var8) && (var9 = mc.field_1724.method_5858(var8)) < var4) {
               var4 = var9;
               var3 = var8;
            }
         }

         return var3;
      } else {
         return null;
      }
   }

   boolean J() {
      float var1 = mc.field_1724.method_7261(1.5F);
      float var2 = Math.max(0.82F, IdealHitUtils.a() - 0.08F);
      int var3 = var1 >= var2 ? 1 : 0;
      int var4 = !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 < 0.0 && mc.field_1724.field_6017 > 0.0 ? 1 : 0;
      return var3 != 0 || var4 != 0;
   }

   private void K() {
      class_1268 var1 = null;
      if (this.unpressShield.isEnabled()) {
         var1 = this.M();
         if (var1 != null) {
            mc.field_1761.method_2897(mc.field_1724);
         }
      }

      this.auraAttackInProgress = true;

      try {
         boolean var2 = false;
         if (this.target instanceof class_1657 var3 && var3.method_6039() && this.breakShield.isEnabled()) {
            if (this.rotationType.isSelected("Legit")) {
               SlotSearchResult var15 = HotbarUtil.c();
               if (var15.isFound() && var15.d()) {
                  int var5 = mc.field_1724.method_31548().method_67532();
                  if (var15.getSlot() == var5) {
                     mc.field_1761.method_2918(mc.field_1724, var3);
                     var2 = true;
                  }
               }
            } else {
               var2 = this.a(var3);
            }
         }

         if (!var2) {
            int var14 = !IdealHitUtils.e() && !this.onlyCrits.isOn() ? 0 : 1;
            boolean var16 = mc.field_1724.method_5624();
            if (var14 != 0 && var16) {
               if (mc.field_1724.field_3944 != null) {
                  mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12985));
               }

               mc.field_1724.method_5728(false);
            }

            try {
               mc.field_1761.method_2918(mc.field_1724, this.target);
            } finally {
               if (var14 == 0 && mc.field_1724 != null && mc.field_1724.method_24828()) {
                  SprintReset.a(this.sprintReset.getActiveMode(), var16);
               } else if (var14 != 0 && var16 && mc.field_1724 != null) {
                  mc.field_1724.method_5728(true);
                  if (mc.field_1724.field_3944 != null) {
                     mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12981));
                  }
               }
            }
         }
      } finally {
         this.auraAttackInProgress = false;
      }

      mc.field_1724.method_6104(class_1268.field_5808);
      if (var1 != null) {
         this.a(var1);
      }

      if (this.rotationType.isSelected("Funtime")) {
         this.funtimeRotation.b();
      }

      if (this.rotationType.isSelected("WhiteRise")) {
         this.whiteRiseRotation.b();
      }

      if (this.rotationType.isSelected("SkyTime")) {
         this.skyTimeRotation.b();
      }

      this.attackDelayTicks = this.L();
      this.ticksToAttack = this.attackDelayTicks;
      this.attackTimer.a();
   }

   private int L() {
      if (this.rotationType.isSelected("Legit")) {
         return ThreadLocalRandom.current().nextInt(0, 2);
      }

      if (!this.S()) {
         return 0;
      }

      int var1 = ThreadLocalRandom.current().nextInt(3, 14);
      if (this.tpsSync != null && this.tpsSync.a()) {
         var1 = class_3532.method_15340(Math.round((float)this.tpsSync.a(var1 * 50L) / 50.0F), 3, 13);
      }

      return var1;
   }

   private boolean a(class_1657 var1) {
      SlotSearchResult var2 = HotbarUtil.c();
      if (!var2.isFound()) {
         return false;
      }

      int var3 = mc.field_1724.method_31548().method_67532();
      if (var2.getSlot() == var3) {
         mc.field_1761.method_2918(mc.field_1724, var1);
         return true;
      }

      if (var2.d()) {
         return this.a(var1, var2.getSlot(), var3);
      }

      if (mc.field_1724.field_7512.field_7763 != 0) {
         return false;
      }

      int var4;
      if ((var4 = this.b(var3)) == -1) {
         return false;
      }

      this.a(var2.getSlot(), var4);
      byte var5 = 0;
      boolean var9 = false;

      try {
         var9 = this.a(var1, var4, var3);
      } finally {
         this.a(var2.getSlot(), var4);
      }

      return var9;
   }

   private boolean a(class_1657 var1, int var2, int var3) {
      if (mc.field_1724 != null && mc.field_1724.field_3944 != null && mc.field_1761 != null) {
         if (var2 >= 0 && var2 <= 8 && var2 != var3) {
            mc.field_1724.field_3944.method_52787(new class_2868(var2));
         }

         try {
            mc.field_1761.method_2918(mc.field_1724, var1);
            return true;
         } finally {
            if (var3 >= 0 && var3 <= 8 && var2 != var3) {
               mc.field_1724.field_3944.method_52787(new class_2868(var3));
            }
         }
      } else {
         return false;
      }
   }

   private void a(int var1, int var2) {
      if (mc.field_1724 != null && mc.field_1761 != null && mc.field_1724.field_3944 != null) {
         SwapManager.a(var1, var2);
      }
   }

   private int b(int var1) {
      for (int var2 = 8; var2 >= 0; var2--) {
         if (var2 != var1) {
            return var2;
         }
      }

      return var1 >= 0 && var1 < 9 ? var1 : -1;
   }

   private class_1268 M() {
      if (mc.field_1724 != null && mc.field_1724.method_6039()) {
         class_1268 var1 = mc.field_1724.method_6058();
         if (var1 == null) {
            return null;
         } else {
            return this.a(mc.field_1724.method_5998(var1)) ? var1 : null;
         }
      } else {
         return null;
      }
   }

   private boolean N() {
      return mc.field_1724 != null && mc.field_1724.method_6115() ? !this.unpressShield.isEnabled() || this.M() == null : false;
   }

   private void a(class_1268 var1) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null && this.a(mc.field_1724.method_5998(var1)) && !mc.field_1724.method_6115()) {
         mc.field_1761.method_2919(mc.field_1724, var1);
      }
   }

   private boolean a(class_1799 var1) {
      return !var1.method_7960() && var1.method_7909() instanceof class_1819;
   }

   private boolean O() {
      if (mc.field_1724 == null) {
         return false;
      }

      class_1792 var1 = mc.field_1724.method_6047().method_7909();
      return var1 != class_1802.field_8162
         && (
            HotbarUtil.c(var1)
               || HotbarUtil.b(var1)
               || HotbarUtil.a(var1)
               || HotbarUtil.d(var1)
               || var1 instanceof class_1794
               || var1 instanceof class_9362
               || var1 == class_1802.field_49814
         );
   }

   public boolean d(class_1309 var1) {
      if (var1 != null && var1 != mc.field_1724) {
         if (!var1.method_5805() || var1.method_6032() <= 0.0F || var1.method_31481()) {
            return false;
         } else if (var1 instanceof class_1531) {
            return false;
         } else if (var1 instanceof class_1657 var2 && this.b(var2)) {
            return false;
         } else {
            double var4 = this.z() + 2.0;
            return mc.field_1724 != null && mc.field_1724.method_5858(var1) <= var4 * var4;
         }
      } else {
         return false;
      }
   }

   public boolean e(class_1309 var1) {
      if (var1 != null && var1 != mc.field_1724) {
         if (!var1.method_5805() || var1.method_6032() <= 0.0F) {
            return false;
         }

         if (var1 instanceof class_1531) {
            return false;
         }

         if (!(var1 instanceof class_1439) && !(var1 instanceof class_1420)) {
            if (var1 instanceof FakePlayerEntity) {
               if (!this.targets.isSelected("Игроки")) {
                  return false;
               }
            } else if (var1 instanceof class_1657 var2) {
               if (!this.targets.isSelected("Игроки")) {
                  return false;
               }

               if (this.b(var2)) {
                  return false;
               }

               if (this.c(var2) && !this.targets.isSelected("Голые")) {
                  return false;
               }
            } else if (!(var1 instanceof class_1296) && !(var1 instanceof class_1431)) {
               if (!(var1 instanceof class_1588)) {
                  return false;
               }

               if (!this.targets.isSelected("Мобы")) {
                  return false;
               }
            } else if (!this.targets.isSelected("Мирные")) {
               return false;
            }

            double var20;
            double var4 = (var20 = this.z()) + 2.0;
            if (mc.field_1724.method_5858(var1) > var4 * var4) {
               return false;
            }

            class_238 var6 = var1.method_5829();
            class_243 var7 = mc.field_1724.method_33571();
            double var8 = class_3532.method_15350(var7.field_1352, var6.field_1323, var6.field_1320);
            double var10 = class_3532.method_15350(var7.field_1351, var6.field_1322, var6.field_1325);
            double var12 = class_3532.method_15350(var7.field_1350, var6.field_1321, var6.field_1324);
            double var14 = var7.field_1352 - var8;
            double var16 = var7.field_1351 - var10;
            double var18 = var7.field_1350 - var12;
            if (var14 * var14 + var16 * var16 + var18 * var18 > var20 * var20) {
               return false;
            }

            if (!this.throughWalls.isEnabled() && !AuraChecks.a(mc, var1)) {
               return false;
            }

            if (this.S()) {
               if (!this.l(var1)) {
                  return false;
               }

               if (!this.throughWalls.isEnabled() && !AuraChecks.a(mc, var1)) {
                  return false;
               }
            }

            if (this.rotationType.isSelected("SkyTime") && !this.skyTimeRotation.e(var1)) {
               return false;
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean b(class_1657 var1) {
      return var1 != null && var1.method_5477() != null ? FriendManager.a(var1.method_5477().getString()) : false;
   }

   private boolean c(class_1657 var1) {
      for (class_1304 var5 : ARMOR_SLOTS) {
         if (!var1.method_6118(var5).method_7960()) {
            return false;
         }
      }

      return true;
   }

   public boolean f(class_1309 var1) {
      if (mc.field_1724 != null && var1 != null && var1.method_5805()) {
         float var2 = this.rotationType.isSelected("Legit") ? Math.min(this.range.getFloatValue(), 3.0F) : this.range.getFloatValue();
         if (this.rotationType.isSelected("NoRotate")) {
            return this.throughWalls.isEnabled() || this.c(var1);
         } else if (!this.rotationType.isSelected("Legit") && !clientLook.isEnabled()) {
            return this.hasServerRotation
               ? this.b(this.lastServerYaw, this.lastServerPitch, var1, var2)
               : this.b(mc.field_1724.method_36454(), mc.field_1724.method_36455(), var1, var2);
         } else {
            return !this.throughWalls.isEnabled() && mc.field_1765 instanceof class_3966 var3 && var3.method_17782() == var1
               ? mc.field_1724.method_33571().method_1022(var3.method_17784()) <= var2
               : this.b(mc.field_1724.method_36454(), mc.field_1724.method_36455(), var1, var2);
         }
      } else {
         return false;
      }
   }

   public boolean b(float var1, float var2, class_1309 var3, float var4) {
      if (mc.field_1724 != null && mc.field_1687 != null && var3 != null && var3.method_5805()) {
         class_243 var5 = mc.field_1724.method_33571();
         class_243 var6 = class_243.method_1030(var2, var1);
         class_243 var7 = var5.method_1019(var6.method_1021(var4));
         double var8 = var4 * var4;
         if (!this.throughWalls.isEnabled()) {
            class_3965 var10 = mc.field_1687.method_17742(new class_3959(var5, var7, class_3960.field_17558, class_242.field_1348, mc.field_1724));
            if (var10 != null && var10.method_17783() != class_240.field_1333) {
               var7 = var10.method_17784();
               var8 = var5.method_1025(var7);
            }
         }

         class_238 var13 = var3.method_5829().method_1014(var3.method_5871());
         if (var13.method_1006(var5)) {
            class_243 var14 = var3.method_5829().method_1005().method_1020(var5);
            return var14.method_1027() < 1.0E-6 ? true : var6.method_1026(var14.method_1029()) > 0.3;
         } else {
            Optional var11 = var13.method_992(var5, var7);
            if (var11.isPresent()) {
               class_243 var12 = (class_243)var11.get();
               return var5.method_1025(var12) <= var8;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public boolean s() {
      return this.throughWalls.isEnabled();
   }

   private boolean P() {
      if (this.target != null && mc.field_1724 != null) {
         float var1 = IdealHitUtils.a();
         if (mc.field_1724.method_7261(0.5F) < var1 - 0.001F) {
            return false;
         }

         if (!this.f(this.target)) {
            return false;
         }

         if (!this.throughWalls.isEnabled() && this.rotationType.isSelected("Data") && !this.a(this.G())) {
            return false;
         }

         if (mc.field_1724.method_6128() && this.target.method_6128()) {
            class_243 var7 = this.target.method_73189().method_1031(0.0, this.target.method_17682() / 2.0, 0.0);
            byte var4 = 0;
            class_243 var8 = PredictUtils.a(this.target, var7, var4);
            if (mc.field_1724.method_33571().method_1022(var8) > 5.0) {
               return false;
            }
         } else {
            double var3 = this.target.method_5829().method_49271(mc.field_1724.method_33571());
            double var5 = this.rotationType.isSelected("Legit") && !this.throughWalls.isEnabled()
               ? Math.min(this.range.getFloatValue(), 3.0F)
               : this.range.getFloatValue();
            if (var3 > var5 * var5) {
               return false;
            }
         }

         return !this.onlyCrits.isOn() ? IdealHitUtils.a(this.target, this.smartCrit.isEnabled()) : IdealHitUtils.d() || IdealHitUtils.e();
      } else {
         return false;
      }
   }

   private boolean Q() {
      class_3966 var1 = this.b(this.lastServerYaw, this.lastServerPitch);
      if (var1 != null && var1.method_17782() == this.target) {
         class_243 var2 = mc.field_1724.method_33571();
         class_243 var3 = this.target.method_5829().method_1005().method_1020(var2);
         if (var3.method_1027() < 1.0E-8) {
            return false;
         }

         class_243 var4 = class_243.method_1030(this.lastServerPitch, this.lastServerYaw);
         return Math.toDegrees(Math.acos(class_3532.method_15350(var4.method_1029().method_1026(var3.method_1029()), -1.0, 1.0))) <= 22.0;
      } else {
         return false;
      }
   }

   private boolean j(class_1309 var1) {
      if (var1 != null && var1 == this.target && mc.field_1724 != null) {
         float var2 = Math.max(0.62F, IdealHitUtils.a() - 0.18F);
         if (this.attackDelayTicks > 3 && mc.field_1724.method_7261(1.5F) < var2) {
            return false;
         }

         class_238 var3 = var1.method_5829();
         class_243 var4 = mc.field_1724.method_33571();
         double var5 = class_3532.method_15350(var4.field_1352, var3.field_1323, var3.field_1320);
         double var7 = class_3532.method_15350(var4.field_1351, var3.field_1322, var3.field_1325);
         double var9 = class_3532.method_15350(var4.field_1350, var3.field_1321, var3.field_1324);
         double var11 = var4.field_1352 - var5;
         double var13 = var4.field_1351 - var7;
         double var15 = var4.field_1350 - var9;
         double var17 = this.range.getFloatValue() + 0.4F;
         return var11 * var11 + var13 * var13 + var15 * var15 <= var17 * var17;
      } else {
         return false;
      }
   }

   private void R() {
      if (this.funtimeModeActive) {
         this.funtimeModeActive = false;
         this.funtimeRotation.a();
      }
   }

   private void Y() {
      if (this.skyTimeModeActive) {
         this.skyTimeModeActive = false;
         this.skyTimeRotation.a();
      }
   }

   private boolean S() {
      return this.rotationType.isSelected("HolyWorld") || this.rotationType.isSelected("Holy2");
   }

   private RotationsSystem T() {
      return this.rotationType.isSelected("Holy2") ? this.holy2Rotation : this.holyWorldRotation;
   }

   private void k(class_1309 var1) {
      if (this.rotationType.isSelected("Holy2")) {
         this.holy2Rotation.d(var1);
      } else {
         this.holyWorldRotation.d(var1);
      }
   }

   private void U() {
      if (this.rotationType.isSelected("Holy2")) {
         this.holy2Rotation.c();
      } else {
         this.holyWorldRotation.c();
      }
   }

   private boolean l(class_1309 var1) {
      return true;
   }

   private void V() {
      this.holyWorldRotation.b();
      this.holy2Rotation.b();
   }

   private void W() {
      if (this.holyWorldModeActive) {
         this.holyWorldModeActive = false;
         this.V();
         this.holyWorldServerTarget = null;
         this.hasServerRotation = false;
         this.holyWorldHiddenSinceNanos = 0L;
         this.auraAttackInProgress = false;
      }
   }

   private void X() {
      if (this.slothModeActive) {
         this.slothModeActive = false;
         this.slothRotation.a();
      }

      this.holyWorldServerTarget = null;
      this.hasServerRotation = false;
      this.holyWorldHiddenSinceNanos = 0L;
   }

   public boolean t() {
      return this.l() && this.S();
   }

   public boolean u() {
      return this.t() && this.auraAttackInProgress;
   }

   public int getTicksToAttack() {
      return this.ticksToAttack;
   }

   private boolean a(class_3966 var1) {
      float var2 = Math.abs(class_3532.method_15393(this.targetRotations.field_1343 - mc.field_1724.method_36454()));
      float var3 = Math.abs(this.targetRotations.field_1342 - mc.field_1724.method_36455());
      int var4 = var2 <= 1.15F && var3 <= 0.9F ? 1 : 0;
      int var5 = var1 != null && var1.method_17782() == this.target ? 1 : 0;
      return var4 != 0 && var5 != 0;
   }

   public boolean w() {
      class_2338 var1 = class_2338.method_49638(mc.field_1724.method_73189().method_1031(0.0, -0.4, 0.0));
      return !mc.field_1724.method_5869() && mc.field_1687.method_8320(var1).method_27852(class_2246.field_10382);
   }

   public float x() {
      return mc.field_1724 == null ? 0.0F : mc.field_1724.method_7261(0.0F);
   }

   public float y() {
      return (float)(1.0 / mc.field_1724.method_45325(class_5134.field_23723) * 20.0);
   }

   public float z() {
      return mc.field_1724.method_6128()
         ? 0.0F
         : (this.rotationType.isSelected("Legit") ? Math.max(this.range.getFloatValue() + 1.5F, 4.5F) : this.range.getFloatValue());
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.returning = false;
      this.hadTarget = false;
      this.prevAuraPlayerYaw = Float.NaN;
      this.B();
      if (this.target != null) {
         this.backTimer.a();
      }

      this.target = null;
      this.testRotation.a();
      this.V();
      this.holyWorldModeActive = false;
      this.funtimeRotation.a();
      this.funtimeModeActive = false;
      this.slothRotation.a();
      this.slothModeActive = false;
      this.skyTimeRotation.a();
      this.skyTimeModeActive = false;
      this.hasServerRotation = false;
      this.holyWorldServerTarget = null;
      this.auraAttackInProgress = false;
      this.holyWorldHiddenSinceNanos = 0L;
      this.whiteRiseRotation.a();
      this.legitRotation.a();
      this.reallyWorldRotation.a();
      this.aimAssistRotation.b();
      this.lastDataTarget = null;
      this.ticksToAttack = 0;
      this.attackDelayTicks = 0;
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.returning = false;
      this.hadTarget = false;
      this.prevAuraPlayerYaw = Float.NaN;
      if (mc.field_1724 != null) {
         this.naturalYaw = mc.field_1724.method_36454();
         this.naturalPitch = mc.field_1724.method_36455();
         FreeLookStorage.setFreeYaw(this.naturalYaw);
         FreeLookStorage.setFreePitch(this.naturalPitch);
      }

      if (this.rotationType.isSelected("Legit")) {
         clientLook.setValue(true);
         FreeLookStorage.a(false);
      }

      this.testRotation.a();
      this.V();
      this.holyWorldModeActive = false;
      this.funtimeRotation.a();
      this.funtimeModeActive = false;
      this.slothRotation.a();
      this.slothModeActive = false;
      this.skyTimeRotation.a();
      this.skyTimeModeActive = false;
      this.hasServerRotation = false;
      this.holyWorldServerTarget = null;
      this.auraAttackInProgress = false;
      this.holyWorldHiddenSinceNanos = 0L;
      this.whiteRiseRotation.a();
      this.legitRotation.a();
      this.reallyWorldRotation.a();
      this.aimAssistRotation.b();
      this.lastDataTarget = null;
      this.ticksToAttack = 0;
      this.attackDelayTicks = 0;
      if (mc.field_1724 != null) {
         this.currentRotations = new class_241(mc.field_1724.method_36454(), mc.field_1724.method_36455());
      }
   }

   public LegitRotation getLegitRotation() {
      return this.legitRotation;
   }
}
