package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.player.GuiMove;
import brokke.cc.core.HotbarSlot;
import brokke.cc.core.ItemSlot;
import brokke.cc.core.SlotGroup;
import brokke.cc.core.SlotGroups;
import brokke.cc.core.Timer2;
import brokke.cc.mixins.interfaces.IClientPlayerInteractionManager;
import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationMath;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.MultiSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.EntityUtility;
import brokke.cc.util.InventoryUtility;
import brokke.cc.util.PotionUtility;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1828;
import net.minecraft.class_2246;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2886;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_742;

@NewFunction(name = "Auto Explosion", description = "Автоматически бросает зелья под себя", category = Category.COMBAT)
public class AutoPotion extends Function {
   private final MultiSetting potions = new MultiSetting("Зелья", "Сила", "Скорость", "Огнестойкость", "Исцеление", "Церка");
   private final NumberSetting healHealth = new NumberSetting("Здоровье исцеления", 6.0, 1.0, 19.0, 0.5);
   private final NumberSetting cerkaHealth = new NumberSetting("Здоровье церки", 6.0, 1.0, 19.0, 0.5);
   private final BooleanSetting throwUp = new BooleanSetting("Вверх", true);
   private final BooleanSetting throwWalls = new BooleanSetting("В стены", true);
   private final BooleanSetting donate = new BooleanSetting("Донат зелья", false);
   private final Timer2 staying = new Timer2();
   private final Timer2 ground = new Timer2();
   private final Timer2 wall = new Timer2();
   private final Timer2 roof = new Timer2();
   private final Timer2 strengthTimer = new Timer2();
   private final Timer2 speedTimer = new Timer2();
   private final Timer2 fireTimer = new Timer2();
   private final Timer2 healTimer = new Timer2();
   private final Timer2 cerkaTimer = new Timer2();
   private AutoPotion.a task;

   public AutoPotion() {
      this.potions.setOption("Сила", true);
      this.potions.setOption("Скорость", true);
      this.potions.setOption("Огнестойкость", true);
      this.potions.setOption("Исцеление", true);
      this.potions.setOption("Церка", true);
      this.addSettings(this.potions, this.healHealth, this.cerkaHealth, this.throwUp, this.throwWalls, this.donate);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         Rotation2 var2 = this.l();
         if (this.task != null) {
            boolean var3 = this.task.slot instanceof HotbarSlot;
            if (var3) {
               switch (this.task.stage) {
                  case 0:
                     InventoryUtility.e(this.task.slot.get45() - 36);
                     break;
                  case 1:
                     this.a(var2);
                     break;
                  case 2:
                     InventoryUtility.e(this.task.prevSlot);
               }
            } else {
               switch (this.task.stage) {
                  case 0:
                     InventoryUtility.d(this.task.slot.get45(), this.task.prevSlot);
                     InventoryUtility.e(this.task.prevSlot);
                     break;
                  case 1:
                     this.a(var2);
                     break;
                  case 2:
                     GuiMove.bypassQueue = true;

                     try {
                        InventoryUtility.d(this.task.slot.get45(), this.task.prevSlot);
                     } finally {
                        GuiMove.bypassQueue = false;
                     }
               }
            }

            if (this.task.stage < 2) {
               this.task.stage++;
               return;
            }

            this.task = null;
         }

         if (var2.getYaw() != -1.0F && var2.getPitch() != -1.0F) {
            this.a(class_1294.field_5910, "Сила", this.strengthTimer, () -> true, var2);
            this.a(class_1294.field_5904, "Скорость", this.speedTimer, () -> true, var2);
            this.a(class_1294.field_5918, "Огнестойкость", this.fireTimer, () -> true, var2);
            this.a(class_1294.field_5915, "Исцеление", this.healTimer, () -> mc.field_1724.method_6032() <= this.healHealth.getValue(), var2);
            this.a(class_1294.field_5911, "Церка", this.cerkaTimer, this::k, var2);
         }
      }
   }

   private boolean k() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         SlotGroup<ItemSlot> var1 = SlotGroups.b().a(SlotGroups.a());
         ItemSlot var2 = var1.a(var0 -> PotionUtility.a(var0, class_1294.field_5915) && !mc.field_1724.method_7357().method_7904(var0));
         ItemSlot var3 = var1.a(var0 -> var0.method_7909() == class_1802.field_8367 && !mc.field_1724.method_7357().method_7904(var0));
         boolean var4 = false;

         for (class_742 var6 : mc.field_1687.method_18456()) {
            if (mc.field_1724.method_5739(var6) < 5.0F && var6 != mc.field_1724) {
               var4 = true;
               break;
            }
         }

         return mc.field_1724.method_6032() + mc.field_1724.method_6067() <= this.cerkaHealth.getValue() && var3 == null && var2 == null && var4;
      } else {
         return false;
      }
   }

   private void a(class_6880<class_1291> var1, String var2, Timer2 var3, Supplier<Boolean> var4, Rotation2 var5) {
      if (this.task == null && mc.field_1724 != null && this.potions.isOptionEnabled(var2) && !mc.field_1724.method_6059(var1) && var3.a(2000L) && var4.get()) {
         SlotGroup<ItemSlot> var6 = SlotGroups.b().a(SlotGroups.a());
         ItemSlot var7 = var6.a(this.a(var1));
         if (var7 != null) {
            this.task = new AutoPotion.a(var7, mc.field_1724.method_31548().method_67532());
            var3.a();
         }
      }
   }

   private void a(Rotation2 var1) {
      if (mc.field_1761 != null && mc.field_1687 != null) {
         ((IClientPlayerInteractionManager)mc.field_1761)
            .invokeSendSequencedPacket(mc.field_1687, var1xx -> new class_2886(class_1268.field_5808, var1xx, var1.getYaw(), var1.getPitch()));
      }
   }

   private Rotation2 l() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         boolean var1 = false;
         float var2 = mc.field_1724.method_36454();
         float var3 = 90.0F;
         if (this.potions.isOptionEnabled("Церка") && this.k()) {
            for (class_742 var5 : mc.field_1687.method_18456()) {
               if (mc.field_1724.method_5739(var5) < 5.0F && var5 != mc.field_1724) {
                  class_243 var6 = mc.field_1724.method_5836(1.0F);
                  double var7 = var5.method_23317() - var6.field_1352;
                  double var9 = var5.method_23318() - var6.field_1351;
                  double var11 = var5.method_23321() - var6.field_1350;
                  double var13 = Math.sqrt(var7 * var7 + var11 * var11);
                  return new Rotation2((float)(Math.toDegrees(Math.atan2(var11, var7)) - 90.0), (float)(-Math.toDegrees(Math.atan2(var9, var13))));
               }
            }
         }

         if (this.throwUp.isToggled()) {
            if (mc.field_1724.method_18798().field_1352 == 0.0
               && mc.field_1724.method_18798().field_1350 == 0.0
               && Math.abs(mc.field_1724.method_18798().field_1351) < 0.1F
               && EntityUtility.a(mc.field_1724) == class_2246.field_10124) {
               if (this.staying.a(500L)) {
                  var3 = -90.0F;
                  return new Rotation2(var2, var3);
               }
            } else {
               this.staying.a();
            }
         }

         if (mc.field_1724.method_24828()) {
            if (this.ground.a(300L)) {
               class_3965 var16 = mc.field_1687
                  .method_17742(
                     new class_3959(
                        mc.field_1724.method_33571(),
                        mc.field_1724.method_33571().method_1019(mc.field_1724.method_5631(var3, var2).method_1021(2.0)),
                        class_3960.field_17558,
                        class_242.field_1348,
                        mc.field_1724
                     )
                  );
               if (var16.method_17783() == class_240.field_1332) {
                  var1 = true;
               } else {
                  var3 = 76.0F;

                  for (int var18 = 0; var18 < 360; var18 += 45) {
                     class_3965 var21 = mc.field_1687
                        .method_17742(
                           new class_3959(
                              mc.field_1724.method_33571(),
                              mc.field_1724.method_33571().method_1019(mc.field_1724.method_5631(var3, var18).method_1021(2.0)),
                              class_3960.field_17558,
                              class_242.field_1348,
                              mc.field_1724
                           )
                        );
                     if (var21.method_17783() == class_240.field_1332) {
                        var2 = RotationMath.b(mc.field_1724.method_36454(), var18);
                        var1 = true;
                     }
                  }
               }
            }
         } else {
            this.ground.a();
            if (this.throwWalls.isToggled()) {
               boolean var17 = false;
               var3 = 5.0F;

               for (int var19 = 0; var19 < 360; var19 += 45) {
                  class_3965 var22 = mc.field_1687
                     .method_17742(
                        new class_3959(
                           mc.field_1724.method_33571(),
                           mc.field_1724.method_33571().method_1019(mc.field_1724.method_5631(var3, var19).method_1021(0.5)),
                           class_3960.field_17558,
                           class_242.field_1348,
                           mc.field_1724
                        )
                     );
                  if (var22.method_17783() == class_240.field_1332) {
                     var2 = RotationMath.b(mc.field_1724.method_36454(), var19);
                     var17 = true;
                  }
               }

               if (!var17) {
                  this.wall.a();
               } else if (this.wall.a(300L)) {
                  var1 = true;
               }

               if (!var1) {
                  boolean var20 = false;
                  var3 = -90.0F;
                  class_3965 var23 = mc.field_1687
                     .method_17742(
                        new class_3959(
                           mc.field_1724.method_33571(),
                           mc.field_1724.method_33571().method_1019(mc.field_1724.method_5631(var3, mc.field_1724.method_36454()).method_1021(0.5)),
                           class_3960.field_17558,
                           class_242.field_1348,
                           mc.field_1724
                        )
                     );
                  if (var23.method_17783() == class_240.field_1332) {
                     var2 = mc.field_1724.method_36454();
                     var20 = true;
                  }

                  if (!var20) {
                     this.roof.a();
                  } else if (this.roof.a(300L)) {
                     var1 = true;
                  }
               }
            }
         }

         return var1 ? new Rotation2(var2, var3) : new Rotation2(-1.0F, -1.0F);
      } else {
         return new Rotation2(-1.0F, -1.0F);
      }
   }

   private Predicate<class_1799> a(class_6880<class_1291> var1) {
      return var2 -> {
         if (!var2.method_7960() && var2.method_7909() instanceof class_1828) {
            List<class_1293> var3 = PotionUtility.a(var2);
            return !this.donate.isToggled() && var1 != class_1294.field_5911
               ? var3.size() == 1 && var3.getFirst().method_5579() == var1
               : var3.stream().anyMatch(var1xxx -> var1xxx.method_5579() == var1);
         } else {
            return false;
         }
      };
   }

   static class a {
      int stage;
      final ItemSlot slot;
      final int prevSlot;

      public a(ItemSlot var1, int var2) {
         this.slot = var1;
         this.prevSlot = var2;
      }
   }
}
