package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.EnchantmentUtility;
import brokke.cc.util.ItemUtility;
import brokke.cc.util.TimerUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;

@NewFunction(name = "Auto Armor", description = "Автоматически надевает лучшую броню", category = Category.COMBAT)
public class AutoArmor extends Function {
   private final NumberSetting delay = new NumberSetting("Задержка", 250.0, 50.0, 1000.0, 50.0);
   private final BooleanSetting elytra = new BooleanSetting("Не снимать элитры", false);
   private final TimerUtil timer = new TimerUtil();
   private static final class_1304[] ARMOR_SLOTS = new class_1304[]{class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169};

   public AutoArmor() {
      this.addSettings(this.delay, this.elytra);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         class_1661 var2 = mc.field_1724.method_31548();
         int[] var3 = new int[4];
         int[] var4 = new int[4];
         Arrays.fill(var3, -1);
         Arrays.fill(var4, -1);

         for (int var5 = 0; var5 < 4; var5++) {
            class_1799 var6 = mc.field_1724.method_6118(ARMOR_SLOTS[var5]);
            if (!var6.method_7960()) {
               var4[var5] = this.c(var6);
            }
         }

         for (int var10 = 0; var10 < 36; var10++) {
            class_1799 var12 = var2.method_5438(var10);
            if (!var12.method_7960() && this.a(var12)) {
               int var7 = this.b(var12);
               if (var7 >= 0) {
                  int var8 = this.c(var12);
                  if (var8 > var4[var7]) {
                     var3[var7] = var10;
                     var4[var7] = var8;
                  }
               }
            }
         }

         ArrayList var11 = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
         Collections.shuffle(var11);

         for (int var14 : (Iterable<Integer>)(Iterable<?>)(var11)) {
            int var15 = var3[var14];
            if (var15 != -1) {
               class_1799 var9 = mc.field_1724.method_6118(ARMOR_SLOTS[var14]);
               if ((var9.method_7960() || var2.method_7376() != -1)
                  && (!this.elytra.isToggled() || mc.field_1724.method_6118(class_1304.field_6174).method_7909() != class_1802.field_8833 || var14 != 2)) {
                  this.a(var15, var14);
                  break;
               }
            }
         }
      }
   }

   private boolean a(class_1799 var1) {
      return ItemUtility.i(var1) != null;
   }

   private int b(class_1799 var1) {
      class_1304 var2 = ItemUtility.i(var1);
      if (var2 == class_1304.field_6169) {
         return 3;
      } else if (var2 == class_1304.field_6174) {
         return 2;
      } else if (var2 == class_1304.field_6172) {
         return 1;
      } else {
         return var2 == class_1304.field_6166 ? 0 : -1;
      }
   }

   private int c(class_1799 var1) {
      if (ItemUtility.h(var1)) {
         return Integer.MAX_VALUE;
      }

      int var2 = ItemUtility.j(var1);
      int var3 = ItemUtility.k(var1);
      int var4 = EnchantmentUtility.a(var1, class_1893.field_9111);
      return var2 * 5 + var4 * 3 + var3;
   }

   private void a(int var1, int var2) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         if (var1 < 9) {
            var1 += 36;
         }

         if (this.timer.a((long)this.delay.getValue())) {
            class_1799 var3 = mc.field_1724.method_6118(ARMOR_SLOTS[var2]);
            if (!var3.method_7960()) {
               mc.field_1761.method_2906(0, 8 - var2, 0, class_1713.field_7794, mc.field_1724);
            }

            mc.field_1761.method_2906(0, var1, 0, class_1713.field_7794, mc.field_1724);
            this.timer.a();
         }
      }
   }
}
