package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import net.minecraft.class_1657;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_8646;
import net.minecraft.class_9013;
import net.minecraft.class_9015;

@NewFunction(name = "FixHP", description = "Чинит отображение HP в неймтегах и таргет худе по scoreboard'у, у невидимых показывает ?", category = Category.COMBAT)
public class FixHp extends Function {
   private static FixHp instance;
   private final BooleanSetting scoreHp = new BooleanSetting("HP из scoreboard", true);
   private final BooleanSetting questionMark = new BooleanSetting("Вопрос у невидимых", true);

   public FixHp() {
      this.addSettings(this.scoreHp, this.questionMark);
   }

   public static FixHp getInstance() {
      if (instance == null) {
         instance = FunctionManager.a(FixHp.class);
      }

      return instance;
   }

   public static float scoreHealth(class_1657 var0) {
      FixHp var1 = getInstance();
      if (var1 == null || !var1.isEnabled() || !var1.scoreHp.isToggled() || var0 == null || mc.field_1687 == null) {
         return -1.0F;
      } else {
         class_269 var2 = mc.field_1687.method_8428();
         class_266 var3 = var2.method_1189(class_8646.field_45158);
         if (var3 == null) {
            return -1.0F;
         } else {
            class_9013 var4 = var2.method_55430(class_9015.method_55422(var0.method_5820()), var3);
            return var4 == null ? -1.0F : (float)var4.method_55397();
         }
      }
   }

   public static boolean isUnknown(class_1657 var0) {
      FixHp var1 = getInstance();
      return var1 != null && var1.isEnabled() && var1.questionMark.isToggled() && var0 != null && var0.method_5767();
   }
}
