package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;

@NewFunction(name = "TargetPearl", description = "Автоматически кидает пёрл за выбранной целью", category = Category.COMBAT)
public class TargetPearl extends Function {
   private final Set<UUID> seenPearls = new HashSet<>();
   private final NumberSetting radius = new NumberSetting("Радиус", 30.0, 5.0, 100.0, 1.0);
   private final NumberSetting delay = new NumberSetting("Тики", 10.0, 1.0, 40.0, 1.0);
   private final BooleanSetting pauseAimAssist = new BooleanSetting("Пауза AimAssist", true);
   private int lastThrowTick = 0;
   private boolean aimAssistWasEnabled = false;
   private boolean aimBotWasEnabled = false;
   private int throwStage = 0;
   private int pearlSlot = -1;
   private int oldSlot = -1;
   private float targetYaw = 0.0F;
   private float targetPitch = 0.0F;

   public TargetPearl() {
      this.addSettings(this.radius, this.delay, this.pauseAimAssist);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.seenPearls.clear();
      this.lastThrowTick = 0;
      this.n();
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.seenPearls.clear();
      this.lastThrowTick = 0;
      this.n();
      this.m();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.lastThrowTick++;
         if (this.throwStage > 0) {
            this.k();
         } else {
            for (class_1297 var3 : mc.field_1687.method_18112()) {
               if (var3 instanceof class_1684 var4) {
                  UUID var5 = var4.method_5667();
                  int var8;
                  if (!this.seenPearls.contains(var5)
                     && var4.field_6012 <= 2
                     && var4.method_24921() instanceof class_1657 var7
                     && var7 != mc.field_1724
                     && !(mc.field_1724.method_5739(var7) > this.radius.getValue())
                     && this.lastThrowTick >= (int)this.delay.getValue()
                     && (var8 = this.l()) != -1) {
                     class_243 var9 = this.a(var4);
                     float[] var10 = this.a(var9);
                     this.pearlSlot = var8;
                     this.oldSlot = mc.field_1724.method_31548().method_67532();
                     this.targetYaw = var10[0];
                     this.targetPitch = var10[1];
                     if (this.pauseAimAssist.isToggled()) {
                        this.b(true);
                     }

                     this.throwStage = 1;
                     this.lastThrowTick = 0;
                     this.seenPearls.add(var5);
                     break;
                  }
               }
            }
         }
      }
   }

   private void k() {
      switch (this.throwStage) {
         case 1:
            mc.field_1724.method_31548().method_61496(this.pearlSlot);
            if (mc.field_1724.field_3944 != null) {
               mc.field_1724.field_3944.method_52787(new class_2868(this.pearlSlot));
            }

            mc.field_1724.method_36456(this.targetYaw);
            mc.field_1724.method_36457(this.targetPitch);
            this.throwStage = 2;
            break;
         case 2:
            class_1799 var1 = mc.field_1724.method_6047();
            if (var1.method_31574(class_1802.field_8634) && mc.field_1761 != null) {
               mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            }

            this.throwStage = 3;
            break;
         case 3:
            mc.field_1724.method_31548().method_61496(this.oldSlot);
            if (mc.field_1724.field_3944 != null) {
               mc.field_1724.field_3944.method_52787(new class_2868(this.oldSlot));
            }

            if (this.pauseAimAssist.isToggled()) {
               this.b(false);
            }

            this.n();
            break;
         default:
            this.n();
      }
   }

   private class_243 a(class_1684 var1) {
      class_243 var2 = new class_243(var1.method_23317(), var1.method_23318(), var1.method_23321());
      class_243 var3 = var1.method_18798();

      for (int var4 = 0; var4 < 200; var4++) {
         class_243 var5 = var2.method_1019(var3);
         class_3965 var6 = mc.field_1687.method_17742(new class_3959(var2, var5, class_3960.field_17558, class_242.field_1348, var1));
         if (var6.method_17783() != class_240.field_1333) {
            return var6.method_17784();
         }

         var2 = var5;
         var3 = new class_243(var3.field_1352 * 0.99, var3.field_1351 * 0.99 - 0.03, var3.field_1350 * 0.99);
      }

      return var2;
   }

   private float[] a(class_243 var1) {
      class_243 var2 = mc.field_1724.method_33571();
      double var3 = var1.field_1352 - var2.field_1352;
      double var5 = var1.field_1350 - var2.field_1350;
      double var7 = var1.field_1351 - var2.field_1351;
      double var9 = Math.sqrt(var3 * var3 + var5 * var5);
      float var11 = (float)(Math.toDegrees(Math.atan2(var5, var3)) - 90.0);
      float var12;
      float var13 = var12 = (float)(-Math.toDegrees(Math.atan2(var7, var9)));
      double var14 = Double.MAX_VALUE;

      for (float var16 = var12; var16 >= -85.0F && var16 >= var12 - 50.0F; var16 -= 0.5F) {
         class_243 var17 = this.a(var2, var11, var16);
         double var18;
         if ((var18 = var17.method_1022(var1)) < var14) {
            var14 = var18;
            var13 = var16;
         }
      }

      return new float[]{var11, var13};
   }

   private class_243 a(class_243 var1, float var2, float var3) {
      double var4 = 1.5;
      double var6 = -Math.sin(Math.toRadians(var2)) * Math.cos(Math.toRadians(var3)) * var4;
      double var8 = -Math.sin(Math.toRadians(var3)) * var4;
      double var10 = Math.cos(Math.toRadians(var2)) * Math.cos(Math.toRadians(var3)) * var4;
      class_243 var12 = new class_243(var6, var8, var10);
      class_243 var13 = var1;

      for (int var14 = 0; var14 < 200; var14++) {
         class_243 var15 = var13.method_1019(var12);
         class_3965 var16 = mc.field_1687.method_17742(new class_3959(var13, var15, class_3960.field_17558, class_242.field_1348, mc.field_1724));
         if (var16.method_17783() != class_240.field_1333) {
            return var16.method_17784();
         }

         var13 = var15;
         var12 = new class_243(var12.field_1352 * 0.99, var12.field_1351 * 0.99 - 0.03, var12.field_1350 * 0.99);
      }

      return var13;
   }

   private int l() {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         class_1799 var2 = mc.field_1724.method_31548().method_5438(var1);
         if (var2.method_31574(class_1802.field_8634)) {
            return var1;
         }
      }

      return -1;
   }

   private void b(boolean var1) {
      AimBot var2 = FunctionManager.a(AimBot.class);
      AimAssist var3 = FunctionManager.a(AimAssist.class);
      if (var1) {
         if (var2 != null && var2.isActive()) {
            this.aimBotWasEnabled = true;
            var2.setEnabled(false);
         }

         if (var3 != null && var3.isActive()) {
            this.aimAssistWasEnabled = true;
            var3.setEnabled(false);
         }
      } else {
         if (this.aimBotWasEnabled && var2 != null && !var2.isActive()) {
            var2.setEnabled(true);
            this.aimBotWasEnabled = false;
         }

         if (this.aimAssistWasEnabled && var3 != null && !var3.isActive()) {
            var3.setEnabled(true);
            this.aimAssistWasEnabled = false;
         }
      }
   }

   private void m() {
      AimBot var1 = FunctionManager.a(AimBot.class);
      if (this.aimBotWasEnabled && var1 != null && !var1.isActive()) {
         var1.setEnabled(true);
         this.aimBotWasEnabled = false;
      }
   }

   private void n() {
      this.throwStage = 0;
      this.pearlSlot = -1;
      this.oldSlot = -1;
   }
}
