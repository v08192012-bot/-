package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.config.ConfigManager;
import brokke.cc.config.HudConfig;
import brokke.cc.core.Timer2;
import brokke.cc.manager.TaskScheduler;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.HudRenderEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.ui.ClickGui;
import brokke.cc.util.ItemUtility;
import java.util.Comparator;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1685;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_4969;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

@NewFunction(name = "Auto Totem", description = "Автоматически берет тотем в левую руку", category = Category.COMBAT)
public class AutoTotem extends Function {
   private final NumberSetting health = new NumberSetting("Здоровье", 6.0, 1.0, 20.0, 0.5);
   private final NumberSetting healthElytra = new NumberSetting("Здоровье на элитре", 6.0, 1.0, 20.0, 0.5);
   private final BooleanSetting stopUsing = new BooleanSetting("Останавливать использование", true);
   private final BooleanSetting crystal = new BooleanSetting("Кристаллы", true);
   private final NumberSetting crystalRange = new NumberSetting("Дистанция кристаллов", 19.0, 1.0, 80.0, 1.0).visibleWhen(() -> this.crystal.isToggled());
   private final BooleanSetting anchor = new BooleanSetting("Якори", true);
   private final NumberSetting anchorRange = new NumberSetting("Дистанция якорей", 6.0, 1.0, 20.0, 0.5).visibleWhen(() -> this.anchor.isToggled());
   private final BooleanSetting tnt = new BooleanSetting("Динамит", true);
   private final NumberSetting tntRange = new NumberSetting("Дистанция ТНТ", 19.0, 1.0, 80.0, 1.0).visibleWhen(() -> this.tnt.isToggled());
   private final BooleanSetting trident = new BooleanSetting("Трезубец", true);
   private final BooleanSetting fall = new BooleanSetting("Падение", true);
   private final BooleanSetting hud = new BooleanSetting("Счетчик тотемов", true);
   private static float posX = -1.0F;
   private static float posY = -1.0F;
   private static float targetX = -1.0F;
   private static float targetY = -1.0F;
   private boolean dragging;
   private boolean wasPressed;
   private float dragDX;
   private float dragDY;
   private int savedSlot = -1;
   private final Timer2 swapTimer = new Timer2();
   private final Timer2 returnTimer = new Timer2();
   private int totemCount = 0;

   public static float[] k() {
      return new float[]{posX, posY};
   }

   public static void a(float var0, float var1) {
      posX = var0;
      posY = var1;
      targetX = var0;
      targetY = var1;
   }

   public AutoTotem() {
      this.addSettings(
         this.health,
         this.healthElytra,
         this.stopUsing,
         this.crystal,
         this.crystalRange,
         this.anchor,
         this.anchorRange,
         this.tnt,
         this.tntRange,
         this.trident,
         this.fall,
         this.hud
      );
   }

   @Override
   public void onDisable() {
      super.onDisable();
      if (this.savedSlot != -1 && mc.field_1724 != null && mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
         int var1 = this.savedSlot;
         this.savedSlot = -1;
         TaskScheduler.a(AutoTotem.class, () -> TaskScheduler.a(var1), 100);
      }

      this.savedSlot = -1;
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && !(mc.field_1724.method_6063() <= 2.0F)) {
         this.r();
         boolean var2 = this.n();
         boolean var3 = this.q();
         class_1799 var4 = mc.field_1724.method_6079();
         boolean var5 = var4.method_31574(class_1802.field_8288);
         if (var2 && (!var3 || var5)) {
            this.returnTimer.a();
            class_1735 var10 = this.o();
            int var7 = var5 ? ItemUtility.f(var4) : -1;
            int var8 = var10 != null ? ItemUtility.f(var10.method_7677()) : -1;
            if ((!var5 || var10 != null && var7 > var8)
               && this.totemCount > 0
               && this.p()
               && TaskScheduler.a(AutoTotem.class)
               && this.swapTimer.a(200L)
               && var10 != null) {
               if (this.savedSlot == -1) {
                  this.savedSlot = var10.field_7874;
               }

               TaskScheduler.a(AutoTotem.class, () -> TaskScheduler.a(var10.field_7874), 100);
               this.swapTimer.a();
            }
         } else if (this.savedSlot != -1 && this.returnTimer.a(350L) && TaskScheduler.a(AutoTotem.class) && this.p()) {
            if (var5) {
               int var6 = this.savedSlot;
               this.savedSlot = -1;
               TaskScheduler.a(AutoTotem.class, () -> TaskScheduler.a(var6), 100);
               this.swapTimer.a();
            } else {
               this.savedSlot = -1;
            }
         }
      }
   }

   private class_1735 o() {
      return mc.field_1724 != null && mc.field_1724.field_7498 != null
         ? mc.field_1724
            .field_7498
            .field_7761
            .stream()
            .filter(var0 -> var0.field_7874 != 45 && var0.method_7677().method_31574(class_1802.field_8288))
            .min(
               Comparator.<class_1735, Integer>comparing(var0 -> ItemUtility.f(var0.method_7677()))
                  .thenComparing(var0 -> var0.method_7677().method_7942())
                  .thenComparingInt(var0 -> var0.field_7874)
            )
            .orElse(null)
         : null;
   }

   public boolean l() {
      return this.isActive() && mc.field_1724 != null ? this.n() || this.savedSlot != -1 : false;
   }

   public boolean m() {
      return this.n();
   }

   public boolean n() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float var1 = mc.field_1724.method_6032() + mc.field_1724.method_6067();
         float var2 = mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833
            ? (float)this.healthElytra.getValue()
            : (float)this.health.getValue();
         if (var1 <= var2) {
            return true;
         }

         if (this.crystal.isToggled()) {
            double var3 = this.crystalRange.getValue();
            if (!mc.field_1687.method_8390(class_1511.class, mc.field_1724.method_5829().method_1014(var3), var0 -> true).isEmpty()) {
               return true;
            }
         }

         if (this.anchor.isToggled()) {
            double var12 = this.anchorRange.getValue();
            class_2338 var5 = mc.field_1724.method_24515();

            int var6;
            for (int var7 = -(var6 = (int)Math.ceil(var12)); var7 <= var6; var7++) {
               for (int var8 = -var6; var8 <= var6; var8++) {
                  for (int var9 = -var6; var9 <= var6; var9++) {
                     class_2338 var10 = var5.method_10069(var7, var8, var9);
                     if (mc.field_1724.method_5707(class_243.method_24953(var10)) <= var12 * var12) {
                        class_2680 var11 = mc.field_1687.method_8320(var10);
                        if (var11.method_27852(class_2246.field_23152)
                           && (var11.method_26213() > 0 || var11.method_28498(class_4969.field_23153) && var11.method_11654(class_4969.field_23153) > 0)) {
                           return true;
                        }
                     }
                  }
               }
            }
         }

         if (this.tnt.isToggled()) {
            double var13 = this.tntRange.getValue();
            if (!mc.field_1687.method_8390(class_1541.class, mc.field_1724.method_5829().method_1014(var13), var0 -> true).isEmpty()) {
               return true;
            }
         }

         return this.fall.isToggled()
               && !mc.field_1724.method_24828()
               && !mc.field_1724.method_6128()
               && !mc.field_1724.method_5799()
               && !mc.field_1724.method_6101()
               && !mc.field_1724.method_5771()
               && a(mc.field_1724, 30) >= var1
            ? true
            : this.trident.isToggled()
               && mc.field_1687
                  .method_8390(class_1685.class, mc.field_1724.method_5829().method_1014(5.0), var0 -> var0.method_5805() && var0.method_24921() != mc.field_1724)
                  .stream()
                  .anyMatch(var0 -> var0.method_18798().method_1027() > 0.1);
      } else {
         return false;
      }
   }

   private boolean p() {
      return this.stopUsing.isToggled() || !mc.field_1724.method_6115();
   }

   private boolean q() {
      return mc.field_1724 != null && mc.field_1724.method_7357() != null
         ? mc.field_1724.method_7357().method_7904(class_1802.field_8288.method_7854())
         : false;
   }

   private static float a(class_1657 var0, int var1) {
      if (var0 != null && var0.method_73183() != null) {
         class_243 var2 = var0.method_18798();
         class_238 var3 = var0.method_5829();
         double var4 = 0.0;

         for (int var6 = 0; var6 < var1; var6++) {
            var2 = var2.method_1031(0.0, -0.08, 0.0).method_18805(0.98, 0.98, 0.98);
            var3 = var3.method_997(var2);
            if (!var0.method_73183().method_18026(var3.method_989(0.0, -0.001, 0.0))) {
               break;
            }

            if (var2.field_1351 < 0.0) {
               var4 -= var2.field_1351;
            }
         }

         if (var4 <= 3.0) {
            return 0.0F;
         }

         float var7 = class_3532.method_15375((float)(var4 - 3.0));
         class_1799 var8 = var0.method_6118(class_1304.field_6166);
         int var9 = 0;
         class_9304 var10 = var8.method_58694(class_9334.field_49633);
         if (var10 != null) {
            for (class_6880 var12 : var10.method_57534()) {
               if (var12.method_40225(class_1893.field_9129)) {
                  var9 = var10.method_57536(var12);
                  break;
               }
            }
         }

         if (var9 > 0) {
            var7 = Math.max(var7 - var7 * 0.15F * var9, 0.0F);
         }

         return var0.method_6059(class_1294.field_5906) ? 0.0F : var7;
      } else {
         return 0.0F;
      }
   }

   private void r() {
      if (mc.field_1724 != null && mc.field_1724.field_7498 != null) {
         this.totemCount = (int)mc.field_1724.field_7498.field_7761.stream().filter(var0 -> var0.method_7677().method_31574(class_1802.field_8288)).count();
      } else {
         this.totemCount = 0;
      }
   }

   private void a(float var1, float var2, float var3, float var4) {
      if (mc.field_1755 != null && mc.field_1755 instanceof class_408) {
         double var5 = mc.method_22683().method_4495();
         float var7 = (float)(mc.field_1729.method_1603() / var5);
         float var8 = (float)(mc.field_1729.method_1604() / var5);
         int var9;
         if ((var9 = GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 0) == 1 ? 1 : 0) != 0
            && !this.wasPressed
            && var7 >= var1
            && var7 <= var1 + var3
            && var8 >= var2
            && var8 <= var2 + var4) {
            this.dragging = true;
            this.dragDX = var7 - targetX;
            this.dragDY = var8 - targetY;
         }

         if (var9 == 0) {
            if (this.dragging) {
               HudConfig.b();
               ConfigManager.onSettingChanged();
            }

            this.dragging = false;
         }

         this.wasPressed = var9 != 0;
         if (this.dragging) {
            float[] var10 = HudConfig.b("autototem", var7 - this.dragDX, var8 - this.dragDY, var3, var4);
            targetX = var10[0];
            targetY = var10[1];
         }

         if (this.dragging || targetX >= 0.0F && (Math.abs(targetX - posX) > 0.05F || Math.abs(targetY - posY) > 0.05F)) {
            float[] var11 = HudConfig.a("autototem", posX, posY, targetX, targetY);
            posX = var11[0];
            posY = var11[1];
         }
      } else {
         this.dragging = false;
         this.wasPressed = false;
      }
   }

   @EventHandler
   public void onHudRender(HudRenderEvent var1) {
      if (this.hud.isToggled() && mc.field_1724 != null) {
         boolean var2 = mc.field_1755 instanceof class_408;
         if (this.totemCount > 0 || var2) {
            int var3 = mc.field_1690.method_42552().method_41753() == class_1306.field_6182 ? 1 : 0;
            int var4 = mc.method_22683().method_4486();
            int var5 = mc.method_22683().method_4502();
            float var6 = var3 != 0 ? var4 / 2.0F - 103.0F : var4 / 2.0F + 103.0F;
            float var7 = var5 - 21.0F;
            if (posX < 0.0F || posY < 0.0F) {
               posX = var6;
               posY = var7;
               targetX = var6;
               targetY = var7;
            }

            this.a(posX - 8.0F, posY, 22.0F, 22.0F);
            int var8 = (int)posX;
            int var9 = (int)posY;
            float var10 = 2.0F / mc.method_22683().method_4495();
            if (!ClickGui.a((var8 - 8.0F) * var10, (var9 + 3.0F) * var10, 16.0F * var10, 16.0F * var10)) {
               var1.getContext().method_51427(new class_1799(class_1802.field_8288), var8 - 8, var9 + 3);
               String var11 = String.valueOf(this.totemCount);
               int var12 = mc.field_1772.method_1727(var11);
               var1.getContext().method_25303(mc.field_1772, var11, var8 - var12 / 2 + 8, var9 + 15, -1);
            }
         }
      }
   }
}
