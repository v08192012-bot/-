package brokke.cc.module.combat;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.HandlerProcessor;
import brokke.cc.core.SlotSearchResult;
import brokke.cc.core.Timer2;
import brokke.cc.manager.FriendManager;
import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationStorage;
import brokke.cc.setting.BindSetting;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.AttackEntityEvent;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.DeltaInventoryUtil;
import brokke.cc.util.GCDUtil;
import brokke.cc.util.HotbarUtil;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2664;
import net.minecraft.class_2680;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_355;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_408;
import net.minecraft.class_490;
import net.minecraft.class_4969;
import net.minecraft.class_5321;
import net.minecraft.class_640;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

@NewFunction(
   name = "AutoCrystal",
   category = Category.COMBAT,
   description = "Выбирает подходящий тип взрыва по позиции противника: использует кристаллы при открытой позиции над основанием, а в остальных случаях — якоря с защитой от собственного урона."
)
public class AutoCrystal extends Function {
   public static AutoCrystal INSTANCE;
   private final BooleanSetting pingFix = new BooleanSetting("Ping Fix from TAB", true);
   private final BooleanSetting autoTarget = new BooleanSetting("Авто таргет", true);
   private final NumberSetting targetRange = new NumberSetting("Дистанция поиска цели", 6.0, 3.0, 10.0, 0.5);
   private final BooleanSetting bindOnly = new BooleanSetting("Только по зажатию бинда", false);
   private final BindSetting cycleBind = new BindSetting("Кнопка активации", 86);
   private final BooleanSetting onlySword = new BooleanSetting("Только с оружием", false);
   private final BooleanSetting preferCrystals = new BooleanSetting("Кристаллы при открытой позиции", true);
   private final BooleanSetting placeObsidian = new BooleanSetting("Ставить обсидиан", true).visibleWhen(this.preferCrystals::isToggled);
   private final BooleanSetting autoAnchor = new BooleanSetting("Авто якоря", true);
   private final BooleanSetting safeAnchor = new BooleanSetting("SafeAnchor (Защита)", true).visibleWhen(this.autoAnchor::isToggled);
   private final NumberSetting range = new NumberSetting("Дистанция взаимодействия", 4.5, 2.0, 6.0, 0.1);
   private final NumberSetting actionDelay = new NumberSetting("Задержка (тиков)", 0.0, 0.0, 5.0, 1.0);
   private final BooleanSetting clientLook = new BooleanSetting("Наводка от первого лица", false);
   private final BooleanSetting autoSwap = new BooleanSetting("AutoSwap", true);
   private final BooleanSetting autoSwapSword = new BooleanSetting("Sword", true).visibleWhen(this.autoSwap::isToggled);
   private final BooleanSetting autoSwapAxe = new BooleanSetting("Axe", false).visibleWhen(this.autoSwap::isToggled);
   private final BooleanSetting autoSwapMace = new BooleanSetting("Mace", true).visibleWhen(this.autoSwap::isToggled);
   private final BooleanSetting autoTotem = new BooleanSetting("AutoTotem", true);
   private final NumberSetting totemHotbarSlot = new NumberSetting("Totem Hotbar Slot (1-9)", 1.0, 1.0, 9.0, 1.0).visibleWhen(this.autoTotem::isToggled);
   private final NumberSetting totemBatchDelay = new NumberSetting("Refill Delay (ticks)", 1.0, 0.0, 10.0, 1.0).visibleWhen(this.autoTotem::isToggled);
   private static final Pattern TAB_PING_REGEX = Pattern.compile("(?i)\\b(\\d{1,5})\\s*ms\\b");
   private static final float MACE_CRIT_CHARGE = 0.91F;
   private int delayTicks = 0;
   private final Map<Integer, Long> deadCrystals = new ConcurrentHashMap<>();
   private final Map<class_2338, Long> placedAnchors = new ConcurrentHashMap<>();
   private final Map<class_2338, Long> chargedAnchors = new ConcurrentHashMap<>();
   private final Map<class_2338, Long> safeShieldAttempted = new ConcurrentHashMap<>();
   private boolean placingInternal = false;
   private boolean conflictingActionSentThisTick = false;
   private class_2338 lastPlacedObsidian = null;
   private long lastPlacedObsidianTick = 0L;
   private final Timer2 totemBatchTimer = new Timer2();
   private long tickCounter = 0L;
   private boolean totemRefillPending = false;
   private Integer maceRestoreSlot = null;
   private Integer maceActionSlot = null;
   private long maceRestoreAtTick = 0L;

   public boolean isPlacingInternal() {
      return this.placingInternal;
   }

   public AutoCrystal() {
      INSTANCE = this;
      this.addSettings(
         this.pingFix,
         this.autoTarget,
         this.targetRange,
         this.bindOnly,
         this.cycleBind,
         this.onlySword,
         this.preferCrystals,
         this.placeObsidian,
         this.autoAnchor,
         this.safeAnchor,
         this.range,
         this.actionDelay,
         this.clientLook,
         this.autoSwap,
         this.autoSwapSword,
         this.autoSwapAxe,
         this.autoSwapMace,
         this.autoTotem,
         this.totemHotbarSlot,
         this.totemBatchDelay
      );
   }

   @Override
   public void onEnable() {
      this.n();
      this.m();
      this.totemBatchTimer.a();
      this.p();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.b(true);
      this.m();
      this.p();
      if (RotationStorage.instance != null && RotationStorage.instance.k()) {
         RotationStorage.instance.j();
      }

      super.onDisable();
   }

   private void m() {
      this.delayTicks = 0;
      this.placingInternal = false;
      this.conflictingActionSentThisTick = false;
      this.deadCrystals.clear();
   }

   private void n() {
      this.maceRestoreSlot = null;
      this.maceActionSlot = null;
      this.maceRestoreAtTick = 0L;
   }

   private void a(int var1, int var2) {
      this.maceRestoreSlot = var1;
      this.maceActionSlot = var2;
      this.maceRestoreAtTick = this.tickCounter + 1L;
   }

   private void b(boolean var1) {
      if (this.maceRestoreSlot == null || mc.field_1724 == null) {
         this.n();
      } else if (var1 || this.tickCounter >= this.maceRestoreAtTick) {
         int var2 = this.maceRestoreSlot;
         Integer var3 = this.maceActionSlot;
         this.n();
         if ((var3 == null || mc.field_1724.method_31548().method_67532() == var3)
            && var2 >= 0
            && var2 <= 8
            && var2 != mc.field_1724.method_31548().method_67532()) {
            HandlerProcessor.a().getUseableHandler().a(var2);
         }
      }
   }

   private void o() {
      this.b(false);
   }

   private void p() {
      this.totemRefillPending = false;
   }

   private void q() {
      if (this.pingFix.isToggled() && mc.field_1724 != null && mc.method_1562() != null) {
         try {
            class_355 var1 = mc.field_1705.method_1750();
            class_2561 var2 = null;

            for (Field var6 : class_355.class.getDeclaredFields()) {
               if (class_2561.class.isAssignableFrom(var6.getType())) {
                  var6.setAccessible(true);
                  class_2561 var7 = (class_2561)var6.get(var1);
                  if (var7 != null && TAB_PING_REGEX.matcher(var7.getString()).find()) {
                     var2 = var7;
                     break;
                  }
               }
            }

            if (var2 == null) {
               return;
            }

            Matcher var11 = TAB_PING_REGEX.matcher(var2.getString());
            if (!var11.find()) {
               return;
            }

            int var12 = Integer.parseInt(var11.group(1));
            int var13 = class_3532.method_15340(var12, 0, 60000);
            class_640 var14 = mc.method_1562().method_2871(mc.field_1724.method_5667());
            if (var14 != null) {
               for (Field var9 : class_640.class.getDeclaredFields()) {
                  if (var9.getType() == int.class) {
                     var9.setAccessible(true);
                     var9.setInt(var14, var13);
                     break;
                  }
               }
            }
         } catch (Exception var11) {
         }
      }
   }

   @EventHandler
   public void onAttackEntity(AttackEntityEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1297 var2 = var1.getTarget();
         if (this.autoSwap.isToggled()) {
            Integer var3 = this.a(var2);
            if (var3 != null && var3 >= 0 && var3 <= 8) {
               boolean var4 = mc.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_49814);
               int var5 = mc.field_1724.method_31548().method_67532();
               if ((!this.conflictingActionSentThisTick || var3 == var5) && (!var4 || !(mc.field_1724.method_7261(0.5F) < 0.91F)) && var3 != var5) {
                  HandlerProcessor.a().getUseableHandler().a(var3);
                  this.conflictingActionSentThisTick = true;
                  if (var4) {
                     this.a(var5, var3);
                  }
               }
            }
         }
      }
   }

   private Integer a(class_1297 var1) {
      int var2 = mc.field_1724.method_31548().method_67532();
      boolean var3 = this.maceRestoreSlot != null
         && this.maceActionSlot != null
         && this.maceActionSlot == var2
         && mc.field_1724.method_6047().method_31574(class_1802.field_49814);
      if (this.autoSwapMace.isToggled() && this.b(var1) && var3) {
         return var2;
      }

      if (this.autoSwapMace.isToggled() && this.b(var1) && this.r()) {
         Integer var4 = this.c(var1);
         if (var4 != null) {
            return var4;
         }
      }

      if (this.autoSwapAxe.isToggled() && var1 instanceof class_1657 var6 && this.a(var6)) {
         SlotSearchResult var5 = HotbarUtil.d();
         if (var5.isFound()) {
            return var5.getSlot();
         }
      }

      if (this.autoSwapSword.isToggled()) {
         SlotSearchResult var7 = HotbarUtil.i();
         if (var7.isFound()) {
            return var7.getSlot();
         }
      }

      return null;
   }

   private boolean r() {
      class_1799 var1 = mc.field_1724.method_6047();
      return var1.method_31573(class_3489.field_42611);
   }

   private boolean a(class_1657 var1) {
      if (var1.method_6039()) {
         return true;
      } else if (var1.method_6030().method_31574(class_1802.field_8255)) {
         return true;
      } else {
         return !var1.method_6115() ? false : var1.method_6047().method_31574(class_1802.field_8255) || var1.method_6079().method_31574(class_1802.field_8255);
      }
   }

   private boolean b(class_1297 var1) {
      return var1 instanceof class_1309
         && mc.field_1724.field_6017 > 0.0
         && mc.field_1724.method_18798().field_1351 < 0.0
         && !mc.field_1724.method_24828()
         && !mc.field_1724.method_6101()
         && !mc.field_1724.method_5799()
         && !mc.field_1724.method_5771()
         && !mc.field_1724.method_6128()
         && !mc.field_1724.method_5765()
         && !mc.field_1724.method_31549().field_7479
         && !mc.field_1724.method_6123()
         && !mc.field_1724.method_6059(class_1294.field_5919);
   }

   private Integer c(class_1297 var1) {
      double var2 = mc.field_1724.field_6017;
      boolean var4 = var2 > 1.5 && !mc.field_1724.method_6128();
      int var5 = -1;
      double var6 = -Double.MAX_VALUE;

      for (int var8 = 0; var8 < 9; var8++) {
         class_1799 var9 = mc.field_1724.method_31548().method_5438(var8);
         if (var9.method_31574(class_1802.field_49814)) {
            double var10 = this.a(var9, var1, var2, var4);
            if (var10 > var6) {
               var6 = var10;
               var5 = var8;
            }
         }
      }

      return var5 == -1 ? null : var5;
   }

   private double a(class_1799 var1, class_1297 var2, double var3, boolean var5) {
      int var6 = this.a(var1, class_1893.field_50157);
      int var7 = this.a(var1, class_1893.field_50158);
      int var8 = this.a(var1, class_1893.field_9123);
      int var9 = this.a(var1, class_1893.field_9112);
      int var10 = this.a(var1, class_1893.field_50159);
      double var11 = 6.0;
      if (var5) {
         if (var3 <= 3.0) {
            var11 += 4.0 * var3;
         } else if (var3 <= 8.0) {
            var11 += 12.0 + 2.0 * (var3 - 3.0);
         } else {
            var11 += 22.0 + var3 - 8.0;
         }

         var11 += 0.5 * var6 * var3;
         var11 += 5.0 * var10;
      }

      double var15 = var11 + 2.0 * var7;
      if (var2 instanceof class_1309) {
         if (var8 > 0 && this.d(var2)) {
            var15 += 2.5 * var8;
         }

         if (var9 > 0 && this.e(var2)) {
            var15 += 2.5 * var9;
         }
      }

      return var15;
   }

   private int a(class_1799 var1, class_5321<class_1887> var2) {
      class_9304 var3 = var1.method_58695(class_9334.field_49633, class_9304.field_49385);

      for (class_6880 var5 : var3.method_57534()) {
         if (var5.method_40225(var2)) {
            return var3.method_57536(var5);
         }
      }

      return 0;
   }

   private boolean d(class_1297 var1) {
      class_1299 var2 = var1.method_5864();
      return var2 == class_1299.field_49148
         || var2 == class_1299.field_6123
         || var2 == class_1299.field_6071
         || var2 == class_1299.field_6078
         || var2 == class_1299.field_6137
         || var2 == class_1299.field_6075
         || var2 == class_1299.field_6098
         || var2 == class_1299.field_6119
         || var2 == class_1299.field_6076
         || var2 == class_1299.field_23696
         || var2 == class_1299.field_6051
         || var2 == class_1299.field_6048
         || var2 == class_1299.field_6054
         || var2 == class_1299.field_6050;
   }

   private boolean e(class_1297 var1) {
      class_1299 var2 = var1.method_5864();
      return var2 == class_1299.field_20346
         || var2 == class_1299.field_6084
         || var2 == class_1299.field_6128
         || var2 == class_1299.field_6125
         || var2 == class_1299.field_6079;
   }

   public boolean l() {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null) {
         if (this.onlySword.isToggled()) {
            class_1799 var1 = mc.field_1724.method_6047();
            if (var1.method_7960() || !var1.method_31573(class_3489.field_42611) && !var1.method_31573(class_3489.field_42612) && !var1.method_31574(class_1802.field_49814)) {
               return false;
            }
         }

         if (!this.bindOnly.isToggled()) {
            return true;
         } else {
            int var4 = this.cycleBind.getKey();
            if (var4 != -1 && var4 != 0) {
               long var2 = mc.method_22683().method_4490();
               return var4 < 0 ? GLFW.glfwGetMouseButton(var2, -var4 - 100) == 1 : GLFW.glfwGetKey(var2, var4) == 1;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.tickCounter++;
         this.q();
         this.o();
         if (!mc.field_1724.method_29504() && !(mc.field_1724.method_6032() <= 0.0F)) {
            this.v();
            this.conflictingActionSentThisTick = false;
            if (!this.autoTotem.isToggled() || !this.w() || !this.x()) {
               if (!this.l()) {
                  if (RotationStorage.instance != null && RotationStorage.instance.k()) {
                     RotationStorage.instance.j();
                  }
               } else if (this.delayTicks > 0) {
                  this.delayTicks--;
               } else {
                  class_1657 var2 = this.s();
                  if (var2 == null) {
                     if (RotationStorage.instance != null && RotationStorage.instance.k()) {
                        RotationStorage.instance.j();
                     }
                  } else {
                     this.b(var2);
                  }
               }
            }
         }
      }
   }

   private boolean a(class_243 var1) {
      if (mc.field_1724 == null) {
         return false;
      }

      class_243 var2 = mc.field_1724.method_33571();
      double var3 = var1.field_1352 - var2.field_1352;
      double var5 = var1.field_1351 - var2.field_1351;
      double var7 = var1.field_1350 - var2.field_1350;
      double var9 = Math.sqrt(var3 * var3 + var7 * var7);
      float var11 = (float)Math.toDegrees(Math.atan2(var7, var3)) - 90.0F;
      float var12 = (float)(-Math.toDegrees(Math.atan2(var5, var9)));
      float var13 = Math.abs(class_3532.method_15393(mc.field_1724.method_36454() - var11));
      float var14 = Math.abs(mc.field_1724.method_36455() - var12);
      return var13 < 3.5F && var14 < 3.5F;
   }

   private Rotation2 a(float var1, float var2, float var3, float var4) {
      float var5 = GCDUtil.a();
      if (var5 <= 1.0E-4F) {
         var5 = 0.005F;
      }

      float var6 = class_3532.method_15393(var3 - var1);
      float var7 = var4 - var2;
      float var8 = Math.round(var6 / var5) * var5;
      float var9 = Math.round(var7 / var5) * var5;
      if (Math.abs(var8) < 1.0E-4F && Math.abs(var9) < 1.0E-4F) {
         var8 = (ThreadLocalRandom.current().nextBoolean() ? 1 : -1) * var5;
         var9 = (ThreadLocalRandom.current().nextBoolean() ? 1 : -1) * var5;
      }

      float var10 = var1 + var8;
      float var11 = class_3532.method_15363(var2 + var9, -90.0F, 90.0F);
      return new Rotation2(var10, var11);
   }

   private class_1657 s() {
      if (!this.autoTarget.isToggled()
         && mc.field_1765 instanceof class_3966 var2
         && var2.method_17782() instanceof class_1657 var3
         && var3 != mc.field_1724
         && !var3.method_29504()
         && var3.method_6032() > 0.0F
         && !FriendManager.a(var3.method_5477().getString())) {
         return var3;
      }

      double var10 = this.targetRange.getValue() * this.targetRange.getValue();
      class_1657 var11 = null;
      double var12 = var10;

      for (class_1657 var7 : mc.field_1687.method_18456()) {
         if (var7 != mc.field_1724 && !var7.method_29504() && !(var7.method_6032() <= 0.0F) && !FriendManager.a(var7.method_5477().getString())) {
            double var8 = mc.field_1724.method_5858(var7);
            if (var8 < var12) {
               var12 = var8;
               var11 = var7;
            }
         }
      }

      return var11;
   }

   private class_243 a(class_2338 var1, class_2350 var2) {
      class_243 var3 = mc.field_1724 != null ? mc.field_1724.method_33571() : class_243.method_24953(var1);
      class_243 var4 = class_243.method_24953(var1);
      class_243 var5 = var4.method_1020(var3);
      double var6 = var5.method_1033();
      if (var6 > 1.0E-4) {
         var5 = var5.method_1021(1.0 / var6);
      }

      double var8 = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.08;
      double var10 = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.08;
      double var12 = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.08;
      double var14 = var4.field_1352 + var8;
      double var16 = var4.field_1351 + var10;
      double var18 = var4.field_1350 + var12;
      switch (var2) {
         case field_11036:
            var16 = var1.method_10264() + 1.0;
            if (Math.abs(var5.field_1351) > 1.0E-4) {
               double var26 = (var16 - var3.field_1351) / var5.field_1351;
               if (var26 > 0.0) {
                  var14 = var3.field_1352 + var26 * var5.field_1352 + var8;
                  var18 = var3.field_1350 + var26 * var5.field_1350 + var12;
               }
            }

            var14 = class_3532.method_15350(var14, var1.method_10263() + 0.15, var1.method_10263() + 0.85);
            var18 = class_3532.method_15350(var18, var1.method_10260() + 0.15, var1.method_10260() + 0.85);
            break;
         case field_11033:
            var16 = var1.method_10264();
            if (Math.abs(var5.field_1351) > 1.0E-4) {
               double var25 = (var16 - var3.field_1351) / var5.field_1351;
               if (var25 > 0.0) {
                  var14 = var3.field_1352 + var25 * var5.field_1352 + var8;
                  var18 = var3.field_1350 + var25 * var5.field_1350 + var12;
               }
            }

            var14 = class_3532.method_15350(var14, var1.method_10263() + 0.15, var1.method_10263() + 0.85);
            var18 = class_3532.method_15350(var18, var1.method_10260() + 0.15, var1.method_10260() + 0.85);
            break;
         case field_11043:
            var18 = var1.method_10260();
            if (Math.abs(var5.field_1350) > 1.0E-4) {
               double var24 = (var18 - var3.field_1350) / var5.field_1350;
               if (var24 > 0.0) {
                  var14 = var3.field_1352 + var24 * var5.field_1352 + var8;
                  var16 = var3.field_1351 + var24 * var5.field_1351 + var10;
               }
            }

            var14 = class_3532.method_15350(var14, var1.method_10263() + 0.15, var1.method_10263() + 0.85);
            var16 = class_3532.method_15350(var16, var1.method_10264() + 0.15, var1.method_10264() + 0.85);
            break;
         case field_11035:
            var18 = var1.method_10260() + 1.0;
            if (Math.abs(var5.field_1350) > 1.0E-4) {
               double var23 = (var18 - var3.field_1350) / var5.field_1350;
               if (var23 > 0.0) {
                  var14 = var3.field_1352 + var23 * var5.field_1352 + var8;
                  var16 = var3.field_1351 + var23 * var5.field_1351 + var10;
               }
            }

            var14 = class_3532.method_15350(var14, var1.method_10263() + 0.15, var1.method_10263() + 0.85);
            var16 = class_3532.method_15350(var16, var1.method_10264() + 0.15, var1.method_10264() + 0.85);
            break;
         case field_11039:
            var14 = var1.method_10263();
            if (Math.abs(var5.field_1352) > 1.0E-4) {
               double var22 = (var14 - var3.field_1352) / var5.field_1352;
               if (var22 > 0.0) {
                  var16 = var3.field_1351 + var22 * var5.field_1351 + var10;
                  var18 = var3.field_1350 + var22 * var5.field_1350 + var12;
               }
            }

            var16 = class_3532.method_15350(var16, var1.method_10264() + 0.15, var1.method_10264() + 0.85);
            var18 = class_3532.method_15350(var18, var1.method_10260() + 0.15, var1.method_10260() + 0.85);
            break;
         case field_11034:
            var14 = var1.method_10263() + 1.0;
            if (Math.abs(var5.field_1352) > 1.0E-4) {
               double var20 = (var14 - var3.field_1352) / var5.field_1352;
               if (var20 > 0.0) {
                  var16 = var3.field_1351 + var20 * var5.field_1351 + var10;
                  var18 = var3.field_1350 + var20 * var5.field_1350 + var12;
               }
            }

            var16 = class_3532.method_15350(var16, var1.method_10264() + 0.15, var1.method_10264() + 0.85);
            var18 = class_3532.method_15350(var18, var1.method_10260() + 0.15, var1.method_10260() + 0.85);
      }

      return new class_243(var14, var16, var18);
   }

   private void b(class_1657 var1) {
      boolean var2 = mc.field_1687.method_27983().method_29177().method_12832().equals("the_nether");
      boolean var3 = this.preferCrystals.isToggled() && this.c(var1);
      if ((!var3 || !this.d(var1))
         && (!this.autoAnchor.isToggled() || var2 || !this.f(var1))
         && RotationStorage.instance != null
         && RotationStorage.instance.k()) {
         RotationStorage.instance.j();
      }
   }

   private boolean a(class_1792 var1) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         return !mc.field_1724.method_6047().method_31574(var1) && !mc.field_1724.method_6079().method_31574(var1)
            ? DeltaInventoryUtil.a(var1, true) != -1 || DeltaInventoryUtil.a(var1, false) != -1
            : true;
      }
   }

   private boolean c(class_1657 var1) {
      if (var1 != null && this.a(class_1802.field_8301)) {
         int var2 = mc.field_1724.method_24515().method_10264();
         int var3 = var1.method_24515().method_10264();
         if (var3 <= var2) {
            return false;
         }

         List var4 = this.e(var1);
         if (var4.isEmpty()) {
            return false;
         }

         boolean var5 = false;

         for (class_2338 var7 : (Iterable<class_2338>)(Iterable<?>)(var4)) {
            if (mc.field_1687.method_8320(var7).method_27852(class_2246.field_10540) || mc.field_1687.method_8320(var7).method_27852(class_2246.field_9987)) {
               var5 = true;
               break;
            }
         }

         return var5 ? true : this.placeObsidian.isToggled() && this.a(class_1802.field_8281);
      } else {
         return false;
      }
   }

   private boolean d(class_1657 var1) {
      if (var1 != null && mc.field_1724 != null && mc.field_1687 != null) {
         if (this.lastPlacedObsidian != null && this.tickCounter <= this.lastPlacedObsidianTick) {
            class_2338 var2 = this.lastPlacedObsidian;
            if (mc.field_1687.method_8320(var2).method_27852(class_2246.field_10540)) {
               if (this.f(var2)) {
                  class_1511 var3 = this.g(var2);
                  if (var3 != null && mc.field_1724.method_5858(var3) > var1.method_5858(var3)) {
                     class_243 var4 = var3.method_5829().method_1005();
                     boolean var5 = this.a(var4);
                     this.b(var4);
                     if (var5) {
                        this.a(var3);
                        this.delayTicks = (int)this.actionDelay.getValue();
                     }

                     return true;
                  }
               } else if (this.e(var2)) {
                  class_1268 var13 = mc.field_1724.method_6079().method_31574(class_1802.field_8301) ? class_1268.field_5810 : class_1268.field_5808;
                  if (var13 == class_1268.field_5810 || this.b(class_1802.field_8301)) {
                     class_243 var16 = this.a(var2, class_2350.field_11036);
                     boolean var19 = this.a(var16);
                     this.b(var16);
                     if (var19 && this.a(var2, var16, var13)) {
                        this.delayTicks = (int)this.actionDelay.getValue();
                     }

                     return true;
                  }
               }
            } else {
               this.lastPlacedObsidian = null;
            }
         }

         class_1511 var12 = this.h(var1.method_24515());
         if (var12 != null && mc.field_1724.method_5858(var12) > var1.method_5858(var12)) {
            class_243 var15 = var12.method_5829().method_1005();
            boolean var18 = this.a(var15);
            this.b(var15);
            if (var18) {
               this.a(var12);
               this.delayTicks = (int)this.actionDelay.getValue();
            }

            return true;
         } else {
            for (class_2338 var20 : this.e(var1)) {
               class_2680 var6 = mc.field_1687.method_8320(var20);
               if (!var6.method_27852(class_2246.field_10540) && !var6.method_27852(class_2246.field_9987)) {
                  if (this.placeObsidian.isToggled() && this.d(var20)) {
                     class_2350 var22 = this.a(var20);
                     if (var22 != null) {
                        class_1268 var24 = mc.field_1724.method_6079().method_31574(class_1802.field_8281) ? class_1268.field_5810 : class_1268.field_5808;
                        if (var24 != class_1268.field_5808 || this.b(class_1802.field_8281)) {
                           class_2338 var26 = var20.method_10093(var22.method_10153());
                           class_243 var10 = this.a(var26, var22);
                           boolean var11 = this.a(var10);
                           this.b(var10);
                           if (var11 && this.a(var26, var22, var10, var24)) {
                              this.delayTicks = (int)this.actionDelay.getValue();
                           }

                           return true;
                        }
                     }
                  }
               } else if (this.f(var20)) {
                  class_1511 var21 = this.g(var20);
                  if (var21 != null && mc.field_1724.method_5858(var21) > var1.method_5858(var21)) {
                     class_243 var23 = var21.method_5829().method_1005();
                     boolean var25 = this.a(var23);
                     this.b(var23);
                     if (var25) {
                        this.a(var21);
                        this.delayTicks = (int)this.actionDelay.getValue();
                     }

                     return true;
                  }
               } else if (this.e(var20)) {
                  class_1268 var7 = mc.field_1724.method_6079().method_31574(class_1802.field_8301) ? class_1268.field_5810 : class_1268.field_5808;
                  if (var7 != class_1268.field_5808 || this.b(class_1802.field_8301)) {
                     class_243 var8 = this.a(var20, class_2350.field_11036);
                     boolean var9 = this.a(var8);
                     this.b(var8);
                     if (var9 && this.a(var20, var8, var7)) {
                        this.delayTicks = (int)this.actionDelay.getValue();
                     }

                     return true;
                  }
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private List<class_2338> e(class_1657 var1) {
      ArrayList var2 = new ArrayList();
      if (var1 != null && mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var3 = var1.method_24515();
         double var4 = this.range.getValue() * this.range.getValue();
         int var6 = var3.method_10264();

         for (int var7 = -2; var7 <= 2; var7++) {
            for (int var8 = -2; var8 <= 2; var8++) {
               for (int var9 = -1; var9 <= 1; var9++) {
                  class_2338 var10 = new class_2338(var3.method_10263() + var7, var6 + var9, var3.method_10260() + var8);
                  class_243 var11 = class_243.method_24953(var10);
                  class_243 var12 = new class_243(var10.method_10263() + 0.5, var10.method_10264() + 1.0, var10.method_10260() + 0.5);
                  if (!(mc.field_1724.method_5707(var11) > var4) && !(mc.field_1724.method_5707(var12) <= var1.method_5707(var12))) {
                     class_2680 var13 = mc.field_1687.method_8320(var10);
                     boolean var14 = var13.method_27852(class_2246.field_10540) || var13.method_27852(class_2246.field_9987);
                     boolean var15 = this.placeObsidian.isToggled() && this.d(var10) && this.a(var10) != null;
                     if (var14 || var15) {
                        class_2338 var16 = var10.method_10084();
                        class_2338 var17 = var10.method_10086(2);
                        class_2680 var18 = mc.field_1687.method_8320(var16);
                        class_2680 var19 = mc.field_1687.method_8320(var17);
                        if ((var18.method_26215() || var18.method_45474()) && (var19.method_26215() || var19.method_45474())) {
                           var2.add(var10);
                        }
                     }
                  }
               }
            }
         }

         var2.sort((var1xx, var2x) -> {
            boolean var3x = mc.field_1687.method_8320((class_2338)var1xx).method_27852(class_2246.field_10540) || mc.field_1687.method_8320((class_2338)var1xx).method_27852(class_2246.field_9987);
            boolean var4x = mc.field_1687.method_8320((class_2338)var2x).method_27852(class_2246.field_10540) || mc.field_1687.method_8320((class_2338)var2x).method_27852(class_2246.field_9987);
            if (var3x != var4x) {
               return var3x ? -1 : 1;
            }

            double var5 = var1.method_5707(class_243.method_24953((class_2338)var1xx));
            double var7x = var1.method_5707(class_243.method_24953((class_2338)var2x));
            return Double.compare(var5, var7x);
         });
         return var2;
      } else {
         return var2;
      }
   }

   private class_2350 a(class_2338 var1) {
      for (class_2350 var5 : class_2350.values()) {
         class_2338 var6 = var1.method_10093(var5.method_10153());
         class_2680 var7 = mc.field_1687.method_8320(var6);
         if (!var7.method_26215() && !var7.method_45474() && !var7.method_51176()) {
            return var5;
         }
      }

      return null;
   }

   private boolean f(class_1657 var1) {
      if (var1 != null && mc.field_1724 != null && mc.field_1687 != null) {
         for (class_2338 var4 : this.g(var1)) {
            if (this.i(var4)) {
               if (this.safeAnchor.isToggled() && this.b(var4) && !this.safeShieldAttempted.containsKey(var4)) {
                  class_2338 var5 = this.c(var4);
                  if (var5 != null && !mc.field_1687.method_8320(var5).method_27852(class_2246.field_10171)) {
                     class_2350 var6 = this.a(var5);
                     if (var6 != null && this.b(class_1802.field_8801)) {
                        class_2338 var7 = var5.method_10093(var6.method_10153());
                        class_243 var8 = this.a(var7, var6);
                        boolean var9 = this.a(var8);
                        this.b(var8);
                        if (var9 && this.a(var5, var7, var6, var8)) {
                           this.safeShieldAttempted.put(var4, this.tickCounter + 20L);
                           this.delayTicks = (int)this.actionDelay.getValue();
                        }

                        return true;
                     }
                  }
               }

               if (this.u()) {
                  class_243 var12 = this.a(var4, class_2350.field_11036);
                  boolean var15 = this.a(var12);
                  this.b(var12);
                  if (var15 && this.b(var4, var12)) {
                     this.delayTicks = (int)this.actionDelay.getValue();
                  }

                  return true;
               }
            } else if (this.b(class_1802.field_8801)) {
               class_243 var13 = this.a(var4, class_2350.field_11036);
               boolean var16 = this.a(var13);
               this.b(var13);
               if (var16 && this.a(var4, var13)) {
                  this.delayTicks = (int)this.actionDelay.getValue();
               }

               return true;
            }
         }

         for (class_2338 var14 : this.h(var1)) {
            class_2350 var17 = this.a(var14);
            if (var17 != null && this.b(class_1802.field_23141)) {
               class_2338 var18 = var14.method_10093(var17.method_10153());
               class_243 var19 = this.a(var18, var17);
               boolean var20 = this.a(var19);
               this.b(var19);
               if (var20 && this.a(var18, var17, var19)) {
                  this.delayTicks = (int)this.actionDelay.getValue();
               }

               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private List<class_2338> g(class_1657 var1) {
      ArrayList var2 = new ArrayList();
      class_2338 var3 = var1.method_24515();
      double var4 = this.range.getValue() * this.range.getValue();

      for (int var6 = -3; var6 <= 3; var6++) {
         for (int var7 = -2; var7 <= 2; var7++) {
            for (int var8 = -3; var8 <= 3; var8++) {
               class_2338 var9 = var3.method_10069(var6, var7, var8);
               if (!(mc.field_1724.method_5707(class_243.method_24953(var9)) > var4)) {
                  boolean var10 = mc.field_1687.method_8320(var9).method_27852(class_2246.field_23152);
                  boolean var11 = this.placedAnchors.containsKey(var9) && this.tickCounter <= this.placedAnchors.get(var9);
                  if (var10 || var11) {
                     var2.add(var9);
                  }
               }
            }
         }
      }

      var2.sort(Comparator.comparingDouble(var1xx -> var1.method_5707(class_243.method_24953((class_2338)var1xx))));
      return var2;
   }

   private List<class_2338> h(class_1657 var1) {
      ArrayList var2 = new ArrayList();
      if (var1 != null && mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var3 = var1.method_24515();
         double var4 = this.range.getValue() * this.range.getValue();
         int var6 = var3.method_10264();

         for (int var7 = -2; var7 <= 2; var7++) {
            for (int var8 = -2; var8 <= 2; var8++) {
               for (int var9 = -1; var9 <= 1; var9++) {
                  class_2338 var10 = new class_2338(var3.method_10263() + var7, var6 + var9, var3.method_10260() + var8);
                  class_243 var11 = class_243.method_24953(var10);
                  if (!(mc.field_1724.method_5707(var11) > var4)) {
                     class_2680 var12 = mc.field_1687.method_8320(var10);
                     if (var12.method_26215() || var12.method_45474()) {
                        class_238 var13 = new class_238(var10);
                        boolean var14 = false;

                        for (class_1297 var16 : mc.field_1687.method_18112()) {
                           if (!(
                                 var16 instanceof class_1511 var17
                                    && (!var17.method_5805() || var17.method_31481() || this.deadCrystals.containsKey(var17.method_5628()))
                              )
                              && var16.method_5805()
                              && !var16.method_31481()
                              && !(var16 instanceof class_1542)
                              && !(var16 instanceof class_1303)
                              && var16.method_5829().method_994(var13)) {
                              var14 = true;
                              break;
                           }
                        }

                        if (!var14 && this.a(var10) != null) {
                           var2.add(var10);
                        }
                     }
                  }
               }
            }
         }

         var2.sort(Comparator.comparingDouble(var1xx -> var1.method_5707(class_243.method_24953((class_2338)var1xx))));
         return var2;
      } else {
         return var2;
      }
   }

   private boolean a(class_2338 var1, class_2350 var2, class_243 var3) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null && var2 != null) {
         this.placingInternal = true;

         try {
            class_3965 var4 = new class_3965(var3, var2, var1, false);
            class_1269 var5 = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var4);
            if (var5.method_23665()) {
               mc.field_1724.method_6104(class_1268.field_5808);
               this.conflictingActionSentThisTick = true;
               class_2338 var6 = var1.method_10093(var2);
               this.placedAnchors.put(var6, this.tickCounter + 40L);
               if (mc.field_1687 != null) {
                  mc.field_1687.method_8501(var6, class_2246.field_23152.method_9564());
               }

               return true;
            }
         } finally {
            this.placingInternal = false;
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean a(class_2338 var1, class_243 var2) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null) {
         this.placingInternal = true;

         try {
            class_3965 var3 = new class_3965(var2, class_2350.field_11036, var1, false);
            class_1269 var4 = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var3);
            if (var4.method_23665()) {
               mc.field_1724.method_6104(class_1268.field_5808);
               this.conflictingActionSentThisTick = true;
               this.chargedAnchors.put(var1, this.tickCounter + 40L);
               if (mc.field_1687 != null) {
                  try {
                     mc.field_1687.method_8501(var1, class_2246.field_23152.method_9564().method_11657(class_4969.field_23153, 1));
                  } catch (Exception var9) {
                  }
               }

               return true;
            }
         } finally {
            this.placingInternal = false;
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean b(class_2338 var1, class_243 var2) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null) {
         this.placingInternal = true;

         try {
            class_3965 var3 = new class_3965(var2, class_2350.field_11036, var1, false);
            class_1269 var4 = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var3);
            if (var4.method_23665()) {
               mc.field_1724.method_6104(class_1268.field_5808);
               this.conflictingActionSentThisTick = true;
               this.chargedAnchors.remove(var1);
               this.placedAnchors.remove(var1);
               this.safeShieldAttempted.remove(var1);
               if (mc.field_1687 != null) {
                  mc.field_1687.method_8501(var1, class_2246.field_10124.method_9564());
               }

               return true;
            }
         } finally {
            this.placingInternal = false;
         }

         return false;
      } else {
         return false;
      }
   }

   private int t() {
      int var1 = DeltaInventoryUtil.a(class_1802.field_8288, true);
      if (var1 != -1) {
         return var1;
      }

      int var2 = DeltaInventoryUtil.a(class_1802.field_22022, true);
      if (var2 == -1) {
         var2 = DeltaInventoryUtil.a(class_1802.field_8802, true);
      }

      if (var2 != -1) {
         return var2;
      }

      int var3 = DeltaInventoryUtil.a(class_1802.field_49814, true);
      if (var3 != -1) {
         return var3;
      }

      int var4 = mc.field_1724.method_31548().method_67532();
      if (!mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
         return var4;
      }

      for (int var5 = 0; var5 < 9; var5++) {
         class_1799 var6 = mc.field_1724.method_31548().method_5438(var5);
         if (!var6.method_31574(class_1802.field_8801)) {
            return var5;
         }
      }

      return -1;
   }

   private boolean b(class_2338 var1) {
      return var1.method_10264() == class_3532.method_15357(mc.field_1724.method_23318());
   }

   private class_2338 c(class_2338 var1) {
      double var2 = mc.field_1724.method_23317() - (var1.method_10263() + 0.5);
      double var4 = mc.field_1724.method_23321() - (var1.method_10260() + 0.5);
      int var6 = var2 > 0.05 ? 1 : (var2 < -0.05 ? -1 : 0);
      int var7 = var4 > 0.05 ? 1 : (var4 < -0.05 ? -1 : 0);
      if (Math.abs(var2) >= Math.abs(var4) && var6 != 0) {
         return new class_2338(var1.method_10263() + var6, var1.method_10264(), var1.method_10260());
      } else {
         return var7 != 0 ? new class_2338(var1.method_10263(), var1.method_10264(), var1.method_10260() + var7) : null;
      }
   }

   private boolean a(class_2338 var1, class_2338 var2, class_2350 var3, class_243 var4) {
      if (mc.field_1724 != null && mc.field_1761 != null && var2 != null && var3 != null) {
         class_2680 var5 = mc.field_1687.method_8320(var1);
         if (var5.method_27852(class_2246.field_10171)) {
            return true;
         }

         if (!var5.method_26215() && !var5.method_45474()) {
            return false;
         }

         this.placingInternal = true;

         try {
            class_3965 var6 = new class_3965(var4, var3, var2, false);
            class_1269 var7 = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var6);
            if (var7.method_23665()) {
               mc.field_1724.method_6104(class_1268.field_5808);
               this.conflictingActionSentThisTick = true;
               return true;
            }
         } finally {
            this.placingInternal = false;
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean a(class_2338 var1, class_2350 var2, class_243 var3, class_1268 var4) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null && var2 != null) {
         this.placingInternal = true;

         class_1269 var5;
         try {
            class_3965 var6 = new class_3965(var3, var2, var1, false);
            var5 = mc.field_1761.method_2896(mc.field_1724, var4, var6);
         } finally {
            this.placingInternal = false;
         }

         if (var5.method_23665()) {
            mc.field_1724.method_6104(var4);
            this.conflictingActionSentThisTick = true;
            class_2338 var10 = var1.method_10093(var2);
            this.lastPlacedObsidian = var10;
            this.lastPlacedObsidianTick = this.tickCounter + 20L;
            if (mc.field_1687 != null) {
               mc.field_1687.method_8501(var10, class_2246.field_10540.method_9564());
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean a(class_2338 var1, class_243 var2, class_1268 var3) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null) {
         class_3965 var4 = new class_3965(var2, class_2350.field_11036, var1, false);
         this.placingInternal = true;

         class_1269 var5;
         try {
            var5 = mc.field_1761.method_2896(mc.field_1724, var3, var4);
         } finally {
            this.placingInternal = false;
         }

         if (var5.method_23665()) {
            mc.field_1724.method_6104(var3);
            this.conflictingActionSentThisTick = true;
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void a(class_1511 var1) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null) {
         mc.field_1761.method_2918(mc.field_1724, var1);
         mc.field_1724.method_6104(class_1268.field_5808);
         this.deadCrystals.put(var1.method_5628(), System.currentTimeMillis());

         try {
            var1.method_31472();
         } catch (Exception var3) {
         }

         this.conflictingActionSentThisTick = true;
      }
   }

   private void b(class_243 var1) {
      class_243 var2 = mc.field_1724.method_33571();
      double var3 = var1.field_1352 - var2.field_1352;
      double var5 = var1.field_1351 - var2.field_1351;
      double var7 = var1.field_1350 - var2.field_1350;
      double var9 = Math.sqrt(var3 * var3 + var7 * var7);
      float var11 = (float)Math.toDegrees(Math.atan2(var7, var3)) - 90.0F;
      float var12 = (float)(-Math.toDegrees(Math.atan2(var5, var9)));
      Rotation2 var13 = this.a(mc.field_1724.method_36454(), mc.field_1724.method_36455(), var11, var12);
      RotationStorage.a(var13, 180.0F, 180.0F, 180.0F, 180.0F, 1, 1, this.clientLook.isToggled());
   }

   private boolean d(class_2338 var1) {
      if (mc.field_1687 != null && mc.field_1724 != null && var1 != null) {
         if (mc.field_1724.method_5707(class_243.method_24953(var1)) > this.range.getValue() * this.range.getValue()) {
            return false;
         }

         class_2680 var2 = mc.field_1687.method_8320(var1);
         if (!var2.method_26215() && !var2.method_45474()) {
            return false;
         }

         class_238 var3 = new class_238(var1);

         for (class_1297 var5 : mc.field_1687.method_18112()) {
            if (!(var5 instanceof class_1511 var6 && (!var6.method_5805() || var6.method_31481() || this.deadCrystals.containsKey(var6.method_5628())))
               && var5.method_5805()
               && !var5.method_31481()
               && !(var5 instanceof class_1542)
               && !(var5 instanceof class_1303)
               && var5.method_5829().method_994(var3)) {
               return false;
            }
         }

         class_2338 var8 = var1.method_10084();
         class_2338 var9 = var1.method_10086(2);
         class_2680 var10 = mc.field_1687.method_8320(var8);
         class_2680 var7 = mc.field_1687.method_8320(var9);
         return (var10.method_26215() || var10.method_45474()) && (var7.method_26215() || var7.method_45474());
      } else {
         return false;
      }
   }

   private boolean e(class_2338 var1) {
      if (mc.field_1687 != null && mc.field_1724 != null && var1 != null) {
         if (mc.field_1724.method_5707(class_243.method_24953(var1)) > this.range.getValue() * this.range.getValue()) {
            return false;
         }

         class_2338 var2 = var1.method_10084();
         class_2338 var3 = var1.method_10086(2);
         class_2680 var4 = mc.field_1687.method_8320(var2);
         class_2680 var5 = mc.field_1687.method_8320(var3);
         if (!var4.method_26215() && !var4.method_45474()) {
            return false;
         }

         if (!var5.method_26215() && !var5.method_45474()) {
            return false;
         }

         class_238 var6 = new class_238(var1.method_10263(), var1.method_10264() + 1.0, var1.method_10260(), var1.method_10263() + 1.0, var1.method_10264() + 3.0, var1.method_10260() + 1.0);

         for (class_1297 var8 : mc.field_1687.method_18112()) {
            if (!(var8 instanceof class_1511 var9 && (!var9.method_5805() || var9.method_31481() || this.deadCrystals.containsKey(var9.method_5628())))
               && var8.method_5805()
               && !var8.method_31481()
               && !(var8 instanceof class_1542)
               && !(var8 instanceof class_1303)
               && var8.method_5829().method_994(var6)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean f(class_2338 var1) {
      return this.g(var1) != null;
   }

   private class_1511 g(class_2338 var1) {
      if (mc.field_1687 != null && var1 != null) {
         class_238 var2 = new class_238(var1.method_10263(), var1.method_10264() + 0.5, var1.method_10260(), var1.method_10263() + 1.0, var1.method_10264() + 2.5, var1.method_10260() + 1.0);

         for (class_1297 var4 : mc.field_1687.method_18112()) {
            if (var4 instanceof class_1511 var5
               && !this.deadCrystals.containsKey(var5.method_5628())
               && var5.method_5805()
               && !var5.method_31481()
               && var5.method_5829().method_994(var2)) {
               return var5;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private class_1511 h(class_2338 var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1511 var2 = null;
         double var3 = this.range.getValue() * this.range.getValue();
         class_243 var5 = class_243.method_24953(var1);

         for (class_1297 var7 : mc.field_1687.method_18112()) {
            if (var7 instanceof class_1511 var8 && !this.deadCrystals.containsKey(var8.method_5628()) && var8.method_5805() && !var8.method_31481()) {
               double var9 = mc.field_1724.method_5858(var8);
               double var11 = var5.method_1028(var8.method_23317(), var8.method_23318(), var8.method_23321());
               if (!(var9 > var3) && !(var9 <= var11) && var11 <= var3) {
                  var3 = var11;
                  var2 = var8;
               }
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private boolean i(class_2338 var1) {
      if (this.chargedAnchors.containsKey(var1) && this.tickCounter <= this.chargedAnchors.get(var1)) {
         return true;
      }

      class_2680 var2 = mc.field_1687.method_8320(var1);
      if (!var2.method_27852(class_2246.field_23152)) {
         return false;
      }

      try {
         if (var2.method_11654(class_4969.field_23153) > 0) {
            return true;
         }
      } catch (Exception var4) {
      }

      return var2.method_26213() > 0;
   }

   private boolean b(class_1792 var1) {
      if (mc.field_1724 == null) {
         return false;
      } else if (mc.field_1724.method_6047().method_31574(var1)) {
         return true;
      } else {
         int var2 = DeltaInventoryUtil.a(var1, true);
         if (var2 != -1) {
            this.b(var2);
            return true;
         } else {
            int var3 = DeltaInventoryUtil.a(var1, false);
            if (var3 != -1) {
               HandlerProcessor.a().getInventoryHandler().a(var3, mc.field_1724.method_31548().method_67532(), 1);
               return true;
            } else {
               return false;
            }
         }
      }
   }

   private boolean u() {
      int var1 = this.t();
      if (var1 == -1) {
         return false;
      }

      this.b(var1);
      return true;
   }

   private void b(int var1) {
      if (var1 >= 0 && var1 <= 8 && mc.field_1724 != null) {
         int var2 = mc.field_1724.method_31548().method_67532();
         if (var1 != var2) {
            HandlerProcessor.a().getUseableHandler().a(var1);
         }
      }
   }

   private void v() {
      long var1 = System.currentTimeMillis();
      this.deadCrystals.entrySet().removeIf(var2 -> var1 - var2.getValue() > 1000L);
   }

   private boolean w() {
      return mc.field_1755 == null || mc.field_1755 instanceof class_490 || mc.field_1755 instanceof class_408;
   }

   private boolean x() {
      int var1 = (int)this.totemHotbarSlot.getValue() - 1;
      int var4 = class_3532.method_15340(var1, 0, 8);
      class_1799 var2 = mc.field_1724.method_31548().method_5438(var4);
      if (var2.method_31574(class_1802.field_8288)) {
         this.totemRefillPending = false;
         return false;
      }

      if (!this.totemBatchTimer.a((long)this.totemBatchDelay.getValue() * 50L)) {
         return false;
      }

      int var3 = this.y();
      if (var3 == -1) {
         return false;
      }

      HandlerProcessor.a().getInventoryHandler().a(var3, var4, 1);
      this.totemBatchTimer.a();
      this.conflictingActionSentThisTick = true;
      return true;
   }

   private int y() {
      if (mc.field_1724 != null && mc.field_1724.field_7498 != null) {
         for (class_1735 var2 : mc.field_1724.field_7498.field_7761) {
            if (var2.field_7874 >= 9 && var2.field_7874 < 36 && var2.method_7677().method_31574(class_1802.field_8288)) {
               return var2.field_7874;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (mc.field_1687 != null && var1.getPacket() instanceof class_2664 var2) {
         class_2338 var7 = class_2338.method_49638(var2.comp_2883());
         this.chargedAnchors.remove(var7);
         this.placedAnchors.remove(var7);
         this.safeShieldAttempted.remove(var7);

         for (class_1297 var5 : mc.field_1687.method_18112()) {
            if (var5 instanceof class_1511 var6) {
               this.deadCrystals.put(var6.method_5628(), System.currentTimeMillis());
            }
         }
      }
   }

   static class a {
      final int x;
      final int y;
      final int z;
      final class_2350 side;

      a(int var1, int var2, int var3, class_2350 var4) {
         this.x = var1;
         this.y = var2;
         this.z = var3;
         this.side = var4;
      }
   }
}
