package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.combat.Aura;
import brokke.cc.setting.BooleanSetting;
import net.minecraft.class_2199;
import net.minecraft.class_2238;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2269;
import net.minecraft.class_2275;
import net.minecraft.class_2281;
import net.minecraft.class_2288;
import net.minecraft.class_2304;
import net.minecraft.class_2315;
import net.minecraft.class_2323;
import net.minecraft.class_2325;
import net.minecraft.class_2331;
import net.minecraft.class_2336;
import net.minecraft.class_2349;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_2387;
import net.minecraft.class_2401;
import net.minecraft.class_2406;
import net.minecraft.class_2428;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2531;
import net.minecraft.class_2533;
import net.minecraft.class_3708;
import net.minecraft.class_3709;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3717;
import net.minecraft.class_3718;
import net.minecraft.class_3962;
import net.minecraft.class_4969;

@NewFunction(name = "NoInteract", description = "Блокирует взаимодействие с блоками", category = Category.PLAYER)
public class NoInteract extends Function {
   private final BooleanSetting allBlocks = new BooleanSetting("Все блоки", false);
   private final BooleanSetting onlyAura = new BooleanSetting("Только с Аурой", false);

   public NoInteract() {
      this.addSettings(this.allBlocks, this.onlyAura);
   }

   public boolean a(class_2248 var1) {
      if (!this.isActive()) {
         return false;
      }

      if (this.onlyAura.isToggled()) {
         Function var2 = FunctionManager.a(Aura.class);
         if (var2 == null || !var2.isActive()) {
            return false;
         }
      }

      return this.allBlocks.isToggled() ? true : this.b(var1);
   }

   private boolean b(class_2248 var1) {
      return var1 instanceof class_2304
         || var1 instanceof class_2331
         || var1 instanceof class_2244
         || var1 instanceof class_2281
         || var1 instanceof class_2336
         || var1 instanceof class_2531
         || var1 instanceof class_2363
         || var1 instanceof class_3708
         || var1 instanceof class_2480
         || var1 instanceof class_2325
         || var1 instanceof class_2315
         || var1 instanceof class_2377
         || var1 instanceof class_2199
         || var1 instanceof class_2275
         || var1 instanceof class_2478
         || var1 instanceof class_3709
         || var1 instanceof class_3962
         || var1 instanceof class_2260
         || var1 instanceof class_2387
         || var1 instanceof class_2288
         || var1 instanceof class_2238
         || var1 instanceof class_4969
         || var1 instanceof class_3713
         || var1 instanceof class_3715
         || var1 instanceof class_3711
         || var1 instanceof class_2406
         || var1 instanceof class_3717
         || var1 instanceof class_3718
         || var1 instanceof class_2323
         || var1 instanceof class_2533
         || var1 instanceof class_2349
         || var1 instanceof class_2269
         || var1 instanceof class_2401
         || var1 instanceof class_2428;
   }
}
