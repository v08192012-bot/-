package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.combat.Aura;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.InventoryUtility;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

@NewFunction(name = "AutoTool", description = "Автоматически выбирает лучший инструмент из хотбара", category = Category.PLAYER)
public class AutoTool extends Function {
   public final BooleanSetting invisible = new BooleanSetting("Незаметный", false);
   private int oldSlot = -1;
   private int swappedInventorySlotId = -1;
   private boolean swapped;
   private class_1799 visualStack = class_1799.field_8037;
   private int visualResetTicks = 0;
   private int attackHoldTicks = 0;

   public AutoTool() {
      this.addSettings(this.invisible);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1690.field_1886.method_1434()) {
         this.attackHoldTicks++;
      } else {
         this.attackHoldTicks = 0;
         if (!this.swapped) {
            if (this.visualResetTicks > 0) {
               this.visualResetTicks--;
            } else {
               this.visualStack = class_1799.field_8037;
            }
         }
      }

      if (mc.field_1724 != null && mc.field_1687 != null && !mc.field_1724.method_68878()) {
         Aura var2 = FunctionManager.a(Aura.class);
         if (var2 != null && var2.isActive()) {
            this.l();
         } else if (!(mc.field_1765 instanceof class_3965 var3 && mc.field_1690.field_1886.method_1434())) {
            this.l();
         } else if (this.attackHoldTicks >= 1) {
            if (this.swappedInventorySlotId != -1) {
               if (this.oldSlot != -1 && mc.field_1724.method_31548().method_67532() != this.oldSlot) {
                  InventoryUtility.e(this.oldSlot);
               }

               return;
            }

            class_2338 var7 = var3.method_17777();
            class_2680 var5 = mc.field_1687.method_8320(var7);
            class_1735 var6 = this.a(var5);
            if (var6 != null) {
               this.a(var6);
            }
         }
      } else {
         this.l();
      }
   }

   private class_1735 a(class_2680 var1) {
      if (mc.field_1724 != null && mc.field_1724.field_7512 != null) {
         class_1735 var2 = null;
         float var3 = 1.0F;

         for (class_1735 var5 : mc.field_1724.field_7512.field_7761) {
            if (this.d(var5.field_7874)) {
               float var6 = var5.method_7677().method_7924(var1);
               if (var6 > var3) {
                  var3 = var6;
                  var2 = var5;
               }
            }
         }

         if (var2 != null) {
            return var2;
         }

         class_1735 var9 = null;
         float var10 = 1.0F;

         for (class_1735 var7 : mc.field_1724.field_7512.field_7761) {
            if (this.c(var7.field_7874) && !this.d(var7.field_7874)) {
               float var8 = var7.method_7677().method_7924(var1);
               if (var8 > var10) {
                  var10 = var8;
                  var9 = var7;
               }
            }
         }

         return var9;
      } else {
         return null;
      }
   }

   private void a(class_1735 var1) {
      if (mc.field_1724 != null && var1 != null && mc.field_1761 != null) {
         int var2 = mc.field_1724.method_31548().method_67532();
         if (this.oldSlot == -1) {
            this.oldSlot = var2;
            this.visualStack = mc.field_1724.method_31548().method_5438(var2).method_7972();
            this.visualResetTicks = 0;
         }

         if (this.d(var1.field_7874)) {
            int var3 = var1.field_7874 - 36;
            if (this.swappedInventorySlotId != -1) {
               this.m();
            }

            if (mc.field_1724.method_31548().method_67532() != var3) {
               InventoryUtility.e(var3);
            }

            this.swapped = true;
         } else if (this.swappedInventorySlotId == var1.field_7874) {
            if (mc.field_1724.method_31548().method_67532() != this.oldSlot) {
               InventoryUtility.e(this.oldSlot);
            }

            this.swapped = true;
         } else {
            if (this.swappedInventorySlotId != -1) {
               this.m();
            }

            InventoryUtility.e(this.oldSlot);
            mc.field_1761
               .method_2906(mc.field_1724.field_7512.field_7763, var1.field_7874, mc.field_1724.method_31548().method_67532(), class_1713.field_7791, mc.field_1724);
            this.swappedInventorySlotId = var1.field_7874;
            this.swapped = true;
         }
      }
   }

   private void l() {
      if (!this.swapped) {
         this.oldSlot = -1;
         this.swappedInventorySlotId = -1;
      } else {
         this.m();
         if (mc.field_1724 != null && this.oldSlot != -1) {
            InventoryUtility.e(this.oldSlot);
         }

         this.swapped = false;
         this.visualResetTicks = 5;
         this.oldSlot = -1;
         this.swappedInventorySlotId = -1;
      }
   }

   private void m() {
      if (mc.field_1724 != null && mc.field_1761 != null && this.swappedInventorySlotId != -1) {
         class_1735 var1 = this.b(this.swappedInventorySlotId);
         if (var1 != null && this.oldSlot != -1) {
            InventoryUtility.e(this.oldSlot);
            mc.field_1761
               .method_2906(mc.field_1724.field_7512.field_7763, var1.field_7874, mc.field_1724.method_31548().method_67532(), class_1713.field_7791, mc.field_1724);
         }

         this.swappedInventorySlotId = -1;
      }
   }

   private class_1735 b(int var1) {
      if (mc.field_1724 != null && mc.field_1724.field_7512 != null) {
         return var1 >= 0 && var1 < mc.field_1724.field_7512.field_7761.size() ? mc.field_1724.field_7512.field_7761.get(var1) : null;
      } else {
         return null;
      }
   }

   private boolean c(int var1) {
      return var1 >= 9 && var1 <= 44;
   }

   private boolean d(int var1) {
      return var1 >= 36 && var1 <= 44;
   }

   public class_1799 getVisualStack() {
      return this.visualStack;
   }

   @Override
   public void onDisable() {
      this.l();
      super.onDisable();
   }
}
