package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.HandlerProcessor;
import brokke.cc.manager.FriendManager;
import brokke.cc.setting.BindSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.KeyEvent;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3966;
import net.minecraft.class_742;

@NewFunction(name = "ClickAction", description = "Выполняет действие, привязанное к выбранной клавише", category = Category.PLAYER)
public class ClickAction extends Function {
   private final BindSetting pearlBind = new BindSetting("Эндер-жемчуг", -1);
   private final BindSetting friendBind = new BindSetting("Добавление друга", -1);

   public ClickAction() {
      this.addSettings(this.pearlBind, this.friendBind);
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1755 == null && var1.getAction() == 1) {
         int var2 = var1.getKey();
         if (this.pearlBind.getKey() != -1 && var2 == this.pearlBind.getKey()) {
            HandlerProcessor.a().getUseableHandler().a(class_1802.field_8634.method_7854());
         }

         if (this.friendBind.getKey() != -1
            && var2 == this.friendBind.getKey()
            && mc.field_1765 instanceof class_3966 var3
            && var3.method_17782() instanceof class_742 var6
            && var6 != mc.field_1724) {
            String var7 = var6.method_5477().getString();
            if (FriendManager.a(var7)) {
               FriendManager.c(var7);
               this.a("Товарищ " + var7 + " был успешно удален из списка друзей.");
            } else {
               FriendManager.b(var7);
               this.a("Товарищ " + var7 + " был успешно добавлен в список друзей.");
            }
         }
      }
   }

   private void a(String var1) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_7353(class_2561.method_43470("§7[§dClickAction§7] §f" + var1), false);
      }
   }
}
