package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.InventoryUtility;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4174;
import net.minecraft.class_9334;

@NewFunction(name = "AutoEat", description = "Автоматически ест еду при голоде", category = Category.PLAYER)
public class AutoEat extends Function {
   private static AutoEat instance;
   public final NumberSetting hunger = new NumberSetting("Голод", 16.0, 1.0, 19.0, 1.0);
   public final BooleanSetting gapples = new BooleanSetting("Золотые яблоки", false);
   public final BooleanSetting badFood = new BooleanSetting("Опасная еда", false);
   private boolean eating = false;
   private int originalSlot = -1;
   private int swappedInventorySlot = -1;
   private int hotbarTargetSlot = -1;
   private int eatTicks = 0;

   public AutoEat() {
      instance = this;
      this.addSettings(this.hunger, this.gapples, this.badFood);
   }

   public static AutoEat getInstance() {
      return instance;
   }

   public static boolean l() {
      return instance != null && instance.isActive() && instance.eating;
   }

   public boolean isEating() {
      return this.eating;
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.o();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.isActive() && mc.field_1755 == null) {
         int var2 = mc.field_1724.method_7344().method_7586();
         if (this.eating) {
            this.b(var2);
         } else if (var2 <= (int)this.hunger.getValue() && mc.field_1724.method_7332(false)) {
            this.n();
         }
      }
   }

   private void n() {
      int var1 = this.q();
      if (var1 != -1) {
         this.originalSlot = mc.field_1724.method_31548().method_67532();
         if (var1 < 9) {
            this.hotbarTargetSlot = var1;
            this.swappedInventorySlot = -1;
            if (mc.field_1724.method_31548().method_67532() != var1) {
               InventoryUtility.e(var1);
            }
         } else {
            int var2 = this.p();
            if (var2 != -1) {
               this.hotbarTargetSlot = var2;
            } else {
               this.hotbarTargetSlot = this.originalSlot;
            }

            this.swappedInventorySlot = var1;
            InventoryUtility.e(this.hotbarTargetSlot);
            if (mc.field_1761 != null && mc.field_1724.field_7512 != null) {
               mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var1, this.hotbarTargetSlot, class_1713.field_7791, mc.field_1724);
            }
         }

         this.eating = true;
         this.eatTicks = 0;
         if (mc.field_1690 != null) {
            mc.field_1690.field_1904.method_23481(true);
         }

         if (mc.field_1761 != null) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
         }
      }
   }

   private void b(int var1) {
      this.eatTicks++;
      class_1799 var2 = mc.field_1724.method_6047();
      if (!this.b(var2)) {
         this.o();
      } else if (var1 < 20 && (var1 <= (int)this.hunger.getValue() || mc.field_1724.method_7332(false))) {
         if (this.eatTicks > 8 && !mc.field_1724.method_6115()) {
            this.o();
         } else if (this.eatTicks > 45) {
            this.o();
         } else {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1904.method_23481(true);
            }

            if (!mc.field_1724.method_6115() && mc.field_1761 != null) {
               mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            }
         }
      } else {
         this.o();
      }
   }

   private void o() {
      if (this.eating) {
         if (mc.field_1690 != null) {
            mc.field_1690.field_1904.method_23481(false);
         }

         if (this.swappedInventorySlot != -1 && this.hotbarTargetSlot != -1) {
            if (mc.field_1761 != null && mc.field_1724 != null && mc.field_1724.field_7512 != null) {
               mc.field_1761
                  .method_2906(mc.field_1724.field_7512.field_7763, this.swappedInventorySlot, this.hotbarTargetSlot, class_1713.field_7791, mc.field_1724);
            }

            this.swappedInventorySlot = -1;
         }

         if (this.originalSlot != -1 && mc.field_1724 != null) {
            if (mc.field_1724.method_31548().method_67532() != this.originalSlot) {
               InventoryUtility.e(this.originalSlot);
            }

            this.originalSlot = -1;
         }

         this.eating = false;
         this.eatTicks = 0;
         this.hotbarTargetSlot = -1;
      }
   }

   private int p() {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         if (mc.field_1724.method_31548().method_5438(var1).method_7960()) {
            return var1;
         }
      }

      return -1;
   }

   private int q() {
      if (mc.field_1724 == null) {
         return -1;
      }

      int var1 = -1;
      int var2 = -1;

      for (int var3 = 0; var3 < 9; var3++) {
         class_1799 var4 = mc.field_1724.method_31548().method_5438(var3);
         int var5 = this.a(var4);
         if (var5 > var2) {
            var2 = var5;
            var1 = var3;
         }
      }

      if (var1 != -1) {
         return var1;
      }

      for (int var6 = 9; var6 < 36; var6++) {
         class_1799 var7 = mc.field_1724.method_31548().method_5438(var6);
         int var8 = this.a(var7);
         if (var8 > var2) {
            var2 = var8;
            var1 = var6;
         }
      }

      return var1;
   }

   private int a(class_1799 var1) {
      if (!this.b(var1)) {
         return -1;
      }

      class_4174 var2 = var1.method_58694(class_9334.field_50075);
      if (var2 == null) {
         return -1;
      }

      int var3 = var2.comp_2491() * 10 + (int)(var2.comp_2492() * 10.0F);
      if (var1.method_31574(class_1802.field_8071)) {
         var3 += 500;
      } else if (var1.method_31574(class_1802.field_8176)) {
         var3 += 400;
      } else if (var1.method_31574(class_1802.field_8261)) {
         var3 += 390;
      } else if (var1.method_31574(class_1802.field_8347)) {
         var3 += 300;
      } else if (var1.method_31574(class_1802.field_8509)) {
         var3 += 280;
      } else if (var1.method_31574(class_1802.field_8229)) {
         var3 += 250;
      } else if (var1.method_31574(class_1802.field_8512)) {
         var3 += 240;
      } else if (var1.method_31574(class_1802.field_8544)) {
         var3 += 230;
      }

      return var3;
   }

   private boolean b(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         class_4174 var2 = var1.method_58694(class_9334.field_50075);
         if (var2 == null) {
            return false;
         } else {
            return this.gapples.getValue() || !var1.method_31574(class_1802.field_8463) && !var1.method_31574(class_1802.field_8367)
               ? this.badFood.getValue()
                  || !var1.method_31574(class_1802.field_8511)
                     && !var1.method_31574(class_1802.field_8680)
                     && !var1.method_31574(class_1802.field_8323)
                     && !var1.method_31574(class_1802.field_8635)
                     && !var1.method_31574(class_1802.field_8233)
               : false;
         }
      } else {
         return false;
      }
   }
}
