package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import net.minecraft.class_2708;
import net.minecraft.class_2709;

@NewFunction(name = "NoRotate", description = "Запрещает серверу вращать камеру", category = Category.PLAYER)
public class NoRotate extends Function {
   @EventHandler
   public void onPacket(EventPacket var1) {
      if (mc.field_1724 != null && var1.getPacket() instanceof class_2708 var2) {
         var2.comp_3229().remove(class_2709.field_12397);
         var2.comp_3229().remove(class_2709.field_12401);
      }
   }
}
