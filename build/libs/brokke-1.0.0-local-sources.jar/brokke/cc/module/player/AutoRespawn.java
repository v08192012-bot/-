package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_418;

@NewFunction(name = "AutoRespawn", description = "Автоматическое возрождение при смерти", category = Category.PLAYER)
public class AutoRespawn extends Function {
   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && (mc.field_1724.method_29504() || mc.field_1724.method_6032() <= 0.0F || mc.field_1755 instanceof class_418)) {
         mc.field_1724.method_7331();
         if (mc.field_1755 instanceof class_418) {
            mc.method_1507(null);
         }
      }
   }
}
