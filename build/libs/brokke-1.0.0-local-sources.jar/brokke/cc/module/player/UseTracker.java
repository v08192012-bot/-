package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.animation.NotificationManager;
import brokke.cc.animation.NotificationType;
import brokke.cc.cosmetic.DonateItem;
import brokke.cc.manager.NbtDumpManager;
import brokke.cc.setting.MultiSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.EventPopTotem;
import brokke.cc.system.events.impl.PotionEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.ItemUtility;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2663;
import net.minecraft.class_2781;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import java.util.Map.Entry;

@NewFunction(name = "Tracker", description = "Отслеживает выбранные использования и уведомляет о них", category = Category.PLAYER)
public class UseTracker extends Function {
   private final MultiSetting track = new MultiSetting("Отслеживать", "Тотемы", "Зелья", "Предметы");
   public static final List<UseTracker.b> trackers = new ArrayList<>();
   private final Set<Integer> usedEntityIds = new HashSet<>();
   private final Map<UUID, Integer> poppedTotems = new HashMap<>();
   private final Map<UUID, Long> lastPopTimes = new HashMap<>();

   public UseTracker() {
      this.track.setOption("Тотема", true);
      this.track.setOption("Зелья", true);
      this.track.setOption("Предмета", true);
      this.addSettings(this.track);
   }

   @Override
   public void onDisable() {
      this.usedEntityIds.clear();
      trackers.clear();
      this.poppedTotems.clear();
      this.lastPopTimes.clear();
      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         boolean var2 = this.track.isOptionEnabled("Предмета");
         boolean var3 = this.track.isOptionEnabled("Зелья");
         if (var2 || var3) {
            for (class_1297 var5 : mc.field_1687.method_18112()) {
               if (var5 instanceof class_1657 var6 && var6 != mc.field_1724) {
                  class_1799 var7 = var6.method_6030();
                  boolean var8 = var7.method_7909() instanceof class_1812;
                  int var9 = var7.method_58694(class_9334.field_50075) == null && var7.method_7909() != class_1802.field_8103 ? 0 : 1;
                  int var10 = var8 && var3 || var9 != 0 && var2 ? 1 : 0;
                  if (var6.method_6115() && var10 != 0) {
                     if (var6.method_6014() <= 1) {
                        if (this.usedEntityIds.add(var6.method_5628())) {
                           String var11 = b(var7);
                           String var12 = var8 ? "§a" : "§c";
                           if (var7.method_31574(class_1802.field_8103)) {
                              trackers.removeIf(var1x -> var1x.getEntityId() == var6.method_5628());
                           }

                           this.c("§7[" + this.getName() + "] §f" + var6.method_5477().getString() + " использовал \"" + var12 + var11 + "§7\"");
                           NotificationManager.addNotification("Использование", var6.method_5477().getString() + " использовал " + var11, NotificationType.INFO, 1500L);
                        }
                     } else {
                        this.usedEntityIds.remove(var6.method_5628());
                     }
                  } else {
                     this.usedEntityIds.remove(var6.method_5628());
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onPotion(PotionEvent var1) {
      if (this.track.isOptionEnabled("Зелья") && var1.getType() == PotionEvent.Type.PARTICLES && mc.field_1687 != null) {
         for (UseTracker.a var5 : UseTracker.a.values()) {
            int[] var6 = var5.getThrowColors();
            int var7 = var6.length;

            for (int var8 = 0; var8 < var7; var8++) {
               int var9;
               if (((var9 = var6[var8]) & 16777215) == (var1.getData() & 16777215)) {
                  class_2338 var10 = var1.getPos();
                  class_243 var11 = var10.method_46558();
                  class_238 var12 = new class_238(var10.method_10263() - 4, var10.method_10264() - 4, var10.method_10260() - 4, var10.method_10263() + 5, var10.method_10264() + 5, var10.method_10260() + 5);

                  for (class_1657 var14 : mc.field_1687.method_8390(class_1657.class, var12, class_1309::method_5805)) {
                     class_238 var15 = var14.method_5829();
                     double var16;
                     if ((
                           var16 = 1.0
                              - Math.sqrt(
                                    Math.pow(var11.field_1352 - class_3532.method_15350(var11.field_1352, var15.field_1323, var15.field_1320), 2.0)
                                       + Math.pow(var11.field_1351 - class_3532.method_15350(var11.field_1351, var15.field_1322, var15.field_1325), 2.0)
                                       + Math.pow(var11.field_1350 - class_3532.method_15350(var11.field_1350, var15.field_1321, var15.field_1324), 2.0)
                                 )
                                 / 4.0
                        )
                        > 0.0) {
                        ArrayList var18 = new ArrayList();
                        int var19 = (int)(var16 * 100.0);
                        if (var14 != mc.field_1724) {
                           this.a(
                              class_2561.method_43470("§7[" + this.getName() + "] §f" + var14.method_5477().getString() + " получил эффекты от \"")
                                 .method_10852(var5.e())
                                 .method_10852(class_2561.method_43470("§7\""))
                           );
                           this.c("§7[" + this.getName() + "] §7- Успешность: §a" + var19 + "%");
                        } else {
                           this.a(
                              class_2561.method_43470("§7[" + this.getName() + "] §fВы получили эффекты от \"")
                                 .method_10852(var5.e())
                                 .method_10852(class_2561.method_43470("§7\" (" + var19 + "%)"))
                           );
                        }

                        NotificationManager.addNotification(
                           "Зелье", var14.method_5477().getString() + " получил " + var5.getDisplayName() + " (" + var19 + "%)", NotificationType.INFO, 2000L
                        );

                        for (Entry var21 : var5.getEffects()) {
                           int var22 = Math.max(0, class_3532.method_15357(((int[])var21.getValue())[0] * var16 + 0.5));
                           int var23 = ((int[])var21.getValue())[1];
                           if (var22 > 20) {
                              int var24 = var22 / 20;
                              if (var14 != mc.field_1724) {
                                 this.c(
                                    "§7["
                                       + this.getName()
                                       + "] §7- §c"
                                       + ((class_1291)((class_6880<?>)var21.getKey()).comp_349()).method_5560().getString()
                                       + " "
                                       + b(var23)
                                       + " §7("
                                       + var24 / 60
                                       + ":"
                                       + String.format(Locale.ROOT, "%02d", var24 % 60)
                                       + ")"
                                 );
                              }

                              if (((class_6880<?>)var21.getKey()).equals(class_1294.field_5919)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5910)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5909)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5920)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5899)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5911)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5924)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5914)
                                 || ((class_6880<?>)var21.getKey()).equals(class_1294.field_5907)) {
                                 var18.add(new class_1293((class_6880<class_1291>)var21.getKey(), var22, var23));
                              }
                           }
                        }

                        if (!var18.isEmpty()) {
                           trackers.add(new UseTracker.b(List.copyOf(var18), var14.method_5628(), var14.field_6012));
                        }
                     }
                  }

                  return;
               }
            }
         }
      }
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (mc.field_1687 != null) {
         if (var1.getPacket() instanceof class_2781 var2) {
            for (net.minecraft.class_2781.class_2782 var4 : var2.method_11938()) {
               if (var4.comp_2177().method_40230().toString().contains("minecraft:movement_speed")) {
                  for (class_1322 var6 : var4.comp_2179()) {
                     if (mc.field_1687.method_8469(var2.method_11937()) instanceof class_1657
                        && var6.comp_2447().toString().equals("minecraft:effect.speed")
                        && var6.comp_2449() <= 0.40000001199465773
                        && var6.comp_2450() == class_1323.field_6331) {
                        trackers.removeIf(var1x -> var1x.getEntityId() == var2.method_11937());
                     }
                  }
               }
            }
         }

         if (var1.getPacket() instanceof class_2663 var7 && var7.method_11469(mc.field_1687) instanceof class_1657 var11 && var7.method_11470() == 3) {
            this.poppedTotems.remove(var11.method_5667());
            this.lastPopTimes.remove(var11.method_5667());
         }
      }
   }

   @EventHandler
   public void onPopTotem(EventPopTotem var1) {
      class_1657 var2 = var1.getPlayer();
      long var3;
      if (var2 != null && mc.field_1687 != null && (var3 = System.currentTimeMillis()) - this.lastPopTimes.getOrDefault(var2.method_5667(), 0L) >= 100L) {
         this.lastPopTimes.put(var2.method_5667(), var3);
         trackers.removeIf(var1x -> var1x.getEntityId() == var2.method_5628());
         if (this.track.isOptionEnabled("Тотема") || this.track.isOptionEnabled("Тотем") || this.track.isOptionEnabled("Тотемы")) {
            class_1799 var5 = var2.method_6047().method_7909() == class_1802.field_8288
               ? var2.method_6047()
               : (var2.method_6079().method_7909() == class_1802.field_8288 ? var2.method_6079() : null);
            if (var5 == null) {
               var5 = new class_1799(class_1802.field_8288);
            }

            String var6 = a(var5);
            String var8 = var6.startsWith("Талисман") || var5.method_7958() || var5.method_7942() ? "§a●§7" : "§c●§7";
            if (var2 == mc.field_1724) {
               int var9;
               String var10 = (var9 = this.poppedTotems.merge(mc.field_1724.method_5667(), 1, Integer::sum)) > 1 ? "§6" + var9 + "x " : "";
               this.c("§7[" + this.getName() + "] §fВы использовали " + var10 + "тотем §7(\"" + var6 + "§7\", зачарован: " + var8 + ")");
               NotificationManager.addNotification("Тотем", "Вы использовали " + var10 + "тотем (" + var6 + ")", NotificationType.WARNING, 2000L);
            } else {
               int var11;
               String var12 = (var11 = this.poppedTotems.merge(var2.method_5667(), 1, Integer::sum)) > 1 ? "§6" + var11 + "x " : "";
               this.c(
                  "§7["
                     + this.getName()
                     + "] §fВы дали "
                     + var12
                     + "тотем §e"
                     + var2.method_5477().getString()
                     + " §7(\""
                     + var6
                     + "§7\", зачарован: "
                     + var8
                     + ")"
               );
               NotificationManager.addNotification("Тотем", "Вы дали " + var12 + "тотем " + var2.method_5477().getString() + " (" + var6 + ")", NotificationType.WARNING, 2000L);
            }
         }
      }
   }

   public static String a(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         String var1 = NbtDumpManager.a(var0);
         if (var1 != null && !var1.isEmpty()) {
            return var1;
         }

         String var2 = ItemUtility.p(var0);
         return var2 != null && !var2.isEmpty() ? var2 : ItemUtility.b(var0.method_7964().getString());
      } else {
         return "Тотем";
      }
   }

   public static String b(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         String var1 = NbtDumpManager.a(var0);
         if (var1 != null && !var1.isEmpty()) {
            return var1;
         }

         DonateItem var2 = ItemUtility.e(var0);
         if (var2 != null) {
            String var3 = b(var2.getName());
            if (var3 != null && !var3.isEmpty()) {
               return var3;
            }
         }

         class_2561 var14 = var0.method_58694(class_9334.field_49631);
         if (var14 == null) {
            var14 = var0.method_58694(class_9334.field_50239);
         }

         String var4 = var14 != null ? b(var14.getString()) : "";
         if (!var4.isEmpty() && !a(var4)) {
            return var4;
         }

         String var5 = b(var0.method_7964().getString());
         if (!var5.isEmpty() && !a(var5)) {
            return var5;
         }

         if (var0.method_7909() instanceof class_1812) {
            class_9290 var6 = var0.method_58694(class_9334.field_49632);
            if (var6 != null) {
               for (class_2561 var8 : var6.comp_2400()) {
                  String var9 = b(var8.getString());
                  if (var9.toLowerCase().contains("зелье")
                     || var9.toLowerCase().contains("вода")
                     || var9.toLowerCase().contains("снотворное")
                     || var9.toLowerCase().contains("хлопушка")) {
                     return var9;
                  }
               }
            }

            class_1844 var15 = var0.method_58694(class_9334.field_49651);
            if (var15 != null) {
               ArrayList var16 = new ArrayList();
               var15.method_57397().forEach(var16::add);
               String var17 = a(var16);
               if (var17 != null) {
                  return var17;
               }

               ArrayList var10 = new ArrayList();

               for (class_1293 var12 : (Iterable<class_1293>)(Iterable<?>)(var16)) {
                  String var13 = var12.method_5579().comp_349().method_5560().getString();
                  if (var12.method_5578() > 0) {
                     var13 = var13 + " " + b(var12.method_5578());
                  }

                  var10.add(var13);
               }

               if (!var10.isEmpty()) {
                  return "Зелье (" + String.join(", ", var10) + ")";
               }
            }
         }

         return !var5.isEmpty() ? var5 : var0.method_7909().method_63680().getString();
      } else {
         return "";
      }
   }

   private static boolean a(String var0) {
      if (var0 != null && !var0.isBlank()) {
         String var1 = var0.toLowerCase().trim();
         return var1.equals("зелье")
            || var1.equals("potion")
            || var1.equals("несоздаваемое зелье")
            || var1.equals("uncraftable potion")
            || var1.equals("взрывное зелье")
            || var1.equals("splash potion")
            || var1.equals("оседающее зелье")
            || var1.equals("lingering potion");
      } else {
         return true;
      }
   }

   private static String a(List<class_1293> var0) {
      if (var0 != null && !var0.isEmpty()) {
         for (UseTracker.a var4 : UseTracker.a.values()) {
            byte var5 = 1;

            for (Entry var7 : var4.getEffects()) {
               byte var8 = 0;

               for (class_1293 var10 : var0) {
                  if (var10.method_5579().equals(var7.getKey())) {
                     var8 = 1;
                     break;
                  }
               }

               if (var8 == 0) {
                  var5 = 0;
                  break;
               }
            }

            if (var5 != 0) {
               return var4.getDisplayName();
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static String b(String var0) {
      if (var0 == null) {
         return "";
      }

      String var1 = var0.replaceAll("(?i)§[0-9a-fk-or]", "").replaceAll("(?i)&[0-9a-fk-or]", "");
      var1 = var1.replaceAll("[\\uE000-\\uF8FF]", "");
      var1 = var1.replaceAll("[\\?\\uFFFD]+", "");
      return var1.trim();
   }

   private static String b(int var0) {
      String[] var1 = new String[]{"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
      return var0 >= 0 && var0 < var1.length ? var1[var0] : String.valueOf(var0 + 1);
   }

   private void c(String var1) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_7353(class_2561.method_43470(var1), false);
      }
   }

   private void a(class_5250 var1) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_7353(var1, false);
      }
   }

   public MultiSetting getTrack() {
      return this.track;
   }

   public Set<Integer> getUsedEntityIds() {
      return this.usedEntityIds;
   }

   public Map<UUID, Integer> getPoppedTotems() {
      return this.poppedTotems;
   }

   public Map<UUID, Long> getLastPopTimes() {
      return this.lastPopTimes;
   }

   public enum a {
      POPPER_POTION(
         List.of(
            Map.entry(class_1294.field_5909, new int[]{200, 9}),
            Map.entry(class_1294.field_5904, new int[]{300, 4}),
            Map.entry(class_1294.field_5919, new int[]{100, 9}),
            Map.entry(class_1294.field_5912, new int[]{3600, 0})
         ),
         "[★] Хлопушка",
         new int[]{16738740},
         new int[]{16711765, 16727869, 16743972, 16760076, 14410269, 9628759, 4846994, 65484}
      ),
      HOLY_WATER(
         List.of(
            Map.entry(class_1294.field_5924, new int[]{900, 1}),
            Map.entry(class_1294.field_5905, new int[]{12000, 1}),
            Map.entry(class_1294.field_5915, new int[]{0, 2})
         ),
         "[★] Святая вода",
         new int[]{16777215},
         new int[]{16777163, 16777148, 16777132, 16777117, 16777102, 16777087, 16776815, 16776800, 16776785, 16776769, 16776754}
      ),
      RAGE_POTION(
         List.of(Map.entry(class_1294.field_5910, new int[]{600, 4}), Map.entry(class_1294.field_5909, new int[]{600, 3})),
         "[★] Зелье Гнева",
         new int[]{10040115},
         new int[]{9109504, 10620416, 12131328, 13707520, 15218432, 16729344, 16732928, 16736512, 16740352, 16743936, 16747520}
      ),
      PALLADIN_POTION(
         List.of(
            Map.entry(class_1294.field_5907, new int[]{12000, 0}),
            Map.entry(class_1294.field_5918, new int[]{12000, 0}),
            Map.entry(class_1294.field_5914, new int[]{1200, 2}),
            Map.entry(class_1294.field_5905, new int[]{18000, 2})
         ),
         "[★] Зелье Палладина",
         new int[]{65535},
         new int[]{
            13762395,
            14090092,
            14417789,
            14745486,
            15007648,
            15335345,
            15663042,
            15990739,
            15663042,
            15335345,
            15007648,
            14745486,
            14417789,
            14090092,
            13762395
         }
      ),
      ASSASSIN_POTION(
         List.of(
            Map.entry(class_1294.field_5910, new int[]{1200, 3}),
            Map.entry(class_1294.field_5904, new int[]{6000, 2}),
            Map.entry(class_1294.field_5917, new int[]{1200, 0}),
            Map.entry(class_1294.field_5921, new int[]{0, 1})
         ),
         "[★] Зелье Ассасина",
         new int[]{3355443},
         new int[]{4277061, 4603456, 4929850, 5256245, 5516848, 5843242, 6169637, 6496032, 6822427, 7148821, 7409424, 7735819, 8062213, 8388608}
      ),
      RADIATION_POTION(
         List.of(
            Map.entry(class_1294.field_5899, new int[]{1200, 1}),
            Map.entry(class_1294.field_5920, new int[]{1200, 1}),
            Map.entry(class_1294.field_5909, new int[]{1800, 2}),
            Map.entry(class_1294.field_5903, new int[]{1200, 4}),
            Map.entry(class_1294.field_5912, new int[]{2400, 0})
         ),
         "[★] Зелье Радиации",
         new int[]{3329330},
         new int[]{16774970, 16250192, 15659878, 15135100, 14545043, 14020265, 13429951, 12905919, 12382378, 11858836, 11269759, 10746217, 10222676, 9699134}
      ),
      SLEEPING_PILL(
         List.of(
            Map.entry(class_1294.field_5911, new int[]{1800, 1}),
            Map.entry(class_1294.field_5901, new int[]{200, 1}),
            Map.entry(class_1294.field_5920, new int[]{1800, 2}),
            Map.entry(class_1294.field_5919, new int[]{200, 0})
         ),
         "[★] Снотворное",
         new int[]{255, 4737096},
         new int[]{4132250, 3219615, 2306725, 1394090, 481455, 812728, 2322884, 3833041, 5408733, 6918889}
      );

      private final List<Entry<class_6880<class_1291>, int[]>> effects;
      private final String displayName;
      private final int[] throwColors;
      private final int[] nameColors;

      a(List<Entry<class_6880<class_1291>, int[]>> nullxx, String nullxxx, int[] nullxxxx, int[] nullxxxxx) {
         this.effects = nullxx;
         this.displayName = nullxxx;
         this.throwColors = nullxxxx;
         this.nameColors = nullxxxxx;
      }

      public List<Entry<class_6880<class_1291>, int[]>> getEffects() {
         return this.effects;
      }

      public String getDisplayName() {
         return this.displayName;
      }

      public int[] getThrowColors() {
         return this.throwColors;
      }

      public int[] getNameColors() {
         return this.nameColors;
      }

      public class_5250 e() {
         int var1 = this.displayName.indexOf(32) + 1;
         class_5250 var2 = class_2561.method_43470("");

         for (int var3 = 0; var3 < this.displayName.length(); var3++) {
            int var4 = var3 < var1 ? this.nameColors[0] : this.nameColors[Math.min(var3 - var1, this.nameColors.length - 1)];
            var2.method_10852(class_2561.method_43470(String.valueOf(this.displayName.charAt(var3))).method_10862(class_2583.field_24360.method_36139(var4).method_10982(true)));
         }

         return var2;
      }
   }

   public record b(List<class_1293> effects, int entityId, int age) {
      public List<class_1293> getEffects() {
         return this.effects;
      }

      public int getEntityId() {
         return this.entityId;
      }

      public int getAge() {
         return this.age;
      }
   }
}
