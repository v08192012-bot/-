package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.HandlerProcessor;
import brokke.cc.setting.BindSetting;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.KeyEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.DeltaInventoryUtil;
import java.util.List;
import net.minecraft.class_10192;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;

@NewFunction(name = "Elytra Helper", description = "Помощник с элитрами", category = Category.PLAYER)
public class ElytraUtils extends Function {
   private final BindSetting swapKey = new BindSetting("Свап на элитры", -1);
   private final BindSetting fireworkKey = new BindSetting("Фейерверк", -1);
   private final BooleanSetting startSetting = new BooleanSetting("Быстрый старт", false);
   private final BooleanSetting sprintSetting = new BooleanSetting("Спринт", false);
   private final BooleanSetting onlyHotBar = new BooleanSetting("Только хотбар", false);
   private final BooleanSetting autoFirework = new BooleanSetting("Авто-фейерверк", false);
   private final NumberSetting autoFireworkDelay = new NumberSetting("Задержка", 250.0, 100.0, 1000.0, 25.0);
   private long lastFireworkTime = 0L;
   private boolean prevJump = false;
   private static final List<class_1792> CHESTPLATE_TIERS = List.of(
      class_1802.field_22028,
      class_1802.field_8058,
      class_1802.field_8873,
      class_1802.field_8523,
      class_1802.field_8678,
      class_1802.field_8577
   );

   public ElytraUtils() {
      this.addSettings(this.swapKey, this.fireworkKey, this.startSetting, this.sprintSetting, this.onlyHotBar, this.autoFirework, this.autoFireworkDelay);
      this.startSetting.onChanged(this::k);
      this.autoFirework.onChanged(this::k);
      this.k();
   }

   private void k() {
      this.sprintSetting.setVisible(this.startSetting.isToggled());
      this.autoFireworkDelay.setVisible(this.autoFirework.isToggled());
   }

   @Override
   public void onDisable() {
      this.lastFireworkTime = 0L;
      this.prevJump = false;
      super.onDisable();
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.getAction() == 1 && mc.field_1755 == null && mc.field_1724 != null) {
         if (this.swapKey.getKey() != -1 && this.swapKey.getKey() == var1.getKey()) {
            this.l();
         } else if (this.fireworkKey.getKey() != -1 && this.fireworkKey.getKey() == var1.getKey() && mc.field_1724.method_6128()) {
            this.n();
         }
      }
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      if (mc.field_1724 != null && mc.field_1724.method_5805() && mc.field_1724.field_7512 instanceof class_1723 && this.startSetting.isToggled()) {
         class_1799 var2 = mc.field_1724.method_6118(class_1304.field_6174);
         if (var2.method_31574(class_1802.field_8833)) {
            if (mc.field_1724.method_24828()) {
               var1.setJump(true);
               this.prevJump = true;
            } else if (!mc.field_1724.method_6128()) {
               if (this.sprintSetting.isToggled()
                  && (mc.field_1724.method_7344().method_7586() > 6 || mc.field_1724.method_31549().field_7478)
                  && !mc.field_1724.field_5976
                  && !mc.field_1724.method_6059(class_1294.field_5919)
                  && !mc.field_1724.method_6115()
                  && !mc.field_1724.method_5869()) {
                  mc.field_1724.method_5728(true);
               }

               var1.setJump(!this.prevJump);
               this.prevJump = var1.isJump();
            } else if (mc.field_1724.method_6128() && mc.field_1724.field_5976) {
               var1.setForward(0.0F);
            }
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      long var2;
      if (mc.field_1724 != null
         && mc.field_1687 != null
         && mc.field_1724.field_7512 instanceof class_1723
         && this.autoFirework.isToggled()
         && mc.field_1724.method_6128()
         && (var2 = System.currentTimeMillis()) - this.lastFireworkTime >= (long)this.autoFireworkDelay.getValue()) {
         this.n();
         this.lastFireworkTime = var2;
      }
   }

   private void l() {
      if (mc.field_1724 != null && mc.field_1724.field_7512 instanceof class_1723) {
         int var2;
         if (mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833)) {
            var2 = this.onlyHotBar.isToggled() ? this.m() : DeltaInventoryUtil.a();
         } else {
            var2 = this.onlyHotBar.isToggled() ? DeltaInventoryUtil.a(class_1802.field_8833, true) : DeltaInventoryUtil.b(class_1802.field_8833);
         }

         if (var2 != -1) {
            HandlerProcessor.a().getInventoryHandler().b(var2, 1, 1);
         }
      }
   }

   private int m() {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         class_1799 var2 = mc.field_1724.method_31548().method_5438(var1);
         if (a(var2)) {
            return var1;
         }
      }

      return -1;
   }

   private void n() {
      if (mc.field_1724 != null && mc.field_1724.method_6128()) {
         HandlerProcessor.a().getUseableHandler().a(class_1802.field_8639.method_7854());
      }
   }

   private static boolean a(class_1799 var0) {
      if (var0 == null || var0.method_7960() || var0.method_31574(class_1802.field_8833)) {
         return false;
      }

      if (var0.method_58694(class_9334.field_54197) != null) {
         return false;
      }

      class_10192 var1 = var0.method_58694(class_9334.field_54196);
      return var1 != null ? var1.comp_3174() == class_1304.field_6174 : CHESTPLATE_TIERS.contains(var0.method_7909());
   }
}
