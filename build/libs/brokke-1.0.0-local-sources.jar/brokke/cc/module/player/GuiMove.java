package brokke.cc.module.player;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.Timer2;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.SendPacketEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.ui.ClickGui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_306;
import net.minecraft.class_3675.class_307;
import net.minecraft.class_408;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_498;
import org.lwjgl.glfw.GLFW;

@NewFunction(name = "GuiMove", description = "Позволяет двигаться в открытых меню", category = Category.PLAYER)
public class GuiMove extends Function {
   public static boolean bypassQueue = false;
   private final List<class_2596<?>> packets = new ArrayList<>();
   private final ModeSetting mode = new ModeSetting("Режим", "HolyWorld", "Grim", "Visual", "Vanilla");
   private final Timer2 timer = new Timer2();
   private int ticksDelay = 0;
   private boolean needSend = false;
   private boolean hasQueuedClicks = false;
   private boolean sending = false;

   public GuiMove() {
      this.addSettings(this.mode);
      this.setEnabled(true);
   }

   @Override
   public void onDisable() {
      this.packets.clear();
      this.ticksDelay = 0;
      this.needSend = false;
      this.hasQueuedClicks = false;
      this.sending = false;
      bypassQueue = false;
      this.n();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null) {
         if (this.ticksDelay > 0) {
            this.ticksDelay--;
         }

         if (!this.mode.isMode("HolyWorld") && !this.mode.isMode("Vanilla")) {
            if (!this.mode.isMode("Grim")) {
               if (this.mode.isMode("Visual") && !this.k()) {
                  this.m();
               }
            } else if ((this.ticksDelay <= 0 || this.timer.a(99L))
               && (mc.field_1755 == null || mc.field_1755 instanceof class_490 || mc.field_1755 instanceof class_481)) {
               this.m();
               if (this.needSend && this.ticksDelay == 0) {
                  this.l();
                  this.needSend = false;
                  this.hasQueuedClicks = false;
               }
            }
         } else if (!this.o() && this.p()) {
            this.m();
         }
      }
   }

   @EventHandler
   public void onSendPacket(SendPacketEvent var1) {
      if (!this.sending && !this.mode.isMode("HolyWorld") && !this.mode.isMode("Vanilla") && !bypassQueue && this.mode.isMode("Grim")) {
         if (var1.getPacket() instanceof class_2813 var2) {
            if (mc.field_1755 == null) {
               this.packets.add(var2);
               var1.cancel();
               this.hasQueuedClicks = true;
               this.ticksDelay = 2;
               this.needSend = true;
               this.timer.a();
               return;
            }

            if (mc.field_1755 instanceof class_490 && this.k()) {
               this.packets.add(var2);
               var1.cancel();
               return;
            }
         }

         if (var1.getPacket() instanceof class_2815 && this.k()) {
            if (!this.packets.isEmpty()) {
               this.hasQueuedClicks = true;
               this.ticksDelay = 2;
               this.needSend = true;
               this.timer.a();
            }

            var1.cancel();
         }
      }
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      if (mc.field_1755 instanceof class_465 || mc.field_1755 instanceof ClickGui) {
         var1.setSneak(false);
      }

      if (this.mode.isMode("Grim") && this.ticksDelay > 0 && !this.timer.a(195L)) {
         var1.setForward(0.0F);
         var1.setStrafe(0.0F);
         var1.setJump(false);
         var1.setSneak(false);
         var1.setSprint(false);
      }
   }

   private boolean k() {
      return mc.field_1724 == null ? false : mc.field_1724.field_6250 != 0.0F || mc.field_1724.field_6212 != 0.0F;
   }

   private void l() {
      if (!this.packets.isEmpty() && mc.field_1724 != null && mc.field_1724.field_3944 != null) {
         this.sending = true;

         for (class_2596 var2 : this.packets) {
            mc.field_1724.field_3944.method_52787(var2);
         }

         int var3 = mc.field_1724.field_7512 != null ? mc.field_1724.field_7512.field_7763 : 0;
         mc.field_1724.field_3944.method_52787(new class_2815(var3));
         this.packets.clear();
         this.sending = false;
      }
   }

   private void m() {
      if (mc.field_1690 != null && mc.method_22683() != null && !this.o() && this.p()) {
         class_1041 var1 = mc.method_22683();
         int var2;
         class_304[] var3 = (var2 = !(mc.field_1755 instanceof class_465) && !(mc.field_1755 instanceof ClickGui) ? 0 : 1) != 0
            ? new class_304[]{mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913, mc.field_1690.field_1849, mc.field_1690.field_1903, mc.field_1690.field_1867}
            : new class_304[]{
               mc.field_1690.field_1894,
               mc.field_1690.field_1881,
               mc.field_1690.field_1913,
               mc.field_1690.field_1849,
               mc.field_1690.field_1903,
               mc.field_1690.field_1832,
               mc.field_1690.field_1867
            };
         if (var2 != 0) {
            mc.field_1690.field_1832.method_23481(false);
         }

         for (class_304 var7 : var3) {
            class_306 var8 = class_3675.method_15981(var7.method_1428());
            if (var8.method_1442() == class_307.field_1668) {
               var7.method_23481(class_3675.method_15987(var1, var8.method_1444()));
            } else if (var8.method_1442() == class_307.field_1672) {
               var7.method_23481(GLFW.glfwGetMouseButton(var1.method_4490(), var8.method_1444()) == 1);
            }
         }
      }
   }

   private void n() {
      if (mc.field_1690 != null) {
         class_304[] var1 = new class_304[]{
            mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913, mc.field_1690.field_1849, mc.field_1690.field_1903, mc.field_1690.field_1832, mc.field_1690.field_1867
         };

         for (class_304 var5 : var1) {
            var5.method_23481(false);
         }
      }
   }

   private boolean o() {
      return mc.field_1755 instanceof ClickGui var1
         ? var1.r()
         : mc.field_1755 instanceof class_408 || mc.field_1755 instanceof class_498 || mc.field_1755 instanceof class_471;
   }

   private boolean p() {
      return mc.field_1755 instanceof class_465 || mc.field_1755 instanceof ClickGui || mc.field_1755 != null;
   }
}
