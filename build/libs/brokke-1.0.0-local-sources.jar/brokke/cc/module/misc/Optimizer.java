package brokke.cc.module.misc;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import net.minecraft.class_10017;
import net.minecraft.class_11954;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

@NewFunction(name = "Optimizer", description = "Не рендерит объекты позади камеры для повышения FPS", category = Category.MISC)
public class Optimizer extends Function {
   public final BooleanSetting cullEntities = new BooleanSetting("Сущности", true);
   public final BooleanSetting cullBlockEntities = new BooleanSetting("Блок-сущности", true);
   public final BooleanSetting cullParticles = new BooleanSetting("Частицы", true);
   public final NumberSetting safetyMargin = new NumberSetting("Отступ (блоки)", 1.0, 0.0, 4.0, 0.5);
   private static double camX;
   private static double camY;
   private static double camZ;
   private static double lookX;
   private static double lookY;
   private static double lookZ;
   private static boolean cameraValid = false;
   private static Optimizer INSTANCE;

   public Optimizer() {
      INSTANCE = this;
      this.addSettings(this.cullEntities, this.cullBlockEntities, this.cullParticles, this.safetyMargin);
      this.setEnabled(true);
   }

   public static Optimizer k() {
      if (INSTANCE == null) {
         INSTANCE = FunctionManager.a(Optimizer.class);
      }

      return INSTANCE;
   }

   public static boolean l() {
      Optimizer var0 = k();
      return var0 != null && var0.isActive() && var0.cullEntities.getValue();
   }

   public static boolean m() {
      Optimizer var0 = k();
      return var0 != null && var0.isActive() && var0.cullBlockEntities.getValue();
   }

   public static boolean n() {
      Optimizer var0 = k();
      return var0 != null && var0.isActive() && var0.cullParticles.getValue();
   }

   public static double o() {
      Optimizer var0 = k();
      return var0 != null ? var0.safetyMargin.getValue() : 1.0;
   }

   public static void a(class_4184 var0) {
      if (var0 == null) {
         cameraValid = false;
      } else {
         class_243 var1 = var0.method_71156();
         camX = var1.field_1352;
         camY = var1.field_1351;
         camZ = var1.field_1350;
         float var2 = var0.method_19330();
         float var3 = var0.method_19329();
         double var4 = Math.toRadians(var2);
         double var6 = Math.toRadians(var3);
         lookX = -Math.sin(var4) * Math.cos(var6);
         lookY = -Math.sin(var6);
         lookZ = Math.cos(var4) * Math.cos(var6);
         cameraValid = true;
      }
   }

   private static void p() {
      if (!cameraValid) {
         class_310 var0 = class_310.method_1551();
         if (var0.field_1773 != null && var0.field_1773.method_19418() != null) {
            a(var0.field_1773.method_19418());
         }
      }
   }

   public static boolean a(double var0, double var2, double var4, double var6) {
      p();
      if (!cameraValid) {
         return false;
      }

      double var8 = var0 * lookX + var2 * lookY + var4 * lookZ;
      return var8 < -var6;
   }

   public static boolean a(class_1297 var0, double var1, double var3, double var5) {
      if (l() && var0 != null) {
         class_310 var7 = class_310.method_1551();
         if (var0 == var7.field_1724) {
            return false;
         }

         double var8 = var0.method_23317() - var1;
         double var10 = var0.method_23318() - var3;
         double var12 = var0.method_23321() - var5;
         double var14 = Math.max(var0.method_17681(), var0.method_17682()) * 0.75;
         return a(var8, var10, var12, var14 + o());
      } else {
         return false;
      }
   }

   public static boolean a(class_10017 var0, double var1, double var3, double var5) {
      if (l() && var0 != null) {
         double var7 = Math.max(var0.field_53329, var0.field_53330) * 0.75;
         return a(var1, var3, var5, var7 + o());
      } else {
         return false;
      }
   }

   public static boolean a(class_11954 var0) {
      if (m() && var0 != null) {
         class_2338 var1 = var0.field_62673;
         if (var1 == null) {
            return false;
         }

         p();
         if (!cameraValid) {
            return false;
         }

         double var2 = var1.method_10263() + 0.5 - camX;
         double var4 = var1.method_10264() + 0.5 - camY;
         double var6 = var1.method_10260() + 0.5 - camZ;
         return a(var2, var4, var6, 1.0 + o());
      } else {
         return false;
      }
   }

   public static boolean a(double var0, double var2, double var4) {
      if (!n()) {
         return false;
      }

      p();
      if (!cameraValid) {
         return false;
      }

      double var6 = var0 - camX;
      double var8 = var2 - camY;
      double var10 = var4 - camZ;
      return a(var6, var8, var10, o());
   }
}
