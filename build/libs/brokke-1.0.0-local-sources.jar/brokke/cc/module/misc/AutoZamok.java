package brokke.cc.module.misc;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.player.AutoEat;
import brokke.cc.core.Timer2;
import brokke.cc.mixins.interfaces.IClientPlayerInteractionManager;
import brokke.cc.nav.GoalNear;
import brokke.cc.nav.GotoTask;
import brokke.cc.nav.NavigationManager;
import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationStorage;
import brokke.cc.setting.FloatSetting;
import brokke.cc.setting.TextSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.GCDUtil2;
import brokke.cc.util.HotbarUtil;
import brokke.cc.util.InventoryUtility;
import brokke.cc.util.PotionUtility;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1828;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2531;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2745;
import net.minecraft.class_3532;
import net.minecraft.class_3708;
import net.minecraft.class_3965;
import net.minecraft.class_418;
import net.minecraft.class_476;
import net.minecraft.class_7439;
import net.minecraft.class_9334;

@NewFunction(name = "AutoZamok", description = "Автоматический сбор шалкеров на Замке", category = Category.MISC)
public class AutoZamok extends Function {
   private static final class_243[] SHULKER_SPAWNS = new class_243[]{
      new class_243(-5.5, 64.0, 6.4),
      new class_243(-5.5, 64.0, -5.6),
      new class_243(0.4, 64.0, -12.5),
      new class_243(6.5, 64.0, -5.3),
      new class_243(13.4, 64.0, 0.5),
      new class_243(6.3, 64.0, 6.5),
      new class_243(6.5, 83.0, 6.4),
      new class_243(15.4, 79.0, 15.4),
      new class_243(15.5, 79.0, -14.5),
      new class_243(-5.5, 83.0, -5.5),
      new class_243(-14.5, 79.0, 15.6),
      new class_243(-5.5, 83.0, 6.5)
   };
   private static final class_2338 ZAMOK_CENTER_POS = new class_2338(14, 64, 0);
   public final TextSetting homeSklad = new TextSetting("Дом склада", "sklad");
   public final TextSetting homeZamok = new TextSetting("Дом замка", "zamok");
   public final FloatSetting tpWarmupDelay = new FloatSetting("Задержка телепорта", 4.5F, 3.0F, 10.0F, 0.5F);
   public final FloatSetting tpCooldownDelay = new FloatSetting("Кулдаун телепорта", 4.0F, 1.0F, 15.0F, 0.5F);
   public final FloatSetting chestDelay = new FloatSetting("Задержка сундука", 150.0F, 50.0F, 500.0F, 25.0F);
   public final FloatSetting potionDelay = new FloatSetting("Задержка зелий", 500.0F, 200.0F, 1500.0F, 50.0F);
   public final FloatSetting postTpDelay = new FloatSetting("Пауза после ТП", 1.0F, 0.2F, 3.0F, 0.1F);
   private AutoZamok.a state = AutoZamok.a.IDLE;
   private final Timer2 actionTimer = new Timer2();
   private final Timer2 drinkTimer = new Timer2();
   private final Timer2 slotActionTimer = new Timer2();
   private final Timer2 patrolPointTimer = new Timer2();
   private final Timer2 fleeTimer = new Timer2();
   private final Timer2 fleeRepathTimer = new Timer2();
   private final List<class_2338> chestQueue = new ArrayList<>();
   private final List<Integer> visitedPatrolSpawns = new ArrayList<>();
   private int currentChestIndex = 0;
   private int currentPatrolTargetIndex = -1;
   private class_2338 currentTargetChest = null;
   private class_2338 currentShulkerPos = null;
   private float lastPlayerHealth = 20.0F;
   private class_1657 fleeingFromPlayer = null;
   private long nextAllowedTpTime = 0L;
   private boolean tpFailedCooldown = false;
   private boolean tpCancelled = false;

   public AutoZamok() {
      this.addSettings(this.homeSklad, this.homeZamok, this.tpWarmupDelay, this.tpCooldownDelay, this.chestDelay, this.potionDelay, this.postTpDelay);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.chestQueue.clear();
      this.currentChestIndex = 0;
      this.currentTargetChest = null;
      this.currentShulkerPos = null;
      this.visitedPatrolSpawns.clear();
      this.currentPatrolTargetIndex = -1;
      this.tpFailedCooldown = false;
      this.tpCancelled = false;
      this.lastPlayerHealth = mc.field_1724 != null ? mc.field_1724.method_6032() : 20.0F;
      this.fleeingFromPlayer = null;
      this.fleeTimer.a();
      this.fleeRepathTimer.a();
      this.actionTimer.a();
      this.slotActionTimer.a();
      this.patrolPointTimer.a();
      this.state = AutoZamok.a.TP_TO_SKLAD;
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.state = AutoZamok.a.IDLE;
      this.visitedPatrolSpawns.clear();
      this.currentPatrolTargetIndex = -1;
      this.fleeingFromPlayer = null;
      if (mc.field_1690 != null) {
         mc.field_1690.field_1904.method_23481(false);
         mc.field_1690.field_1886.method_23481(false);
      }

      this.k();
      this.ab();
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (this.isActive()) {
         if (var1.getPacket() instanceof class_7439 var2) {
            String var4 = var2.comp_763().getString();
            this.a(var4);
         } else if (var1.getPacket() instanceof class_2708) {
            this.nextAllowedTpTime = System.currentTimeMillis() + (long)(this.tpCooldownDelay.getFloatValue() * 1000.0F);
         }
      }
   }

   private void a(String var1) {
      if (var1 != null) {
         String var2 = var1.toLowerCase(Locale.ROOT);
         if (var2.contains("времени до следующей телепортации")) {
            Matcher var3 = Pattern.compile("(\\d+)").matcher(var2);
            long var4 = 2L;
            if (var3.find()) {
               try {
                  var4 = Long.parseLong(var3.group(1));
               } catch (Exception var7) {
               }
            }

            this.nextAllowedTpTime = System.currentTimeMillis() + (var4 + 1L) * 1000L + 500L;
            this.tpFailedCooldown = true;
            this.d("§cКулдаун телепортации: " + var4 + " сек. Ожидание...");
         } else if (var2.contains("телепортация отменена")) {
            this.tpCancelled = true;
            this.nextAllowedTpTime = System.currentTimeMillis() + 1500L;
            this.d("§cТелепортация была отменена сервером. Повтор...");
         } else if (var2.contains("телепортирование к") || var2.contains("телепортирование начинается")) {
            this.nextAllowedTpTime = System.currentTimeMillis() + (long)(this.tpCooldownDelay.getFloatValue() * 1000.0F);
         }
      }
   }

   private void k() {
      NavigationManager.getInstance().c();
      if (mc.field_1690 != null) {
         mc.field_1690.field_1894.method_23481(false);
         mc.field_1690.field_1881.method_23481(false);
         mc.field_1690.field_1913.method_23481(false);
         mc.field_1690.field_1849.method_23481(false);
         mc.field_1690.field_1903.method_23481(false);
         mc.field_1690.field_1832.method_23481(false);
         mc.field_1690.field_1867.method_23481(false);
         mc.field_1690.field_1904.method_23481(false);
         mc.field_1690.field_1886.method_23481(false);
      }

      if (mc.field_1724 != null) {
         mc.field_1724.method_5728(false);
      }
   }

   private void a(String var1, AutoZamok.a var2) {
      long var3 = System.currentTimeMillis();
      if (var3 >= this.nextAllowedTpTime) {
         this.ad();
         this.ab();
         this.ac();
         this.k();
         this.tpFailedCooldown = false;
         this.tpCancelled = false;
         this.c("home " + var1);
         this.state = var2;
         this.actionTimer.a();
         this.nextAllowedTpTime = var3 + (long)(this.tpCooldownDelay.getFloatValue() * 1000.0F);
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && this.isActive()) {
         if (!mc.field_1724.method_29504() && !(mc.field_1724.method_6032() <= 0.0F) && !(mc.field_1755 instanceof class_418)) {
            this.N();
            if (!AutoEat.l() && (!mc.field_1724.method_6115() || !this.a(mc.field_1724.method_6030()))) {
               switch (this.state) {
                  case TP_TO_SKLAD:
                     this.l();
                     break;
                  case WAIT_TP_SKLAD:
                     this.m();
                     break;
                  case SEARCH_SUPPLIES:
                     this.n();
                     break;
                  case OPEN_NEXT_SUPPLY_CHEST:
                     this.o();
                     break;
                  case WAIT_CHEST_SUPPLIES:
                     this.p();
                     break;
                  case DRINK_INVIS:
                     this.r();
                     break;
                  case PREPARE_DRINK_INVIS:
                     this.s();
                     break;
                  case DRINKING_INVIS:
                     this.t();
                     break;
                  case WAIT_SPLASH_INVIS:
                     this.u();
                     break;
                  case PAUSE_AFTER_INVIS:
                     this.v();
                     break;
                  case DRINK_SPEED:
                     this.w();
                     break;
                  case PREPARE_DRINK_SPEED:
                     this.x();
                     break;
                  case DRINKING_SPEED:
                     this.y();
                     break;
                  case WAIT_SPLASH_SPEED:
                     this.z();
                     break;
                  case PAUSE_AFTER_SPEED:
                     this.A();
                     break;
                  case TP_TO_ZAMOK:
                     this.B();
                     break;
                  case WAIT_TP_ZAMOK:
                     this.C();
                     break;
                  case PATROL_SHULKER_SPAWNS:
                     this.H();
                     break;
                  case APPROACH_SHULKER:
                     this.I();
                     break;
                  case MINE_SHULKER:
                     this.J();
                     break;
                  case COLLECT_LOOT:
                     this.K();
                     break;
                  case RUN_AWAY:
                     this.M();
                     break;
                  case FLEE_PLAYER:
                     this.P();
                     break;
                  case STOP_BEFORE_SKLAD_TP:
                     this.Q();
                     break;
                  case WAIT_TP_SKLAD_RETURN:
                     this.R();
                     break;
                  case DEPOSIT_LOOT:
                     this.U();
                     break;
                  case OPEN_NEXT_DEPOSIT_CHEST:
                     this.V();
                     break;
                  case WAIT_CHEST_DEPOSIT:
                     this.W();
                     break;
                  case RESTOCK_SEARCH_CHESTS:
                     this.Y();
                     break;
                  case RESTOCK_OPEN_NEXT_CHEST:
                     this.Z();
                     break;
                  case RESTOCK_WAIT_CHEST:
                     this.aa();
               }
            }
         } else {
            mc.field_1724.method_7331();
            if (mc.field_1755 instanceof class_418) {
               mc.method_1507(null);
            }

            this.k();
            this.ab();
            this.state = AutoZamok.a.TP_TO_SKLAD;
            this.nextAllowedTpTime = System.currentTimeMillis() + 2500L;
            this.actionTimer.a();
            this.lastPlayerHealth = 20.0F;
            this.fleeingFromPlayer = null;
            this.d("§cПерсонаж погиб! Автовозрождение и запуск сбора с нуля.");
         }
      }
   }

   private void l() {
      this.k();
      if (System.currentTimeMillis() >= this.nextAllowedTpTime) {
         this.a(this.homeSklad.getValue(), AutoZamok.a.WAIT_TP_SKLAD);
      }
   }

   private void m() {
      this.k();
      this.ab();
      if (!this.tpFailedCooldown && !this.tpCancelled) {
         long var1 = (long)(this.tpWarmupDelay.getFloatValue() * 1000.0F);
         long var3 = (long)(this.postTpDelay.getFloatValue() * 1000.0F);
         if (this.actionTimer.a(var1 + var3)) {
            this.state = AutoZamok.a.SEARCH_SUPPLIES;
            this.actionTimer.a();
         }
      } else if (System.currentTimeMillis() >= this.nextAllowedTpTime && this.actionTimer.a(1000L)) {
         this.a(this.homeSklad.getValue(), AutoZamok.a.WAIT_TP_SKLAD);
      }
   }

   private void n() {
      boolean var1 = this.ah();
      boolean var2 = this.ai() || this.ak();
      if (var1 && var2) {
         this.state = AutoZamok.a.DRINK_INVIS;
         this.actionTimer.a();
      } else {
         this.ao();
         if (this.chestQueue.isEmpty()) {
            this.q();
         } else {
            this.currentChestIndex = 0;
            this.state = AutoZamok.a.OPEN_NEXT_SUPPLY_CHEST;
            this.actionTimer.a();
         }
      }
   }

   private void o() {
      if (this.actionTimer.a((long)this.chestDelay.getFloatValue()) && mc.field_1755 == null) {
         boolean var1 = this.ah();
         boolean var2 = this.ai() || this.ak();
         if (var1 && var2) {
            this.state = AutoZamok.a.DRINK_INVIS;
            this.actionTimer.a();
         } else if (this.currentChestIndex >= this.chestQueue.size()) {
            this.q();
         } else {
            this.currentTargetChest = this.chestQueue.get(this.currentChestIndex);
            this.c(this.currentTargetChest);
            this.state = AutoZamok.a.WAIT_CHEST_SUPPLIES;
            this.actionTimer.a();
            this.slotActionTimer.a();
         }
      }
   }

   private void p() {
      if (this.actionTimer.a(4000L)) {
         this.ar();
         this.currentChestIndex++;
         this.state = AutoZamok.a.OPEN_NEXT_SUPPLY_CHEST;
         this.actionTimer.a();
      } else if (mc.field_1755 instanceof class_476 var1) {
         if (!this.slotActionTimer.a((long)this.chestDelay.getFloatValue())) {
            return;
         }

         class_1707 var12 = var1.method_17577();
         int var3 = var12.method_17388() * 9;
         int var4 = -1;
         int var5 = this.ag();
         if (var5 != -1 && mc.field_1724 != null) {
            var4 = this.d(mc.field_1724.method_31548().method_5438(var5));
         }

         int var6 = -1;
         int var7 = var4;

         for (int var8 = 0; var8 < var3; var8++) {
            class_1799 var9 = var12.method_7611(var8).method_7677();
            if (var9 != null && !var9.method_7960()) {
               int var10 = this.d(var9);
               if (var10 > var7) {
                  var7 = var10;
                  var6 = var8;
               }
            }
         }

         if (var6 != -1) {
            this.a(var12, var6);
            this.slotActionTimer.a();
            return;
         }

         boolean var13 = !this.ai() && !this.ak();
         boolean var14 = !this.aj() && !this.al();

         for (int var15 = 0; var15 < var3; var15++) {
            class_1799 var11 = var12.method_7611(var15).method_7677();
            if (var11 != null && !var11.method_7960()) {
               if (var13 && this.f(var11)) {
                  this.a(var12, var15);
                  this.slotActionTimer.a();
                  return;
               }

               if (var14 && this.g(var11)) {
                  this.a(var12, var15);
                  this.slotActionTimer.a();
                  return;
               }
            }
         }

         this.ar();
         this.af();
         this.currentChestIndex++;
         this.state = AutoZamok.a.OPEN_NEXT_SUPPLY_CHEST;
         this.actionTimer.a();
      }
   }

   private void q() {
      this.d("§cНет кирки или невидимости! Завершение работы.§r");
      this.setEnabled(false);
   }

   private void r() {
      if (this.ai()) {
         this.state = AutoZamok.a.DRINK_SPEED;
         this.actionTimer.a();
      } else {
         int var1 = this.b(true);
         if (var1 == -1) {
            this.q();
         } else {
            this.b(var1);
            this.state = AutoZamok.a.PREPARE_DRINK_INVIS;
            this.actionTimer.a();
         }
      }
   }

   private void s() {
      class_1799 var1 = mc.field_1724.method_6047();
      if (this.f(var1)) {
         if (var1.method_7909() instanceof class_1828) {
            this.am();
            this.state = AutoZamok.a.WAIT_SPLASH_INVIS;
            this.actionTimer.a();
         } else {
            this.state = AutoZamok.a.DRINKING_INVIS;
            this.drinkTimer.a();
            this.actionTimer.a();
         }
      } else if (this.actionTimer.a(1000L)) {
         int var2 = this.b(true);
         if (var2 != -1) {
            this.b(var2);
            this.actionTimer.a();
         } else {
            this.q();
         }
      }
   }

   private void t() {
      if (this.ai()) {
         if (mc.field_1690 != null) {
            mc.field_1690.field_1904.method_23481(false);
         }

         this.ae();
         this.ab();
         this.state = AutoZamok.a.PAUSE_AFTER_INVIS;
         this.actionTimer.a();
      } else {
         class_1799 var1 = mc.field_1724.method_6047();
         if (this.c(var1) || !this.f(var1) && this.drinkTimer.a(600L)) {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1904.method_23481(false);
            }

            this.ae();
            this.ab();
            this.state = AutoZamok.a.PAUSE_AFTER_INVIS;
            this.actionTimer.a();
         } else {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1904.method_23481(true);
            }

            if (!mc.field_1724.method_6115() && mc.field_1761 != null) {
               mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            }

            if (this.drinkTimer.a(2600L)) {
               if (mc.field_1690 != null) {
                  mc.field_1690.field_1904.method_23481(false);
               }

               this.ae();
               this.ab();
               this.state = AutoZamok.a.PAUSE_AFTER_INVIS;
               this.actionTimer.a();
            }
         }
      }
   }

   private void u() {
      if (this.ai() || this.actionTimer.a(1000L)) {
         this.ae();
         this.ab();
         this.state = AutoZamok.a.PAUSE_AFTER_INVIS;
         this.actionTimer.a();
      }
   }

   private void v() {
      this.ae();
      this.ab();
      if (this.actionTimer.a((long)this.potionDelay.getFloatValue())) {
         if (!this.ai()) {
            if (this.ak()) {
               this.state = AutoZamok.a.DRINK_INVIS;
               this.actionTimer.a();
            } else {
               this.q();
            }
         } else {
            this.state = AutoZamok.a.DRINK_SPEED;
            this.actionTimer.a();
         }
      }
   }

   private void w() {
      if (!this.aj() && this.al()) {
         int var1 = this.b(false);
         if (var1 == -1) {
            this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
            this.actionTimer.a();
         } else {
            this.b(var1);
            this.state = AutoZamok.a.PREPARE_DRINK_SPEED;
            this.actionTimer.a();
         }
      } else {
         this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
         this.actionTimer.a();
      }
   }

   private void x() {
      class_1799 var1 = mc.field_1724.method_6047();
      if (this.g(var1)) {
         if (var1.method_7909() instanceof class_1828) {
            this.am();
            this.state = AutoZamok.a.WAIT_SPLASH_SPEED;
            this.actionTimer.a();
         } else {
            this.state = AutoZamok.a.DRINKING_SPEED;
            this.drinkTimer.a();
            this.actionTimer.a();
         }
      } else if (this.actionTimer.a(1000L)) {
         int var2 = this.b(false);
         if (var2 != -1) {
            this.b(var2);
            this.actionTimer.a();
         } else {
            this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
            this.actionTimer.a();
         }
      }
   }

   private void y() {
      if (this.aj()) {
         if (mc.field_1690 != null) {
            mc.field_1690.field_1904.method_23481(false);
         }

         this.ae();
         this.ab();
         this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
         this.actionTimer.a();
      } else {
         class_1799 var1 = mc.field_1724.method_6047();
         if (this.c(var1) || !this.g(var1) && this.drinkTimer.a(600L)) {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1904.method_23481(false);
            }

            this.ae();
            this.ab();
            this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
            this.actionTimer.a();
         } else {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1904.method_23481(true);
            }

            if (!mc.field_1724.method_6115() && mc.field_1761 != null) {
               mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            }

            if (this.drinkTimer.a(2600L)) {
               if (mc.field_1690 != null) {
                  mc.field_1690.field_1904.method_23481(false);
               }

               this.ae();
               this.ab();
               this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
               this.actionTimer.a();
            }
         }
      }
   }

   private void z() {
      if (this.aj() || this.actionTimer.a(1000L)) {
         this.ae();
         this.ab();
         this.state = AutoZamok.a.PAUSE_AFTER_SPEED;
         this.actionTimer.a();
      }
   }

   private void A() {
      this.ae();
      this.ab();
      if (this.actionTimer.a((long)this.potionDelay.getFloatValue())) {
         this.state = AutoZamok.a.TP_TO_ZAMOK;
         this.actionTimer.a();
      }
   }

   private void B() {
      this.k();
      this.ab();
      this.ac();
      if (!this.ai()) {
         this.d("§cОшибка: эффект невидимости отсутствует! Отмена телепортации на замок.");
         this.state = AutoZamok.a.SEARCH_SUPPLIES;
         this.actionTimer.a();
      } else if (System.currentTimeMillis() >= this.nextAllowedTpTime) {
         this.a(this.homeZamok.getValue(), AutoZamok.a.WAIT_TP_ZAMOK);
      }
   }

   private void C() {
      this.k();
      this.ab();
      if (!this.tpFailedCooldown && !this.tpCancelled) {
         long var1 = (long)(this.tpWarmupDelay.getFloatValue() * 1000.0F);
         long var3 = (long)(this.postTpDelay.getFloatValue() * 1000.0F);
         if (this.actionTimer.a(var1 + var3)) {
            if (mc.field_1724.method_5649(14.0, mc.field_1724.method_23318(), 0.0) > 25000.0) {
               if (System.currentTimeMillis() >= this.nextAllowedTpTime && this.actionTimer.a(var1 + 2000L)) {
                  this.a(this.homeZamok.getValue(), AutoZamok.a.WAIT_TP_ZAMOK);
               }
            } else if (this.D()) {
               this.E();
            } else {
               class_2338 var5 = this.an();
               if (var5 != null) {
                  this.currentShulkerPos = var5;
                  NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
                  this.state = AutoZamok.a.APPROACH_SHULKER;
               } else {
                  this.F();
               }

               this.actionTimer.a();
            }
         }
      } else if (System.currentTimeMillis() >= this.nextAllowedTpTime && this.actionTimer.a(1000L)) {
         this.a(this.homeZamok.getValue(), AutoZamok.a.WAIT_TP_ZAMOK);
      }
   }

   private boolean D() {
      if (mc.field_1724 == null) {
         return true;
      }

      class_1293 var1 = mc.field_1724.method_6112(class_1294.field_5905);
      if (var1 == null) {
         return true;
      }

      int var2 = (int)(this.tpWarmupDelay.getFloatValue() * 20.0F) + 100;
      return var1.method_5584() <= var2;
   }

   private void E() {
      this.d("§cНевидимость заканчивается! Возвращаемся домой...");
      this.currentShulkerPos = null;
      this.k();
      if (mc.field_1690 != null) {
         mc.field_1690.field_1886.method_23481(false);
         mc.field_1690.field_1904.method_23481(false);
      }

      if (mc.field_1761 != null) {
         mc.field_1761.method_2925();
      }

      this.ab();
      this.ac();
      this.state = AutoZamok.a.STOP_BEFORE_SKLAD_TP;
      this.actionTimer.a();
   }

   private void F() {
      this.visitedPatrolSpawns.clear();
      this.currentPatrolTargetIndex = -1;
      this.state = AutoZamok.a.PATROL_SHULKER_SPAWNS;
      this.patrolPointTimer.a();
      this.d("§eШалкер не обнаружен. Начинаем обход координат спавна...");
      this.G();
   }

   private void G() {
      if (mc.field_1724 != null) {
         this.ab();
         this.ac();
         if (this.visitedPatrolSpawns.size() >= SHULKER_SPAWNS.length) {
            this.visitedPatrolSpawns.clear();
         }

         int var1 = -1;
         double var2 = Double.MAX_VALUE;

         for (int var4 = 0; var4 < SHULKER_SPAWNS.length; var4++) {
            if (!this.visitedPatrolSpawns.contains(var4)) {
               double var5 = mc.field_1724.method_5707(SHULKER_SPAWNS[var4]);
               if (var5 < var2) {
                  var2 = var5;
                  var1 = var4;
               }
            }
         }

         if (var1 == -1) {
            this.visitedPatrolSpawns.clear();

            for (int var7 = 0; var7 < SHULKER_SPAWNS.length; var7++) {
               double var9 = mc.field_1724.method_5707(SHULKER_SPAWNS[var7]);
               if (var9 < var2) {
                  var2 = var9;
                  var1 = var7;
               }
            }
         }

         this.currentPatrolTargetIndex = var1;
         this.patrolPointTimer.a();
         if (var1 != -1) {
            class_243 var8 = SHULKER_SPAWNS[var1];
            class_2338 var10 = class_2338.method_49637(var8.field_1352, var8.field_1351, var8.field_1350);
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(var10, 3.5), "Patrol Spawn " + (var1 + 1)));
         }
      }
   }

   private void H() {
      this.ab();
      this.ac();
      if (this.D()) {
         this.E();
      } else {
         class_2338 var1 = this.an();
         if (var1 != null) {
            this.currentShulkerPos = var1;
            NavigationManager.getInstance().c();
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
            this.state = AutoZamok.a.APPROACH_SHULKER;
            this.actionTimer.a();
            this.d("§aОбнаружен шалкер! Идём к нему...");
         } else if (this.currentPatrolTargetIndex == -1) {
            this.G();
         } else {
            class_243 var2 = SHULKER_SPAWNS[this.currentPatrolTargetIndex];
            double var3 = mc.field_1724.method_5707(var2);
            boolean var5 = var3 <= 16.0;
            boolean var6 = !NavigationManager.getInstance().d() && this.patrolPointTimer.a(1200L);
            boolean var7 = this.patrolPointTimer.a(9000L);
            if (var5 || var6 || var7) {
               if (!this.visitedPatrolSpawns.contains(this.currentPatrolTargetIndex)) {
                  this.visitedPatrolSpawns.add(this.currentPatrolTargetIndex);
               }

               this.G();
            }
         }
      }
   }

   private void I() {
      this.ab();
      if (this.D()) {
         this.E();
      } else if (this.currentShulkerPos != null && this.a(this.currentShulkerPos)) {
         class_2338 var6 = this.an();
         if (var6 != null && !var6.equals(this.currentShulkerPos)) {
            double var2 = mc.field_1724.method_5707(class_243.method_24953(this.currentShulkerPos));
            double var4 = mc.field_1724.method_5707(class_243.method_24953(var6));
            if (var4 + 25.0 < var2) {
               this.currentShulkerPos = var6;
               NavigationManager.getInstance().c();
               NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
               return;
            }
         }

         double var7 = mc.field_1724.method_33571().method_1025(class_243.method_24953(this.currentShulkerPos));
         double var8 = mc.field_1724.method_5707(class_243.method_24953(this.currentShulkerPos));
         if (var8 <= 3.8 || var7 <= 4.8) {
            NavigationManager.getInstance().c();
            this.state = AutoZamok.a.MINE_SHULKER;
            this.actionTimer.a();
         } else if (!NavigationManager.getInstance().d()) {
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
         }
      } else {
         class_2338 var1 = this.an();
         if (var1 != null) {
            this.currentShulkerPos = var1;
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
         } else {
            NavigationManager.getInstance().c();
            this.F();
         }
      }
   }

   private void J() {
      if (this.D()) {
         this.E();
      } else {
         if (this.currentShulkerPos == null) {
            class_2338 var1 = this.an();
            if (var1 == null) {
               if (mc.field_1690 != null) {
                  mc.field_1690.field_1886.method_23481(false);
               }

               this.ab();
               this.F();
               return;
            }

            this.currentShulkerPos = var1;
         }

         if (!this.a(this.currentShulkerPos)) {
            if (mc.field_1690 != null) {
               mc.field_1690.field_1886.method_23481(false);
            }

            if (mc.field_1761 != null) {
               mc.field_1761.method_2925();
            }

            this.ab();
            this.state = AutoZamok.a.COLLECT_LOOT;
            this.actionTimer.a();
         } else {
            double var25 = mc.field_1724.method_33571().method_1025(class_243.method_24953(this.currentShulkerPos));
            double var3 = mc.field_1724.method_5707(class_243.method_24953(this.currentShulkerPos));
            if (var25 > 16.0) {
               if (mc.field_1690 != null) {
                  mc.field_1690.field_1886.method_23481(false);
               }

               if (!NavigationManager.getInstance().d()) {
                  NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
               }

               this.state = AutoZamok.a.APPROACH_SHULKER;
            } else {
               if (!(var3 > 4.2) || !(var25 > 5.5)) {
                  NavigationManager.getInstance().c();
               } else if (!NavigationManager.getInstance().d()) {
                  NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
               }

               this.af();
               class_243 var5 = class_243.method_24953(this.currentShulkerPos);
               class_243 var6 = mc.field_1724.method_33571();
               class_2350 var7 = class_2350.field_11036;
               double var8 = Double.MAX_VALUE;

               for (class_2350 var13 : class_2350.values()) {
                  class_243 var14 = var5.method_1031(var13.method_10148() * 0.5, var13.method_10164() * 0.5, var13.method_10165() * 0.5);
                  double var15 = var6.method_1025(var14);
                  if (var15 < var8) {
                     var8 = var15;
                     var7 = var13;
                  }
               }

               class_243 var26 = this.a(this.currentShulkerPos, var7);
               double var27 = var26.field_1352 - var6.field_1352;
               double var28 = var26.field_1351 - var6.field_1351;
               double var29 = var26.field_1350 - var6.field_1350;
               double var17 = Math.max(Math.hypot(var27, var29), 0.001);
               float var19 = (float)Math.toDegrees(Math.atan2(var29, var27)) - 90.0F;
               float var20 = (float)(-Math.toDegrees(Math.atan2(var28, var17)));
               long var21 = System.currentTimeMillis();
               float var23 = (float)(Math.sin(var21 * 0.015) * 0.07 + Math.cos(var21 * 0.031) * 0.04);
               float var24 = (float)(Math.cos(var21 * 0.017) * 0.06 + Math.sin(var21 * 0.027) * 0.03);
               var19 += GCDUtil2.a(var23);
               var20 = class_3532.method_15363(var20 + GCDUtil2.a(var24), -90.0F, 90.0F);
               mc.field_1724.method_36456(var19);
               mc.field_1724.method_36457(var20);
               RotationStorage.a(new Rotation2(var19, var20), 360.0F, 360.0F, 360.0F, 360.0F, 2, 1, true);
               if (mc.field_1761 != null) {
                  mc.field_1690.field_1886.method_23481(true);
                  mc.field_1761.method_2902(this.currentShulkerPos, var7);
                  ((IClientPlayerInteractionManager)mc.field_1761).setBlockBreakingCooldown(0);
                  mc.field_1724.method_6104(class_1268.field_5808);
               }
            }
         }
      }
   }

   private class_243 a(class_2338 var1, class_2350 var2) {
      class_243 var3 = class_243.method_24953(var1).method_1031(var2.method_10148() * 0.49, var2.method_10164() * 0.49, var2.method_10165() * 0.49);
      double var4 = System.currentTimeMillis() * 0.0025;
      double var6 = Math.sin(var4 * 1.3) * 0.16 + Math.cos(var4 * 2.1) * 0.05;
      double var8 = Math.cos(var4 * 1.1) * 0.16 + Math.sin(var4 * 1.8) * 0.05;
      class_243 var10;
      class_243 var11;
      if (var2.method_10166() == class_2351.field_11052) {
         var10 = new class_243(1.0, 0.0, 0.0);
         var11 = new class_243(0.0, 0.0, 1.0);
      } else if (var2.method_10166() == class_2351.field_11048) {
         var10 = new class_243(0.0, 1.0, 0.0);
         var11 = new class_243(0.0, 0.0, 1.0);
      } else {
         var10 = new class_243(1.0, 0.0, 0.0);
         var11 = new class_243(0.0, 1.0, 0.0);
      }

      return var3.method_1019(var10.method_1021(var6)).method_1019(var11.method_1021(var8));
   }

   private void K() {
      if (mc.field_1690 != null) {
         mc.field_1690.field_1886.method_23481(false);
      }

      this.ad();
      this.ab();
      if (this.D() && this.actionTimer.a(600L)) {
         this.E();
      } else if (this.currentShulkerPos != null && this.a(this.currentShulkerPos)) {
         this.state = AutoZamok.a.MINE_SHULKER;
         this.actionTimer.a();
      } else {
         if (this.currentShulkerPos != null) {
            List var1 = mc.field_1687.method_8390(class_1542.class, new class_238(this.currentShulkerPos).method_1014(6.0), var0 -> var0 != null && var0.method_5805());
            if (!var1.isEmpty()) {
               class_1542 var2 = (class_1542)var1.getFirst();
               if (!NavigationManager.getInstance().d() && mc.field_1724.method_5858(var2) > 1.5) {
                  NavigationManager.getInstance().a(new GotoTask(var2.method_24515()));
               }
            }
         }

         if (this.actionTimer.a(1800L)) {
            class_2338 var3 = this.an();
            if (var3 != null && !this.D()) {
               this.currentShulkerPos = var3;
               NavigationManager.getInstance().c();
               NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
               this.state = AutoZamok.a.APPROACH_SHULKER;
               this.actionTimer.a();
               this.d("§aОбнаружен шалкер! Идём к нему...");
               return;
            }

            NavigationManager.getInstance().c();
            this.L();
            this.state = AutoZamok.a.RUN_AWAY;
            this.actionTimer.a();
         }
      }
   }

   private void L() {
      this.ad();
      this.ab();
      double var1 = mc.field_1724.method_23317() - (this.currentShulkerPos != null ? this.currentShulkerPos.method_10263() : 0);
      double var3 = mc.field_1724.method_23321() - (this.currentShulkerPos != null ? this.currentShulkerPos.method_10260() : 0);
      if (Math.hypot(var1, var3) < 0.1) {
         var1 = 1.0;
         var3 = 0.0;
      }

      double var5 = Math.hypot(var1, var3);
      int var7 = class_3532.method_15357(mc.field_1724.method_23317() + var1 / var5 * 22.0);
      int var8 = class_3532.method_15357(mc.field_1724.method_23321() + var3 / var5 * 22.0);
      NavigationManager.getInstance().a(new GotoTask(var7, var8));
   }

   private void M() {
      this.ad();
      this.ab();
      if (!this.D()) {
         class_2338 var1 = this.an();
         if (var1 != null) {
            this.currentShulkerPos = var1;
            NavigationManager.getInstance().c();
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
            this.state = AutoZamok.a.APPROACH_SHULKER;
            this.actionTimer.a();
            this.d("§aОбнаружен шалкер! Идём к нему...");
            return;
         }
      }

      double var3 = this.currentShulkerPos != null ? mc.field_1724.method_5707(class_243.method_24953(this.currentShulkerPos)) : 400.0;
      if (var3 >= 324.0 || !NavigationManager.getInstance().d() || this.actionTimer.a(8000L)) {
         NavigationManager.getInstance().c();
         this.k();
         this.state = AutoZamok.a.STOP_BEFORE_SKLAD_TP;
         this.actionTimer.a();
      }
   }

   private void N() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (this.state != AutoZamok.a.TP_TO_SKLAD
            && this.state != AutoZamok.a.WAIT_TP_SKLAD
            && this.state != AutoZamok.a.WAIT_TP_SKLAD_RETURN
            && this.state != AutoZamok.a.WAIT_TP_ZAMOK) {
            float var1 = mc.field_1724.method_6032();
            class_1309 var2 = mc.field_1724.method_6065();
            if (var2 == null) {
               var2 = mc.field_1724.method_49107();
            }

            class_1657 var3 = null;
            if (var2 instanceof class_1657 var4 && var4 != mc.field_1724) {
               var3 = var4;
            } else if (var1 < this.lastPlayerHealth - 0.2F) {
               List var5 = mc.field_1687
                  .method_8390(
                     class_1657.class, mc.field_1724.method_5829().method_1014(8.0), var0 -> var0 != mc.field_1724 && !var0.method_7325() && var0.method_5805()
                  );
               if (!var5.isEmpty()) {
                  var3 = (class_1657)var5.get(0);
               }
            }

            this.lastPlayerHealth = var1;
            if (var3 != null && this.state != AutoZamok.a.FLEE_PLAYER) {
               this.a(var3);
            }
         } else {
            this.lastPlayerHealth = mc.field_1724.method_6032();
         }
      }
   }

   private void a(class_1657 var1) {
      this.fleeingFromPlayer = var1;
      this.state = AutoZamok.a.FLEE_PLAYER;
      this.fleeTimer.a();
      this.fleeRepathTimer.a();
      if (mc.field_1690 != null) {
         mc.field_1690.field_1886.method_23481(false);
         mc.field_1690.field_1904.method_23481(false);
      }

      if (mc.field_1761 != null) {
         mc.field_1761.method_2925();
      }

      if (mc.field_1755 != null) {
         this.ar();
      }

      this.ab();
      this.ac();
      this.d("§cВНИМАНИЕ! Получен урон от игрока " + var1.method_5477().getString() + "! Начинаем убегать!");
      this.O();
   }

   private void O() {
      if (mc.field_1724 != null) {
         class_243 var1 = mc.field_1724.method_73189();
         class_243 var2;
         if (this.fleeingFromPlayer != null && this.fleeingFromPlayer.method_5805()) {
            class_243 var9 = this.fleeingFromPlayer.method_73189();
            double var4 = var1.field_1352 - var9.field_1352;
            double var6 = var1.field_1350 - var9.field_1350;
            if (Math.hypot(var4, var6) < 0.2) {
               float var8 = (float)Math.toRadians(mc.field_1724.method_36454() + 180.0F);
               var2 = new class_243(-Math.sin(var8), 0.0, Math.cos(var8)).method_1029();
            } else {
               var2 = new class_243(var4, 0.0, var6).method_1029();
            }
         } else {
            float var3 = (float)Math.toRadians(mc.field_1724.method_36454() + 180.0F);
            var2 = new class_243(-Math.sin(var3), 0.0, Math.cos(var3)).method_1029();
         }

         double var10 = 28.0;
         int var5 = class_3532.method_15357(var1.field_1352 + var2.field_1352 * var10);
         int var11 = class_3532.method_15357(var1.field_1350 + var2.field_1350 * var10);
         NavigationManager.getInstance().a(new GotoTask(var5, var11));
         this.fleeRepathTimer.a();
      }
   }

   private void P() {
      this.ab();
      this.ac();
      if (this.fleeingFromPlayer != null && this.fleeingFromPlayer.method_5805()) {
         double var1 = mc.field_1724.method_5858(this.fleeingFromPlayer);
         if (var1 < 144.0 && this.fleeRepathTimer.a(1500L)) {
            this.O();
         }

         if (var1 > 576.0 && this.fleeTimer.a(6000L)) {
            this.d("§aУспешно оторвались от игрока! Возвращаемся на базу.");
            this.fleeingFromPlayer = null;
            NavigationManager.getInstance().c();
            this.k();
            this.state = AutoZamok.a.STOP_BEFORE_SKLAD_TP;
            this.actionTimer.a();
            return;
         }
      } else if (this.fleeTimer.a(5000L)) {
         this.d("§aУгроза миновала! Возвращаемся на базу.");
         this.fleeingFromPlayer = null;
         NavigationManager.getInstance().c();
         this.k();
         this.state = AutoZamok.a.STOP_BEFORE_SKLAD_TP;
         this.actionTimer.a();
         return;
      }

      if (this.fleeTimer.a(12000L)) {
         this.d("§eВремя побега вышло. Возвращаемся на базу.");
         this.fleeingFromPlayer = null;
         NavigationManager.getInstance().c();
         this.k();
         this.state = AutoZamok.a.STOP_BEFORE_SKLAD_TP;
         this.actionTimer.a();
      }
   }

   private void Q() {
      this.ad();
      this.k();
      this.ab();
      if (!this.D()) {
         class_2338 var1 = this.an();
         if (var1 != null) {
            this.currentShulkerPos = var1;
            NavigationManager.getInstance().c();
            NavigationManager.getInstance().a(new GotoTask(new GoalNear(this.currentShulkerPos, 1.4), "Goto Shulker"));
            this.state = AutoZamok.a.APPROACH_SHULKER;
            this.actionTimer.a();
            this.d("§aОбнаружен шалкер! Идём к нему...");
            return;
         }
      }

      if (this.actionTimer.a(800L) && System.currentTimeMillis() >= this.nextAllowedTpTime) {
         this.a(this.homeSklad.getValue(), AutoZamok.a.WAIT_TP_SKLAD_RETURN);
      }
   }

   private void R() {
      this.k();
      this.ab();
      if (!this.tpFailedCooldown && !this.tpCancelled) {
         long var1 = (long)(this.tpWarmupDelay.getFloatValue() * 1000.0F);
         long var3 = (long)(this.postTpDelay.getFloatValue() * 1000.0F);
         if (this.actionTimer.a(var1 + var3)) {
            this.state = AutoZamok.a.DEPOSIT_LOOT;
            this.actionTimer.a();
         }
      } else if (System.currentTimeMillis() >= this.nextAllowedTpTime && this.actionTimer.a(1000L)) {
         this.a(this.homeSklad.getValue(), AutoZamok.a.WAIT_TP_SKLAD_RETURN);
      }
   }

   private boolean S() {
      if (mc.field_1724 == null) {
         return false;
      }

      boolean var1 = false;
      int var2 = 0;
      int var3 = 0;

      for (int var4 = 0; var4 < 36; var4++) {
         class_1799 var5 = mc.field_1724.method_31548().method_5438(var4);
         if (var5 != null && !var5.method_7960()) {
            if (this.b(var5)) {
               return true;
            }

            if (this.e(var5) && !var1) {
               var1 = true;
            } else if (this.f(var5) && var2 < 2) {
               var2++;
            } else if (this.g(var5) && var3 < 2) {
               var3++;
            } else if (!this.a(var5)) {
               return true;
            }
         }
      }

      class_1799 var9 = mc.field_1724.method_6079();
      if (var9 != null && !var9.method_7960()) {
         if (this.b(var9)) {
            return true;
         }

         if (this.e(var9) && !var1) {
            var1 = true;
         } else if (this.f(var9) && var2 < 2) {
            var2++;
         } else if (this.g(var9) && var3 < 2) {
            var3++;
         } else if (!this.a(var9)) {
            return true;
         }
      }

      return false;
   }

   private void T() {
      this.chestQueue.clear();
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var1 = mc.field_1724.method_24515();
         byte var2 = 5;
         ArrayList var3 = new ArrayList();
         ArrayList var4 = new ArrayList();

         for (int var5 = -var2; var5 <= var2; var5++) {
            for (int var6 = -var2; var6 <= var2; var6++) {
               for (int var7 = -var2; var7 <= var2; var7++) {
                  class_2338 var8 = var1.method_10069(var5, var6, var7);
                  if (!(mc.field_1724.method_5707(class_243.method_24953(var8)) > 20.25)) {
                     class_2680 var9 = mc.field_1687.method_8320(var8);
                     class_2248 var10 = var9.method_26204();
                     if (this.a(var10)) {
                        if (var10 instanceof class_2281) {
                           class_2745 var11 = var9.method_11654(class_2281.field_10770);
                           if (var11 == class_2745.field_12574) {
                              continue;
                           }
                        }

                        if (this.b(var8)) {
                           var3.add(var8);
                        } else {
                           var4.add(var8);
                        }
                     }
                  }
               }
            }
         }

         var3.sort(
            (var0, var1x) -> Double.compare(
               mc.field_1724.method_5707(class_243.method_24953((class_2338)var0)), mc.field_1724.method_5707(class_243.method_24953((class_2338)var1x))
            )
         );
         var4.sort(
            (var0, var1x) -> Double.compare(
               mc.field_1724.method_5707(class_243.method_24953((class_2338)var0)), mc.field_1724.method_5707(class_243.method_24953((class_2338)var1x))
            )
         );
         this.chestQueue.addAll(var3);
         this.chestQueue.addAll(var4);
      }
   }

   private void U() {
      this.ad();
      this.ac();
      if (!this.S()) {
         this.X();
      } else {
         this.T();
         if (this.chestQueue.isEmpty()) {
            this.X();
         } else {
            this.currentChestIndex = 0;
            this.state = AutoZamok.a.OPEN_NEXT_DEPOSIT_CHEST;
            this.actionTimer.a();
         }
      }
   }

   private void V() {
      if (this.actionTimer.a((long)this.chestDelay.getFloatValue()) && mc.field_1755 == null) {
         this.ad();
         this.ac();
         if (!this.S()) {
            this.X();
         } else if (this.currentChestIndex >= this.chestQueue.size()) {
            this.X();
         } else {
            this.currentTargetChest = this.chestQueue.get(this.currentChestIndex);
            this.c(this.currentTargetChest);
            this.state = AutoZamok.a.WAIT_CHEST_DEPOSIT;
            this.actionTimer.a();
            this.slotActionTimer.a();
         }
      }
   }

   private void W() {
      if (this.actionTimer.a(4000L)) {
         this.ar();
         this.ac();
         this.ad();
         this.currentChestIndex++;
         this.state = AutoZamok.a.OPEN_NEXT_DEPOSIT_CHEST;
         this.actionTimer.a();
      } else if (mc.field_1755 instanceof class_476 var1) {
         if (!this.slotActionTimer.a((long)this.chestDelay.getFloatValue())) {
            return;
         }

         class_1707 var15 = var1.method_17577();
         int var3 = var15.method_17388() * 9;
         int var4 = -1;
         int var5 = -1;

         for (int var6 = var3; var6 < var3 + 36; var6++) {
            class_1799 var7 = var15.method_7611(var6).method_7677();
            int var8 = this.d(var7);
            if (var8 > var5) {
               var5 = var8;
               var4 = var6;
            }
         }

         int var16 = -1;
         int var17 = var5;

         for (int var18 = 0; var18 < var3; var18++) {
            class_1799 var9 = var15.method_7611(var18).method_7677();
            int var10 = this.d(var9);
            if (var10 > var17) {
               var17 = var10;
               var16 = var18;
            }
         }

         if (var16 != -1) {
            this.a(var15, var16);
            this.slotActionTimer.a();
            return;
         }

         int var19 = 0;
         int var20 = 0;

         for (int var21 = var3; var21 < var3 + 36; var21++) {
            class_1799 var11 = var15.method_7611(var21).method_7677();
            if (var11 != null && !var11.method_7960()) {
               if (this.b(var11)) {
                  if (mc.field_1761 != null && mc.field_1724 != null) {
                     mc.field_1761.method_2906(var15.field_7763, var21, 1, class_1713.field_7795, mc.field_1724);
                  }

                  this.slotActionTimer.a();
                  return;
               }

               if (var21 != var4) {
                  if (this.f(var11) && var19 < 2) {
                     var19++;
                  } else if (this.g(var11) && var20 < 2) {
                     var20++;
                  } else if (!this.a(var11)) {
                     boolean var12 = false;

                     for (int var13 = 0; var13 < var3; var13++) {
                        class_1799 var14 = var15.method_7611(var13).method_7677();
                        if (var14 == null || var14.method_7960()) {
                           var12 = true;
                           break;
                        }

                        if (class_1799.method_31577(var11, var14) && var14.method_7947() < var14.method_7914()) {
                           var12 = true;
                           break;
                        }
                     }

                     if (var12) {
                        this.a(var15, var21);
                        this.slotActionTimer.a();
                        return;
                     }
                  }
               }
            }
         }

         this.ar();
         this.ac();
         this.ad();
         this.af();
         this.currentChestIndex++;
         this.state = AutoZamok.a.OPEN_NEXT_DEPOSIT_CHEST;
         this.actionTimer.a();
      }
   }

   private void X() {
      boolean var1 = this.ah();
      boolean var2 = this.ai() || this.ak();
      if (var1 && var2) {
         this.state = AutoZamok.a.DRINK_INVIS;
         this.actionTimer.a();
      } else {
         this.ao();
         if (this.chestQueue.isEmpty()) {
            this.q();
         } else {
            this.currentChestIndex = 0;
            this.state = AutoZamok.a.RESTOCK_OPEN_NEXT_CHEST;
            this.actionTimer.a();
         }
      }
   }

   private void Y() {
      this.X();
   }

   private void Z() {
      if (this.actionTimer.a((long)this.chestDelay.getFloatValue()) && mc.field_1755 == null) {
         boolean var1 = this.ah();
         boolean var2 = this.ai() || this.ak();
         if (var1 && var2) {
            this.state = AutoZamok.a.DRINK_INVIS;
            this.actionTimer.a();
         } else if (this.currentChestIndex >= this.chestQueue.size()) {
            this.q();
         } else {
            this.currentTargetChest = this.chestQueue.get(this.currentChestIndex);
            this.c(this.currentTargetChest);
            this.state = AutoZamok.a.RESTOCK_WAIT_CHEST;
            this.actionTimer.a();
            this.slotActionTimer.a();
         }
      }
   }

   private void aa() {
      if (this.actionTimer.a(4000L)) {
         this.ar();
         this.currentChestIndex++;
         this.state = AutoZamok.a.RESTOCK_OPEN_NEXT_CHEST;
         this.actionTimer.a();
      } else if (mc.field_1755 instanceof class_476 var1) {
         if (!this.slotActionTimer.a((long)this.chestDelay.getFloatValue())) {
            return;
         }

         class_1707 var12 = var1.method_17577();
         int var3 = var12.method_17388() * 9;
         int var4 = -1;
         int var5 = this.ag();
         if (var5 != -1 && mc.field_1724 != null) {
            var4 = this.d(mc.field_1724.method_31548().method_5438(var5));
         }

         int var6 = -1;
         int var7 = var4;

         for (int var8 = 0; var8 < var3; var8++) {
            class_1799 var9 = var12.method_7611(var8).method_7677();
            if (var9 != null && !var9.method_7960()) {
               int var10 = this.d(var9);
               if (var10 > var7) {
                  var7 = var10;
                  var6 = var8;
               }
            }
         }

         if (var6 != -1) {
            this.a(var12, var6);
            this.slotActionTimer.a();
            return;
         }

         boolean var13 = !this.ai() && !this.ak();
         boolean var14 = !this.aj() && !this.al();

         for (int var15 = 0; var15 < var3; var15++) {
            class_1799 var11 = var12.method_7611(var15).method_7677();
            if (var11 != null && !var11.method_7960()) {
               if (var13 && this.f(var11)) {
                  this.a(var12, var15);
                  this.slotActionTimer.a();
                  return;
               }

               if (var14 && this.g(var11)) {
                  this.a(var12, var15);
                  this.slotActionTimer.a();
                  return;
               }
            }
         }

         this.ar();
         this.af();
         this.currentChestIndex++;
         this.state = AutoZamok.a.RESTOCK_OPEN_NEXT_CHEST;
         this.actionTimer.a();
      }
   }

   private void ab() {
      if (mc.field_1724 != null) {
         this.ae();

         for (int var1 = 0; var1 < 9; var1++) {
            if (mc.field_1724.method_31548().method_5438(var1).method_7960()) {
               if (mc.field_1724.method_31548().method_67532() != var1) {
                  InventoryUtility.e(var1);
               }

               return;
            }
         }

         for (int var3 = 9; var3 < 36; var3++) {
            if (mc.field_1724.method_31548().method_5438(var3).method_7960()) {
               int var2 = mc.field_1724.method_31548().method_67532();
               InventoryUtility.d(var3, var2);
               return;
            }
         }
      }
   }

   private void ac() {
      if (mc.field_1724 != null && !mc.field_1724.method_6079().method_7960()) {
         for (int var1 = 9; var1 < 36; var1++) {
            if (mc.field_1724.method_31548().method_5438(var1).method_7960()) {
               InventoryUtility.a(InventoryUtility.b(var1));
               break;
            }
         }
      }
   }

   private boolean a(class_1799 var1) {
      return var1 != null && !var1.method_7960() ? var1.method_57826(class_9334.field_50075) : false;
   }

   private boolean b(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return false;
      }

      if (this.a(var1)) {
         return false;
      }

      if (var1.method_31574(class_1802.field_8469)) {
         return true;
      }

      if (var1.method_31574(class_1802.field_8283) || var1.method_31574(class_1802.field_8873) || var1.method_31574(class_1802.field_8218) || var1.method_31574(class_1802.field_8313)
         )
       {
         return true;
      }

      if (!var1.method_31574(class_1802.field_8528) && !var1.method_31574(class_1802.field_8776) && !var1.method_31574(class_1802.field_8062) && !var1.method_31574(class_1802.field_8431)) {
         if ((var1.method_31574(class_1802.field_8387) || var1.method_31574(class_1802.field_8647)) && mc.field_1724 != null) {
            int var2 = this.ag();
            if (var2 != -1) {
               class_1799 var3 = mc.field_1724.method_31548().method_5438(var2);
               if (this.d(var3) > this.d(var1)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private boolean c(class_1799 var1) {
      return this.b(var1);
   }

   private void ad() {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         if (mc.field_1755 instanceof class_476 var8) {
            class_1707 var12 = var8.method_17577();
            int var3 = var12.method_17388() * 9;

            for (int var4 = var3; var4 < var12.field_7761.size(); var4++) {
               class_1799 var5 = var12.method_7611(var4).method_7677();
               if (this.b(var5)) {
                  mc.field_1761.method_2906(var12.field_7763, var4, 1, class_1713.field_7795, mc.field_1724);
               }
            }
         } else if (mc.field_1755 == null) {
            for (int var1 = 0; var1 < 9; var1++) {
               class_1799 var9 = mc.field_1724.method_31548().method_5438(var1);
               if (this.b(var9)) {
                  mc.field_1761.method_2906(0, 36 + var1, 1, class_1713.field_7795, mc.field_1724);
               }
            }

            for (int var6 = 9; var6 < 36; var6++) {
               class_1799 var10 = mc.field_1724.method_31548().method_5438(var6);
               if (this.b(var10)) {
                  mc.field_1761.method_2906(0, var6, 1, class_1713.field_7795, mc.field_1724);
               }
            }

            for (int var7 = 5; var7 <= 8; var7++) {
               class_1799 var11 = mc.field_1724.field_7498.method_7611(var7).method_7677();
               if (this.b(var11)) {
                  mc.field_1761.method_2906(0, var7, 1, class_1713.field_7795, mc.field_1724);
               }
            }

            if (this.b(mc.field_1724.method_6079())) {
               mc.field_1761.method_2906(0, 45, 1, class_1713.field_7795, mc.field_1724);
            }
         }
      }
   }

   private void ae() {
      this.ad();
   }

   private void af() {
      if (mc.field_1724 != null) {
         int var1 = this.ag();
         if (var1 != -1) {
            if (var1 < 9) {
               if (mc.field_1724.method_31548().method_67532() != var1) {
                  InventoryUtility.e(var1);
               }
            } else {
               int var2 = mc.field_1724.method_31548().method_67532();
               InventoryUtility.d(var1, var2);
            }
         }
      }
   }

   private int d(class_1799 var1) {
      if (var1 != null && !var1.method_7960() && this.e(var1)) {
         class_1792 var2 = var1.method_7909();
         short var3 = 0;
         if (var2 == class_1802.field_22024) {
            var3 = 6000;
         } else if (var2 == class_1802.field_8377) {
            var3 = 5000;
         } else if (var2 == class_1802.field_8335) {
            var3 = 4000;
         } else if (var2 == class_1802.field_8403) {
            var3 = 3000;
         } else if (var2 == class_1802.field_8387) {
            var3 = 2000;
         } else if (var2 == class_1802.field_8647) {
            var3 = 1000;
         } else {
            var3 = 500;
         }

         float var4 = var1.method_7924(class_2246.field_10340.method_9564());
         int var6 = var3 + (int)(var4 * 100.0F);
         if (var1.method_7942()) {
            var6 += 300;
         }

         if (var1.method_7986()) {
            var6 -= (int)((float)var1.method_7919() / Math.max(1, var1.method_7936()) * 100.0F);
         }

         return var6;
      } else {
         return -1;
      }
   }

   private int ag() {
      if (mc.field_1724 == null) {
         return -1;
      }

      int var1 = -1;
      int var2 = -1;

      for (int var3 = 0; var3 < 36; var3++) {
         class_1799 var4 = mc.field_1724.method_31548().method_5438(var3);
         int var5 = this.d(var4);
         if (var5 > var2) {
            var2 = var5;
            var1 = var3;
         }
      }

      return var1;
   }

   private boolean e(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return false;
      }

      if (HotbarUtil.b(var1.method_7909())) {
         return true;
      }

      String var2 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      return var2.contains("кирк") || var2.contains("pickaxe");
   }

   private boolean ah() {
      return this.ag() != -1;
   }

   private boolean ai() {
      if (mc.field_1724 == null) {
         return false;
      }

      class_1293 var1 = mc.field_1724.method_6112(class_1294.field_5905);
      return var1 != null && var1.method_5584() > 200;
   }

   private boolean aj() {
      if (mc.field_1724 == null) {
         return false;
      }

      class_1293 var1 = mc.field_1724.method_6112(class_1294.field_5904);
      return var1 != null && var1.method_5584() > 200;
   }

   private boolean f(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return false;
      }

      if (!(var1.method_7909() instanceof class_1812)) {
         return false;
      }

      if (PotionUtility.a(var1, class_1294.field_5905)) {
         return true;
      }

      String var2 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      if (!var2.contains("невидим") && !var2.contains("invis")) {
         class_1844 var3 = var1.method_58694(class_9334.field_49651);
         if (var3 != null) {
            for (class_1293 var5 : var3.method_57397()) {
               if (var5.method_5579().equals(class_1294.field_5905)) {
                  return true;
               }
            }

            if (var3.comp_2378().isPresent()) {
               String var7 = var3.comp_2378().get().method_40230().map(var0 -> var0.method_29177().method_12832()).orElse("").toLowerCase(Locale.ROOT);
               if (var7.contains("invis")) {
                  return true;
               }
            }
         }

         for (String var9 : this.h(var1)) {
            String var6 = this.b(var9).toLowerCase(Locale.ROOT);
            if (var6.contains("невидим") || var6.contains("invis")) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private boolean g(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return false;
      }

      if (!(var1.method_7909() instanceof class_1812)) {
         return false;
      }

      if (PotionUtility.a(var1, class_1294.field_5904)) {
         return true;
      }

      String var2 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      if (!var2.contains("скорост") && !var2.contains("speed")) {
         class_1844 var3 = var1.method_58694(class_9334.field_49651);
         if (var3 != null) {
            for (class_1293 var5 : var3.method_57397()) {
               if (var5.method_5579().equals(class_1294.field_5904)) {
                  return true;
               }
            }

            if (var3.comp_2378().isPresent()) {
               String var7 = var3.comp_2378().get().method_40230().map(var0 -> var0.method_29177().method_12832()).orElse("").toLowerCase(Locale.ROOT);
               if (var7.contains("speed") || var7.contains("swiftness")) {
                  return true;
               }
            }
         }

         for (String var9 : this.h(var1)) {
            String var6 = this.b(var9).toLowerCase(Locale.ROOT);
            if (var6.contains("скорост") || var6.contains("speed") || var6.contains("стремительн")) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private List<String> h(class_1799 var1) {
      ArrayList var2 = new ArrayList();
      if (var1 != null && !var1.method_7960()) {
         try {
            class_9635 var3 = mc.field_1687 != null ? class_9635.method_59528(mc.field_1687) : class_9635.field_51353;
            List var4 = var1.method_7950(var3, mc.field_1724, class_1836.field_41070);
            if (var4 != null) {
               for (class_2561 var6 : (Iterable<class_2561>)(Iterable<?>)(var4)) {
                  if (var6 != null) {
                     var2.add(var6.getString());
                  }
               }
            }
         } catch (Exception var7) {
         }

         if (var2.isEmpty()) {
            var2.add(var1.method_7964().getString());
         }

         return var2;
      } else {
         return var2;
      }
   }

   private String b(String var1) {
      return var1 == null ? "" : var1.replaceAll("§[0-9a-fk-orA-FK-OR]", "");
   }

   private boolean ak() {
      return this.b(true) != -1;
   }

   private boolean al() {
      return this.b(false) != -1;
   }

   private int b(boolean var1) {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var2 = 0; var2 < 9; var2++) {
         class_1799 var3 = mc.field_1724.method_31548().method_5438(var2);
         if (var1 ? this.f(var3) : this.g(var3)) {
            return var2;
         }
      }

      for (int var4 = 9; var4 < 36; var4++) {
         class_1799 var5 = mc.field_1724.method_31548().method_5438(var4);
         if (var1 ? this.f(var5) : this.g(var5)) {
            return var4;
         }
      }

      return -1;
   }

   private void b(int var1) {
      if (mc.field_1724 != null) {
         if (var1 >= 0 && var1 < 9) {
            if (mc.field_1724.method_31548().method_67532() != var1) {
               InventoryUtility.e(var1);
            }
         } else {
            int var2 = -1;

            for (int var3 = 0; var3 < 9; var3++) {
               if (mc.field_1724.method_31548().method_5438(var3).method_7960()) {
                  var2 = var3;
                  break;
               }
            }

            if (var2 == -1) {
               var2 = mc.field_1724.method_31548().method_67532();
            }

            InventoryUtility.e(var2);
            if (mc.field_1761 != null && mc.field_1724.field_7512 != null) {
               mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var1, var2, class_1713.field_7791, mc.field_1724);
            }
         }
      }
   }

   private void am() {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         mc.field_1724.method_36457(90.0F);
         RotationStorage.a(new Rotation2(mc.field_1724.method_36454(), 90.0F), 360.0F, 360.0F, 360.0F, 360.0F, 2, 1, false);
         mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
         mc.field_1724.method_6104(class_1268.field_5808);
      }
   }

   private class_2338 an() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         class_2338 var1 = null;
         double var2 = Double.MAX_VALUE;

         for (class_243 var7 : SHULKER_SPAWNS) {
            int var8 = class_3532.method_15357(var7.field_1352);
            int var9 = class_3532.method_15357(var7.field_1351);
            int var10 = class_3532.method_15357(var7.field_1350);
            if (mc.field_1687.method_8393(var8 >> 4, var10 >> 4)) {
               for (int var11 = -5; var11 <= 5; var11++) {
                  for (int var12 = -3; var12 <= 5; var12++) {
                     for (int var13 = -5; var13 <= 5; var13++) {
                        class_2338 var14 = new class_2338(var8 + var11, var9 + var12, var10 + var13);
                        class_2680 var15 = mc.field_1687.method_8320(var14);
                        if (var15.method_26204() instanceof class_2480) {
                           double var16 = mc.field_1724.method_5707(class_243.method_24953(var14));
                           if (var16 < var2) {
                              var2 = var16;
                              var1 = var14;
                           }
                        }
                     }
                  }
               }
            }
         }

         class_2338 var18 = mc.field_1724.method_24515();
         byte var19 = 24;

         for (int var20 = -var19; var20 <= var19; var20++) {
            for (int var21 = -var19; var21 <= var19; var21++) {
               int var22 = var18.method_10263() + var20 >> 4;
               int var23 = var18.method_10260() + var21 >> 4;
               if (mc.field_1687.method_8393(var22, var23)) {
                  for (int var24 = -8; var24 <= 12; var24++) {
                     class_2338 var25 = var18.method_10069(var20, var24, var21);
                     class_2680 var26 = mc.field_1687.method_8320(var25);
                     if (var26.method_26204() instanceof class_2480) {
                        double var27 = mc.field_1724.method_5707(class_243.method_24953(var25));
                        if (var27 < var2) {
                           var2 = var27;
                           var1 = var25;
                        }
                     }
                  }
               }
            }
         }

         return var1;
      } else {
         return null;
      }
   }

   private boolean a(class_2338 var1) {
      return mc.field_1687 != null && var1 != null ? mc.field_1687.method_8320(var1).method_26204() instanceof class_2480 : false;
   }

   private void ao() {
      this.chestQueue.clear();
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var1 = mc.field_1724.method_24515();
         byte var2 = 5;

         for (int var3 = -var2; var3 <= var2; var3++) {
            for (int var4 = -var2; var4 <= var2; var4++) {
               for (int var5 = -var2; var5 <= var2; var5++) {
                  class_2338 var6 = var1.method_10069(var3, var4, var5);
                  class_2680 var7 = mc.field_1687.method_8320(var6);
                  class_2248 var8 = var7.method_26204();
                  if (this.a(var8)) {
                     if (var8 instanceof class_2281) {
                        class_2745 var9 = var7.method_11654(class_2281.field_10770);
                        if (var9 == class_2745.field_12574) {
                           continue;
                        }
                     }

                     this.chestQueue.add(var6);
                  }
               }
            }
         }

         this.chestQueue
            .sort((var0, var1x) -> Double.compare(mc.field_1724.method_5707(class_243.method_24953(var0)), mc.field_1724.method_5707(class_243.method_24953(var1x))));
      }
   }

   private class_2338 ap() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var1 = mc.field_1724.method_24515();
         class_2338 var2 = null;
         double var3 = Double.MAX_VALUE;
         byte var5 = 5;

         for (int var6 = -var5; var6 <= var5; var6++) {
            for (int var7 = -var5; var7 <= var5; var7++) {
               for (int var8 = -var5; var8 <= var5; var8++) {
                  class_2338 var9 = var1.method_10069(var6, var7, var8);
                  class_2680 var10 = mc.field_1687.method_8320(var9);
                  class_2248 var11 = var10.method_26204();
                  if (this.a(var11) && this.b(var9)) {
                     double var12 = mc.field_1724.method_5707(class_243.method_24953(var9));
                     if (var12 < var3) {
                        var3 = var12;
                        var2 = var9;
                     }
                  }
               }
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private class_2338 aq() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 var1 = mc.field_1724.method_24515();
         class_2338 var2 = null;
         double var3 = Double.MAX_VALUE;
         byte var5 = 5;

         for (int var6 = -var5; var6 <= var5; var6++) {
            for (int var7 = -var5; var7 <= var5; var7++) {
               for (int var8 = -var5; var8 <= var5; var8++) {
                  class_2338 var9 = var1.method_10069(var6, var7, var8);
                  class_2680 var10 = mc.field_1687.method_8320(var9);
                  class_2248 var11 = var10.method_26204();
                  if (this.a(var11)) {
                     double var12 = mc.field_1724.method_5707(class_243.method_24953(var9));
                     if (var12 < var3) {
                        var3 = var12;
                        var2 = var9;
                     }
                  }
               }
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private boolean a(class_2248 var1) {
      return var1 instanceof class_2281 || var1 instanceof class_2531 || var1 instanceof class_3708;
   }

   private boolean b(class_2338 var1) {
      if (mc.field_1687 == null) {
         return false;
      }

      for (class_2350 var5 : class_2350.values()) {
         class_2338 var6 = var1.method_10093(var5);
         class_2680 var7 = mc.field_1687.method_8320(var6);
         if (var7.method_26204() instanceof class_2478) {
            return true;
         }
      }

      return false;
   }

   private void c(class_2338 var1) {
      if (mc.field_1724 != null && mc.field_1761 != null && var1 != null) {
         class_3965 var2 = new class_3965(class_243.method_24953(var1), class_2350.field_11036, var1, false);
         mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var2);
         mc.field_1724.method_6104(class_1268.field_5808);
      }
   }

   private void a(class_1707 var1, int var2) {
      if (mc.field_1761 != null && mc.field_1724 != null && var1 != null) {
         mc.field_1761.method_2906(var1.field_7763, var2, 0, class_1713.field_7794, mc.field_1724);
      }
   }

   private void ar() {
      if (mc.field_1724 != null) {
         mc.field_1724.method_7346();
      }
   }

   private void c(String var1) {
      if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
         mc.field_1724.field_3944.method_45730(var1);
      }
   }

   private void d(String var1) {
      if (mc.field_1724 != null) {
         mc.field_1724.method_7353(class_2561.method_43470("§6[AutoZamok] §f" + var1), false);
      }
   }

   enum a {
      IDLE,
      TP_TO_SKLAD,
      WAIT_TP_SKLAD,
      SEARCH_SUPPLIES,
      OPEN_NEXT_SUPPLY_CHEST,
      WAIT_CHEST_SUPPLIES,
      DRINK_INVIS,
      PREPARE_DRINK_INVIS,
      DRINKING_INVIS,
      WAIT_SPLASH_INVIS,
      PAUSE_AFTER_INVIS,
      DRINK_SPEED,
      PREPARE_DRINK_SPEED,
      DRINKING_SPEED,
      WAIT_SPLASH_SPEED,
      PAUSE_AFTER_SPEED,
      TP_TO_ZAMOK,
      WAIT_TP_ZAMOK,
      PATROL_SHULKER_SPAWNS,
      APPROACH_SHULKER,
      MINE_SHULKER,
      COLLECT_LOOT,
      RUN_AWAY,
      FLEE_PLAYER,
      STOP_BEFORE_SKLAD_TP,
      WAIT_TP_SKLAD_RETURN,
      DEPOSIT_LOOT,
      OPEN_NEXT_DEPOSIT_CHEST,
      WAIT_CHEST_DEPOSIT,
      RESTOCK_SEARCH_CHESTS,
      RESTOCK_OPEN_NEXT_CHEST,
      RESTOCK_WAIT_CHEST;
   }
}
