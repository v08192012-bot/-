package brokke.cc.module.misc;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.module.combat.Aura;
import brokke.cc.core.HandlerProcessor;
import brokke.cc.core.RCTCommand;
import brokke.cc.manager.FriendManager;
import brokke.cc.mixins.interfaces.IBossBarHud;
import brokke.cc.mixins.interfaces.IClientPlayerInteractionManager;
import brokke.cc.mixins.render.IGameRenderer;
import brokke.cc.render.ColorPipeline;
import brokke.cc.render.RenderUtil;
import brokke.cc.render.Theme;
import brokke.cc.render.WorldToScreen;
import brokke.cc.rotation.Rotation2;
import brokke.cc.setting.BindSetting;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.FloatSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.AttackEntityEvent;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.FinishEatEvent;
import brokke.cc.system.events.impl.HudRenderEvent;
import brokke.cc.system.events.impl.KeyEvent;
import brokke.cc.system.events.impl.Render2DEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.DeltaInventoryUtil;
import brokke.cc.util.PotionUtility;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1259.class_1261;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1680;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2675;
import net.minecraft.class_2767;
import net.minecraft.class_2868;
import net.minecraft.class_287;
import net.minecraft.class_2886;
import net.minecraft.class_332;
import net.minecraft.class_345;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_5250;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

@NewFunction(name = "ServerAssistant", description = "Помощник для серверов", category = Category.MISC)
public class ServerHelper extends Function {
   private final ModeSetting mode = new ModeSetting("Режим", "HolyWorld", "Funtime");
   private final BindSetting healKey = new BindSetting("Исцеление", -1);
   private final BindSetting brokkeKey = new BindSetting("Хорус", -1);
   private final BooleanSetting throwHeal = new BooleanSetting("Кидать исцел", false);
   private final FloatSetting throwHealRadius = new FloatSetting("Радиус", 4.0F, 1.0F, 6.0F, 0.1F);
   private final BooleanSetting onlyWinnerPotion = new BooleanSetting("Только на победилку", false);
   private final BindSetting disorientationKey = new BindSetting("Дезориентация", -1);
   private final BindSetting trapKey = new BindSetting("Трапка", -1);
   private final BindSetting plastKey = new BindSetting("Пласт", -1);
   private final BindSetting pilKey = new BindSetting("Явная пыль", -1);
   private final BindSetting snegKey = new BindSetting("Снег заморозки", -1);
   private final BindSetting auraKey = new BindSetting("Заряд ветра", -1);
   private final BindSetting netherStarKey = new BindSetting("Стан", -1);
   private final BindSetting prismarineShardKey = new BindSetting("Взрывная трапка", -1);
   private final BindSetting poppedbrokkeKey = new BindSetting("Трапка", -1);
   private final BindSetting fireChargeKey = new BindSetting("Взрывная штучка", -1);
   private final BindSetting snowballKey = new BindSetting("Ком снега", -1);
   private final BooleanSetting snowballEffect = new BooleanSetting("Эффект снежка", false);
   private final BooleanSetting outlineSetting = new BooleanSetting("Отображать радиус", true);
   private final BooleanSetting autoRct = new BooleanSetting("Авто RCT (дабл чар)", false);
   private static final UUID STUN_BOSS_BAR_UUID = UUID.fromString("00000000-0000-0000-0000-000000000077");
   private static final UUID TRAP_BOSS_BAR_UUID = UUID.fromString("00000000-0000-0000-0000-000000000078");
   private class_345 stunBossBar;
   private class_345 trapBossBar;
   private class_1657 lastAttackedPlayer;
   private long lastAttackTime;
   private long lastThrowPotionTime;
   private UUID lastPotionTargetUuid;
   private boolean hasThrownForCurrentPotion;
   private final List<ServerHelper.c> trackedConsumables = new CopyOnWriteArrayList<>();
   private static final int[][] EDGES = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
   private static final long FREEZE_SNOWBALL_DURATION_MS = 10000L;
   private static final int FREEZE_OWNERLESS_SNOWBALL_MAX_AGE = 3;
   private static final double FREEZE_OWNERLESS_SNOWBALL_RANGE_SQ = 20.25;
   private static final double FREEZE_OWNERLESS_SNOWBALL_DIRECTION_DOT = 0.45;
   private static final double FREEZE_SEGMENT_EXPAND = 0.25;
   private static final double FREEZE_HITBOX_EXPAND = 0.2;
   private static final int SNOW_GLOW_COLOR = 3842303;
   private final List<ServerHelper.d> trackedSnowballs = new ArrayList<>();
   private final List<ServerHelper.a> freezeMarks = new ArrayList<>();

   public ServerHelper() {
      this.addSettings(
         this.mode,
         this.healKey,
         this.brokkeKey,
         this.disorientationKey,
         this.trapKey,
         this.plastKey,
         this.pilKey,
         this.snegKey,
         this.auraKey,
         this.netherStarKey,
         this.prismarineShardKey,
         this.poppedbrokkeKey,
         this.fireChargeKey,
         this.snowballKey,
         this.snowballEffect,
         this.outlineSetting,
         this.throwHeal,
         this.throwHealRadius,
         this.onlyWinnerPotion,
         this.autoRct
      );
      this.mode.onChanged(this::p);
      this.throwHeal.onChanged(this::p);
      this.p();
   }

   private void p() {
      boolean var1 = this.mode.isMode("Funtime");
      boolean var2 = this.mode.isMode("HolyWorld");
      boolean var3 = this.throwHeal.isToggled();
      this.autoRct.setVisible(var2);
      this.throwHealRadius.setVisible(var3);
      this.onlyWinnerPotion.setVisible(var3);
      this.disorientationKey.setVisible(var1);
      this.trapKey.setVisible(var1);
      this.plastKey.setVisible(var1);
      this.pilKey.setVisible(var1);
      this.snegKey.setVisible(var1);
      this.auraKey.setVisible(var1);
      this.netherStarKey.setVisible(var2);
      this.prismarineShardKey.setVisible(var2);
      this.poppedbrokkeKey.setVisible(var2);
      this.fireChargeKey.setVisible(var2);
      this.snowballKey.setVisible(var2);
      this.snowballEffect.setVisible(var2);
      if (!var2) {
         this.w();
      }
   }

   public boolean k() {
      return this.mode.isMode("Funtime");
   }

   public boolean l() {
      return this.mode.isMode("HolyWorld");
   }

   public List<ServerHelper.b> m() {
      return List.of(
         new ServerHelper.b("Дезориентация", class_1802.field_8449, this.disorientationKey),
         new ServerHelper.b("Трапка", class_1802.field_22021, this.trapKey),
         new ServerHelper.b("Пласт", class_1802.field_8551, this.plastKey),
         new ServerHelper.b("Явная пыль", class_1802.field_8479, this.pilKey),
         new ServerHelper.b("Снег заморозки", class_1802.field_8543, this.snegKey),
         new ServerHelper.b("Заряд ветра", class_1802.field_49098, this.auraKey)
      );
   }

   public List<ServerHelper.b> n() {
      return List.of(
         new ServerHelper.b("стан", class_1802.field_8137, this.netherStarKey),
         new ServerHelper.b("взрывная трапка", class_1802.field_8662, this.prismarineShardKey),
         new ServerHelper.b("трапка хорус", class_1802.field_8882, this.poppedbrokkeKey),
         new ServerHelper.b("взрывная штучка", class_1802.field_8814, this.fireChargeKey),
         new ServerHelper.b("ком снега", class_1802.field_8543, this.snowballKey)
      );
   }

   public boolean a(class_1297 var1) {
      if (var1 != null && this.isActive() && this.l() && this.snowballEffect.isToggled() && !this.freezeMarks.isEmpty()) {
         long var2 = System.currentTimeMillis();

         for (int var4 = 0; var4 < this.freezeMarks.size() && var4 < this.freezeMarks.size(); var4++) {
            ServerHelper.a var5 = this.freezeMarks.get(var4);
            if (var5.getPlayerId().equals(var1.method_5667()) && var2 < var5.getExpiresAt()) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public int get3842303() {
      return 3842303;
   }

   private void q() {
      if (mc.field_1687 != null && mc.field_1724 != null && this.isActive() && this.l() && this.snowballEffect.isToggled()) {
         long var1 = System.currentTimeMillis();
         this.r();
         this.freezeMarks.removeIf(var3x -> {
            if (var3x.getExpiresAt() <= var1) {
               return true;
            }

            class_1657 var4x = this.a(var3x.getPlayerId());
            return var4x == null || !var4x.method_5805() || var4x.method_7325();
         });

         for (int var3 = this.trackedSnowballs.size() - 1; var3 >= 0; var3--) {
            ServerHelper.d var4 = this.trackedSnowballs.get(var3);
            class_1680 var5 = var4.getEntity();
            if (var5 != null && !var5.method_31481() && !var5.method_24828()) {
               class_243 var6 = new class_243(var5.method_23317(), var5.method_23318(), var5.method_23321());
               class_1657 var7 = this.a(var4.getLastPos(), var6, var5);
               if (var7 != null) {
                  this.a(var7, var1, var1 + 10000L);
                  this.trackedSnowballs.remove(var3);
               } else {
                  this.trackedSnowballs.set(var3, var4.a(var6));
               }
            } else {
               this.trackedSnowballs.remove(var3);
            }
         }

         for (class_1657 var9 : mc.field_1687.method_18456()) {
            if (var9 != null && var9.method_5805() && !var9.method_7325() && this.a(var9)) {
               this.a(var9, var1, this.a(var9, var1));
            }
         }

         this.s();
      } else {
         this.trackedSnowballs.clear();
         this.freezeMarks.clear();
      }
   }

   private void r() {
      for (class_1297 var2 : mc.field_1687.method_18112()) {
         if (var2 instanceof class_1680 var3) {
            boolean var4 = this.trackedSnowballs.stream().anyMatch(var1 -> var1.getEntity() == var3);
            if (!var4) {
               this.trackedSnowballs.add(new ServerHelper.d(var3, this.a(var3)));
            }
         }
      }
   }

   private class_243 a(class_1680 var1) {
      class_243 var2 = new class_243(var1.method_23317(), var1.method_23318(), var1.method_23321());
      class_243 var3 = new class_243(var1.field_6038, var1.field_5971, var1.field_5989);
      if (var2.method_1025(var3) > 1.0E-4) {
         return var3;
      }

      class_243 var4 = var1.method_18798();
      if (var4.method_1027() > 1.0E-4) {
         return var2.method_1020(var4);
      }

      class_1297 var5 = var1.method_24921();
      return var5 != null ? var5.method_33571() : var2;
   }

   private class_1657 a(class_243 var1, class_243 var2, class_1680 var3) {
      if (var1 != null && var2 != null) {
         class_238 var4 = new class_238(var1, var2).method_1014(0.25);
         class_1657 var5 = null;
         double var6 = Double.MAX_VALUE;
         class_1297 var8 = var3 != null ? var3.method_24921() : null;

         for (class_1657 var10 : mc.field_1687
            .method_8390(class_1657.class, var4, var1x -> var1x.method_5805() && !var1x.method_7325() && (var8 == null || var1x != var8))) {
            Optional var11 = var10.method_5829().method_1014(0.2).method_992(var1, var2);
            if (!var11.isEmpty()) {
               double var12 = var1.method_1025((class_243)var11.get());
               if (var12 < var6) {
                  var6 = var12;
                  var5 = var10;
               }
            }
         }

         return var5;
      } else {
         return null;
      }
   }

   private boolean a(class_1657 var1) {
      return var1 != null && this.a(var1.method_6112(class_1294.field_5909));
   }

   private boolean a(class_1293 var1) {
      return var1 != null && var1.method_5578() >= 5;
   }

   private long a(class_1657 var1, long var2) {
      if (var1 == null) {
         return var2 + 10000L;
      }

      class_1293 var4 = var1.method_6112(class_1294.field_5909);
      return !this.a(var4) ? var2 + 10000L : var2 + Math.max(50L, var4.method_5584() * 50L);
   }

   private void a(class_1657 var1, long var2, long var4) {
      UUID var6 = var1.method_5667();
      this.freezeMarks.removeIf(var1x -> var1x.getPlayerId().equals(var6));
      this.freezeMarks.add(new ServerHelper.a(var6, var2, var4));
   }

   private class_1657 a(UUID var1) {
      return mc.field_1687 != null && var1 != null ? mc.field_1687.method_18470(var1) : null;
   }

   @EventHandler
   public void onHudRender(HudRenderEvent var1) {
      if (mc.field_1687 != null && mc.field_1724 != null && this.isActive() && this.l() && this.snowballEffect.isToggled() && !this.freezeMarks.isEmpty()) {
         class_332 var2 = var1.getContext();
         long var3 = System.currentTimeMillis();
         float var5 = mc.method_61966().method_60637(true);
         class_1799 var6 = new class_1799(class_1802.field_8543);
         int var7 = -12934913;

         for (int var8 = 0; var8 < this.freezeMarks.size() && var8 < this.freezeMarks.size(); var8++) {
            ServerHelper.a var9 = this.freezeMarks.get(var8);
            if (var9.getExpiresAt() > var3) {
               class_1657 var10 = this.a(var9.getPlayerId());
               if (var10 != null && var10.method_5805() && !var10.method_7325()) {
                  float var11 = class_3532.method_15363(
                     (float)(var9.getExpiresAt() - var3) / (float)Math.max(1L, var9.getExpiresAt() - var9.getStartedAt()), 0.0F, 1.0F
                  );
                  class_243 var12 = var10.method_30950(var5);
                  double var13 = var12.field_1352;
                  double var15 = var12.field_1351 + var10.method_17682() * 0.5;
                  double var17 = var12.field_1350;
                  float[] var19 = this.a(new class_243(var13, var15, var17));
                  if (var19 != null) {
                     this.a(var2, var19[0], var19[1], 9.0F, var6, var11, var7);
                  }
               }
            }
         }
      }
   }

   private void a(class_332 var1, float var2, float var3, float var4, class_1799 var5, float var6, int var7) {
      RenderUtil.a(var2, var3, var4, new Color(var7, true));
      float var8 = 2.0F / mc.method_22683().method_4495();
      Matrix3x2fStack var9 = var1.method_51448();
      var9.pushMatrix();
      var9.translate(var2 * var8, var3 * var8);
      float var10 = var4 / 16.0F * var8 * 0.8F;
      var9.scale(var10, var10);
      var9.translate(-8.0F, -8.0F);
      var1.method_51427(var5, 0, 0);
      var1.method_51431(mc.field_1772, var5, 0, 0);
      var9.popMatrix();
   }

   private float[] a(class_243 var1) {
      class_4184 var2 = mc.field_1773.method_19418();
      class_243 var3 = var2.method_71156();
      double var4 = var1.field_1352 - var3.field_1352;
      double var6 = var1.field_1351 - var3.field_1351;
      double var8 = var1.field_1350 - var3.field_1350;
      double var10 = Math.toRadians(var2.method_19330());
      double var12 = Math.toRadians(var2.method_19329());
      double var14 = Math.cos(var10);
      double var16 = Math.sin(var10);
      double var18 = Math.cos(var12);
      double var20 = Math.sin(var12);
      double var22 = -var16 * var18;
      double var24 = -var20;
      double var26 = var14 * var18;
      double var28 = -var14;
      double var30 = -var16;
      double var32 = -var16 * var20;
      double var34 = var18;
      double var36 = var14 * var20;
      double var38 = var4 * var28 + var8 * var30;
      double var40 = var4 * var32 + var6 * var34 + var8 * var36;
      double var42 = var4 * var22 + var6 * var24 + var8 * var26;
      if (var42 < 0.05) {
         return null;
      }

      float var44 = RenderUtil.a();
      float var45 = RenderUtil.b();
      float var46 = ((IGameRenderer)mc.field_1773).invokeGetFov(var2, mc.method_61966().method_60637(true), true);
      double var47 = var45 / 2.0 / Math.tan(Math.toRadians(var46) / 2.0);
      return new float[]{var44 / 2.0F + (float)(var38 / var42 * var47), var45 / 2.0F - (float)(var40 / var42 * var47), (float)(var47 / var42)};
   }

   private void s() {
      if (!this.freezeMarks.isEmpty()) {
         ThreadLocalRandom var1 = ThreadLocalRandom.current();

         for (ServerHelper.a var3 : this.freezeMarks) {
            class_1657 var4 = this.a(var3.getPlayerId());
            if (var4 != null && var4.method_5805() && !var4.method_7325()) {
               class_238 var5 = var4.method_5829();
               double var6 = var5.field_1320 - var5.field_1323;
               double var8 = var5.field_1324 - var5.field_1321;
               double var10 = var5.field_1325 - var5.field_1322;

               for (int var12 = 0; var12 < 4; var12++) {
                  double var13 = var5.field_1323 - 0.15 + var1.nextDouble() * (var6 + 0.3);
                  double var15 = var5.field_1321 - 0.15 + var1.nextDouble() * (var8 + 0.3);
                  double var17 = var5.field_1322 + var1.nextDouble() * (var10 + 0.4);
                  mc.field_1687.method_8406(class_2398.field_28013, var13, var17, var15, 0.0, -0.05, 0.0);
               }
            }
         }
      }
   }

   @EventHandler
   public void onBinding(KeyEvent var1) {
      if (var1.getAction() == 1 && mc.field_1755 == null && mc.field_1724 != null && mc.field_1724.field_7512 instanceof class_1723) {
         int var2 = var1.getKey();
         class_1792 var3 = null;
         if (this.healKey.getKey() != -1 && var2 == this.healKey.getKey()) {
            var3 = class_1802.field_8436;
         } else if (this.brokkeKey.getKey() != -1 && var2 == this.brokkeKey.getKey()) {
            var3 = class_1802.field_8233;
         } else if (this.mode.isMode("Funtime")) {
            if (var2 == this.disorientationKey.getKey()) {
               var3 = class_1802.field_8449;
            } else if (var2 == this.trapKey.getKey()) {
               var3 = class_1802.field_22021;
            } else if (var2 == this.plastKey.getKey()) {
               var3 = class_1802.field_8551;
            } else if (var2 == this.pilKey.getKey()) {
               var3 = class_1802.field_8479;
            } else if (var2 == this.snegKey.getKey()) {
               var3 = class_1802.field_8543;
            } else if (var2 == this.auraKey.getKey()) {
               var3 = class_1802.field_49098;
            }
         } else if (this.mode.isMode("HolyWorld")) {
            if (var2 == this.netherStarKey.getKey()) {
               var3 = class_1802.field_8137;
            } else if (var2 == this.prismarineShardKey.getKey()) {
               var3 = class_1802.field_8662;
            } else if (var2 == this.poppedbrokkeKey.getKey()) {
               var3 = class_1802.field_8882;
            } else if (var2 == this.fireChargeKey.getKey()) {
               var3 = class_1802.field_8814;
            } else if (var2 == this.snowballKey.getKey()) {
               var3 = class_1802.field_8543;
            }
         }

         if (var3 != null) {
            HandlerProcessor.a().getUseableHandler().a(var3.method_7854());
         }
      }
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (this.isActive() && mc.field_1687 != null) {
         if (var1.getPacket() instanceof class_2767 var2
            && this.l()
            && var2.method_11894().method_40230().isPresent()
            && var2.method_11894().method_40230().get().method_29177().method_12832().equals("block.beacon.deactivate")) {
            this.b(new class_243(var2.method_11890(), var2.method_11889(), var2.method_11893()));
         }

         if (var1.getPacket() instanceof class_2675 var4 && this.l()) {
            if (var4.method_11551().method_10295() == class_2398.field_11203) {
               this.trackedConsumables
                  .add(new ServerHelper.c(class_1802.field_8662, new class_243(var4.method_11544(), var4.method_11547(), var4.method_11546()), System.currentTimeMillis() + 11000L));
            } else if (var4.method_11551().method_10295() == class_2398.field_11233) {
               this.b(new class_243(var4.method_11544(), var4.method_11547(), var4.method_11546()));
            }
         }
      }
   }

   private void b(class_243 var1) {
      long var2 = System.currentTimeMillis();
      boolean var4 = this.trackedConsumables.stream().anyMatch(var1xx -> var1xx.item == class_1802.field_8137 && var1xx.pos.method_1025(var1) < 64.0);
      if (!var4) {
         this.trackedConsumables.add(new ServerHelper.c(class_1802.field_8137, var1, var2 + 15000L));
      }
   }

   @EventHandler
   public void onAttack(AttackEntityEvent var1) {
      if (var1.getPlayer() == mc.field_1724 && var1.getTarget() instanceof class_1657 var2 && !FriendManager.a(var2.method_5477().getString())) {
         this.lastAttackedPlayer = var2;
         this.lastAttackTime = System.currentTimeMillis();
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         long var2 = System.currentTimeMillis();
         this.trackedConsumables.removeIf(var2xx -> var2 >= var2xx.expireTime);
         this.t();
         this.q();
         this.x();
      } else {
         this.w();
      }
   }

   private void t() {
      if (mc.field_1724 != null && mc.field_1687 != null && this.isActive() && this.l()) {
         long var1 = System.currentTimeMillis();
         long var3 = 0L;
         long var5 = 0L;

         for (ServerHelper.c var8 : this.trackedConsumables) {
            if (var8.item == class_1802.field_8137 && var8.expireTime > var1) {
               if (var8.expireTime > var3) {
                  var3 = var8.expireTime;
               }
            } else if (var8.item == class_1802.field_8662 && var8.expireTime > var1 && var8.expireTime > var5) {
               var5 = var8.expireTime;
            }
         }

         if (mc.field_1705 != null && mc.field_1705.method_1740() != null) {
            Map var14 = ((IBossBarHud)mc.field_1705.method_1740()).getBossBars();
            if (var3 > var1) {
               long var15 = var3 - var1;
               float var10 = class_3532.method_15363((float)var15 / 15000.0F, 0.0F, 1.0F);
               int var11 = (int)Math.ceil(var15 / 1000.0);
               String var12 = var11 <= 5 ? "§c" : "§f";
               class_5250 var13 = class_2561.method_43470("§fДействие стана §7- " + var12 + var11 + " §f" + b(var11));
               if (this.stunBossBar == null) {
                  this.stunBossBar = new class_345(
                     STUN_BOSS_BAR_UUID, var13, var10, net.minecraft.class_1259.class_1260.field_5785, class_1261.field_5795, false, false, false
                  );
               } else {
                  this.stunBossBar.method_5413(var13);
                  this.stunBossBar.method_5408(var10);
                  this.stunBossBar.method_5416(net.minecraft.class_1259.class_1260.field_5785);
               }

               var14.put(STUN_BOSS_BAR_UUID, this.stunBossBar);
            } else {
               this.u();
            }

            if (var5 > var1) {
               long var16 = var5 - var1;
               float var17 = class_3532.method_15363((float)var16 / 11000.0F, 0.0F, 1.0F);
               int var18 = (int)Math.ceil(var16 / 1000.0);
               String var19 = var18 <= 5 ? "§c" : "§f";
               class_5250 var20 = class_2561.method_43470("§fДействие Взрывной трапки §7- " + var19 + var18 + " §f" + b(var18));
               if (this.trapBossBar == null) {
                  this.trapBossBar = new class_345(
                     TRAP_BOSS_BAR_UUID, var20, var17, net.minecraft.class_1259.class_1260.field_5786, class_1261.field_5795, false, false, false
                  );
               } else {
                  this.trapBossBar.method_5413(var20);
                  this.trapBossBar.method_5408(var17);
                  this.trapBossBar.method_5416(net.minecraft.class_1259.class_1260.field_5786);
               }

               var14.put(TRAP_BOSS_BAR_UUID, this.trapBossBar);
            } else {
               this.v();
            }
         } else {
            this.w();
         }
      } else {
         this.w();
      }
   }

   private void u() {
      if (this.stunBossBar != null) {
         if (mc.field_1705 != null && mc.field_1705.method_1740() != null) {
            try {
               ((IBossBarHud)mc.field_1705.method_1740()).getBossBars().remove(STUN_BOSS_BAR_UUID);
            } catch (Exception var2) {
            }
         }

         this.stunBossBar = null;
      }
   }

   private void v() {
      if (this.trapBossBar != null) {
         if (mc.field_1705 != null && mc.field_1705.method_1740() != null) {
            try {
               ((IBossBarHud)mc.field_1705.method_1740()).getBossBars().remove(TRAP_BOSS_BAR_UUID);
            } catch (Exception var2) {
            }
         }

         this.trapBossBar = null;
      }
   }

   private void w() {
      this.u();
      this.v();
   }

   private static String b(int var0) {
      int var1 = var0 % 100;
      int var2 = var0 % 10;
      if (var1 >= 11 && var1 <= 19) {
         return "секунд";
      } else if (var2 == 1) {
         return "секунда";
      } else {
         return var2 >= 2 && var2 <= 4 ? "секунды" : "секунд";
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && !mc.field_1690.field_1842 && this.isActive() && this.outlineSetting.isToggled()) {
         class_287 var2 = ColorPipeline.a();
         if (var2 != null) {
            boolean var3 = false;
            if (this.l()) {
               boolean var4 = this.a(class_1802.field_8137, this.netherStarKey);
               boolean var5 = this.a(class_1802.field_8662, this.prismarineShardKey);
               boolean var6 = this.a(class_1802.field_8882, this.poppedbrokkeKey);
               if (var4) {
                  this.b(var2, mc.field_1724.method_24515(), 15.01F);
                  var3 = true;
               }

               if (var5) {
                  this.a(var2, mc.field_1724.method_24515(), 3.99F);
                  var3 = true;
               }

               if (var6) {
                  this.a(var2, mc.field_1724.method_24515(), 1.99F);
                  var3 = true;
               }
            } else if (this.k()) {
               boolean var7 = this.a(class_1802.field_22021, this.trapKey);
               if (var7) {
                  this.a(var2, mc.field_1724.method_24515(), 1.99F);
                  var3 = true;
               }
            }

            for (ServerHelper.c var9 : this.trackedConsumables) {
               if (var9.item == class_1802.field_8137) {
                  this.b(var2, class_2338.method_49638(var9.pos), 15.01F);
                  var3 = true;
               } else if (var9.item == class_1802.field_8662) {
                  this.a(var2, class_2338.method_49638(var9.pos), 15.01F);
                  var3 = true;
               } else if (var9.item == class_1802.field_22021) {
                  this.a(var2, class_2338.method_49638(var9.pos), 1.99F);
                  var3 = true;
               }
            }

            if (var3) {
               ColorPipeline.a(var2, false);
            }
         }
      }
   }

   private boolean a(class_1792 var1, BindSetting var2) {
      if (mc.field_1724 == null) {
         return false;
      }

      if (!mc.field_1724.method_6047().method_31574(var1) && !mc.field_1724.method_6079().method_31574(var1)) {
         if (mc.field_1755 == null && var2 != null && var2.getKey() != -1 && mc.method_22683() != null) {
            long var3 = mc.method_22683().method_4490();
            int var5 = var2.getKey();
            if (var5 >= 0 && var5 <= 348) {
               return GLFW.glfwGetKey(var3, var5) == 1;
            }

            if (var5 >= 0) {
               return GLFW.glfwGetMouseButton(var3, var5) == 1;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private void a(class_287 var1, class_2338 var2, float var3) {
      class_238 var4 = new class_238(var2.method_10084()).method_35580(0.0, 0.2, 0.0).method_1014(var3);
      boolean var5 = mc.field_1687
         .method_18456()
         .stream()
         .anyMatch(
            var1x -> var1x != mc.field_1724
               && var1x.method_5805()
               && !var1x.method_31481()
               && var4.method_994(var1x.method_5829())
               && !FriendManager.a(var1x.method_5477().getString())
         );
      Color var6 = Theme.getInstance().getAccent();
      int var7 = -436207616 | var6.getRed() << 16 | var6.getGreen() << 8 | var6.getBlue();
      int var8 = -251707071;
      int var9 = var5 ? var8 : var7;
      this.a(var1, var4, var9);
   }

   private void b(class_287 var1, class_2338 var2, float var3) {
      class_238 var4 = new class_238(var2.method_10084()).method_35580(0.0, 0.2, 0.0).method_1014(var3);
      boolean var5 = mc.field_1687
         .method_18456()
         .stream()
         .anyMatch(
            var1x -> var1x != mc.field_1724
               && var1x.method_5805()
               && !var1x.method_31481()
               && var4.method_994(var1x.method_5829())
               && !FriendManager.a(var1x.method_5477().getString())
         );
      Color var6 = Theme.getInstance().getAccent();
      int var7 = -436207616 | var6.getRed() << 16 | var6.getGreen() << 8 | var6.getBlue();
      int var8 = -251707071;
      int var9 = var5 ? var8 : var7;
      this.a(var1, var4, var9);
   }

   private void a(class_287 var1, class_238 var2, int var3) {
      class_243[] var4 = new class_243[]{
         new class_243(var2.field_1323, var2.field_1322, var2.field_1321),
         new class_243(var2.field_1320, var2.field_1322, var2.field_1321),
         new class_243(var2.field_1320, var2.field_1322, var2.field_1324),
         new class_243(var2.field_1323, var2.field_1322, var2.field_1324),
         new class_243(var2.field_1323, var2.field_1325, var2.field_1321),
         new class_243(var2.field_1320, var2.field_1325, var2.field_1321),
         new class_243(var2.field_1320, var2.field_1325, var2.field_1324),
         new class_243(var2.field_1323, var2.field_1325, var2.field_1324)
      };

      for (int[] var8 : EDGES) {
         float[][] var9 = WorldToScreen.a(var4[var8[0]], var4[var8[1]]);
         if (var9 != null) {
            ColorPipeline.a(var1, var9[0][0], var9[0][1], var9[1][0], var9[1][1], 1.5F, var3);
         }
      }
   }

   private void x() {
      if (!this.isActive() || !this.throwHeal.isToggled() || mc.field_1724 == null || mc.field_1687 == null) {
         this.hasThrownForCurrentPotion = false;
         this.lastPotionTargetUuid = null;
      } else if (mc.field_1724.field_7512 instanceof class_1723) {
         class_1657 var1 = this.y();
         if (var1 != null && var1.method_5805() && !var1.method_7325() && !var1.method_31481()) {
            if (mc.field_1724.method_5739(var1) > this.throwHealRadius.getFloatValue()) {
               this.hasThrownForCurrentPotion = false;
            } else {
               if (this.lastPotionTargetUuid == null || !this.lastPotionTargetUuid.equals(var1.method_5667())) {
                  this.lastPotionTargetUuid = var1.method_5667();
                  this.hasThrownForCurrentPotion = false;
               }

               if (!this.b(var1)) {
                  this.hasThrownForCurrentPotion = false;
               } else if (!this.hasThrownForCurrentPotion) {
                  long var2 = System.currentTimeMillis();
                  if (var2 - this.lastThrowPotionTime >= 650L) {
                     Rotation2 var4 = this.b((class_1297)var1);
                     int var5 = DeltaInventoryUtil.a(true);
                     int var6 = DeltaInventoryUtil.a(false);
                     if (var5 != -1) {
                        int var7 = mc.field_1724.method_31548().method_67532();
                        if (var5 != var7) {
                           mc.field_1724.method_31548().method_61496(var5);
                           if (mc.field_1724.field_3944 != null) {
                              mc.field_1724.field_3944.method_52787(new class_2868(var5));
                           }
                        }

                        mc.field_1724.method_36456(var4.getYaw());
                        mc.field_1724.method_36457(var4.getPitch());
                        if (mc.field_1761 != null) {
                           ((IClientPlayerInteractionManager)mc.field_1761)
                              .invokeSendSequencedPacket(
                                 mc.field_1687, var1x -> new class_2886(class_1268.field_5808, var1x, var4.getYaw(), var4.getPitch())
                              );
                           mc.field_1724.method_6104(class_1268.field_5808);
                        }

                        if (var5 != var7) {
                           mc.field_1724.method_31548().method_61496(var7);
                           if (mc.field_1724.field_3944 != null) {
                              mc.field_1724.field_3944.method_52787(new class_2868(var7));
                           }
                        }

                        this.lastThrowPotionTime = var2;
                        this.hasThrownForCurrentPotion = true;
                     } else if (var6 != -1) {
                        if (!HandlerProcessor.a().getUseableHandler().getTasks().isEmpty()) {
                           return;
                        }

                        mc.field_1724.method_36456(var4.getYaw());
                        mc.field_1724.method_36457(var4.getPitch());
                        HandlerProcessor.a().getUseableHandler().a(class_1802.field_8436.method_7854(), var4);
                        this.lastThrowPotionTime = var2;
                        this.hasThrownForCurrentPotion = true;
                     }
                  }
               }
            }
         } else {
            this.hasThrownForCurrentPotion = false;
            this.lastPotionTargetUuid = null;
         }
      }
   }

   private class_1657 y() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         float var1 = this.throwHealRadius.getFloatValue();
         Aura var2 = FunctionManager.a(Aura.class);
         if (var2 != null
            && var2.isActive()
            && var2.getTarget() instanceof class_1657 var3
            && var3.method_5805()
            && !var3.method_7325()
            && !var3.method_31481()
            && !FriendManager.a(var3.method_5477().getString())
            && mc.field_1724.method_5739(var3) <= var1
            && this.b(var3)) {
            return var3;
         }

         long var12 = System.currentTimeMillis();
         if (this.lastAttackedPlayer != null
            && this.lastAttackedPlayer.method_5805()
            && !this.lastAttackedPlayer.method_7325()
            && !this.lastAttackedPlayer.method_31481()
            && !FriendManager.a(this.lastAttackedPlayer.method_5477().getString())
            && mc.field_1724.method_5739(this.lastAttackedPlayer) <= var1
            && var12 - this.lastAttackTime <= 8000L
            && this.b(this.lastAttackedPlayer)) {
            return this.lastAttackedPlayer;
         }

         for (class_1657 var6 : mc.field_1687.method_18456()) {
            if (var6 != mc.field_1724
               && var6.method_5805()
               && !var6.method_7325()
               && !var6.method_31481()
               && !FriendManager.a(var6.method_5477().getString())
               && mc.field_1724.method_5739(var6) <= var1
               && this.b(var6)) {
               return var6;
            }
         }

         if (var2 != null
            && var2.isActive()
            && var2.getTarget() instanceof class_1657 var13
            && var13.method_5805()
            && !var13.method_7325()
            && !var13.method_31481()
            && !FriendManager.a(var13.method_5477().getString())
            && mc.field_1724.method_5739(var13) <= var1) {
            return var13;
         }

         if (this.lastAttackedPlayer != null
            && this.lastAttackedPlayer.method_5805()
            && !this.lastAttackedPlayer.method_7325()
            && !this.lastAttackedPlayer.method_31481()
            && !FriendManager.a(this.lastAttackedPlayer.method_5477().getString())
            && mc.field_1724.method_5739(this.lastAttackedPlayer) <= var1
            && var12 - this.lastAttackTime <= 8000L) {
            return this.lastAttackedPlayer;
         }

         class_1657 var14 = null;
         double var16 = (double)var1 * var1;

         for (class_1657 var9 : mc.field_1687.method_18456()) {
            if (var9 != mc.field_1724 && var9.method_5805() && !var9.method_7325() && !var9.method_31481() && !FriendManager.a(var9.method_5477().getString())) {
               double var10 = mc.field_1724.method_5858(var9);
               if (var10 <= var16) {
                  var16 = var10;
                  var14 = var9;
               }
            }
         }

         return var14;
      } else {
         return null;
      }
   }

   private boolean b(class_1657 var1) {
      if (var1 == null) {
         return false;
      }

      boolean var2 = var1.method_6115() || var1.method_6014() > 0 || var1.method_6048() > 0;
      if (!var2) {
         return false;
      }

      class_1799 var3 = var1.method_6030();
      class_1799 var4 = var1.method_6047();
      class_1799 var5 = var1.method_6079();
      return this.onlyWinnerPotion.isToggled() ? this.a(var3) || this.a(var4) || this.a(var5) : this.b(var3) || this.b(var4) || this.b(var5);
   }

   private boolean a(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         String var2 = var1.method_7964().getString().toLowerCase();
         if (var2.contains("победител") || var2.contains("победы")) {
            return true;
         }

         if (!DeltaInventoryUtil.a(var1, "победител") && !DeltaInventoryUtil.a(var1, "Победител")) {
            List var3 = PotionUtility.a(var1);
            boolean var4 = false;
            boolean var5 = false;
            boolean var6 = false;

            for (class_1293 var8 : (Iterable<class_1293>)(Iterable<?>)(var3)) {
               if (var8.method_5579() == class_1294.field_5917) {
                  var4 = true;
               }

               if (var8.method_5579() == class_1294.field_5905) {
                  var5 = true;
               }

               if (var8.method_5579() == class_1294.field_5915) {
                  var6 = true;
               }
            }

            return var4 && (var5 || var6);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean b(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return false;
      }

      if (var1.method_31574(class_1802.field_8574)) {
         return true;
      }

      if (this.a(var1)) {
         return true;
      }

      if (PotionUtility.a(var1, class_1294.field_5915)) {
         return true;
      }

      String var2 = var1.method_7964().getString().toLowerCase();
      return !var2.contains("исцелен") && !var2.contains("heal") && !var2.contains("зелье") && !var2.contains("лечени")
         ? DeltaInventoryUtil.a(var1, "исцелен")
            || DeltaInventoryUtil.a(var1, "Исцелен")
            || DeltaInventoryUtil.a(var1, "Instant Health")
            || DeltaInventoryUtil.a(var1, "Мгновенное лечение")
            || DeltaInventoryUtil.a(var1, "зелье")
         : true;
   }

   private Rotation2 b(class_1297 var1) {
      if (mc.field_1724 != null && var1 != null) {
         class_243 var2 = mc.field_1724.method_33571();
         class_243 var3 = new class_243(var1.method_23317(), var1.method_23318() + var1.method_5751() * 0.5, var1.method_23321());
         double var4 = var3.field_1352 - var2.field_1352;
         double var6 = var3.field_1351 - var2.field_1351;
         double var8 = var3.field_1350 - var2.field_1350;
         double var10 = Math.sqrt(var4 * var4 + var8 * var8);
         float var12 = (float)(Math.toDegrees(Math.atan2(var8, var4)) - 90.0);
         float var13 = (float)(-Math.toDegrees(Math.atan2(var6, var10)));
         float var14 = var13;
         if (var10 > 1.5) {
            var14 -= (float)Math.min(18.0, var10 * 1.2);
         }

         return new Rotation2(var12, class_3532.method_15363(var14, -89.0F, 89.0F));
      } else {
         return new Rotation2(0.0F, 0.0F);
      }
   }

   @EventHandler
   public void onFinishEat(FinishEatEvent var1) {
      if (this.isActive()
         && this.l()
         && this.autoRct.isToggled()
         && var1.getUser() == mc.field_1724
         && var1.getStack().method_31574(class_1802.field_8367)
         && !RCTCommand.g()
         && mc.field_1724 != null
         && mc.field_1724.field_3944 != null) {
         mc.field_1724.field_3944.method_45729(".rct");
      }
   }

   @Override
   public void onDisable() {
      this.w();
      this.freezeMarks.clear();
      this.trackedSnowballs.clear();
      this.trackedConsumables.clear();
      this.lastAttackedPlayer = null;
      this.lastPotionTargetUuid = null;
      this.hasThrownForCurrentPotion = false;
      super.onDisable();
   }

   record a(UUID playerId, long startedAt, long expiresAt) {
      public UUID getPlayerId() {
         return this.playerId;
      }

      public long getStartedAt() {
         return this.startedAt;
      }

      public long getExpiresAt() {
         return this.expiresAt;
      }
   }

   public record b(String name, class_1792 item, BindSetting bind) {
      public String getName() {
         return this.name;
      }

      public class_1792 getItem() {
         return this.item;
      }

      public BindSetting getBind() {
         return this.bind;
      }
   }

   record c(class_1792 item, class_243 pos, long expireTime) {
      public class_1792 getItem() {
         return this.item;
      }

      public class_243 getPos() {
         return this.pos;
      }

      public long getExpireTime() {
         return this.expireTime;
      }
   }

   record d(class_1680 entity, class_243 lastPos) {
      public ServerHelper.d a(class_243 var1) {
         return new ServerHelper.d(this.entity, var1);
      }

      public class_1680 getEntity() {
         return this.entity;
      }

      public class_243 getLastPos() {
         return this.lastPos;
      }
   }
}
