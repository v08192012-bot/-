package brokke.cc.module.misc;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.Timer2;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventGameUpdate;
import java.util.Locale;
import net.minecraft.class_1268;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1716;
import net.minecraft.class_1722;
import net.minecraft.class_1723;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2315;
import net.minecraft.class_2325;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2531;
import net.minecraft.class_3708;
import net.minecraft.class_3965;
import net.minecraft.class_476;

@NewFunction(name = "Chest Stealer", description = "Автоматически забирает вещи из сундука", category = Category.MISC)
public class ChestStealer extends Function {
   private final NumberSetting delay = new NumberSetting("Задержка", 50.0, 10.0, 250.0, 1.0);
   private final BooleanSetting holyWorldPriority = new BooleanSetting("Приоритет HolyWorld", false);
   private final BooleanSetting autoOpen = new BooleanSetting("Открывать сундук/шалкер", false);
   private final BooleanSetting autoDisable = new BooleanSetting("Выключать после закрытия", false);
   private final Timer2 timer = new Timer2();
   private final Timer2 openTimer = new Timer2();
   private boolean wasInContainer = false;

   public ChestStealer() {
      this.addSettings(this.delay, this.holyWorldPriority, this.autoOpen, this.autoDisable);
   }

   @Override
   public void onEnable() {
      this.timer.a();
      this.openTimer.a();
      this.wasInContainer = false;
   }

   @Override
   public void onDisable() {
      this.timer.a();
      this.openTimer.a();
      this.wasInContainer = false;
   }

   @EventHandler
   public void onGameUpdate(EventGameUpdate var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (mc.field_1755 == null) {
            if (this.wasInContainer) {
               this.wasInContainer = false;
               if (this.autoDisable.getValue()) {
                  this.setEnabled(false);
                  return;
               }
            }

            this.k();
         } else if (mc.field_1724.field_7512 instanceof class_1723) {
            if (this.wasInContainer) {
               this.wasInContainer = false;
               if (this.autoDisable.getValue()) {
                  this.setEnabled(false);
               }
            }
         } else {
            int var2 = this.l();
            if (var2 > 0) {
               this.wasInContainer = true;
               if (this.timer.a((long)this.delay.getValue())) {
                  int var3 = -1;
                  int var4 = -1;

                  for (int var5 = 0; var5 < var2; var5++) {
                     class_1735 var6 = mc.field_1724.field_7512.method_7611(var5);
                     if (var6 != null && var6.method_7681() && !var6.method_7677().method_7960()) {
                        class_1799 var7 = var6.method_7677();
                        if (this.e(var7)) {
                           int var8 = this.a(var7);
                           if (var8 > var4) {
                              var4 = var8;
                              var3 = var5;
                           }
                        }
                     }
                  }

                  if (var3 != -1) {
                     mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, var3, 0, class_1713.field_7794, mc.field_1724);
                     this.timer.a();
                  }
               }
            }
         }
      }
   }

   private void k() {
      if (this.autoOpen.getValue() && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && this.openTimer.a(300L)) {
         class_2338 var1 = null;
         double var2 = 25.0;
         if (mc.field_1765 instanceof class_3965 var4) {
            class_2338 var14 = var4.method_17777();
            if (this.a(mc.field_1687.method_8320(var14).method_26204())) {
               var1 = var14;
               var2 = 0.0;
            }
         }

         if (var1 == null) {
            class_2338 var12 = mc.field_1724.method_24515();
            byte var15 = 4;

            for (int var6 = -var15; var6 <= var15; var6++) {
               for (int var7 = -var15; var7 <= var15; var7++) {
                  for (int var8 = -var15; var8 <= var15; var8++) {
                     class_2338 var9 = var12.method_10069(var6, var7, var8);
                     if (this.a(mc.field_1687.method_8320(var9).method_26204())) {
                        double var10 = mc.field_1724.method_5649(var9.method_10263() + 0.5, var9.method_10264() + 0.5, var9.method_10260() + 0.5);
                        if (var10 < var2) {
                           var2 = var10;
                           var1 = var9;
                        }
                     }
                  }
               }
            }
         }

         if (var1 != null) {
            class_3965 var13 = new class_3965(class_243.method_24953(var1), class_2350.field_11036, var1, false);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, var13);
            mc.field_1724.method_6104(class_1268.field_5808);
            this.openTimer.a();
         }
      }
   }

   private boolean a(class_2248 var1) {
      return var1 instanceof class_2281
         || var1 instanceof class_2336
         || var1 instanceof class_2531
         || var1 instanceof class_3708
         || var1 instanceof class_2480
         || var1 instanceof class_2315
         || var1 instanceof class_2325
         || var1 instanceof class_2377;
   }

   private int a(class_1799 var1) {
      if (var1 == null || var1.method_7960()) {
         return -1;
      } else if (!this.holyWorldPriority.getValue()) {
         return 0;
      } else if (var1.method_31574(class_1802.field_8366)) {
         return 2;
      } else {
         return !var1.method_31574(class_1802.field_8288)
               && !var1.method_31574(class_1802.field_8575)
               && !var1.method_31574(class_1802.field_8662)
               && !var1.method_31574(class_1802.field_8137)
               && !var1.method_31574(class_1802.field_22020)
               && !var1.method_31574(class_1802.field_22018)
               && !this.b(var1)
               && !var1.method_31574(class_1802.field_8547)
               && !var1.method_31574(class_1802.field_8626)
               && !var1.method_31574(class_1802.field_8367)
               && !var1.method_31574(class_1802.field_8849)
               && !var1.method_31574(class_1802.field_8833)
               && !var1.method_31574(class_1802.field_8287)
               && !var1.method_31574(class_1802.field_8543)
               && !this.c(var1)
               && !this.d(var1)
            ? 0
            : 1;
      }
   }

   private boolean b(class_1799 var1) {
      return var1.method_31574(class_1802.field_22027)
         || var1.method_31574(class_1802.field_22028)
         || var1.method_31574(class_1802.field_22029)
         || var1.method_31574(class_1802.field_22030)
         || var1.method_31574(class_1802.field_22022)
         || var1.method_31574(class_1802.field_22024)
         || var1.method_31574(class_1802.field_22025)
         || var1.method_31574(class_1802.field_22023)
         || var1.method_31574(class_1802.field_22026);
   }

   private boolean c(class_1799 var1) {
      if (!var1.method_31574(class_1802.field_22019)) {
         return false;
      }

      String var2 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      return var2.contains("уникальный приват");
   }

   private boolean d(class_1799 var1) {
      if (!var1.method_31574(class_1802.field_8574) && !var1.method_31574(class_1802.field_8436) && !var1.method_31574(class_1802.field_8150)) {
         return false;
      }

      String var2 = var1.method_7964().getString().toLowerCase(Locale.ROOT);
      return var2.contains("победителя");
   }

   private int l() {
      if (mc.field_1724 != null && mc.field_1724.field_7512 != null) {
         if (mc.field_1724.field_7512 instanceof class_1707 var1) {
            if (mc.field_1755 instanceof class_476 var4) {
               String var5 = var4.method_25440() != null ? var4.method_25440().getString().toLowerCase(Locale.ROOT) : "";
               if (var5.contains("аукцион")
                  || var5.contains("аукционы")
                  || var5.contains("поиск")
                  || var5.contains("auction")
                  || var5.equals("ah")
                  || var5.startsWith("ah ")) {
                  return -1;
               }
            }

            return var1.method_17388() * 9;
         } else if (mc.field_1724.field_7512 instanceof class_1733) {
            return 27;
         } else if (mc.field_1724.field_7512 instanceof class_1716) {
            return 9;
         } else {
            return mc.field_1724.field_7512 instanceof class_1722 ? 5 : -1;
         }
      } else {
         return -1;
      }
   }

   private boolean e(class_1799 var1) {
      if (mc.field_1724 == null) {
         return false;
      }

      for (int var2 = 0; var2 < 36; var2++) {
         class_1799 var3 = mc.field_1724.method_31548().method_5438(var2);
         if (var3.method_7960()) {
            return true;
         }

         if (class_1799.method_31577(var3, var1) && var3.method_7947() < var3.method_7914()) {
            return true;
         }
      }

      return false;
   }
}
