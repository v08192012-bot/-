package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_10255;
import net.minecraft.class_1297;
import net.minecraft.class_238;

@NewFunction(name = "BoatLongJump", description = "Длинный прыжок рядом с лодкой (HW)", category = Category.MOVEMENT)
public class BoatLongJump extends Function {
   private boolean jumped = false;

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1724.method_5854() == null) {
         class_1297 var2 = this.k();
         if (mc.field_1724.method_24828()) {
            if (mc.field_1690.field_1903.method_1434() && var2 != null && !this.jumped && mc.field_1724.method_5624()) {
               float var3 = mc.field_1724.method_36454();
               double var4 = mc.field_1724.method_18798().field_1352 + -Math.sin(Math.toRadians(var3)) * 0.9;
               double var6 = mc.field_1724.method_18798().field_1350 + Math.cos(Math.toRadians(var3)) * 0.9;
               mc.field_1724.method_18800(var4, mc.field_1724.method_18798().field_1351, var6);
               this.jumped = true;
            }
         } else {
            this.jumped = false;
         }
      }
   }

   private class_1297 k() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_238 var1 = mc.field_1724.method_5829().method_1014(1.0);

         for (class_1297 var3 : mc.field_1687.method_18112()) {
            if (var3 instanceof class_10255 var4 && !var4.method_5626(mc.field_1724) && var4.method_5829().method_994(var1)) {
               return var4;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   @Override
   public void onDisable() {
      this.jumped = false;
      super.onDisable();
   }
}
