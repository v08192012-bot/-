package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1733;

@NewFunction(name = "ShulkerJump", description = "Подлетаешь вверх при взаимодействии с шалкером", category = Category.MOVEMENT)
public class ShulkerJump extends Function {
   private final NumberSetting velocity = new NumberSetting("Сила подброса", 2.4, 0.5, 5.0, 0.1);
   private int ticks = 0;
   private boolean jumping = false;

   public ShulkerJump() {
      this.addSettings(this.velocity);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1724.field_7512 instanceof class_1733 && !this.jumping) {
            mc.field_1690.field_1903.method_23481(true);
            mc.field_1724.method_7346();
            mc.field_1724.method_5762(0.0, this.velocity.getValue(), 0.0);
            this.jumping = true;
            this.ticks = 0;
         }

         if (this.jumping) {
            if (this.ticks >= 5) {
               mc.field_1724.method_7346();
               mc.field_1690.field_1903.method_23481(false);
               this.jumping = false;
               this.ticks = 0;
            } else {
               this.ticks++;
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.jumping = false;
      this.ticks = 0;
      if (mc.field_1690 != null && mc.field_1690.field_1903 != null) {
         mc.field_1690.field_1903.method_23481(false);
      }

      super.onDisable();
   }
}
