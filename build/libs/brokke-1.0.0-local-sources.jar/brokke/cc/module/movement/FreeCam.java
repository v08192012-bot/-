package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.SendPacketEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1937;
import net.minecraft.class_2828;

@NewFunction(name = "Free Camera", description = "Свободная камера", category = Category.MOVEMENT)
public class FreeCam extends Function {
   private final NumberSetting speed = new NumberSetting("Скорость", 1.0, 0.1, 5.0, 0.1);
   private float savedYaw;
   private float savedPitch;
   private double fakeX;
   private double fakeY;
   private double fakeZ;
   private double prevFakeX;
   private double prevFakeY;
   private double prevFakeZ;
   private class_1937 lastWorld;

   public FreeCam() {
      this.addSettings(this.speed);
   }

   @Override
   public void onEnable() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         mc.field_1730 = false;
         this.savedYaw = mc.field_1724.method_36454();
         this.savedPitch = mc.field_1724.method_36455();
         this.fakeX = this.prevFakeX = mc.field_1724.method_23317();
         this.fakeY = this.prevFakeY = mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376());
         this.fakeZ = this.prevFakeZ = mc.field_1724.method_23321();
         this.lastWorld = mc.field_1687;
         super.onEnable();
      } else {
         this.toggle();
      }
   }

   @Override
   public void onDisable() {
      mc.field_1730 = true;
      this.lastWorld = null;
      if (mc.field_1724 != null) {
         mc.field_1724.method_36456(this.savedYaw);
         mc.field_1724.method_36457(this.savedPitch);
      }

      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1687 == this.lastWorld) {
         this.prevFakeX = this.fakeX;
         this.prevFakeY = this.fakeY;
         this.prevFakeZ = this.fakeZ;
         float var2 = 0.0F;
         float var3 = 0.0F;
         if (mc.field_1690.field_1894.method_1434()) {
            var2++;
         }

         if (mc.field_1690.field_1881.method_1434()) {
            var2--;
         }

         if (mc.field_1690.field_1913.method_1434()) {
            var3++;
         }

         if (mc.field_1690.field_1849.method_1434()) {
            var3--;
         }

         double var4 = this.speed.getValue();
         if (mc.field_1690.field_1867.method_1434()) {
            var4 *= 1.5;
         }

         double[] var6 = this.a(var2, var3, var4);
         this.fakeX = this.fakeX + var6[0];
         this.fakeZ = this.fakeZ + var6[1];
         if (mc.field_1690.field_1903.method_1434()) {
            this.fakeY += var4;
         }

         if (mc.field_1690.field_1832.method_1434()) {
            this.fakeY -= var4;
         }
      } else {
         this.toggle();
      }
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      var1.setForward(0.0F);
      var1.setStrafe(0.0F);
      var1.setJump(false);
      var1.setSneak(false);
      var1.setSprint(false);
   }

   @EventHandler
   public void onSendPacket(SendPacketEvent var1) {
      if (var1.getPacket() instanceof class_2828) {
         var1.cancel();
      }
   }

   private double[] a(float var1, float var2, double var3) {
      if (mc.field_1724 == null) {
         return new double[]{0.0, 0.0};
      }

      float var5 = mc.field_1724.method_36454();
      if (var1 != 0.0F) {
         if (var2 > 0.0F) {
            var5 += var1 > 0.0F ? -45.0F : 45.0F;
         } else if (var2 < 0.0F) {
            var5 += var1 > 0.0F ? 45.0F : -45.0F;
         }

         var2 = 0.0F;
         var1 = var1 > 0.0F ? 1.0F : -1.0F;
      }

      double var6 = Math.sin(Math.toRadians(var5 + 90.0F));
      double var8 = Math.cos(Math.toRadians(var5 + 90.0F));
      return new double[]{var1 * var3 * var8 + var2 * var3 * var6, var1 * var3 * var6 - var2 * var3 * var8};
   }

   public float k() {
      return mc.field_1724 != null ? mc.field_1724.method_36454() : this.savedYaw;
   }

   public float l() {
      return mc.field_1724 != null ? mc.field_1724.method_36455() : this.savedPitch;
   }

   public double a(float var1) {
      return this.prevFakeX + (this.fakeX - this.prevFakeX) * var1;
   }

   public double b(float var1) {
      return this.prevFakeY + (this.fakeY - this.prevFakeY) * var1;
   }

   public double c(float var1) {
      return this.prevFakeZ + (this.fakeZ - this.prevFakeZ) * var1;
   }
}
