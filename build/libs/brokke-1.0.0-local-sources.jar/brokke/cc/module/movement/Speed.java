package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.ElytraChestplateSwapper;
import brokke.cc.manager.TimerController;
import brokke.cc.rotation.HolyWorldElytraPredictor;
import brokke.cc.rotation.RotationTask;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import net.minecraft.class_2868;

@NewFunction(name = "Speed", description = "Elytra speed", category = Category.MOVEMENT)
public class Speed extends Function {
   private static final String ROTATION_TASK = "speed_elytra";
   private static final int ROTATION_PRIORITY = 35;
   public final ModeSetting mode = new ModeSetting("Mode", "HolyWorld", "ReallyWorld", "GrimElytra", "SpookyElytra");
   public final BooleanSetting swapElytra = new BooleanSetting("Свап элитры", true);
   private final HolyWorldElytraPredictor holyPredictor = new HolyWorldElytraPredictor();
   private int rwTicks;
   private int rwCollisionTicks;
   private boolean rwTimerActive;
   private int grimTicks;

   public Speed() {
      this.addSettings(this.mode, this.swapElytra);
   }

   @Override
   public void onEnable() {
      this.holyPredictor.e();
      this.rwTicks = 0;
      this.rwCollisionTicks = 0;
      this.rwTimerActive = false;
      this.grimTicks = 0;
      TimerController.b();
      super.onEnable();
      if (this.swapElytra.isToggled() && mc.field_1724 != null) {
         ElytraChestplateSwapper.b(mc);
      }
   }

   @Override
   public void onDisable() {
      TimerController.b();
      this.t();
      this.holyPredictor.e();
      if (this.swapElytra.isToggled() && mc.field_1724 != null) {
         ElytraChestplateSwapper.c(mc);
      }

      this.rwTicks = 0;
      this.rwCollisionTicks = 0;
      this.rwTimerActive = false;
      this.grimTicks = 0;
      super.onDisable();
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      if (mc.field_1724 != null) {
         if (this.mode.isSelected("HolyWorld")) {
            if (this.holyPredictor.isActive()) {
               if (this.holyPredictor.isJumpRequested()) {
                  var1.setJump(true);
               }

               if (this.holyPredictor.isSprintRequested()) {
                  var1.setSprint(true);
               }
            }
         } else if (this.mode.isSelected("ReallyWorld")) {
            if (mc.field_1724.field_5992) {
               this.rwCollisionTicks++;
            } else {
               this.rwCollisionTicks = 0;
            }

            if (this.rwCollisionTicks >= 1) {
               var1.setJump(true);
            }
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (this.mode.isSelected("HolyWorld")) {
            this.k();
         } else if (this.mode.isSelected("ReallyWorld")) {
            this.l();
         } else if (this.mode.isSelected("SpookyElytra")) {
            this.m();
         } else if (this.mode.isSelected("GrimElytra")) {
            this.n();
         }
      }
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (this.mode.isSelected("ReallyWorld") && var1.getPacket() instanceof class_2708) {
         if (this.rwTicks % 2 == 1) {
            this.rwTicks++;
         }

         TimerController.a(1.0F);
      }
   }

   private void k() {
      this.holyPredictor.a(mc);
      if (this.holyPredictor.isActive() && (mc.field_1724.method_6128() || !mc.field_1724.method_24828())) {
         RotationTask.a("speed_elytra", 35);
         RotationTask.a(mc.field_1724.method_36454(), this.holyPredictor.getTargetPitch(), 360.0F, 360.0F, 360.0F, 360.0F, 0.0, 35);
      } else {
         this.t();
      }
   }

   private void l() {
      TimerController.a(1.7F);
      this.rwTimerActive = true;
      if (this.rwTicks > 3) {
         double var1 = 0.03;
         if (this.rwTicks % 2 == 0) {
            mc.field_1724.method_5762(0.0, 0.03, 0.0);
            var1 = mc.field_1724.method_24828() ? 0.085 : 0.03;
         }

         class_243 var3 = this.q();
         mc.field_1724.method_5762(var3.field_1352 * var1, 0.0, var3.field_1350 * var1);
      }

      if (this.rwTicks % 2 == 0 && mc.field_1724.field_3944 != null) {
         TimerController.a(0.3F);
         mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
      }

      this.rwTicks++;
   }

   private void m() {
      if (mc.field_1724.field_6017 > 1.0 && !mc.field_1724.method_6128() && mc.field_1761 != null && mc.field_1724.field_3944 != null) {
         class_1735 var1 = this.p();
         if (var1 != null) {
            int var2 = mc.field_1724.method_31548().method_67532();
            mc.field_1724.field_3944.method_52787(new class_2868(var1.field_7874 >= 36 && var1.field_7874 <= 44 ? var1.field_7874 - 36 : var2));
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            if (mc.field_1724.method_5624() && this.r() && mc.field_1724.method_23668()) {
               mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
            }

            mc.field_1724.field_3944.method_52787(new class_2868(var2));
         }
      }
   }

   private void n() {
      if (this.r()) {
         mc.field_1724.method_5728(true);
      }

      if (!mc.field_1724.method_24828() && !mc.field_1724.method_6128() && this.o()) {
         if (mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
         }

         mc.field_1724.method_23669();
      }

      if (mc.field_1724.method_24828()) {
         this.grimTicks = 16;
      }

      if (this.r() && !mc.field_1724.method_24828() && this.o() && this.grimTicks > 0) {
         float var1 = this.s();
         RotationTask.a("speed_elytra", 35);
         RotationTask.a(var1, 75.0F, 360.0F, 360.0F, 360.0F, 360.0F, 0.0, 35);
      } else {
         this.t();
      }
   }

   private boolean o() {
      return mc.field_1724 != null && mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
   }

   private class_1735 p() {
      return mc.field_1724 != null && mc.field_1724.field_7512 != null
         ? mc.field_1724.field_7512.field_7761.stream().filter(var0 -> var0.method_7677().method_31574(class_1802.field_8833)).findFirst().orElse(null)
         : null;
   }

   private class_243 q() {
      if (mc.field_1724 != null && mc.field_1724.field_3913 != null) {
         float var1 = mc.field_1724.field_3913.method_3128().field_1342;
         float var2 = mc.field_1724.field_3913.method_3128().field_1343;
         if (var1 == 0.0F && var2 == 0.0F) {
            return class_243.field_1353;
         }

         float var3 = mc.field_1724.method_36454();
         if (var1 != 0.0F) {
            if (var2 > 0.0F) {
               var3 += var1 > 0.0F ? -45.0F : 45.0F;
            } else if (var2 < 0.0F) {
               var3 += var1 > 0.0F ? 45.0F : -45.0F;
            }

            if (var1 < 0.0F) {
               var3 += 180.0F;
            }
         } else if (var2 != 0.0F) {
            var3 += var2 > 0.0F ? -90.0F : 90.0F;
         }

         double var4 = Math.toRadians(var3);
         return new class_243(-Math.sin(var4), 0.0, Math.cos(var4));
      } else {
         return class_243.field_1353;
      }
   }

   private boolean r() {
      return mc.field_1724 != null && mc.field_1724.field_3913 != null && (mc.field_1724.field_3913.method_3128().field_1342 != 0.0F || mc.field_1724.field_3913.method_3128().field_1343 != 0.0F);
   }

   private float s() {
      float var1 = mc.field_1724.field_3913.method_3128().field_1342;
      float var2 = mc.field_1724.field_3913.method_3128().field_1343;
      float var3 = mc.field_1724.method_36454();
      if (var1 < 0.0F) {
         var3 += 180.0F;
      }

      float var4 = var1 < 0.0F ? -0.5F : (var1 > 0.0F ? 0.5F : 1.0F);
      if (var2 > 0.0F) {
         var3 -= 90.0F * var4;
      } else if (var2 < 0.0F) {
         var3 += 90.0F * var4;
      }

      return var3;
   }

   private void t() {
      if (RotationTask.rotationPriority <= 35) {
         RotationTask.b("speed_elytra");
         RotationTask.rotationState = RotationTask.a.RESET;
         RotationTask.rotationPriority = 0;
      }
   }
}
