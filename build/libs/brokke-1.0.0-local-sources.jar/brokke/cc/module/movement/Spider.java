package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationStorage;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.InventoryUtility;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

@NewFunction(name = "Spider", description = "Автоматически ставит блоки для карабканья по стенам", category = Category.MOVEMENT)
public class Spider extends Function {
   private final BooleanSetting rotate = new BooleanSetting("Поворот", true);
   private final BooleanSetting swing = new BooleanSetting("Анимация руки", true);

   public Spider() {
      this.addSettings(this.rotate, this.swing);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && !mc.field_1724.method_7325()) {
         boolean var2 = mc.field_1724.method_6079().method_7909() instanceof class_1747;
         int var3 = this.k();
         if (var2 || var3 != -1) {
            class_2338 var4 = this.l();
            class_2338 var5 = this.b(var4);
            if (!var5.equals(class_2338.field_10980)) {
               class_2350 var6 = this.a(var5, var4);
               if (var6 != null) {
                  class_1799 var7 = var2 ? mc.field_1724.method_6079() : mc.field_1724.method_31548().method_5438(var3);
                  if (var7.method_7909() instanceof class_1747 var8) {
                     class_265 var22 = var8.method_7711().method_9564().method_26220(mc.field_1687, var4);
                     if (!var22.method_1110()) {
                        class_238 var10 = var22.method_1107().method_996(var4);
                        if (!var10.method_994(mc.field_1724.method_5829())) {
                           class_243 var11 = new class_243(
                              var5.method_10263() + 0.5 + var6.method_10148() * 0.5,
                              var5.method_10264() + 0.5 + var6.method_10164() * 0.5,
                              var5.method_10260() + 0.5 + var6.method_10165() * 0.5
                           );
                           if (this.rotate.isToggled()) {
                              double var12 = var11.field_1352 - mc.field_1724.method_23317();
                              double var14 = var11.field_1351 - mc.field_1724.method_33571().field_1351;
                              double var16 = var11.field_1350 - mc.field_1724.method_23321();
                              double var18 = Math.hypot(var12, var16);
                              float var20 = (float)Math.toDegrees(Math.atan2(var16, var12)) - 90.0F;
                              float var21 = (float)(-Math.toDegrees(Math.atan2(var14, var18)));
                              RotationStorage.a(new Rotation2(var20, var21), 180.0F, 180.0F, 1, 2, false);
                           }

                           class_3965 var23 = new class_3965(var11, var6, var5, false);
                           class_1268 var13 = var2 ? class_1268.field_5810 : class_1268.field_5808;
                           int var24 = mc.field_1724.method_31548().method_67532();
                           if (!var2) {
                              InventoryUtility.e(var3);
                           }

                           mc.field_1761.method_2896(mc.field_1724, var13, var23);
                           if (this.swing.isToggled()) {
                              mc.field_1724.method_6104(var13);
                           }

                           if (!var2) {
                              InventoryUtility.e(var24);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private class_2350 a(class_2338 var1, class_2338 var2) {
      if (var1.method_10263() < var2.method_10263()) {
         return class_2350.field_11034;
      } else if (var1.method_10263() > var2.method_10263()) {
         return class_2350.field_11039;
      } else if (var1.method_10260() < var2.method_10260()) {
         return class_2350.field_11035;
      } else if (var1.method_10260() > var2.method_10260()) {
         return class_2350.field_11043;
      } else if (var1.method_10264() < var2.method_10264()) {
         return class_2350.field_11036;
      } else {
         return var1.method_10264() > var2.method_10264() ? class_2350.field_11033 : null;
      }
   }

   private int k() {
      if (mc.field_1724 == null) {
         return -1;
      }

      for (int var1 = 0; var1 < 9; var1++) {
         class_1799 var2 = mc.field_1724.method_31548().method_5438(var1);
         if (!var2.method_7960() && var2.method_7909() instanceof class_1747) {
            return var1;
         }
      }

      return -1;
   }

   private class_2338 l() {
      class_243 var1 = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
      return class_2338.method_49638(var1.method_1019(mc.field_1724.method_18798()).method_1031(0.0, -0.001, 0.0));
   }

   private boolean a(class_2338 var1) {
      if (mc.field_1687 == null) {
         return false;
      }

      class_2680 var2 = mc.field_1687.method_8320(var1);
      return !var2.method_26215() && var2.method_26212(mc.field_1687, var1);
   }

   private class_2338 b(class_2338 var1) {
      if (mc.field_1687 == null) {
         return class_2338.field_10980;
      } else {
         return this.a(var1)
            ? class_2338.field_10980
            : Stream.of(var1.method_10067(), var1.method_10078(), var1.method_10072(), var1.method_10095()).filter(this::a).findFirst().orElse(class_2338.field_10980);
      }
   }
}
