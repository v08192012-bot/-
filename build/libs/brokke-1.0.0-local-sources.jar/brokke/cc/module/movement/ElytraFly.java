package brokke.cc.module.movement;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventMoveInput;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;

@NewFunction(name = "ElytraFly", description = "Взлетает вверх с элитрой (HW)", category = Category.MOVEMENT)
public class ElytraFly extends Function {
   private boolean val121 = false;

   @Override
   public void onDisable() {
      this.val121 = false;
      super.onDisable();
   }

   @EventHandler
   public void onMoveInput(EventMoveInput var1) {
      if (mc.field_1724 != null) {
         class_1799 var2 = mc.field_1724.method_6118(class_1304.field_6174);
         if (var2.method_31574(class_1802.field_8833)) {
            if (mc.field_1724.method_24828()) {
               var1.setJump(true);
               this.val121 = true;
            } else if (!mc.field_1724.method_6128()) {
               if (!this.val121) {
                  if (mc.field_1724.field_3944 != null) {
                     mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
                  }

                  mc.field_1724.method_23669();
               } else {
                  this.val121 = false;
               }
            } else {
               this.val121 = false;
            }
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_1799 var2 = mc.field_1724.method_6118(class_1304.field_6174);
         if (var2.method_31574(class_1802.field_8833) && mc.field_1724.method_6128()) {
            mc.field_1724.method_36457(0.0F);
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351 + 0.0305, mc.field_1724.method_18798().field_1350);
         }
      }
   }
}
