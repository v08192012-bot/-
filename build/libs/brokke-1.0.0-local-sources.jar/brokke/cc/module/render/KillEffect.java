package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.mixins.render.IGameRenderer;
import brokke.cc.render.RenderContext;
import brokke.cc.render.Theme;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.ColorSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.UpdateEvent;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.class_5590;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_1041;
import net.minecraft.class_10789;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2663;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.system.MemoryUtil;

@NewFunction(name = "KillEffect", description = "Торнадо на месте убийства", category = Category.RENDER)
public class KillEffect extends Function {
   private static KillEffect instance;
   private static final VertexFormat FORMAT = VertexFormat.builder()
      .add("Position", VertexFormatElement.POSITION)
      .add("UV", VertexFormatElement.UV0)
      .add("Color", VertexFormatElement.COLOR)
      .build();
   private static RenderPipeline tornadoPipeline;
   private static GpuBuffer matrixUniformBuffer;
   private static GpuBuffer beamUniformBuffer;
   private static GpuBuffer tornadoVbo;
   private static ByteBuffer scratchMatrix;
   private static ByteBuffer scratchBeam;
   private static final int MATRIX_SIZE = 64;
   private static final int BEAM_SIZE = 48;
   private static final int MAX_EFFECTS = 16;
   private final BooleanSetting syncTheme = new BooleanSetting("Цвет темы", true);
   private final ColorSetting customColor = new ColorSetting("Цвет", new Color(130, 80, 255));
   private final NumberSetting size = new NumberSetting("Размер", 2.5, 0.5, 6.0, 0.1);
   private final NumberSetting intensity = new NumberSetting("Интенсивность", 1.0, 0.1, 3.0, 0.1);
   private final NumberSetting speed = new NumberSetting("Скорость", 1.0, 0.2, 3.0, 0.1);
   private final NumberSetting lifetime = new NumberSetting("Длительность", 2.0, 0.5, 5.0, 0.1);
   private final List<KillEffect.a> activeEffects = new CopyOnWriteArrayList<>();
   private final Set<Integer> knownAlive = new HashSet<>();

   public KillEffect() {
      instance = this;
      this.addSettings(this.syncTheme, this.customColor, this.size, this.intensity, this.speed, this.lifetime);
      this.syncTheme.onChanged(() -> this.customColor.setVisible(!this.syncTheme.isToggled()));
   }

   public static KillEffect k() {
      if (instance == null) {
         instance = FunctionManager.a(KillEffect.class);
      }

      return instance;
   }

   private static void a(WorldRenderContext var0) {
      KillEffect var1 = k();
      if (var1 != null && var1.isActive()) {
         var1.b(var0);
      }
   }

   public static void a(class_243 var0) {
      KillEffect var1 = k();
      if (var1 != null && var1.isActive()) {
         var1.b(var0);
      }
   }

   public void b(class_243 var1) {
      if (var1 != null) {
         Color var2 = this.syncTheme.isToggled() ? Theme.getInstance().getAccent() : this.customColor.getColor();
         this.activeEffects
            .add(
               new KillEffect.a(
                  var1,
                  System.currentTimeMillis(),
                  var2,
                  (float)this.size.getValue(),
                  (float)this.intensity.getValue(),
                  (float)this.speed.getValue(),
                  (float)this.lifetime.getValue()
               )
            );

         while (this.activeEffects.size() > 16) {
            this.activeEffects.remove(0);
         }
      }
   }

   @Override
   public void onDisable() {
      this.activeEffects.clear();
      this.knownAlive.clear();
      super.onDisable();
   }

   @EventHandler
   public void onPacket(EventPacket var1) {
      if (mc.field_1687 != null && mc.field_1724 != null && var1.getPacket() instanceof class_2663 var2 && var2.method_11470() == 3) {
         class_1297 var4 = var2.method_11469(mc.field_1687);
         if (var4 instanceof class_1309 && var4 != mc.field_1724) {
            this.b(var4.method_73189());
         }
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         for (class_1297 var3 : mc.field_1687.method_18112()) {
            if (var3 instanceof class_1309 var4 && var3 != mc.field_1724) {
               if ((var4.method_29504() || var4.method_6032() <= 0.0F) && this.knownAlive.remove(var3.method_5628())) {
                  this.b(var3.method_73189());
               } else if (!var4.method_29504() && var4.method_6032() > 0.0F) {
                  this.knownAlive.add(var3.method_5628());
               }
            }
         }

         long var5 = System.currentTimeMillis();
         this.activeEffects.removeIf(var2 -> (float)(var5 - var2.startTime) > var2.lifetimeSec * 1000.0F);
      } else {
         this.knownAlive.clear();
      }
   }

   private void b(WorldRenderContext var1) {
      if (!this.activeEffects.isEmpty() && mc.field_1724 != null && mc.field_1687 != null) {
         l();
         if (tornadoPipeline != null && matrixUniformBuffer != null && beamUniformBuffer != null) {
            Matrix4f var2 = this.m();
            class_243 var3 = mc.field_1773.method_19418().method_71156();
            class_4184 var4 = mc.field_1773.method_19418();
            long var5 = System.currentTimeMillis();
            if (scratchMatrix == null) {
               scratchMatrix = MemoryUtil.memAlloc(64);
            }

            scratchMatrix.clear();
            scratchMatrix.putFloat(var2.m00()).putFloat(var2.m01()).putFloat(var2.m02()).putFloat(var2.m03());
            scratchMatrix.putFloat(var2.m10()).putFloat(var2.m11()).putFloat(var2.m12()).putFloat(var2.m13());
            scratchMatrix.putFloat(var2.m20()).putFloat(var2.m21()).putFloat(var2.m22()).putFloat(var2.m23());
            scratchMatrix.putFloat(var2.m30()).putFloat(var2.m31()).putFloat(var2.m32()).putFloat(var2.m33());
            scratchMatrix.flip();
            CommandEncoder var7 = RenderSystem.getDevice().createCommandEncoder();
            var7.writeToBuffer(matrixUniformBuffer.slice(), scratchMatrix);
            class_276 var8 = mc.method_1522();

            for (KillEffect.a var10 : this.activeEffects) {
               float var11 = (float)(var5 - var10.startTime) / 1000.0F;
               float var12 = var11 / Math.max(0.1F, var10.lifetimeSec);
               if (!(var12 >= 1.0F)) {
                  float var13 = var11 * var10.speed;
                  Color var14 = this.syncTheme.isToggled() ? Theme.getInstance().getAccent() : var10.color;
                  float var15 = var14.getRed() / 255.0F;
                  float var16 = var14.getGreen() / 255.0F;
                  float var17 = var14.getBlue() / 255.0F;
                  float var18 = var14.getAlpha() / 255.0F;
                  if (scratchBeam == null) {
                     scratchBeam = MemoryUtil.memAlloc(48);
                  }

                  scratchBeam.clear();
                  scratchBeam.putFloat(var13);
                  scratchBeam.putFloat(var12);
                  scratchBeam.putFloat(0.0F);
                  scratchBeam.putFloat(0.0F);
                  scratchBeam.putFloat(var15);
                  scratchBeam.putFloat(var16);
                  scratchBeam.putFloat(var17);
                  scratchBeam.putFloat(var18);
                  scratchBeam.putFloat(var10.intensity);
                  scratchBeam.putFloat(var10.size);
                  scratchBeam.putFloat(0.0F);
                  scratchBeam.putFloat(0.0F);
                  scratchBeam.flip();
                  var7.writeToBuffer(beamUniformBuffer.slice(), scratchBeam);
                  class_287 var19 = class_289.method_1348().method_60827(class_5596.field_27379, FORMAT);
                  this.a(var19, var3, var4, var10.pos, var10.size);
                  class_9801 var20 = null;

                  try {
                     var20 = var19.method_60800();
                     int var21 = var20.method_60822().comp_751();
                     if (var21 > 0) {
                        int var22 = var20.method_60818().remaining();
                        if (tornadoVbo == null || tornadoVbo.size() < var22) {
                           if (tornadoVbo != null) {
                              tornadoVbo.close();
                           }

                           tornadoVbo = RenderSystem.getDevice().createBuffer(() -> "KillEffect VBO", 40, Math.max(var22, 4096));
                        }

                        var7.writeToBuffer(tornadoVbo.slice(0L, var22), var20.method_60818());
                        class_5590 var23 = RenderSystem.getSequentialBuffer(class_5596.field_27379);
                        GpuBuffer var24 = var23.method_68274(var21);

                        try (RenderPass var25 = var7.createRenderPass(
                              () -> "KillEffect", var8.method_71639(), OptionalInt.empty(), var8.method_71640(), OptionalDouble.empty()
                           )) {
                           var25.setPipeline(tornadoPipeline);
                           var25.setVertexBuffer(0, tornadoVbo);
                           var25.setIndexBuffer(var24, var23.method_31924());
                           var25.setUniform("MatrixData", matrixUniformBuffer);
                           var25.setUniform("BeamData", beamUniformBuffer);
                           var25.drawIndexed(0, 0, var21, 1);
                        }
                     }
                  } catch (Exception var35) {
                  } finally {
                     if (var20 != null) {
                        var20.close();
                     }
                  }
               }
            }
         }
      }
   }

   private void a(class_287 var1, class_243 var2, class_4184 var3, class_243 var4, float var5) {
      float var6 = var5 * 0.9F;
      float var7 = var5 * 2.6F;
      double var8 = var4.field_1352;
      double var10 = var4.field_1351;
      double var12 = var4.field_1350;
      Vector3f var14 = new Vector3f(0.0F, 1.0F, 0.0F);
      Vector3f var15 = new Vector3f(1.0F, 0.0F, 0.0F).rotate(var3.method_23767());
      var15.y = 0.0F;
      if (var15.lengthSquared() > 1.0E-4F) {
         var15.normalize();
      } else {
         var15.set(1.0F, 0.0F, 0.0F);
      }

      this.a(var1, var2, var8, var10, var12, var15, var14, var6, var7, -1);
      Vector3f var16 = new Vector3f(-var15.z, 0.0F, var15.x);
      this.a(var1, var2, var8, var10, var12, var16, var14, var6, var7, -1);
   }

   private void a(class_287 var1, class_243 var2, double var3, double var5, double var7, Vector3f var9, Vector3f var10, float var11, float var12, int var13) {
      double var14 = var9.x * (var11 * 0.5F);
      double var16 = var9.z * (var11 * 0.5F);
      double var18 = var3 - var14;
      double var20 = var5;
      double var22 = var7 - var16;
      double var24 = var3 + var14;
      double var26 = var5;
      double var28 = var7 + var16;
      double var30 = var3 + var14;
      double var32 = var5 + var12;
      double var34 = var7 + var16;
      double var36 = var3 - var14;
      double var38 = var5 + var12;
      double var40 = var7 - var16;
      this.a(var1, var2, var18, var20, var22, 0.0F, 0.0F, var13);
      this.a(var1, var2, var24, var26, var28, 1.0F, 0.0F, var13);
      this.a(var1, var2, var30, var32, var34, 1.0F, 1.0F, var13);
      this.a(var1, var2, var18, var20, var22, 0.0F, 0.0F, var13);
      this.a(var1, var2, var30, var32, var34, 1.0F, 1.0F, var13);
      this.a(var1, var2, var36, var38, var40, 0.0F, 1.0F, var13);
   }

   private void a(class_287 var1, class_243 var2, double var3, double var5, double var7, float var9, float var10, int var11) {
      var1.method_22912((float)(var3 - var2.field_1352), (float)(var5 - var2.field_1351), (float)(var7 - var2.field_1350))
         .method_22913(var9, var10)
         .method_1336(var11 >> 16 & 0xFF, var11 >> 8 & 0xFF, var11 & 0xFF, var11 >> 24 & 0xFF);
   }

   private static void l() {
      if (tornadoPipeline == null) {
         tornadoPipeline = RenderPipeline.builder()
            .withLocation(class_2960.method_60655("brokke", "kill_effect_tornado"))
            .withVertexShader(class_2960.method_60655("brokke", "kill_effect_vertex"))
            .withFragmentShader(class_2960.method_60655("brokke", "kill_effect_tornado"))
            .withVertexFormat(FORMAT, class_5596.field_27379)
            .withUniform("MatrixData", class_10789.field_60031)
            .withUniform("BeamData", class_10789.field_60031)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withDepthWrite(false)
            .withDepthBias(-1.0F, -10.0F)
            .withCull(false)
            .withBlend(new BlendFunction(SourceFactor.SRC_ALPHA, DestFactor.ONE))
            .build();
         matrixUniformBuffer = RenderSystem.getDevice().createBuffer(() -> "KillEffect Matrix Uniforms", 136, 64L);
         beamUniformBuffer = RenderSystem.getDevice().createBuffer(() -> "KillEffect Beam Uniforms", 136, 48L);
      }
   }

   private Matrix4f m() {
      if (RenderContext.WORLD_READY) {
         return new Matrix4f(RenderContext.PROJECTION_MATRIX).mul(RenderContext.VIEW_MATRIX);
      }

      class_4184 var1 = mc.field_1773.method_19418();
      float var2 = mc.method_61966().method_60637(true);
      Matrix4f var3 = new Matrix4f().rotation(var1.method_23767());
      float var4 = (float)this.n();
      float var5 = ((IGameRenderer)mc.field_1773).invokeGetFov(var1, var2, true);
      Matrix4f var6 = new Matrix4f().perspective((float)Math.toRadians(var5), var4, 0.05F, 1000.0F);
      return var6.mul(var3);
   }

   private double n() {
      class_1041 var1 = mc.method_22683();
      return (double)var1.method_4489() / Math.max(1, var1.method_4506());
   }

   static {
      WorldRenderEvents.AFTER_ENTITIES.register(KillEffect::a);
   }

   record a(class_243 pos, long startTime, Color color, float size, float intensity, float speed, float lifetimeSec) {
      public class_243 getPos() {
         return this.pos;
      }

      public long getStartTime() {
         return this.startTime;
      }

      public Color getColor() {
         return this.color;
      }

      public float getSize() {
         return this.size;
      }

      public float getIntensity() {
         return this.intensity;
      }

      public float getSpeed() {
         return this.speed;
      }

      public float getLifetimeSec() {
         return this.lifetimeSec;
      }
   }
}
