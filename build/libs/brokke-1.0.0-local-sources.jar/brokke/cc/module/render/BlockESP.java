package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.render.ColorPipeline;
import brokke.cc.render.WorldToScreen;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.setting.MultiSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.EventPacket;
import brokke.cc.system.events.impl.Render2DEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_287;
import net.minecraft.class_3620;
import net.minecraft.class_638;

@NewFunction(name = "BlockESP", description = "Подсвечивает выбранные блоки в мире", category = Category.RENDER)
public class BlockESP extends Function {
   private final ModeSetting mode = new ModeSetting("Режим", "Все", "Только обновление");
   private final NumberSetting range = new NumberSetting("Дистанция", 64.0, 8.0, 128.0, 4.0);
   private final NumberSetting delay = new NumberSetting("Задержка сканирования", 4.0, 1.0, 30.0, 1.0);
   private final BooleanSetting tracers = new BooleanSetting("Трейсера", false);
   private final BooleanSetting fill = new BooleanSetting("Заливка", true);
   private final BooleanSetting outline = new BooleanSetting("Обводка", true);
   private final MultiSetting blocks = new MultiSetting(
      "Блоки", "Алмазы", "Обломки", "Изумруды", "Золото", "Железо", "Редстоун", "Лазурит", "Медь", "Уголь", "Кварц", "Сундуки", "Шалкеры", "Спавнера"
   );
   private final Set<class_2338> foundBlocks = ConcurrentHashMap.newKeySet();
   private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
      Thread scanThread = new Thread(task, "brokke-block-esp");
      scanThread.setDaemon(true);
      return scanThread;
   });
   private final AtomicInteger searchToken = new AtomicInteger();
   private volatile boolean scanning;
   private long lastScanTime;
   private static final int MAX_RENDERED_BLOCKS = 512;
   private static final int[][] EDGES = {
      {0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6},
      {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}
   };
   private static final int[][] FACES = {
      {0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4},
      {2, 3, 7, 6}, {0, 3, 7, 4}, {1, 2, 6, 5}
   };
   private final float[][] screenCorners = new float[8][];

   public BlockESP() {
      this.blocks.setOption("Алмазы", true);
      this.blocks.setOption("Обломки", true);
      this.blocks.setOption("Изумруды", true);
      this.blocks.setOption("Золото", true);
      this.addSettings(this.mode, this.range, this.delay, this.tracers, this.fill, this.outline, this.blocks);
      this.mode.onChanged(this::updateScanSettingsVisibility);
      this.updateScanSettingsVisibility();
   }

   private void updateScanSettingsVisibility() {
      boolean fullScanEnabled = this.mode.isSelected("Все");
      this.range.setVisible(fullScanEnabled);
      this.delay.setVisible(fullScanEnabled);
   }

   @Override
   public void onEnable() {
      this.cancelScan();
      this.lastScanTime = 0L;
      if (this.mode.isSelected("Все")) {
         this.startScan();
      }
   }

   @Override
   public void onDisable() {
      this.cancelScan();
      this.foundBlocks.clear();
   }

   private void cancelScan() {
      this.searchToken.incrementAndGet();
      this.scanning = false;
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         this.cancelScan();
         return;
      }
      long scanDelayMillis = (long)(this.delay.getValue() * 1000.0);
      if (this.mode.isSelected("Все") && !this.scanning
         && System.currentTimeMillis() - this.lastScanTime >= scanDelayMillis) {
         this.startScan();
      }
   }

   private void startScan() {
      if (mc.field_1724 == null || mc.field_1687 == null || this.scanning) {
         return;
      }
      this.scanning = true;
      int token = this.searchToken.incrementAndGet();
      double radius = this.range.getValue();
      class_243 playerPosition = mc.field_1724.method_73189();
      class_638 world = mc.field_1687;
      CompletableFuture.supplyAsync(() -> this.findBlocks(token, playerPosition, radius, world), this.executor)
         .thenAccept(results -> mc.execute(() -> this.applyScanResults(token, results)))
         .exceptionally(failure -> {
            this.scanning = false;
            return null;
         });
   }

   private Set<class_2338> findBlocks(int token, class_243 center, double radius, class_638 world) {
      if (token != this.searchToken.get() || world == null) {
         return Collections.emptySet();
      }

      int blockRadius = (int)Math.ceil(radius);
      int minX = (int)Math.floor(center.field_1352 - blockRadius);
      int maxX = (int)Math.ceil(center.field_1352 + blockRadius);
      int minZ = (int)Math.floor(center.field_1350 - blockRadius);
      int maxZ = (int)Math.ceil(center.field_1350 + blockRadius);
      int minY = Math.max(world.method_31607() + 1, (int)Math.floor(center.field_1351 - blockRadius));
      int maxY = Math.min(world.method_31600(), (int)Math.ceil(center.field_1351 + blockRadius));
      int minChunkX = minX >> 4;
      int maxChunkX = maxX >> 4;
      int minChunkZ = minZ >> 4;
      int maxChunkZ = maxZ >> 4;
      double radiusSquared = radius * radius;
      Set<class_2338> matches = new HashSet<>();
      class_2338.class_2339 position = new class_2338.class_2339();

      for (int chunkX = minChunkX; chunkX <= maxChunkX && token == this.searchToken.get(); chunkX++) {
         for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ && token == this.searchToken.get(); chunkZ++) {
            if (!world.method_8393(chunkX, chunkZ)) {
               continue;
            }
            int chunkMinX = Math.max(minX, chunkX << 4);
            int chunkMaxX = Math.min(maxX, (chunkX << 4) + 15);
            int chunkMinZ = Math.max(minZ, chunkZ << 4);
            int chunkMaxZ = Math.min(maxZ, (chunkZ << 4) + 15);

            for (int x = chunkMinX; x <= chunkMaxX && token == this.searchToken.get(); x++) {
               for (int z = chunkMinZ; z <= chunkMaxZ && token == this.searchToken.get(); z++) {
                  double offsetX = x + 0.5 - center.field_1352;
                  double offsetZ = z + 0.5 - center.field_1350;
                  if (offsetX * offsetX + offsetZ * offsetZ > radiusSquared) {
                     continue;
                  }
                  for (int y = minY; y <= maxY; y++) {
                     position.method_10103(x, y, z);
                     class_2248 block = world.method_8320(position).method_26204();
                     if (this.isSelectedBlock(block)) {
                        matches.add(position.method_10062());
                     }
                  }
               }
            }
         }
      }
      return matches;
   }

   private void applyScanResults(int token, Set<class_2338> results) {
      if (token == this.searchToken.get() && this.isActive() && mc.field_1687 != null) {
         this.foundBlocks.clear();
         this.foundBlocks.addAll(results);
         this.lastScanTime = System.currentTimeMillis();
      }
      this.scanning = false;
   }

   @EventHandler
   public void onPacket(EventPacket event) {
      if (event.getPacket() instanceof class_2637 chunkUpdate) {
         chunkUpdate.method_30621((position, state) -> this.updateBlock(position.method_10062(), state.method_26204()));
      } else if (event.getPacket() instanceof class_2626 blockUpdate) {
         this.updateBlock(blockUpdate.method_11309().method_10062(), blockUpdate.method_11308().method_26204());
      }
   }

   private void updateBlock(class_2338 position, class_2248 block) {
      if (this.isSelectedBlock(block)) {
         this.foundBlocks.add(position);
      } else {
         this.foundBlocks.remove(position);
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1690.field_1842 || this.foundBlocks.isEmpty()) {
         return;
      }
      class_287 buffer = ColorPipeline.a();
      if (buffer == null) {
         return;
      }
      double maxDistanceSquared = this.range.getValue() * this.range.getValue() + 256.0;
      class_243 eyePosition = mc.field_1724.method_33571();
      boolean hasGeometry = false;
      int renderedBlocks = 0;

      for (class_2338 position : this.foundBlocks) {
         if (renderedBlocks >= MAX_RENDERED_BLOCKS) {
            break;
         }
         if (position.method_19770(mc.field_1724.method_73189()) > maxDistanceSquared) {
            continue;
         }
         class_2248 block = mc.field_1687.method_8320(position).method_26204();
         if (!this.isSelectedBlock(block)) {
            continue;
         }
         int rgb = this.getBlockColor(block) & 0xFFFFFF;
         int outlineColor = 0xDC000000 | rgb;
         int fillColor = 0x28000000 | rgb;
         if (this.projectBlockCorners(new class_238(position))) {
            if (this.fill.isToggled()) {
               this.drawFaces(buffer, fillColor);
            }
            if (this.outline.isToggled()) {
               this.drawEdges(buffer, outlineColor);
            }
            hasGeometry = true;
            renderedBlocks++;
         }
         if (this.tracers.isToggled()) {
            float[][] tracerPoints = WorldToScreen.a(eyePosition, position.method_46558());
            if (tracerPoints != null) {
               ColorPipeline.a(buffer, tracerPoints[0][0], tracerPoints[0][1],
                  tracerPoints[1][0], tracerPoints[1][1], 1.2F, outlineColor);
               hasGeometry = true;
            }
         }
      }
      if (hasGeometry) {
         ColorPipeline.a(buffer, false);
      }
   }

   private boolean projectBlockCorners(class_238 box) {
      this.screenCorners[0] = WorldToScreen.a(box.field_1323, box.field_1322, box.field_1321);
      this.screenCorners[1] = WorldToScreen.a(box.field_1320, box.field_1322, box.field_1321);
      this.screenCorners[2] = WorldToScreen.a(box.field_1320, box.field_1322, box.field_1324);
      this.screenCorners[3] = WorldToScreen.a(box.field_1323, box.field_1322, box.field_1324);
      this.screenCorners[4] = WorldToScreen.a(box.field_1323, box.field_1325, box.field_1321);
      this.screenCorners[5] = WorldToScreen.a(box.field_1320, box.field_1325, box.field_1321);
      this.screenCorners[6] = WorldToScreen.a(box.field_1320, box.field_1325, box.field_1324);
      this.screenCorners[7] = WorldToScreen.a(box.field_1323, box.field_1325, box.field_1324);
      for (float[] corner : this.screenCorners) {
         if (corner != null) {
            return true;
         }
      }
      return false;
   }

   private void drawFaces(class_287 buffer, int color) {
      for (int[] face : FACES) {
         float[] first = this.screenCorners[face[0]];
         float[] second = this.screenCorners[face[1]];
         float[] third = this.screenCorners[face[2]];
         float[] fourth = this.screenCorners[face[3]];
         if (first != null && second != null && third != null && fourth != null) {
            ColorPipeline.a(buffer, first, second, third, fourth, color, color, color, color);
         }
      }
   }

   private void drawEdges(class_287 buffer, int color) {
      for (int[] edge : EDGES) {
         float[] start = this.screenCorners[edge[0]];
         float[] end = this.screenCorners[edge[1]];
         if (start != null && end != null) {
            ColorPipeline.a(buffer, start[0], start[1], end[0], end[1], 1.0F, color);
         }
      }
   }

   private boolean isSelectedBlock(class_2248 block) {
      if (block == null || block == class_2246.field_10124 || block == class_2246.field_10543 || block == class_2246.field_10243) {
         return false;
      }
      return this.blocks.isOptionEnabled("Алмазы")
            && (block == class_2246.field_10442 || block == class_2246.field_29029 || block == class_2246.field_10201)
         || this.blocks.isOptionEnabled("Обломки")
            && (block == class_2246.field_22109 || block == class_2246.field_22108)
         || this.blocks.isOptionEnabled("Изумруды")
            && (block == class_2246.field_10013 || block == class_2246.field_29220 || block == class_2246.field_10234)
         || this.blocks.isOptionEnabled("Золото")
            && (block == class_2246.field_10571 || block == class_2246.field_29026 || block == class_2246.field_23077
               || block == class_2246.field_33510 || block == class_2246.field_10205)
         || this.blocks.isOptionEnabled("Железо")
            && (block == class_2246.field_10212 || block == class_2246.field_29027 || block == class_2246.field_33508 || block == class_2246.field_10085)
         || this.blocks.isOptionEnabled("Редстоун")
            && (block == class_2246.field_10080 || block == class_2246.field_29030 || block == class_2246.field_10002)
         || this.blocks.isOptionEnabled("Лазурит")
            && (block == class_2246.field_10090 || block == class_2246.field_29028 || block == class_2246.field_10441)
         || this.blocks.isOptionEnabled("Медь")
            && (block == class_2246.field_27120 || block == class_2246.field_29221 || block == class_2246.field_33509 || block == class_2246.field_27119)
         || this.blocks.isOptionEnabled("Уголь")
            && (block == class_2246.field_10418 || block == class_2246.field_29219 || block == class_2246.field_10381)
         || this.blocks.isOptionEnabled("Кварц") && block == class_2246.field_10213
         || this.blocks.isOptionEnabled("Сундуки")
            && (block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_10443 || block == class_2246.field_16328)
         || this.blocks.isOptionEnabled("Шалкеры") && block instanceof class_2480
         || this.blocks.isOptionEnabled("Спавнера") && (block == class_2246.field_10260 || block == class_2246.field_47336);
   }

   private int getBlockColor(class_2248 block) {
      if (block == class_2246.field_10442 || block == class_2246.field_29029 || block == class_2246.field_10201) {
         return -16718337;
      } else if (block == class_2246.field_22109 || block == class_2246.field_22108) {
         return -7710154;
      } else if (block == class_2246.field_10013 || block == class_2246.field_29220 || block == class_2246.field_10234) {
         return -16711851;
      } else if (block == class_2246.field_10571
         || block == class_2246.field_29026
         || block == class_2246.field_23077
         || block == class_2246.field_33510
         || block == class_2246.field_10205) {
         return 55040;
      } else if (block == class_2246.field_10212 || block == class_2246.field_29027 || block == class_2246.field_33508 || block == class_2246.field_10085) {
         return -2576493;
      } else if (block == class_2246.field_10080 || block == class_2246.field_29030 || block == class_2246.field_10002) {
         return -57312;
      } else if (block == class_2246.field_10090 || block == class_2246.field_29028 || block == class_2246.field_10441) {
         return -14787585;
      } else if (block == class_2246.field_27120 || block == class_2246.field_29221 || block == class_2246.field_33509 || block == class_2246.field_27119) {
         return -1606570;
      } else if (block == class_2246.field_10418 || block == class_2246.field_29219 || block == class_2246.field_10381) {
         return -12566464;
      } else if (block == class_2246.field_10213) {
         return -1382946;
      } else if (block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_10443 || block == class_2246.field_16328) {
         return 38912;
      } else if (block instanceof class_2480) {
         return -4560696;
      } else if (block != class_2246.field_10260 && block != class_2246.field_47336) {
         class_3620 mapColor = block.method_26403();
         return mapColor != null ? 0xFF000000 | mapColor.field_16011 : -1;
      } else {
         return -65451;
      }
   }
}
