package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.render.ColorPipeline;
import brokke.cc.render.Theme;
import brokke.cc.render.WorldToScreen;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.ColorSetting;
import brokke.cc.setting.ModeSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.Render2DEvent;
import java.awt.Color;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;

@NewFunction(name = "EntityBox", description = "Отображает 3D хитбоксы игроков", category = Category.RENDER)
public class EntityBox extends Function {
   private final BooleanSetting onlyArmor = new BooleanSetting("Только в броне", false);
   private final ModeSetting colorSource = new ModeSetting("Источник цвета", "Клиентский", "Свой");
   private final ColorSetting colorSetting = new ColorSetting("Цвет", new Color(255, 255, 255));
   private static final int[][] EDGES = new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
   private static final int[][] FACES = new int[][]{{0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 3, 7, 4}, {1, 2, 6, 5}};
   private static final class_1304[] ARMOR_SLOTS = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
   private final float[][] screenCorners = new float[8][];

   public EntityBox() {
      this.addSettings(this.onlyArmor, this.colorSource, this.colorSetting);
      this.colorSource.onChanged(this::k);
      this.k();
   }

   private void k() {
      this.colorSetting.setVisible(this.colorSource.isSelected("Свой"));
   }

   @EventHandler
   public void onRender2D(Render2DEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && !mc.field_1690.field_1842) {
         float var2 = var1.getTickCounter().method_60637(true);
         Color var3 = Theme.getInstance().getAccent();
         Color var4 = this.colorSource.isSelected("Свой") ? this.colorSetting.getColor() : var3;
         if (var4 == null) {
            var4 = var3;
         }

         int var5 = var4.getAlpha() << 24 | var4.getRed() << 16 | var4.getGreen() << 8 | var4.getBlue();
         int var6 = 754974720 | var4.getRed() << 16 | var4.getGreen() << 8 | var4.getBlue();
         class_287 var7 = ColorPipeline.a();
         if (var7 != null) {
            for (class_1657 var9 : mc.field_1687.method_18456()) {
               if (this.a(var9)) {
                  class_243 var10 = var9.method_30950(var2);
                  class_243 var11 = var10.method_1020(var9.method_73189());
                  class_238 var12 = var9.method_5829().method_997(var11);
                  int var13 = 0;
                  this.screenCorners[0] = WorldToScreen.a(var12.field_1323, var12.field_1322, var12.field_1321);
                  if (this.screenCorners[0] != null) {
                     var13++;
                  }

                  this.screenCorners[1] = WorldToScreen.a(var12.field_1320, var12.field_1322, var12.field_1321);
                  if (this.screenCorners[1] != null) {
                     var13++;
                  }

                  this.screenCorners[2] = WorldToScreen.a(var12.field_1320, var12.field_1322, var12.field_1324);
                  if (this.screenCorners[2] != null) {
                     var13++;
                  }

                  this.screenCorners[3] = WorldToScreen.a(var12.field_1323, var12.field_1322, var12.field_1324);
                  if (this.screenCorners[3] != null) {
                     var13++;
                  }

                  this.screenCorners[4] = WorldToScreen.a(var12.field_1323, var12.field_1325, var12.field_1321);
                  if (this.screenCorners[4] != null) {
                     var13++;
                  }

                  this.screenCorners[5] = WorldToScreen.a(var12.field_1320, var12.field_1325, var12.field_1321);
                  if (this.screenCorners[5] != null) {
                     var13++;
                  }

                  this.screenCorners[6] = WorldToScreen.a(var12.field_1320, var12.field_1325, var12.field_1324);
                  if (this.screenCorners[6] != null) {
                     var13++;
                  }

                  this.screenCorners[7] = WorldToScreen.a(var12.field_1323, var12.field_1325, var12.field_1324);
                  if (this.screenCorners[7] != null) {
                     var13++;
                  }

                  if (var13 != 0) {
                     for (int[] var17 : FACES) {
                        float[] var18 = this.screenCorners[var17[0]];
                        float[] var19 = this.screenCorners[var17[1]];
                        float[] var20 = this.screenCorners[var17[2]];
                        float[] var21 = this.screenCorners[var17[3]];
                        if (var18 != null && var19 != null && var20 != null && var21 != null) {
                           ColorPipeline.a(var7, var18, var19, var20, var21, var6, var6, var6, var6);
                        }
                     }

                     for (int[] var25 : EDGES) {
                        float[] var26 = this.screenCorners[var25[0]];
                        float[] var27 = this.screenCorners[var25[1]];
                        if (var26 != null && var27 != null) {
                           ColorPipeline.a(var7, var26[0], var26[1], var27[0], var27[1], 1.0F, var5);
                        }
                     }
                  }
               }
            }

            ColorPipeline.a(var7, false);
         }
      }
   }

   private boolean a(class_1657 var1) {
      if (var1 != null && !var1.method_31481() && var1.method_5805()) {
         return var1 == mc.field_1724 && mc.field_1690.method_31044().method_31034() ? false : !this.onlyArmor.isToggled() || this.b(var1);
      } else {
         return false;
      }
   }

   private boolean b(class_1657 var1) {
      for (class_1304 var5 : ARMOR_SLOTS) {
         class_1799 var6 = var1.method_6118(var5);
         if (var6 != null && !var6.method_7960()) {
            return true;
         }
      }

      return false;
   }
}
