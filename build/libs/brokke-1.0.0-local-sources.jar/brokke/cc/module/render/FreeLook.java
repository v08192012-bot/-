package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.core.FreeLookStorage;
import brokke.cc.setting.BindSetting;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import brokke.cc.util.GCDUtil;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

@NewFunction(name = "FreeLook", description = "Вращай камерой, не меняя направление персонажа", category = Category.RENDER)
public class FreeLook extends Function {
   public final BindSetting key = new BindSetting("Клавиша", 342);
   public final BooleanSetting thirdPerson = new BooleanSetting("От третьего лица", true);
   private boolean active;
   private float cameraYaw;
   private float cameraPitch;
   private class_5498 prevPerspective = class_5498.field_26664;

   public FreeLook() {
      this.addSettings(this.key, this.thirdPerson);
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.method_22683() != null) {
         if (mc.field_1755 != null) {
            if (this.active) {
               this.n();
            }
         } else {
            int var2 = this.key.getKey();
            if (var2 == -1) {
               if (this.active) {
                  this.n();
               }
            } else {
               boolean var3;
               if (var2 < 0) {
                  var3 = GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), -(var2 + 100)) == 1;
               } else {
                  var3 = GLFW.glfwGetKey(mc.method_22683().method_4490(), var2) == 1;
               }

               if (var3 && !this.active) {
                  this.active = true;
                  this.cameraYaw = mc.field_1724.method_36454();
                  this.cameraPitch = mc.field_1724.method_36455();
                  FreeLookStorage.a(true);
                  FreeLookStorage.setFreeYaw(this.cameraYaw);
                  FreeLookStorage.setFreePitch(this.cameraPitch);
                  if (this.thirdPerson.isToggled() && mc.field_1690 != null) {
                     this.prevPerspective = mc.field_1690.method_31044();
                     mc.field_1690.method_31043(class_5498.field_26665);
                  }
               } else if (!var3 && this.active) {
                  this.n();
               }
            }
         }
      } else if (this.active) {
         this.n();
      }
   }

   public boolean k() {
      return this.isActive() && this.active && mc.field_1755 == null;
   }

   public float getCameraYaw() {
      return this.cameraYaw;
   }

   public float getCameraPitch() {
      return this.cameraPitch;
   }

   public void a(float var1, float var2) {
      float var3 = GCDUtil.a();
      this.cameraYaw += var1 * var3;
      this.cameraPitch = class_3532.method_15363(this.cameraPitch + var2 * var3, -90.0F, 90.0F);
      FreeLookStorage.setFreeYaw(this.cameraYaw);
      FreeLookStorage.setFreePitch(this.cameraPitch);
   }

   private void n() {
      this.active = false;
      FreeLookStorage.a(false);
      if (this.thirdPerson.isToggled() && mc.field_1690 != null) {
         mc.field_1690.method_31043(this.prevPerspective);
      }
   }

   @Override
   public void onDisable() {
      if (this.active) {
         this.n();
      }

      super.onDisable();
   }
}
