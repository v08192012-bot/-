package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.setting.BooleanSetting;
import brokke.cc.setting.NumberSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.UpdateEvent;
import net.minecraft.class_10017;
import net.minecraft.class_11954;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_4184;

@NewFunction(
   name = "ExstraOptimizer",
   description = "Максимальная оптимизация рендера: отсечение далёких сущностей, блок-энтити и частиц + быстрые настройки для сильного буста FPS",
   category = Category.RENDER
)
public class ExstraOptimizer extends Function {
   private static ExstraOptimizer INSTANCE;
   private final BooleanSetting fastSettings = new BooleanSetting("Быстрые настройки", true);
   private final BooleanSetting cullEntities = new BooleanSetting("Отсечение сущностей", true);
   private final NumberSetting entityDistance = new NumberSetting("Дистанция сущностей", 96.0, 16.0, 512.0, 8.0);
   private final BooleanSetting cullBlockEntities = new BooleanSetting("Отсечение блок-энтити", true);
   private final NumberSetting blockEntityDistance = new NumberSetting("Дистанция блок-энтити", 48.0, 8.0, 256.0, 8.0);
   private final BooleanSetting cullParticles = new BooleanSetting("Отсечение частиц", true);
   private final NumberSetting particleDistance = new NumberSetting("Дистанция частиц", 32.0, 8.0, 128.0, 4.0);
   private final BooleanSetting noCelestial = new BooleanSetting("Без солнца и луны", false);
   private static double camX;
   private static double camY;
   private static double camZ;
   private static boolean cameraValid = false;
   private boolean captured = false;
   private boolean prevShadows = true;
   private boolean prevAo = true;
   private int prevBiomeBlend = 0;
   private class_4066 prevParticles = class_4066.field_18197;
   private class_4063 prevClouds = class_4063.field_18164;

   public ExstraOptimizer() {
      INSTANCE = this;
      this.addSettings(
         this.fastSettings,
         this.cullEntities,
         this.entityDistance,
         this.cullBlockEntities,
         this.blockEntityDistance,
         this.cullParticles,
         this.particleDistance,
         this.noCelestial
      );
      this.entityDistance.visibleWhen(this.cullEntities::getValue);
      this.blockEntityDistance.visibleWhen(this.cullBlockEntities::getValue);
      this.particleDistance.visibleWhen(this.cullParticles::getValue);
   }

   public static ExstraOptimizer k() {
      if (INSTANCE == null) {
         INSTANCE = FunctionManager.a(ExstraOptimizer.class);
      }

      return INSTANCE;
   }

   public static boolean sky() {
      ExstraOptimizer var0 = k();
      return var0 != null && var0.isActive() && var0.noCelestial.isToggled();
   }

   public static boolean cullEntity(class_1297 var0, double var1, double var3, double var5) {
      ExstraOptimizer var7 = k();
      if (var7 != null && var7.isActive() && var7.cullEntities.isToggled() && var0 != null) {
         if (var0 == net.minecraft.class_310.method_1551().field_1724) {
            return false;
         } else {
            double var8 = var0.method_23317() - var1;
            double var10 = var0.method_23318() - var3;
            double var12 = var0.method_23321() - var5;
            return a(var8, var10, var12, Math.max(var0.method_17681(), var0.method_17682()), var7.entityDistance.getValue());
         }
      } else {
         return false;
      }
   }

   public static boolean cullEntityState(class_10017 var0, double var1, double var3, double var5) {
      ExstraOptimizer var7 = k();
      return var7 != null && var7.isActive() && var7.cullEntities.isToggled() && var0 != null
         ? a(var1, var3, var5, Math.max(var0.field_53329, var0.field_53330), var7.entityDistance.getValue())
         : false;
   }

   public static boolean cullBlockEntity(class_11954 var0) {
      ExstraOptimizer var1 = k();
      if (var1 != null && var1.isActive() && var1.cullBlockEntities.isToggled() && var0 != null) {
         class_2338 var2 = var0.field_62673;
         if (var2 == null) {
            return false;
         } else {
            p();
            if (!cameraValid) {
               return false;
            } else {
               double var3 = var2.method_10263() + 0.5 - camX;
               double var5 = var2.method_10264() + 0.5 - camY;
               double var7 = var2.method_10260() + 0.5 - camZ;
               return a(var3, var5, var7, 0.0, var1.blockEntityDistance.getValue());
            }
         }
      } else {
         return false;
      }
   }

   public static boolean cullParticle(double var0, double var2, double var4) {
      ExstraOptimizer var6 = k();
      if (var6 != null && var6.isActive() && var6.cullParticles.isToggled()) {
         p();
         if (!cameraValid) {
            return false;
         } else {
            return a(var0 - camX, var2 - camY, var4 - camZ, 0.0, var6.particleDistance.getValue());
         }
      } else {
         return false;
      }
   }

   private static boolean a(double var0, double var2, double var4, double var6, double var8) {
      double var10 = var8 + var6;
      return var0 * var0 + var2 * var2 + var4 * var4 > var10 * var10;
   }

   private static void p() {
      if (!cameraValid) {
         net.minecraft.class_310 var0 = net.minecraft.class_310.method_1551();
         if (var0.field_1773 != null && var0.field_1773.method_19418() != null) {
            a(var0.field_1773.method_19418());
         }
      }
   }

   public static void a(class_4184 var0) {
      if (var0 == null) {
         cameraValid = false;
      } else {
         class_243 var1 = var0.method_71156();
         camX = var1.field_1352;
         camY = var1.field_1351;
         camZ = var1.field_1350;
         cameraValid = true;
      }
   }

   @Override
   public void onEnable() {
      this.captured = false;
      this.q();
   }

   @Override
   public void onDisable() {
      this.r();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      this.q();
   }

   private void q() {
      if (this.fastSettings.isToggled() && mc.field_1690 != null) {
         if (!this.captured) {
            this.prevShadows = mc.field_1690.method_42435().method_41753();
            this.prevAo = mc.field_1690.method_41792().method_41753();
            this.prevBiomeBlend = mc.field_1690.method_41805().method_41753();
            this.prevParticles = mc.field_1690.method_42475().method_41753();
            this.prevClouds = mc.field_1690.method_42528().method_41753();
            this.captured = true;
         }

         mc.field_1690.method_42435().method_41748(false);
         mc.field_1690.method_41792().method_41748(false);
         mc.field_1690.method_41805().method_41748(0);
         mc.field_1690.method_42475().method_41748(class_4066.field_18198);
         mc.field_1690.method_42528().method_41748(class_4063.field_18162);
      }
   }

   private void r() {
      if (this.captured && mc.field_1690 != null) {
         mc.field_1690.method_42435().method_41748(this.prevShadows);
         mc.field_1690.method_41792().method_41748(this.prevAo);
         mc.field_1690.method_41805().method_41748(this.prevBiomeBlend);
         mc.field_1690.method_42475().method_41748(this.prevParticles);
         mc.field_1690.method_42528().method_41748(this.prevClouds);
      }

      this.captured = false;
   }
}
