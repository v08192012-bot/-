package brokke.cc.module.render;


import brokke.cc.module.Category;
import brokke.cc.module.Function;
import brokke.cc.module.FunctionManager;
import brokke.cc.module.NewFunction;
import brokke.cc.config.HudConfig;
import brokke.cc.cosmetic.SkinCache;
import brokke.cc.font.Msdf;
import brokke.cc.font.MsdfManager;
import brokke.cc.mixins.render.IGameRenderer;
import brokke.cc.render.RenderUtil;
import brokke.cc.render.TexturePipeline;
import brokke.cc.render.Theme;
import brokke.cc.render.WorldToScreen;
import brokke.cc.setting.MultiSetting;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.HudRenderEvent;
import brokke.cc.system.events.impl.Render3DEvent;
import brokke.cc.system.events.impl.UpdateEvent;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.class_5590;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1041;
import net.minecraft.class_1044;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1675;
import net.minecraft.class_1676;
import net.minecraft.class_1680;
import net.minecraft.class_1684;
import net.minecraft.class_1685;
import net.minecraft.class_1686;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3857;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

@NewFunction(name = "Prediction", description = "Отображает траекторию полёта эндер-жемчуга, трезубцев и т.п.", category = Category.RENDER)
public class Prediction extends Function {
   private static final class_2960 BLOOM_TEX = class_2960.method_60655("brokke", "textures/bloom.png");
   private static final class_2960 HIT_TEX = class_2960.method_60655("brokke", "textures/hit.png");
   private static final VertexFormat FORMAT_BLOOM = VertexFormat.builder()
      .add("Position", VertexFormatElement.POSITION)
      .add("UV", VertexFormatElement.UV0)
      .add("Color", VertexFormatElement.COLOR)
      .build();
   private static RenderPipeline bloomPipeline;
   private static RenderPipeline bloomPipelineWalls;
   private static GpuBuffer uniformBuffer;
   private static ByteBuffer uniformScratch;
   private static GpuBuffer quadsVbo;
   private static final int UNIFORM_SIZE = 64;
   private final List<Prediction.a> predicted = new CopyOnWriteArrayList<>();
   private final MultiSetting entities = new MultiSetting("Отображать", "Эндер-жемчуги", "Трезубцы", "Снежки", "Стрелы", "Зелья");

   public Prediction() {
      this.entities.setOption("Эндер-жемчуги", true);
      this.entities.setOption("Трезубцы", true);
      this.entities.setOption("Снежки", true);
      this.entities.setOption("Стрелы", true);
      this.entities.setOption("Зелья", true);
      this.addSettings(this.entities);
   }

   @Override
   public void onDisable() {
      this.predicted.clear();
   }

   @EventHandler
   public void onUpdate(UpdateEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.predicted.clear();

         for (class_1297 var3 : mc.field_1687.method_18112()) {
            this.a(var3);
         }
      }
   }

   private void a(class_1297 var1) {
      if (this.b(var1)) {
         if (var1 instanceof class_1676 var2 && var2.method_24921() == null) {
            List<class_742> var3 = new ArrayList<>(mc.field_1687.method_18456());
            if (!var3.isEmpty()) {
               Collections.sort(var3, Comparator.comparingDouble(var1x -> var1x.method_5739(var2)));
               var2.method_7432(var3.getFirst());
            }
         }

         ArrayList var12 = new ArrayList();
         class_243 var13 = var1.method_73189();
         class_243 var4 = var1.method_18798();
         class_1297 var5 = null;
         int var6 = 0;

         for (int var7 = 0; var7 < 150; var7++) {
            class_243 var8 = this.b(var1, var4);
            class_243 var9 = var13.method_1019(var8);
            var6 = var7;
            class_3965 var10 = mc.field_1687.method_17742(new class_3959(var13, var9, class_3960.field_17558, class_242.field_1348, var1));
            class_1297 var11 = this.a(var1, var9);
            if (var11 != null) {
               var12.add(var9);
               var5 = var11;
               break;
            }

            if (var10.method_17783() != class_240.field_1333) {
               var12.add(var10.method_17784());
               break;
            }

            var12.add(var9);
            var13 = var9;
            var4 = var8;
         }

         if (!var12.isEmpty()) {
            this.predicted.add(new Prediction.a(var1, var12, var6, var5));
         }
      }
   }

   @EventHandler
   public void onRender3D(Render3DEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null && !this.predicted.isEmpty()) {
         k();
         if (bloomPipeline != null && uniformBuffer != null) {
            class_1044 var2 = mc.method_1531().method_4619(BLOOM_TEX);
            class_1044 var3 = mc.method_1531().method_4619(HIT_TEX);
            if (var2 != null && var3 != null) {
               GpuTextureView var4 = var2.method_71659();
               GpuTextureView var5 = var3.method_71659();
               if (var4 != null && var5 != null) {
                  class_4184 var6 = var1.getCamera();
                  class_243 var7 = var6.method_71156();
                  float var8 = var1.getTickDelta();
                  Matrix4f var9 = this.l();
                  a(var9);
                  Color var10 = Theme.getInstance().getAccent();
                  float var11 = var10.getRed() / 255.0F;
                  float var12 = var10.getGreen() / 255.0F;
                  float var13 = var10.getBlue() / 255.0F;
                  class_287 var14 = class_289.method_1348().method_60827(class_5596.field_27382, FORMAT_BLOOM);
                  int var15 = 0;

                  for (Prediction.a var17 : this.predicted) {
                     if (!var17.vectors.isEmpty()) {
                        class_243 var18 = var17.vectors.getFirst();
                        class_243 var19 = a(var17.entity, var8);
                        if (var19.method_1022(mc.field_1724.method_33571()) > 2.0) {
                           for (int var20 = 0; var20 < 10; var20++) {
                              float var21 = var20 / 10.0F;
                              class_243 var22 = var19.method_1019(var18.method_1020(var19).method_1021(var21));
                              this.a(var22, var14, (float)var18.method_1022(var19) / 5.5F, 1.0F, var6, var7, var11, var12, var13);
                              this.a(var22, var14, (float)var18.method_1022(var19) * 0.75F, 0.08F, var6, var7, var11, var12, var13);
                              var15 += 2;
                           }
                        }

                        for (class_243 var27 : var17.vectors) {
                           if (var27.method_1022(mc.field_1724.method_33571()) > 2.0) {
                              for (int var29 = 0; var29 < 10; var29++) {
                                 float var23 = var29 / 10.0F;
                                 class_243 var24 = var18.method_1019(var27.method_1020(var18).method_1021(var23));
                                 this.a(var24, var14, (float)var27.method_1022(var18) / 5.5F, 1.0F, var6, var7, var11, var12, var13);
                                 this.a(var24, var14, (float)var27.method_1022(var18) * 0.75F, 0.08F, var6, var7, var11, var12, var13);
                                 var15 += 2;
                              }
                           }

                           var18 = var27;
                        }

                        if (var17.entity instanceof class_1686) {
                           float var26 = 9.0F;
                           float var28 = var26 / 2.0F;
                           class_243 var30 = var17.vectors.getLast();
                           class_4587 var31 = new class_4587();
                           var31.method_46416((float)(var30.field_1352 - var7.field_1352), (float)(var30.field_1351 - var7.field_1351), (float)(var30.field_1350 - var7.field_1350));
                           var31.method_22907(class_7833.field_40713.rotationDegrees(-90.0F));
                           Matrix4f var32 = var31.method_23760().method_23761();
                           var14.method_22918(var32, -var28, var28, 0.0F).method_22913(0.0F, 1.0F).method_22915(var11, var12, var13, 1.0F);
                           var14.method_22918(var32, var28, var28, 0.0F).method_22913(1.0F, 1.0F).method_22915(var11, var12, var13, 1.0F);
                           var14.method_22918(var32, var28, -var28, 0.0F).method_22913(1.0F, 0.0F).method_22915(var11, var12, var13, 1.0F);
                           var14.method_22918(var32, -var28, -var28, 0.0F).method_22913(0.0F, 0.0F).method_22915(var11, var12, var13, 1.0F);
                           var15++;
                        }
                     }
                  }

                  if (var15 > 0) {
                     this.a(var14, var4, bloomPipelineWalls);
                  }
               }
            }
         }
      }
   }

   private void a(class_243 var1, class_287 var2, float var3, float var4, class_4184 var5, class_243 var6, float var7, float var8, float var9) {
      class_4587 var10 = new class_4587();
      var10.method_46416((float)(var1.field_1352 - var6.field_1352), (float)(var1.field_1351 - var6.field_1351), (float)(var1.field_1350 - var6.field_1350));
      var10.method_22907(var5.method_23767());
      Matrix4f var11 = var10.method_23760().method_23761();
      float var12 = var3 / 2.0F;
      var2.method_22918(var11, -var12, var12, 0.0F).method_22913(0.0F, 1.0F).method_22915(var7, var8, var9, var4);
      var2.method_22918(var11, var12, var12, 0.0F).method_22913(1.0F, 1.0F).method_22915(var7, var8, var9, var4);
      var2.method_22918(var11, var12, -var12, 0.0F).method_22913(1.0F, 0.0F).method_22915(var7, var8, var9, var4);
      var2.method_22918(var11, -var12, -var12, 0.0F).method_22913(0.0F, 0.0F).method_22915(var7, var8, var9, var4);
   }

   @EventHandler
   public void onHudRender(HudRenderEvent var1) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_332 var2 = var1.getContext();

         for (Prediction.a var4 : this.predicted) {
            if (!var4.vectors.isEmpty()) {
               class_243 var5 = var4.vectors.getLast();
               if (var4.entity instanceof class_1684) {
                  class_1297 var6 = var4.entity instanceof class_1676 var7 ? var7.method_24921() : null;
                  this.a(var2, var5, var4.ticks, var6);
               } else {
                  float[] var43 = WorldToScreen.a(var5);
                  if (var43 != null) {
                     float var44 = var43[0];
                     float var45 = var43[1];
                     String var9 = var4.entity != null ? var4.entity.method_5477().getString().replace("Брошенный эндер-жемчуг", "Эндер-жемчуг") : "Снаряд";
                     if (var4.entity instanceof class_1686 var10) {
                        var9 = var10.method_7495().method_7964().getString();
                     }

                     String var46 = var9.replace("] ", "").replace("[", "") + String.format(Locale.US, " (%.1f сек)", var4.ticks / 20.0F);
                     class_1799 var47 = class_1802.field_8107.method_7854();
                     if (var4.entity instanceof class_3857 var48) {
                        var47 = var48.method_7495();
                     } else if (var4.entity instanceof class_1665 var12) {
                        var47 = var12.method_54759();
                     } else if (var4.entity instanceof class_1542 var13) {
                        var47 = var13.method_6983();
                     }

                     float var49 = (float)var5.method_1022(mc.field_1724.method_33571());
                     float var50 = class_3532.method_15363(1.0F - var49 / 35.0F, 0.65F, 1.0F);
                     float var51 = 6.5F;
                     float var54 = Msdf.a(MsdfManager.BOLD, var46, var51);
                     float var15 = 10.0F;
                     float var16 = 4.0F;
                     float var17 = 3.5F;
                     float var18 = var16 + var15 + var17 + var54 + var16;
                     float var19 = 13.0F;
                     float var20 = 4.5F;
                     float var21 = var44 - var18 / 2.0F;
                     float var22 = var45 - var19 - 4.0F;
                     Matrix4f var23 = this.a(var44, var45, var50);
                     HudConfig.a(var23, "pred", var21, var22, var18, var19, var20, -1275068416);
                     Msdf.a(
                        var23,
                        MsdfManager.BOLD,
                        var46,
                        var21 + var16 + var15 + var17,
                        var22 + (var19 - Msdf.a(MsdfManager.BOLD, var51)) / 2.0F + 0.5F,
                        var51,
                        -1
                     );
                     Matrix3x2fStack var24 = var2.method_51448();
                     float var25 = 2.0F / mc.method_22683().method_4495();
                     float var26 = var15 / 16.0F * var50 / var25;
                     float var27 = var44 + (var21 + var16 + var15 / 2.0F - var44) * var50;
                     float var28 = var45 + (var22 + var19 / 2.0F - var45) * var50;
                     var24.pushMatrix();
                     var24.translate(var27 * var25, var28 * var25);
                     var24.scale(var26, var26);
                     var24.translate(-8.0F, -8.0F);

                     try {
                        var2.method_51427(var47, 0, 0);
                     } catch (Exception var43x) {
                     }

                     var24.popMatrix();
                     float var29 = var22 + var19 + 2.5F;
                     if (var4.entity instanceof class_1676 var30 && var30.method_24921() instanceof class_742 var31) {
                        String var56 = var30.method_24921() == mc.field_1724 ? "От Вас" : "От " + var31.method_5477().getString();
                        float var33 = 6.25F;
                        float var34 = Msdf.a(MsdfManager.BOLD, var56, var33);
                        float var35 = 8.5F;
                        float var36 = 4.0F;
                        float var37 = 3.5F;
                        float var38 = var36 + var35 + var37 + var34 + var36;
                        float var39 = 12.0F;
                        float var40 = 4.0F;
                        float var41 = var44 - var38 / 2.0F;
                        HudConfig.a(var23, "pred_owner", var41, var29, var38, var39, var40, -1275068416);
                        this.a(var23, var31, var41 + var36, var29 + (var39 - var35) / 2.0F, var35);
                        Msdf.a(
                           var23,
                           MsdfManager.BOLD,
                           var56,
                           var41 + var36 + var35 + var37,
                           var29 + (var39 - Msdf.a(MsdfManager.BOLD, var33)) / 2.0F + 0.5F,
                           var33,
                           -1
                        );
                     }
                  }
               }
            }
         }
      }
   }

   private void a(class_332 var1, class_243 var2, int var3, class_1297 var4) {
      float[] var5 = WorldToScreen.a(var2);
      if (var5 != null) {
         float var6 = var5[0];
         float var7 = var5[1];
         float var8 = (float)var2.method_1022(mc.field_1724.method_33571());
         float var9 = class_3532.method_15363(1.0F - var8 / 45.0F, 0.65F, 1.15F);
         Matrix4f var10 = this.a(var6, var7, var9);
         float var11 = 22.0F;
         float var12 = 6.0F;
         float var13 = var7 - var12 - var11 / 2.0F;
         Color var14 = Theme.getInstance().getAccent();
         int var15 = var14 != null ? var14.getRGB() : -1;
         this.a(var10, var6, var7, 4.5F, var12 + 2.0F, var15);
         RenderUtil.a(var10, var6 - var11 / 2.0F, var13 - var11 / 2.0F, var11, var11, var11 / 2.0F, var11 / 2.0F, var11 / 2.0F, var11 / 2.0F, false, var15);
         float var16 = var11 - 4.0F;
         RenderUtil.a(var10, var6 - var16 / 2.0F, var13 - var16 / 2.0F, var16, var16, var16 / 2.0F, var16 / 2.0F, var16 / 2.0F, var16 / 2.0F, false, -15855592);
         float var17 = 13.0F;
         Matrix3x2fStack var18 = var1.method_51448();
         float var19 = 2.0F / mc.method_22683().method_4495();
         float var20 = var17 / 16.0F * var9 / var19;
         float var21 = var6 + (var6 - var6) * var9;
         float var22 = var7 + (var13 - var7) * var9;
         var18.pushMatrix();
         var18.translate(var21 * var19, var22 * var19);
         var18.scale(var20, var20);
         var18.translate(-8.0F, -8.0F);

         try {
            var1.method_51427(class_1802.field_8634.method_7854(), 0, 0);
         } catch (Exception var42) {
         }

         var18.popMatrix();
         float var23 = var3 / 20.0F;
         String var24 = String.format(Locale.US, "%.1f сек", var23);
         float var25 = 6.25F;
         float var26 = Msdf.a(MsdfManager.BOLD, var24, var25);
         float var27 = 5.0F;
         float var28 = var26 + var27 * 2.0F;
         float var29 = 11.5F;
         float var30 = 4.5F;
         float var31 = var7 + 4.0F;
         if (var4 instanceof class_742 var32 && var32 != mc.field_1724) {
            String var33 = var32.method_5477().getString();
            float var34 = 6.25F;
            float var35 = Msdf.a(MsdfManager.BOLD, var33, var34);
            float var36 = 8.0F;
            float var37 = var36 + 4.0F + var35 + 6.0F;
            float var38 = 11.5F;
            float var39 = var6 - var37 / 2.0F;
            float var40 = var31;
            float var41 = 4.5F;
            RenderUtil.b(var10, var39, var40, var37, var38, var41, 4.5F, 0.4F, 2.5F, -1946157056);
            if (Theme.getInstance().getGuiStyle() == Theme.a.BLUR) {
               RenderUtil.a(var10, var39, var40, var37, var38, var41, 10.0F);
            }

            RenderUtil.a(var10, var39, var40, var37, var38, var41, var41, var41, var41, false, 1845493760);
            RenderUtil.a(var10, var39, var40, var37, var38, var41, 0.75F, 436207615);
            this.a(var10, var32, var39 + 2.0F, var40 + (var38 - var36) / 2.0F, var36);
            Msdf.a(var10, MsdfManager.BOLD, var33, var39 + var36 + 4.0F, var40 + (var38 - Msdf.a(MsdfManager.BOLD, var34)) / 2.0F + 0.5F, var34, -1);
            var31 += var38 + 2.5F;
         }

         float var43 = var6 - var28 / 2.0F;
         float var44 = var31;
         RenderUtil.b(var10, var43, var44, var28, var29, var30, 4.5F, 0.4F, 2.5F, -1946157056);
         if (Theme.getInstance().getGuiStyle() == Theme.a.BLUR) {
            RenderUtil.a(var10, var43, var44, var28, var29, var30, 10.0F);
         }

         RenderUtil.a(var10, var43, var44, var28, var29, var30, var30, var30, var30, false, 1845493760);
         RenderUtil.a(var10, var43, var44, var28, var29, var30, 0.75F, 436207615);
         Msdf.a(var10, MsdfManager.BOLD, var24, var43 + var27, var44 + (var29 - Msdf.a(MsdfManager.BOLD, var25)) / 2.0F + 0.5F, var25, -1);
      }
   }

   private void a(Matrix4f var1, float var2, float var3, float var4, float var5, int var6) {
      for (float var7 = 0.0F; var7 <= var5; var7 += 1.5F) {
         float var8 = var7 / var5;
         float var9 = var4 * (1.0F - var8);
         RenderUtil.a(var1, var2 - var9, var3 - var5 + var7, var9 * 2.0F, 1.75F, 0.0F, 0.0F, 0.0F, 0.0F, false, var6);
      }
   }

   private Matrix4f a(float var1, float var2, float var3) {
      Matrix4f var4 = RenderUtil.d();
      var4.translate(var1, var2, 0.0F);
      var4.scale(var3, var3, 1.0F);
      var4.translate(-var1, -var2, 0.0F);
      return var4;
   }

   private void a(Matrix4f var1, class_742 var2, float var3, float var4, float var5) {
      RenderUtil.a(var1, var3, var4, var5, var5, 2.0F, 2.0F, 2.0F, 2.0F, false, 2013265920);
      class_2960 var6 = SkinCache.a(mc, var2);
      if (var6 != null) {
         try {
            GpuTextureView var7 = mc.method_1531().method_4619(var6).method_71659();
            TexturePipeline.b(var1, var3, var4, var5, var5, var7, -1, 1.5F, 0.0F, 0.125F, 0.125F, 0.25F, 0.25F);
         } catch (Exception var8) {
         }
      }
   }

   private static void k() {
      if (bloomPipeline == null || uniformBuffer == null) {
         try {
            if (bloomPipeline == null) {
               bloomPipeline = b(false);
               bloomPipelineWalls = b(true);
            }

            if (uniformBuffer == null) {
               uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "Prediction Uniforms", 136, 64L);
            }
         } catch (Exception var1) {
         }
      }
   }

   private static RenderPipeline b(boolean var0) {
      return RenderPipeline.builder()
         .withLocation(class_2960.method_60655("brokke", var0 ? "pred_bloom_nodepth" : "pred_bloom"))
         .withVertexShader(class_2960.method_60655("brokke", "world_bloom_vertex"))
         .withFragmentShader(class_2960.method_60655("brokke", "world_bloom_fragment"))
         .withVertexFormat(FORMAT_BLOOM, class_5596.field_27382)
         .withUniform("Uniforms", class_10789.field_60031)
         .withSampler("Sampler0")
         .withDepthTestFunction(var0 ? DepthTestFunction.NO_DEPTH_TEST : DepthTestFunction.LEQUAL_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .withBlend(new BlendFunction(SourceFactor.SRC_ALPHA, DestFactor.ONE))
         .build();
   }

   private static void a(Matrix4f var0) {
      if (uniformBuffer != null) {
         if (uniformScratch == null) {
            uniformScratch = MemoryUtil.memAlloc(64);
         }

         uniformScratch.clear();
         uniformScratch.putFloat(var0.m00()).putFloat(var0.m01()).putFloat(var0.m02()).putFloat(var0.m03());
         uniformScratch.putFloat(var0.m10()).putFloat(var0.m11()).putFloat(var0.m12()).putFloat(var0.m13());
         uniformScratch.putFloat(var0.m20()).putFloat(var0.m21()).putFloat(var0.m22()).putFloat(var0.m23());
         uniformScratch.putFloat(var0.m30()).putFloat(var0.m31()).putFloat(var0.m32()).putFloat(var0.m33());
         uniformScratch.flip();
         CommandEncoder var1 = RenderSystem.getDevice().createCommandEncoder();
         var1.writeToBuffer(uniformBuffer.slice(), uniformScratch);
      }
   }

   private void a(class_287 var1, GpuTextureView var2, RenderPipeline var3) {
      class_9801 var4 = var1.method_60794();
      if (var4 != null) {
         int var5 = var4.method_60822().comp_751();
         if (var5 <= 0) {
            var4.close();
         } else {
            try {
               int var6 = var4.method_60818().remaining();
               if (quadsVbo == null || quadsVbo.size() < var6) {
                  if (quadsVbo != null) {
                     quadsVbo.close();
                  }

                  quadsVbo = RenderSystem.getDevice().createBuffer(() -> "Prediction Quads VBO", 40, Math.max(var6, 4096));
               }

               CommandEncoder var7 = RenderSystem.getDevice().createCommandEncoder();
               var7.writeToBuffer(quadsVbo.slice(0L, var6), var4.method_60818());
               class_5590 var8 = RenderSystem.getSequentialBuffer(class_5596.field_27382);
               GpuBuffer var9 = var8.method_68274(var5);
               class_276 var10 = mc.method_1522();
               if (var10 == null) {
                  return;
               }

               class_12137 var11 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);

               try (RenderPass var12 = var7.createRenderPass(
                     () -> "Prediction Quads", var10.method_71639(), OptionalInt.empty(), var10.method_71640(), OptionalDouble.empty()
                  )) {
                  var12.setPipeline(var3);
                  var12.setVertexBuffer(0, quadsVbo);
                  var12.setIndexBuffer(var9, var8.method_31924());
                  var12.setUniform("Uniforms", uniformBuffer);
                  var12.bindTexture("Sampler0", var2, var11);
                  var12.drawIndexed(0, 0, var5, 1);
                  return;
               }
            } catch (Exception var22) {
            } finally {
               var4.close();
            }

            return;
         }
      }
   }

   private Matrix4f l() {
      float var1 = mc.method_61966().method_60637(true);
      class_4184 var2 = mc.field_1773.method_19418();
      double var3 = Math.toRadians(var2.method_19330());
      double var5 = Math.toRadians(var2.method_19329());
      double var7 = Math.cos(var3);
      double var9 = Math.sin(var3);
      double var11 = Math.cos(var5);
      double var13 = Math.sin(var5);
      class_243 var15 = new class_243(-var9 * var11, -var13, var7 * var11);
      class_243 var16 = new class_243(0.0, 1.0, 0.0);
      class_243 var17 = var15.method_1036(var16);
      if (var17.method_1027() < 1.0E-6) {
         var17 = var15.method_1036(new class_243(0.0, 0.0, 1.0));
      }

      var17 = var17.method_1029();
      class_243 var18 = var17.method_1036(var15).method_1029();
      Matrix4f var19 = new Matrix4f().lookAt(0.0F, 0.0F, 0.0F, (float)var15.field_1352, (float)var15.field_1351, (float)var15.field_1350, (float)var18.field_1352, (float)var18.field_1351, (float)var18.field_1350);
      class_1041 var20 = mc.method_22683();
      float var21 = (float)var20.method_4489() / Math.max(1, var20.method_4506());
      float var22 = ((IGameRenderer)mc.field_1773).invokeGetFov(var2, var1, true);
      Matrix4f var23 = new Matrix4f().perspective((float)Math.toRadians(var22), var21, 0.05F, 1000.0F);
      return var23.mul(var19);
   }

   private static class_243 a(class_1297 var0, float var1) {
      return var0.method_30950(var1);
   }

   private boolean b(class_1297 var1) {
      boolean var2 = false;
      if (var1 instanceof class_1684 && this.entities.isOptionEnabled("Эндер-жемчуги")) {
         var2 = true;
      }

      if (var1 instanceof class_1685 && this.entities.isOptionEnabled("Трезубцы")) {
         var2 = true;
      }

      if (var1 instanceof class_1680 && this.entities.isOptionEnabled("Снежки")) {
         var2 = true;
      }

      if (var1 instanceof class_1667 && this.entities.isOptionEnabled("Стрелы")) {
         var2 = true;
      }

      if (var1 instanceof class_1686 && this.entities.isOptionEnabled("Зелья")) {
         var2 = true;
      }

      return var1 instanceof class_1685 var3 && var3.field_7649 > 0
         ? false
         : var2 && (Math.abs(var1.method_18798().field_1352 + var1.method_18798().field_1350) > 0.01F || Math.abs(var1.method_18798().field_1351) > 0.2F);
   }

   private class_1297 a(class_1297 var1, class_243 var2) {
      class_243 var3 = var1.method_73189();
      class_243 var4 = var2.method_1020(var3);
      if (var4.method_1027() == 0.0) {
         return null;
      }

      class_3966 var5 = class_1675.method_18075(
         var1,
         var3,
         var2,
         var1.method_5829().method_18804(var4).method_1014(0.5),
         var1xx -> mc.field_1724 != var1xx && var1xx.method_5805() && !(var1xx instanceof class_1542) && !(var1xx instanceof class_1303) && var1xx != var1,
         var4.method_1027()
      );
      return var5 != null ? var5.method_17782() : null;
   }

   private class_243 b(class_1297 var1, class_243 var2) {
      return var2.method_1021(0.99).method_1031(0.0, -var1.method_56989(), 0.0);
   }

   record a(class_1297 entity, List<class_243> vectors, int ticks, class_1297 collidedEntity) {
      public class_1297 getEntity() {
         return this.entity;
      }

      public List<class_243> getVectors() {
         return this.vectors;
      }

      public int getTicks() {
         return this.ticks;
      }

      public class_1297 getCollidedEntity() {
         return this.collidedEntity;
      }
   }
}
