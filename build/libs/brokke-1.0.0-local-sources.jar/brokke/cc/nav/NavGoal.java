package brokke.cc.nav;

import net.minecraft.class_2338;

public interface NavGoal {
   boolean a(class_2338 var1);

   double b(class_2338 var1);

   default boolean a() {
      return false;
   }

   default double b() {
      return 0.0;
   }

   default double c() {
      return 0.0;
   }
}
