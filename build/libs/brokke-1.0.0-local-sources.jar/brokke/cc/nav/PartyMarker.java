package brokke.cc.nav;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;

public class PartyMarker {
   private final String id;
   private final String senderName;
   private final boolean isPlayerTarget;
   private final UUID targetPlayerUuid;
   private final String label;
   private final class_243 staticPos;
   private final long createdAt;

   public PartyMarker(String var1, String var2, boolean var3, UUID var4, String var5, class_243 var6) {
      this(var1, var2, var3, var4, var5, var6, System.currentTimeMillis());
   }

   public PartyMarker(String var1, String var2, boolean var3, UUID var4, String var5, class_243 var6, long var7) {
      this.id = var1;
      this.senderName = var2;
      this.isPlayerTarget = var3;
      this.targetPlayerUuid = var4;
      this.label = var5;
      this.staticPos = var6;
      this.createdAt = var7;
   }

   public String getId() {
      return this.id;
   }

   public String getSenderName() {
      return this.senderName;
   }

   public boolean isPlayerTarget() {
      return this.isPlayerTarget;
   }

   public UUID getTargetPlayerUuid() {
      return this.targetPlayerUuid;
   }

   public String getLabel() {
      return this.label;
   }

   public class_243 getStaticPos() {
      return this.staticPos;
   }

   public long getCreatedAt() {
      return this.createdAt;
   }

   public class_243 a(class_1937 var1) {
      if (this.isPlayerTarget && this.targetPlayerUuid != null && var1 != null) {
         class_1657 var2 = var1.method_18470(this.targetPlayerUuid);
         if (var2 != null && var2.method_5805()) {
            return var2.method_33571().method_1031(0.0, 0.4, 0.0);
         }
      }

      return this.staticPos;
   }

   public boolean b(class_1937 var1) {
      if (this.isPlayerTarget && this.targetPlayerUuid != null && var1 != null) {
         class_1657 var2 = var1.method_18470(this.targetPlayerUuid);
         return var2 != null && var2.method_5805();
      } else {
         return this.staticPos != null;
      }
   }
}
