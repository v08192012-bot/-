package brokke.cc.nav;

import brokke.cc.util.InventoryUtility;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class MineBlockTask implements NavTask {
   private final class_310 mc = class_310.method_1551();
   private final class_2338 targetBlock;
   private final NavGoal goal;
   private List<PathNode> path = Collections.emptyList();
   private boolean finished;
   private int miningTicks;
   private int recalculateCooldown;

   public MineBlockTask(class_2338 var1) {
      this.targetBlock = var1;
      this.goal = new GoalNear(var1, 3.2);
   }

   @Override
   public void a() {
      this.finished = false;
      this.miningTicks = 0;
      this.recalculateCooldown = 0;
      this.j();
   }

   @Override
   public void b() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && !this.finished) {
         class_2680 var1 = this.mc.field_1687.method_8320(this.targetBlock);
         if (var1.method_26215()) {
            this.finished = true;
         } else {
            class_243 var2 = this.mc.field_1724.method_33571();
            class_243 var3 = new class_243(this.targetBlock.method_10263() + 0.5, this.targetBlock.method_10264() + 0.5, this.targetBlock.method_10260() + 0.5);
            double var4 = var2.method_1025(var3);
            if (var4 <= 18.0) {
               NavigationManager.getInstance().getMovementController().a();
               NavRotationController var8 = NavigationManager.getInstance().getRotationController();
               var8.a(var3);
               var8.a(45.0F);
               this.a(var1);
               this.miningTicks++;
               if (this.mc.field_1761 != null) {
                  class_2350 var7 = class_2350.method_10142(var3.field_1352 - var2.field_1352, var3.field_1351 - var2.field_1351, var3.field_1350 - var2.field_1350);
                  this.mc.field_1761.method_2902(this.targetBlock, var7);
                  this.mc.field_1724.method_6104(class_1268.field_5808);
               }
            } else {
               if (this.recalculateCooldown > 0) {
                  this.recalculateCooldown--;
               }

               NavMovementController var6 = NavigationManager.getInstance().getMovementController();
               if ((var6.isStuck() || !var6.isActive()) && this.recalculateCooldown <= 0) {
                  this.recalculateCooldown = 20;
                  this.j();
               }
            }
         }
      }
   }

   private void a(class_2680 var1) {
      if (this.mc.field_1724 != null) {
         int var2 = -1;
         float var3 = 1.0F;

         for (int var4 = 0; var4 < 9; var4++) {
            class_1799 var5 = this.mc.field_1724.method_31548().method_5438(var4);
            float var6 = var5.method_7924(var1);
            if (var6 > var3) {
               var3 = var6;
               var2 = var4;
            }
         }

         if (var2 != -1 && this.mc.field_1724.method_31548().method_67532() != var2) {
            InventoryUtility.e(var2);
         }
      }
   }

   private void j() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_2338 var1 = this.mc.field_1724.method_24515();
         List var2 = PathFinder.a(this.mc.field_1687, var1, this.goal);
         if (var2 != null && !var2.isEmpty()) {
            this.path = var2;
            NavigationManager.getInstance().getMovementController().a(var2);
         }
      }
   }

   @Override
   public boolean isFinished() {
      return this.finished;
   }

   @Override
   public void d() {
      NavigationManager.getInstance().getMovementController().a();
      if (this.mc.field_1761 != null) {
         this.mc.field_1761.method_2925();
      }
   }

   @Override
   public String getName() {
      return "Mine " + this.targetBlock.method_10263() + ", " + this.targetBlock.method_10264() + ", " + this.targetBlock.method_10260();
   }

   @Override
   public String f() {
      if (this.finished) {
         return "Вскопано";
      }

      if (this.mc.field_1724 != null
         && this.mc
               .field_1724
               .method_33571()
               .method_1025(new class_243(this.targetBlock.method_10263() + 0.5, this.targetBlock.method_10264() + 0.5, this.targetBlock.method_10260() + 0.5))
            <= 18.0) {
         return "Копает (" + this.miningTicks + " тиков)";
      }

      NavMovementController var1 = NavigationManager.getInstance().getMovementController();
      int var2 = this.path.isEmpty() ? 0 : Math.max(0, this.path.size() - var1.getCurrentIndex());
      return "Идёт к блоку, осталось точек: " + var2;
   }

   @Override
   public NavGoal getGoal() {
      return this.goal;
   }

   @Override
   public List<PathNode> getPath() {
      return this.path;
   }

   public class_2338 getTargetBlock() {
      return this.targetBlock;
   }
}
