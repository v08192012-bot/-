package brokke.cc.nav;

import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationUtils;
import brokke.cc.util.MathUtils;
import brokke.cc.util.RayTraceUtil;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;

public final class BestPoint {
   private static final class_310 mc = class_310.method_1551();
   private static class_243 rotationPoint = class_243.field_1353;
   private static class_243 rotationMotion = class_243.field_1353;

   private BestPoint() {
   }

   public static class_243 getRotationPoint() {
      return rotationPoint;
   }

   public static class_243 a(class_1297 var0) {
      if (mc.field_1724 != null && var0 != null) {
         class_238 var1 = var0.method_5829();
         class_243 var2 = mc.field_1724.method_33571();
         return new class_243(
            class_3532.method_15350(var2.field_1352, var1.field_1323, var1.field_1320), class_3532.method_15350(var2.field_1351, var1.field_1322, var1.field_1325), class_3532.method_15350(var2.field_1350, var1.field_1321, var1.field_1324)
         );
      } else {
         return var0 != null ? var0.method_73189() : class_243.field_1353;
      }
   }

   public static class_243 b(class_1297 var0) {
      class_238 var1 = var0.method_5829();
      double var2 = var1.field_1320 - var1.field_1323;
      double var4 = var1.field_1325 - var1.field_1322;
      double var6 = var1.field_1324 - var1.field_1321;
      double var8 = var1.field_1323 + var2 / 2.0;
      double var10 = var1.field_1322 + var4 * 0.7;
      double var12 = var1.field_1321 + var6 / 2.0;
      double var14 = System.currentTimeMillis() / 50.0;
      int var16 = var0.method_5628();
      double var17 = Math.sin(var14 + var16) * (var2 * 0.45);
      double var19 = Math.cos(var14 * 0.8 + var16) * (var4 * 0.1);
      double var21 = Math.cos(var14 * 1.2 + var16) * (var6 * 0.45);
      return new class_243(var8 + var17, var10 + var19, var12 + var21);
   }

   public static class_243 c(class_1297 var0) {
      class_238 var1 = var0.method_5829();
      double var2 = var1.field_1320 - var1.field_1323;
      double var4 = var1.field_1325 - var1.field_1322;
      double var6 = var1.field_1324 - var1.field_1321;
      double var8 = var1.field_1323 + var2 / 2.0;
      double var10 = var1.field_1322 + var4 * 0.65;
      double var12 = var1.field_1321 + var6 / 2.0;
      double var14 = System.currentTimeMillis() / 65.0;
      int var16 = var0.method_5628();
      double var17 = Math.sin(var14 + var16) * (var2 * 0.7);
      double var19 = Math.cos(var14 * 0.8 + var16) * (var4 * 0.4);
      double var21 = Math.cos(var14 * 1.2 + var16) * (var6 * 0.7);
      return new class_243(var8 + var17, var10 + var19, var12 + var21);
   }

   public static class_243 a(class_1297 var0, class_243 var1, double var2) {
      if (var1 != null && mc.field_1724 != null && mc.field_1687 != null) {
         if (b(var0, var1, var2)) {
            return var1;
         }

         class_238 var4 = var0.method_5829();
         double var5 = 0.12;
         class_243 var7 = null;
         double var8 = Double.MAX_VALUE;

         for (double var10 = var4.field_1323; var10 <= var4.field_1320; var10 += var5) {
            for (double var12 = var4.field_1322; var12 <= var4.field_1325; var12 += var5) {
               for (double var14 = var4.field_1321; var14 <= var4.field_1324; var14 += var5) {
                  class_243 var16 = new class_243(var10, var12, var14);
                  if (b(var0, var16, var2)) {
                     double var17 = var16.method_1025(var1);
                     if (var17 < var8) {
                        var8 = var17;
                        var7 = var16;
                     }
                  }
               }
            }
         }

         return var7 != null ? var7 : var1;
      } else {
         return var1;
      }
   }

   private static boolean b(class_1297 var0, class_243 var1, double var2) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 var4 = mc.field_1724.method_33571();
         double var5 = var4.method_1022(var1);
         if (var5 > var2) {
            return false;
         }

         class_243 var7 = var1.method_1020(var4).method_1029();
         if (!RayTraceUtil.a(var7, var5 + 0.2, var0.method_5829())) {
            return false;
         }

         class_3965 var8 = RayTraceUtil.a(var4, var1, class_3960.field_17558, mc.field_1724);
         return var8.method_17783() == class_240.field_1333 || var4.method_1025(var8.method_17784()) >= var4.method_1025(var1) - 1.0E-4;
      } else {
         return false;
      }
   }

   public static class_243 a(class_1297 var0, double var1) {
      if (mc.field_1724 == null) {
         return var0.method_73189();
      }

      float var3 = 0.005F;
      float var4 = 0.015F;
      float var5 = 0.0015F;
      float var6 = 0.015F;
      double var7 = var0.method_5829().method_17939();
      double var9 = var0.method_5829().method_17940();
      double var11 = var0.method_5829().method_17941();
      if (rotationMotion.equals(class_243.field_1353)) {
         rotationMotion = new class_243(MathUtils.randomDouble(-0.02F, 0.02F), MathUtils.randomDouble(-0.02F, 0.02F), MathUtils.randomDouble(-0.02F, 0.02F));
      }

      if (rotationPoint.equals(class_243.field_1353)) {
         rotationPoint = new class_243(0.0, var9 * 0.5, 0.0);
      }

      rotationPoint = rotationPoint.method_1019(rotationMotion);
      double var13 = (var7 - 0.1) / 2.0;
      double var15 = (var11 - 0.1) / 2.0;
      if (rotationPoint.field_1352 >= var13) {
         rotationMotion = new class_243(-MathUtils.randomDouble(var3, var4), rotationMotion.method_10214(), rotationMotion.method_10215());
      } else if (rotationPoint.field_1352 <= -var13) {
         rotationMotion = new class_243(MathUtils.randomDouble(var3, var4), rotationMotion.method_10214(), rotationMotion.method_10215());
      }

      if (rotationPoint.field_1351 >= var9 * 0.75) {
         rotationMotion = new class_243(rotationMotion.method_10216(), -MathUtils.randomDouble(var5, var6), rotationMotion.method_10215());
      } else if (rotationPoint.field_1351 <= var9 * 0.3) {
         rotationMotion = new class_243(rotationMotion.method_10216(), MathUtils.randomDouble(var5, var6), rotationMotion.method_10215());
      }

      if (rotationPoint.field_1350 >= var15) {
         rotationMotion = new class_243(rotationMotion.method_10216(), rotationMotion.method_10214(), -MathUtils.randomDouble(var3, var4));
      } else if (rotationPoint.field_1350 <= -var15) {
         rotationMotion = new class_243(rotationMotion.method_10216(), rotationMotion.method_10214(), MathUtils.randomDouble(var3, var4));
      }

      rotationPoint = rotationPoint.method_1031(MathUtils.randomDouble(-0.05F, 0.05F), 0.0, MathUtils.randomDouble(-0.05F, 0.05F));
      if (!RayTraceUtil.a(mc.field_1724.method_5720(), var1, var0.method_5829())) {
         float var18 = (float)(var7 / 2.0) * 0.8F;

         for (float var19 = -var18; var19 <= var18; var19 += 0.1F) {
            for (float var20 = -var18; var20 <= var18; var20 += 0.1F) {
               for (float var21 = (float)(var9 * 0.9); var21 >= var9 * 0.3; var21 -= 0.1F) {
                  class_243 var22 = new class_243(var0.method_23317() + var19, var0.method_23318() + var21, var0.method_23321() + var20);
                  Rotation2 var17 = RotationUtils.a(var22);
                  if (RayTraceUtil.a(var17.d(), var1, var0.method_5829())) {
                     rotationPoint = new class_243(var19, var21, var20);
                     return var0.method_73189().method_1019(rotationPoint);
                  }
               }
            }
         }
      }

      return var0.method_73189().method_1019(rotationPoint);
   }
}
