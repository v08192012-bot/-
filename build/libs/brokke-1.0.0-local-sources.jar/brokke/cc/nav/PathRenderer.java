package brokke.cc.nav;

import brokke.cc.render.ColorPipeline;
import brokke.cc.render.Render3DUtil;
import brokke.cc.render.Theme;
import brokke.cc.render.WorldToScreen;
import brokke.cc.system.events.EventHandler;
import brokke.cc.system.events.impl.Render3DEvent;
import java.awt.Color;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_310;

public class PathRenderer {
   private final class_310 mc = class_310.method_1551();
   private boolean enabled = true;

   @EventHandler
   public void onRender3D(Render3DEvent var1) {
      if (this.enabled && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         List var2 = NavigationManager.getInstance().j();
         if (var2 != null && !var2.isEmpty()) {
            int var3 = NavigationManager.getInstance().getMovementController().getCurrentIndex();
            Color var4 = Theme.getInstance().getAccent();
            int var5 = var4.getAlpha() << 24 | var4.getRed() << 16 | var4.getGreen() << 8 | var4.getBlue();
            int var6 = 1619034240;
            class_287 var7 = Render3DUtil.a();
            if (var7 != null) {
               try {
                  for (PathCurve.a var10 : (Iterable<PathCurve.a>)(Iterable<?>)(PathCurve.a(var2, 4))) {
                     float[][] var11 = WorldToScreen.a(var10.getStart(), var10.getEnd());
                     if (var11 != null) {
                        int var12 = var10.getNodeIndex() < var3 ? var6 : var5;
                        ColorPipeline.a(var7, var11[0][0], var11[0][1], var11[1][0], var11[1][1], 2.5F, var12);
                     }
                  }

                  if (!var2.isEmpty()) {
                     class_2338 var16 = ((PathNode)var2.get(var2.size() - 1)).getPos();
                     class_243 var17 = new class_243(var16.method_10263() + 0.5, var16.method_10264() + 0.5, var16.method_10260() + 0.5);
                     Render3DUtil.a(var7, var17, 1.0F, var4, 2.0F);
                  }
               } finally {
                  Render3DUtil.a(var7);
               }
            }
         }
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean var1) {
      this.enabled = var1;
   }
}
