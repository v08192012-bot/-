package brokke.cc.nav;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class PathCurve {
   private final double x0;
   private final double z0;
   private final double x1;
   private final double z1;
   private final double ux;
   private final double uz;
   private final double nx;
   private final double nz;
   private final double totalDist;
   private final double phi1;
   private final double phi2;
   private final boolean hasCurve;

   public PathCurve(double var1, double var3, double var5, double var7) {
      this.x0 = var1;
      this.z0 = var3;
      this.x1 = var5;
      this.z1 = var7;
      double var9 = var5 - var1;
      double var11 = var7 - var3;
      double var13 = Math.hypot(var9, var11);
      this.totalDist = var13;
      this.ux = 0.0;
      this.uz = 0.0;
      this.nx = 0.0;
      this.nz = 0.0;
      this.phi1 = 0.0;
      this.phi2 = 0.0;
      this.hasCurve = false;
   }

   public boolean a() {
      return false;
   }

   public double a(double var1) {
      return 0.0;
   }

   public double a(double var1, double var3) {
      return 0.0;
   }

   public static class_243 a(List<PathNode> var0, double var1) {
      if (var0 != null && !var0.isEmpty()) {
         int var3 = var0.size();
         if (var3 == 1) {
            class_2338 var35 = var0.get(0).getPos();
            return new class_243(var35.method_10263() + 0.5, var35.method_10264() + 0.1, var35.method_10260() + 0.5);
         } else if (var1 <= 0.0) {
            class_2338 var34 = var0.get(0).getPos();
            return new class_243(var34.method_10263() + 0.5, var34.method_10264() + 0.1, var34.method_10260() + 0.5);
         } else if (var1 >= var3 - 1) {
            class_2338 var33 = var0.get(var3 - 1).getPos();
            return new class_243(var33.method_10263() + 0.5, var33.method_10264() + 0.1, var33.method_10260() + 0.5);
         } else {
            int var4 = (int)Math.floor(var1);
            double var5 = var1 - var4;
            int var7 = Math.max(0, var4 - 1);
            int var8 = var4;
            int var9 = Math.min(var3 - 1, var4 + 1);
            int var10 = Math.min(var3 - 1, var4 + 2);
            class_243 var11 = a(var0.get(var7));
            class_243 var12 = a(var0.get(var8));
            class_243 var13 = a(var0.get(var9));
            class_243 var14 = a(var0.get(var10));
            double var15 = var5 * var5;
            double var17 = var15 * var5;
            double var19 = -0.5 * var17 + var15 - 0.5 * var5;
            double var21 = 1.5 * var17 - 2.5 * var15 + 1.0;
            double var23 = -1.5 * var17 + 2.0 * var15 + 0.5 * var5;
            double var25 = 0.5 * var17 - 0.5 * var15;
            double var27 = var11.field_1352 * var19 + var12.field_1352 * var21 + var13.field_1352 * var23 + var14.field_1352 * var25;
            double var29 = var11.field_1351 * var19 + var12.field_1351 * var21 + var13.field_1351 * var23 + var14.field_1351 * var25;
            double var31 = var11.field_1350 * var19 + var12.field_1350 * var21 + var13.field_1350 * var23 + var14.field_1350 * var25;
            return new class_243(var27, var29, var31);
         }
      } else {
         return class_243.field_1353;
      }
   }

   public static List<PathCurve.a> a(List<PathNode> var0, int var1) {
      ArrayList var2 = new ArrayList();
      if (var0 != null && var0.size() >= 2) {
         int var3 = var0.size();
         int var4 = Math.max(1, var1);
         class_243 var5 = a(var0, 0.0);

         for (int var6 = 0; var6 < var3 - 1; var6++) {
            for (int var7 = 1; var7 <= var4; var7++) {
               double var8 = var6 + (double)var7 / var4;
               class_243 var10 = a(var0, var8);
               var2.add(new PathCurve.a(var5, var10, var6));
               var5 = var10;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private static class_243 a(PathNode var0) {
      class_2338 var1 = var0.getPos();
      return new class_243(var1.method_10263() + 0.5, var1.method_10264() + 0.1, var1.method_10260() + 0.5);
   }

   public static class_243 a(List<PathNode> var0, double var1, class_1937 var3, long var4) {
      return var0 != null && !var0.isEmpty() ? a(var0, var1) : class_243.field_1353;
   }

   private static boolean a(class_1937 var0, class_2338 var1) {
      return PathFinder.d(var0, var1) && PathFinder.d(var0, var1.method_10084())
         ? PathFinder.e(var0, var1.method_10074()) || PathFinder.b(var0, var1) || PathFinder.b(var0, var1.method_10074())
         : false;
   }

   public record a(class_243 start, class_243 end, int nodeIndex) {
      public class_243 getStart() {
         return this.start;
      }

      public class_243 getEnd() {
         return this.end;
      }

      public int getNodeIndex() {
         return this.nodeIndex;
      }
   }
}
