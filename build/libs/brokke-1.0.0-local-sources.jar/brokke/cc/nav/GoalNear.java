package brokke.cc.nav;

import net.minecraft.class_2338;

public class GoalNear implements NavGoal {
   private final class_2338 target;
   private final double radius;

   public GoalNear(class_2338 var1, double var2) {
      this.target = var1;
      this.radius = var2;
   }

   public class_2338 getTarget() {
      return this.target;
   }

   public double getRadius() {
      return this.radius;
   }

   @Override
   public boolean a(class_2338 var1) {
      double var2 = var1.method_10263() + 0.5 - (this.target.method_10263() + 0.5);
      double var4 = var1.method_10264() - this.target.method_10264();
      double var6 = var1.method_10260() + 0.5 - (this.target.method_10260() + 0.5);
      return var2 * var2 + var4 * var4 + var6 * var6 <= this.radius * this.radius;
   }

   @Override
   public double b(class_2338 var1) {
      double var2 = var1.method_10263() - this.target.method_10263();
      double var4 = var1.method_10264() - this.target.method_10264();
      double var6 = var1.method_10260() - this.target.method_10260();
      double var8 = Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
      return Math.max(0.0, var8 - this.radius);
   }

   @Override
   public boolean a() {
      return true;
   }

   @Override
   public double b() {
      return this.target.method_10263() + 0.5;
   }

   @Override
   public double c() {
      return this.target.method_10260() + 0.5;
   }
}
