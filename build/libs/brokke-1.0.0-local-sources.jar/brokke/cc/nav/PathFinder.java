package brokke.cc.nav;

import brokke.cc.core.MovementType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1621;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_2358;
import net.minecraft.class_238;
import net.minecraft.class_2399;
import net.minecraft.class_2413;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2541;
import net.minecraft.class_2544;
import net.minecraft.class_2560;
import net.minecraft.class_2563;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3736;
import net.minecraft.class_3830;
import net.minecraft.class_3922;

public class PathFinder {
   private static final int MAX_ITERATIONS = 8000;
   private static final int[][] CARDINALS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
   private static final int[][] DIAGONALS = new int[][]{{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

   public static List<PathNode> a(class_1937 var0, class_2338 var1, NavGoal var2) {
      return a(var0, var1, var2, null, null);
   }

   public static List<PathNode> a(class_1937 var0, class_2338 var1, NavGoal var2, class_2338 var3) {
      return a(var0, var1, var2, var3, null);
   }

   public static List<PathNode> a(class_1937 var0, class_2338 var1, NavGoal var2, class_2338 var3, class_2338 var4) {
      if (var0 != null && var1 != null && var2 != null) {
         class_2338 var5 = var1;
         if (!d(var0, var5) && e(var0, var5)) {
            var5 = var5.method_10084();
         } else if (!b(var0, var5) && b(var0, var5.method_10074())) {
            var5 = var5.method_10074();
         } else if (!e(var0, var5.method_10074()) && !b(var0, var5) && !b(var0, var5.method_10074())) {
            for (int var6 = 1; var6 <= 3; var6++) {
               if (e(var0, var5.method_10087(var6 + 1))) {
                  var5 = var5.method_10087(var6);
                  break;
               }
            }
         }

         PathCurve var30 = null;
         if (var2.a()) {
            class_2338 var7 = var3 != null ? var3 : var5;
            var30 = new PathCurve(var7.method_10263() + 0.5, var7.method_10260() + 0.5, var2.b(), var2.c());
         }

         List var31 = Collections.emptyList();
         if (var0 != null) {
            class_238 var8 = new class_238(var5).method_1014(48.0);
            List var9 = var0.method_8390(
               class_1309.class, var8, var0x -> var0x != null && var0x.method_5805() && (var0x instanceof class_1588 || var0x instanceof class_1621)
            );
            if (!var9.isEmpty()) {
               var31 = new ArrayList(var9.size());

               for (class_1309 var11 : (Iterable<class_1309>)(Iterable<?>)(var9)) {
                  var31.add(var11.method_73189());
               }
            }
         }

         PriorityQueue var32 = new PriorityQueue();
         HashMap var33 = new HashMap();
         PathNode var34 = new PathNode(var5, null, 0.0, var2.b(var5), MovementType.WALK);
         var32.add(var34);
         var33.put(var5, 0.0);
         PathNode var35 = var34;
         double var12 = var34.getHCost();
         PathNode var14 = null;
         double var15 = Double.MAX_VALUE;
         PathNode var17 = null;
         double var18 = 0.0;
         int var20 = 0;

         while (!var32.isEmpty() && var20++ < 8000) {
            PathNode var21 = (PathNode)var32.poll();
            Double var22 = (Double)var33.get(var21.getPos());
            if (var22 == null || !(var21.getGCost() > var22)) {
               if (var2.a(var21.getPos())) {
                  return a(var21);
               }

               if (var21 != var34) {
                  if (var21.getHCost() < var15) {
                     var15 = var21.getHCost();
                     var14 = var21;
                  }

                  if (var21.getGCost() > var18) {
                     var18 = var21.getGCost();
                     var17 = var21;
                  }
               }

               if (var21.getHCost() < var12) {
                  var12 = var21.getHCost();
                  var35 = var21;
               }

               for (PathNode var25 : (Iterable<PathNode>)(Iterable<?>)(a(var0, var21, var2, var30, var4, var31))) {
                  class_2338 var26 = var25.getPos();
                  double var27 = var25.getGCost();
                  Double var29 = (Double)var33.get(var26);
                  if (var29 == null || var27 < var29) {
                     var33.put(var26, var27);
                     var32.add(var25);
                     if (var25.getHCost() < var12) {
                        var12 = var25.getHCost();
                        var35 = var25;
                     }

                     if (var25.getHCost() < var15) {
                        var15 = var25.getHCost();
                        var14 = var25;
                     }

                     if (var25.getGCost() > var18) {
                        var18 = var25.getGCost();
                        var17 = var25;
                     }
                  }
               }
            }
         }

         if (var35 != null && var35 != var34) {
            return a(var35);
         } else if (var17 != null && var17 != var34 && var17.getGCost() >= 2.0) {
            return a(var17);
         } else if (var14 != null && var14 != var34) {
            return a(var14);
         } else {
            return var17 != null && var17 != var34 ? a(var17) : Collections.emptyList();
         }
      } else {
         return Collections.emptyList();
      }
   }

   private static List<PathNode> a(class_1937 var0, PathNode var1, NavGoal var2, PathCurve var3, class_2338 var4, List<class_243> var5) {
      ArrayList var6 = new ArrayList();
      class_2338 var7 = var1.getPos();

      for (int[] var11 : CARDINALS) {
         int var12 = var11[0];
         int var13 = var11[1];
         a(var0, var1, var7, var12, var13, 1.0, false, var2, var3, var4, var5, var6);
      }

      for (int[] var25 : DIAGONALS) {
         int var27 = var25[0];
         int var28 = var25[1];
         a(var0, var1, var7, var27, var28, 1.4142, true, var2, var3, var4, var5, var6);
      }

      if (h(var0, var7)) {
         class_2338 var16 = var7.method_10084();
         if (h(var0, var16) || d(var0, var16) && d(var0, var16.method_10084())) {
            var6.add(new PathNode(var16, var1, var1.getGCost() + 1.1, var2.b(var16), MovementType.WALK));
         }

         class_2338 var19 = var7.method_10074();
         if (h(var0, var19) || d(var0, var19) && (e(var0, var19.method_10074()) || h(var0, var19.method_10074()))) {
            var6.add(new PathNode(var19, var1, var1.getGCost() + 1.0, var2.b(var19), MovementType.WALK));
         }
      }

      if (b(var0, var7)) {
         class_2338 var17 = var7.method_10084();
         if (b(var0, var17)) {
            int var20 = c(var0, var17);
            double var23 = var20 >= 100 ? 45.0 : (var20 <= 2 ? 0.0 : (var20 - 2) * 2.5);
            var6.add(new PathNode(var17, var1, var1.getGCost() + 0.85 + var23, var2.b(var17), MovementType.SWIM));
         }

         class_2338 var21 = var7.method_10074();
         if (b(var0, var21)) {
            int var24 = c(var0, var21);
            double var26 = var24 >= 100 ? 45.0 : (var24 <= 2 ? 0.0 : (var24 - 2) * 2.5);
            double var29 = e(var0, var21.method_10074()) ? 0.35 : 0.0;
            var6.add(new PathNode(var21, var1, var1.getGCost() + 0.85 + var26 + var29, var2.b(var21), MovementType.SWIM));
         }
      }

      return var6;
   }

   private static void a(
      class_1937 var0,
      PathNode var1,
      class_2338 var2,
      int var3,
      int var4,
      double var5,
      boolean var7,
      NavGoal var8,
      PathCurve var9,
      class_2338 var10,
      List<class_243> var11,
      List<PathNode> var12
   ) {
      class_2338 var13 = var2.method_10069(var3, 0, var4);
      if (a(var0, var13)) {
         if (var7) {
            if (b(var0, var2) && !b(var0, var13)) {
               return;
            }

            class_2338 var14 = var2.method_10069(var3, 0, 0);
            class_2338 var15 = var2.method_10069(0, 0, var4);
            if (!d(var0, var14) || !d(var0, var14.method_10084()) || !d(var0, var15) || !d(var0, var15.method_10084())) {
               return;
            }
         }

         double var32 = 0.0;
         if (var9 != null && var9.a()) {
            double var16 = var9.a(var13.method_10263() + 0.5, var13.method_10260() + 0.5);
            var32 = 0.08 * Math.min(var16, 6.0);
         }

         if (var10 != null
            && Math.abs(var13.method_10263() - var10.method_10263()) <= 2
            && Math.abs(var13.method_10260() - var10.method_10260()) <= 2
            && Math.abs(var13.method_10264() - var10.method_10264()) <= 2) {
            var5 += 80.0;
         }

         double var33 = 0.0;
         if (!d(var0, var13.method_10078())
            || !d(var0, var13.method_10067())
            || !d(var0, var13.method_10095())
            || !d(var0, var13.method_10072())
            || !d(var0, var13.method_10078().method_10084())
            || !d(var0, var13.method_10067().method_10084())
            || !d(var0, var13.method_10095().method_10084())
            || !d(var0, var13.method_10072().method_10084())) {
            var33 = 0.05;
         }

         double var18 = 0.0;
         if (var11 != null && !var11.isEmpty()) {
            for (class_243 var21 : var11) {
               double var22 = var13.method_10263() + 0.5 - var21.field_1352;
               double var24 = var13.method_10264() - var21.field_1351;
               double var26 = var13.method_10260() + 0.5 - var21.field_1350;
               double var28 = var22 * var22 + var26 * var26;
               if (Math.abs(var24) < 3.5 && var28 < 36.0) {
                  double var30 = Math.sqrt(var28);
                  if (var30 < 2.5) {
                     var18 += (2.5 - var30) * 12.0 + 8.0;
                  } else {
                     var18 += (6.0 - var30) * 2.0;
                  }
               }
            }

            if (var18 > 35.0) {
               var18 = 35.0;
            }
         }

         double var34 = 0.0;
         if (!b(var0, var13)) {
            for (int[] var25 : CARDINALS) {
               class_2338 var53 = var13.method_10069(var25[0], 0, var25[1]);
               if (d(var0, var53) && !e(var0, var53.method_10087(1)) && !e(var0, var53.method_10087(2)) && !e(var0, var53.method_10087(3)) && !b(var0, var53.method_10087(1))) {
                  var34 += 0.85;
               }
            }
         }

         if (d(var0, var13) && d(var0, var13.method_10084())) {
            if (!b(var0, var13) && (e(var0, var13.method_10074()) || h(var0, var13) || h(var0, var13.method_10074()))) {
               if (var7) {
                  class_2338 var40 = var2.method_10069(var3, 0, 0);
                  class_2338 var45 = var2.method_10069(0, 0, var4);
                  if (!e(var0, var40.method_10074()) && !e(var0, var45.method_10074())) {
                     return;
                  }
               }

               var12.add(
                  new PathNode(
                     var13, var1, var1.getGCost() + var5 + var32 + var33 + var34 + var18, var8.b(var13), var7 ? MovementType.WALK_DIAGONAL : MovementType.WALK
                  )
               );
               return;
            }

            if (b(var0, var13)) {
               int var39 = c(var0, var13);
               double var44 = var39 >= 100 ? 45.0 : (var39 <= 2 ? 0.0 : (var39 - 2) * 2.5);
               double var52 = e(var0, var13.method_10074()) ? 0.35 : 0.0;
               var12.add(new PathNode(var13, var1, var1.getGCost() + var5 * 0.85 + var44 + var52 + var32 + var33 + var18, var8.b(var13), MovementType.SWIM));
               return;
            }

            if (b(var0, var13.method_10074())) {
               int var38 = c(var0, var13.method_10074());
               double var43 = var38 >= 100 ? 45.0 : (var38 <= 2 ? 0.0 : (var38 - 2) * 2.5);
               var12.add(
                  new PathNode(var13.method_10074(), var1, var1.getGCost() + var5 * 0.85 + var43 + var32 + var33 + var18, var8.b(var13.method_10074()), MovementType.SWIM)
               );
               return;
            }

            for (int var36 = 1; var36 <= 3; var36++) {
               class_2338 var41 = var13.method_10087(var36);
               if (!d(var0, var41.method_10084())) {
                  break;
               }

               boolean var47 = true;
               if (var7) {
                  class_2338 var49 = var2.method_10069(var3, 0, 0);
                  class_2338 var54 = var2.method_10069(0, 0, var4);
                  if (!d(var0, var49.method_10087(var36 - 1)) || !d(var0, var54.method_10087(var36 - 1))) {
                     var47 = false;
                  }
               }

               if (var47
                  && d(var0, var41)
                  && d(var0, var41.method_10084())
                  && (e(var0, var41.method_10074()) || b(var0, var41) || h(var0, var41) || h(var0, var41.method_10074()))
                  && (!b(var0, var41) || c(var0, var41) < 100)) {
                  boolean var50 = g(var0, var41.method_10074()) || h(var0, var41) || h(var0, var41.method_10074());
                  MovementType var55 = var50 ? MovementType.WALK : MovementType.FALL_DOWN;
                  var12.add(new PathNode(var41, var1, var1.getGCost() + var5 + var36 * 0.35 + var32 + var33 + var34 + var18, var8.b(var41), var55));
                  return;
               }
            }
         }

         class_2338 var37 = var13.method_10086(1);
         boolean var42 = !var7;
         if (var42
            && d(var0, var2.method_10086(2))
            && d(var0, var37)
            && d(var0, var37.method_10084())
            && (e(var0, var37.method_10074()) || h(var0, var37) || h(var0, var37.method_10074()))
            && (!b(var0, var2) || !b(var0, var2.method_10086(1)))) {
            boolean var48 = g(var0, var37.method_10074());
            boolean var51 = h(var0, var37) || h(var0, var37.method_10074());
            MovementType var56 = !var48 && !var51 ? MovementType.JUMP_UP : (var7 ? MovementType.WALK_DIAGONAL : MovementType.WALK);
            double var27 = !var48 && !var51 ? 0.3 : 0.05;
            var12.add(new PathNode(var37, var1, var1.getGCost() + var5 + var27 + var32 + var33 + var34 + var18, var8.b(var37), var56));
         }
      }
   }

   public static boolean a(class_1937 var0, class_2338 var1) {
      return var0 == null ? false : var0.method_8393(var1.method_10263() >> 4, var1.method_10260() >> 4);
   }

   public static boolean b(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1.method_10264() >= var0.method_31607() && var1.method_10264() < var0.method_31600()) {
         class_3610 var2 = var0.method_8316(var1);
         if (var2.method_15769()) {
            return false;
         } else if (var2.method_15772() == class_3612.field_15910) {
            return true;
         } else {
            return var2.method_15772() == class_3612.field_15909 ? var2.method_15761() >= 7 : false;
         }
      } else {
         return false;
      }
   }

   public static int c(class_1937 var0, class_2338 var1) {
      if (var0 == null) {
         return 0;
      }

      int var2 = 0;
      class_2339 var3 = var1.method_25503();

      while (var2 < 24) {
         var3.method_10098(class_2350.field_11036);
         if (!b(var0, var3)) {
            class_2680 var4 = var0.method_8320(var3);
            if (var4.method_26215() || var4.method_26227().method_15769() && d(var0, var3)) {
               return var2;
            }

            return 999;
         }

         var2++;
      }

      return var2;
   }

   public static boolean d(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1.method_10264() >= var0.method_31607() && var1.method_10264() < var0.method_31600()) {
         class_2680 var2 = var0.method_8320(var1);
         if (var2.method_26215()) {
            return true;
         } else {
            class_2248 var3 = var2.method_26204();
            if (!(var3 instanceof class_2266)
               && !(var3 instanceof class_3830)
               && !(var3 instanceof class_2563)
               && !(var3 instanceof class_2358)
               && !(var3 instanceof class_3922)
               && !(var3 instanceof class_2413)
               && !(var3 instanceof class_2560)) {
               class_3610 var4 = var2.method_26227();
               return var4.method_15772() != class_3612.field_15908 && var4.method_15772() != class_3612.field_15907 ? var2.method_26220(var0, var1).method_1110() : false;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean e(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1.method_10264() >= var0.method_31607() && var1.method_10264() < var0.method_31600()) {
         class_2680 var2 = var0.method_8320(var1);
         if (var2.method_26215()) {
            return false;
         } else {
            class_2248 var3 = var2.method_26204();
            if (!(var3 instanceof class_2266)
               && !(var3 instanceof class_3830)
               && !(var3 instanceof class_2563)
               && !(var3 instanceof class_2358)
               && !(var3 instanceof class_3922)
               && !(var3 instanceof class_2413)
               && !(var3 instanceof class_2560)
               && !(var3 instanceof class_2354)
               && !(var3 instanceof class_2349)
               && !(var3 instanceof class_2544)) {
               class_3610 var4 = var2.method_26227();
               return var4.method_15772() != class_3612.field_15908 && var4.method_15772() != class_3612.field_15907 ? !var2.method_26220(var0, var1).method_1110() : false;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean f(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1 != null) {
         boolean var2 = !d(var0, var1.method_10078()) || !d(var0, var1.method_10078().method_10084());
         boolean var3 = !d(var0, var1.method_10067()) || !d(var0, var1.method_10067().method_10084());
         boolean var4 = !d(var0, var1.method_10095()) || !d(var0, var1.method_10095().method_10084());
         boolean var5 = !d(var0, var1.method_10072()) || !d(var0, var1.method_10072().method_10084());
         return var2 && var3 || var4 && var5;
      } else {
         return false;
      }
   }

   public static boolean g(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1 != null) {
         class_2680 var2 = var0.method_8320(var1);
         class_2248 var3 = var2.method_26204();
         return var3 instanceof class_2510 || var3 instanceof class_2482;
      } else {
         return false;
      }
   }

   public static boolean h(class_1937 var0, class_2338 var1) {
      if (var0 != null && var1 != null) {
         class_2680 var2 = var0.method_8320(var1);
         class_2248 var3 = var2.method_26204();
         return var3 instanceof class_2399 || var3 instanceof class_2541 || var3 instanceof class_3736 || var2.method_26164(class_3481.field_22414);
      } else {
         return false;
      }
   }

   private static List<PathNode> a(PathNode var0) {
      ArrayList var1 = new ArrayList();

      for (PathNode var2 = var0; var2 != null; var2 = var2.getParent()) {
         var1.add(var2);
      }

      Collections.reverse(var1);
      return var1;
   }
}
