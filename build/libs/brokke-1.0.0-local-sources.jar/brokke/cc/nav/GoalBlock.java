package brokke.cc.nav;

import net.minecraft.class_2338;

public class GoalBlock implements NavGoal {
   private final class_2338 target;

   public GoalBlock(class_2338 var1) {
      this.target = var1;
   }

   public class_2338 getTarget() {
      return this.target;
   }

   @Override
   public boolean a(class_2338 var1) {
      if (var1.equals(this.target)) {
         return true;
      } else {
         return var1.method_10263() == this.target.method_10263() && var1.method_10260() == this.target.method_10260() ? Math.abs(var1.method_10264() - this.target.method_10264()) <= 1 : false;
      }
   }

   @Override
   public double b(class_2338 var1) {
      double var2 = var1.method_10263() - this.target.method_10263();
      double var4 = var1.method_10260() - this.target.method_10260();
      double var6;
      if (Math.abs(var1.method_10264() - this.target.method_10264()) <= 1) {
         var6 = 0.0;
      } else if (var1.method_10264() > this.target.method_10264()) {
         var6 = var1.method_10264() - (this.target.method_10264() + 1);
      } else {
         var6 = this.target.method_10264() - var1.method_10264();
      }

      return Math.sqrt(var2 * var2 + var6 * var6 + var4 * var4);
   }

   @Override
   public boolean a() {
      return true;
   }

   @Override
   public double b() {
      return this.target.method_10263() + 0.5;
   }

   @Override
   public double c() {
      return this.target.method_10260() + 0.5;
   }
}
