package brokke.cc.nav;

import brokke.cc.core.MovementType;
import brokke.cc.module.movement.Baritone;
import brokke.cc.system.events.impl.EventMoveInput;
import java.util.List;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;

public class NavMovementController {
   private final class_310 mc = class_310.method_1551();
   private List<PathNode> currentPath;
   private int currentIndex;
   private boolean active;
   private boolean shouldForward;
   private boolean shouldJump;
   private boolean shouldSprint;
   private float strafe;
   private class_243 lastPos = class_243.field_1353;
   private int stuckTicks;
   private boolean stuck;
   private boolean surfacingForAir;
   private int lastIndex = -1;
   private int nodeTicks;
   private long pathSeed;
   private int sprintJumpCount;
   private int sprintJumpCooldown;
   private int microStrafeTimer;
   private int alignTicks;

   public void a(List<PathNode> var1) {
      this.currentPath = var1;
      this.currentIndex = 0;
      this.active = var1 != null && !var1.isEmpty();
      this.shouldForward = false;
      this.shouldJump = false;
      this.shouldSprint = false;
      this.strafe = 0.0F;
      this.alignTicks = 0;
      this.stuckTicks = 0;
      this.stuck = false;
      this.surfacingForAir = false;
      this.lastIndex = -1;
      this.nodeTicks = 0;
      if (!this.active || this.pathSeed == 0L) {
         this.pathSeed = System.nanoTime();
      }

      this.sprintJumpCount = 0;
      this.sprintJumpCooldown = 0;
      this.microStrafeTimer = 0;
      if (this.mc.field_1724 != null) {
         this.lastPos = this.mc.field_1724.method_73189();
      }
   }

   public void a() {
      this.active = false;
      this.currentPath = null;
      this.currentIndex = 0;
      this.shouldForward = false;
      this.shouldJump = false;
      this.shouldSprint = false;
      this.strafe = 0.0F;
      this.alignTicks = 0;
      this.stuckTicks = 0;
      this.stuck = false;
      this.surfacingForAir = false;
      this.lastIndex = -1;
      this.nodeTicks = 0;
      this.sprintJumpCount = 0;
      this.sprintJumpCooldown = 0;
      this.microStrafeTimer = 0;
   }

   public void a(NavRotationController var1) {
      if (this.active && this.mc.field_1724 != null && this.currentPath != null && this.currentIndex < this.currentPath.size()) {
         boolean var2 = this.mc.field_1724.method_5799();
         boolean var3 = this.c();
         boolean var4 = this.d();
         class_243 var5 = this.mc.field_1724.method_73189();
         double var6 = Math.hypot(var5.field_1352 - this.lastPos.field_1352, var5.field_1350 - this.lastPos.field_1350);
         double var8 = Math.abs(var5.field_1351 - this.lastPos.field_1351);
         double var10 = !var2 && !var3 ? var6 : Math.hypot(var6, var8);
         if (this.shouldForward && var10 < 0.04) {
            this.stuckTicks++;
            if (this.mc.field_1724.field_5976 && !var3 && !var4) {
               this.stuckTicks += 2;
            }

            if (this.stuckTicks > 35) {
               this.stuck = true;
            }
         } else {
            this.stuckTicks = 0;
            this.stuck = false;
         }

         this.lastPos = var5;
         if (this.currentIndex == this.lastIndex) {
            this.nodeTicks++;
            if (this.nodeTicks > 100 && var10 < 0.04) {
               this.stuck = true;
            }
         } else {
            this.nodeTicks = 0;
            this.lastIndex = this.currentIndex;
         }

         if (this.currentIndex < this.currentPath.size()) {
            PathNode var12 = this.currentPath.get(this.currentIndex);
            double var13 = var12.getPos().method_10264() + 0.1 - var5.field_1351;
            if (var13 > 1.25 && (this.mc.field_1724.method_24828() || var2) && this.stuckTicks > 10) {
               this.stuck = true;
            }
         }

         boolean var55 = this.mc.field_1724.method_5869();
         int var56 = this.mc.field_1724.method_5669();
         int var14 = Math.min(this.currentIndex + 8, this.currentPath.size());

         for (int var15 = var14 - 1; var15 > this.currentIndex; var15--) {
            PathNode var16 = this.currentPath.get(var15);
            class_2338 var17 = var16.getPos();
            double var18 = var17.method_10263() + 0.5 - var5.field_1352;
            double var20 = var17.method_10260() + 0.5 - var5.field_1350;
            double var22 = Math.hypot(var18, var20);
            double var24 = Math.abs(var17.method_10264() - var5.field_1351);
            class_243 var26 = new class_243(var17.method_10263() + 0.5, var17.method_10264() + 0.1, var17.method_10260() + 0.5);
            if (var22 < 1.35 && var24 < 1.35) {
               this.currentIndex = var15;
               break;
            }

            if (var22 < 2.4 && var24 < 1.35 && this.b(var5, var26)) {
               this.currentIndex = var15;
               break;
            }
         }

         while (this.currentIndex < this.currentPath.size()) {
            PathNode var57 = this.currentPath.get(this.currentIndex);
            class_2338 var59 = var57.getPos();
            boolean var60 = PathFinder.b(this.mc.field_1687, var59);
            double var62 = var59.method_10263() + 0.5 - var5.field_1352;
            double var66 = var59.method_10260() + 0.5 - var5.field_1350;
            double var69 = Math.hypot(var62, var66);
            double var71 = Math.abs(var59.method_10264() - var5.field_1351);
            boolean var72 = this.currentIndex == this.currentPath.size() - 1;
            boolean var27 = false;
            if (var2 && !var60) {
               if (!this.mc.field_1724.method_5799() || this.mc.field_1724.method_24828() && var5.field_1351 >= var59.method_10264() - 0.4) {
                  var27 = true;
               }
            } else if (var57.getType() == MovementType.JUMP_UP) {
               boolean var28 = PathFinder.g(this.mc.field_1687, var59.method_10074()) || PathFinder.g(this.mc.field_1687, var59);
               double var29 = var28 ? 0.65 : 0.2;
               if (var5.field_1351 >= var59.method_10264() - var29 && var69 < (var72 ? 0.35 : 1.4)) {
                  var27 = true;
               }
            } else if (var57.getType() == MovementType.FALL_DOWN) {
               if (var71 < 1.35 && var69 < (var72 ? 0.35 : 1.5) && this.mc.field_1724.method_24828()) {
                  var27 = true;
               }
            } else {
               boolean var74 = this.a(var59);
               if (var72) {
                  class_2338 var78 = class_2338.method_49637(var5.field_1352, var5.field_1351, var5.field_1350);
                  if (var59.equals(var78) || var69 < 0.45 && var71 < 1.2) {
                     var27 = true;
                  }
               } else {
                  double var79 = var2 && var60 ? 1.5 : (var74 ? 0.85 : 1.35);
                  if (var69 < var79 && var71 < 1.5) {
                     var27 = true;
                  } else if (this.currentIndex + 1 < this.currentPath.size()) {
                     PathNode var31 = this.currentPath.get(this.currentIndex + 1);
                     double var32 = var31.getPos().method_10263() + 0.5 - var5.field_1352;
                     double var34 = var31.getPos().method_10260() + 0.5 - var5.field_1350;
                     double var36 = Math.hypot(var32, var34);
                     double var38 = Math.abs(var31.getPos().method_10264() - var5.field_1351);
                     double var40 = var31.getPos().method_10263() + 0.5 - (var59.method_10263() + 0.5);
                     double var42 = var31.getPos().method_10260() + 0.5 - (var59.method_10260() + 0.5);
                     double var44 = Math.hypot(var40, var42);
                     double var46 = var5.field_1352 - (var59.method_10263() + 0.5);
                     double var48 = var5.field_1350 - (var59.method_10260() + 0.5);
                     double var50 = var46 * var40 + var48 * var42;
                     double var52 = var44 > 0.01 ? Math.abs(var46 * var42 - var48 * var40) / var44 : 0.0;
                     class_243 var54 = new class_243(var31.getPos().method_10263() + 0.5, var31.getPos().method_10264() + 0.1, var31.getPos().method_10260() + 0.5);
                     if ((var57.getType() != MovementType.JUMP_UP || var5.field_1351 >= var59.method_10264() - 0.2)
                        && (var50 > 0.0 && var52 < 0.85 || var36 < var69)
                        && var69 < 2.5
                        && var71 < 1.5
                        && var38 < 1.5
                        && this.b(var5, var54)) {
                        var27 = true;
                     }
                  }
               }
            }

            if (!var27) {
               break;
            }

            this.currentIndex++;
         }

         if (this.currentIndex >= this.currentPath.size()) {
            this.active = false;
            this.shouldForward = false;
            this.shouldJump = false;
            this.shouldSprint = false;
            if (var1 != null) {
               var1.b();
            }
         } else {
            double var58 = Double.MAX_VALUE;
            int var61 = Math.min(this.currentIndex + 6, this.currentPath.size());

            for (int var63 = this.currentIndex; var63 < var61; var63++) {
               PathNode var19 = this.currentPath.get(var63);
               double var67 = Math.hypot(var19.getPos().method_10263() + 0.5 - var5.field_1352, var19.getPos().method_10260() + 0.5 - var5.field_1350);
               double var70 = Math.abs(var19.getPos().method_10264() - var5.field_1351);
               if (var70 < 1.5 && var67 < var58) {
                  var58 = var67;
               }
            }

            if (var58 > 2.8 && !var3 && !var2 && this.mc.field_1724.method_24828()) {
               this.stuck = true;
            }

            PathNode var64 = this.currentPath.get(this.currentIndex);
            class_2338 var65 = var64.getPos();
            class_243 var68 = new class_243(var65.method_10263() + 0.5, var65.method_10264(), var65.method_10260() + 0.5);
            double var21 = var68.field_1352 - var5.field_1352;
            double var23 = var68.field_1350 - var5.field_1350;
            double var25 = Math.hypot(var21, var23);
            if (var2 && var55 && var56 <= 110) {
               this.surfacingForAir = true;
            } else if (!var2 || var56 >= 270) {
               this.surfacingForAir = false;
            }

            float var73 = 0.0F;
            if (var1 != null) {
               class_243 var75 = this.a(var5);
               var1.a(var75);
               if (this.surfacingForAir && var55) {
                  float var80 = var1.getTargetPitch();
                  if (var80 > -18.0F) {
                     var1.a(var1.getTargetYaw(), -18.0F);
                  }
               }

               var1.a();
               float var81 = var1.getTargetYaw();
               float var30 = var1.f();
               var73 = Math.abs(class_3532.method_15393(var81 - var30));
               if (var73 > 105.0F) {
                  this.shouldForward = false;
                  this.shouldSprint = false;
                  this.alignTicks = 0;
               } else {
                  this.shouldForward = true;
                  this.alignTicks++;
                  boolean var84 = Baritone.INSTANCE == null || Baritone.INSTANCE.sprint.isEnabled();
                  boolean var87 = this.mc.field_1724.method_7344().method_7586() > 6;
                  this.shouldSprint = var84 && var87 && !var3 && var73 < 65.0F;
               }
            } else {
               this.shouldForward = true;
               boolean var76 = Baritone.INSTANCE == null || Baritone.INSTANCE.sprint.isEnabled();
               boolean var82 = this.mc.field_1724.method_7344().method_7586() > 6;
               this.shouldSprint = var76 && var82 && !var3;
            }

            if (var3) {
               this.shouldSprint = false;
               if (this.mc.field_1724.method_5624()) {
                  this.mc.field_1724.method_5728(false);
               }
            }

            this.microStrafeTimer++;
            this.strafe = 0.0F;
            boolean var77 = Baritone.INSTANCE == null || Baritone.INSTANCE.autoJump.isEnabled();
            this.shouldJump = false;
            double var83 = var68.field_1351 - var5.field_1351;
            if (!var4 && !var3 && var77 && this.mc.field_1724.method_24828()) {
               if (var64.getType() == MovementType.JUMP_UP && var25 < 1.65 && var83 > 0.1 && var83 <= 1.35 && var73 < 65.0F) {
                  this.shouldJump = true;
                  this.shouldForward = true;
               } else if (this.currentIndex + 1 < this.currentPath.size() && this.currentPath.get(this.currentIndex + 1).getType() == MovementType.JUMP_UP) {
                  PathNode var85 = this.currentPath.get(this.currentIndex + 1);
                  double var88 = Math.hypot(var85.getPos().method_10263() + 0.5 - var5.field_1352, var85.getPos().method_10260() + 0.5 - var5.field_1350);
                  double var93 = var85.getPos().method_10264() - var5.field_1351;
                  if (var88 < 1.5 && var93 > 0.1 && var93 <= 1.35 && var73 < 65.0F) {
                     this.shouldJump = true;
                     this.shouldForward = true;
                  }
               }
            }

            if (!var2 && !this.mc.field_1724.method_24828() && (var64.getType() == MovementType.JUMP_UP || var83 > 0.15)) {
               this.shouldForward = true;
            }

            boolean var86 = PathFinder.b(this.mc.field_1687, var64.getPos());
            if (var2) {
               this.shouldForward = true;
               double var89 = var68.field_1351 - var5.field_1351;
               class_2338 var94 = this.mc.field_1724.method_24515();
               int var35 = Integer.compare(var65.method_10263(), var94.method_10263());
               int var99 = Integer.compare(var65.method_10260(), var94.method_10260());
               class_2338 var37 = var35 == 0 && var99 == 0 ? var94.method_10093(this.mc.field_1724.method_5735()) : var94.method_10069(var35, 0, var99);
               boolean var104 = PathFinder.d(this.mc.field_1687, var37.method_10086(1))
                  && PathFinder.d(this.mc.field_1687, var37.method_10086(2))
                  && PathFinder.d(this.mc.field_1687, var94.method_10086(2));
               if (var35 != 0 && var99 != 0) {
                  var104 = var104 && PathFinder.d(this.mc.field_1687, var94.method_10069(var35, 1, 0)) && PathFinder.d(this.mc.field_1687, var94.method_10069(0, 1, var99));
               }

               if (!var86) {
                  this.shouldSprint = false;
                  this.mc.field_1724.method_5728(false);
                  if (var89 > 0.1 && var89 <= 1.25 && var25 < 1.35 && var104 && var77) {
                     this.shouldJump = true;
                  }
               } else {
                  if (Baritone.INSTANCE == null || Baritone.INSTANCE.sprint.isEnabled()) {
                     this.shouldSprint = true;
                  }

                  if (this.surfacingForAir && var55) {
                     if (var77) {
                        this.shouldJump = true;
                     }
                  } else if (var89 > 0.4 && var89 <= 1.25 && var104) {
                     if (var77) {
                        this.shouldJump = true;
                     }
                  } else if (this.mc.field_1724.field_5976 && var104) {
                     if (var77) {
                        this.shouldJump = true;
                     }
                  } else if (this.mc.field_1724.method_24828() && var89 > 0.0 && var89 <= 1.25 && var104 && var77) {
                     this.shouldJump = true;
                  }
               }
            }

            if (!var2 && !var4 && !var3 && this.mc.field_1724.field_5976 && var77 && this.mc.field_1724.method_24828()) {
               class_2338 var90 = this.mc.field_1724.method_24515();
               int var33 = Integer.compare(var65.method_10263(), var90.method_10263());
               int var95 = Integer.compare(var65.method_10260(), var90.method_10260());
               class_2350 var97 = this.mc.field_1724.method_5735();
               class_2338[] var100 = new class_2338[]{
                  var33 == 0 && var95 == 0 ? var90.method_10093(var97) : var90.method_10069(var33, 0, var95),
                  var33 != 0 ? var90.method_10069(var33, 0, 0) : var90.method_10093(var97),
                  var95 != 0 ? var90.method_10069(0, 0, var95) : var90.method_10093(var97),
                  var90.method_10093(var97)
               };

               for (class_2338 var107 : var100) {
                  if (!PathFinder.g(this.mc.field_1687, var107)
                     && !PathFinder.g(this.mc.field_1687, var107.method_10074())
                     && !PathFinder.h(this.mc.field_1687, var107)
                     && !PathFinder.h(this.mc.field_1687, var107.method_10074())
                     && !PathFinder.d(this.mc.field_1687, var107)
                     && PathFinder.d(this.mc.field_1687, var107.method_10086(1))
                     && PathFinder.d(this.mc.field_1687, var107.method_10086(2))
                     && PathFinder.d(this.mc.field_1687, var90.method_10086(2))) {
                     this.shouldJump = true;
                     this.shouldForward = true;
                     break;
                  }
               }
            }

            if (this.stuckTicks > 8 && var2 && var77) {
               double var91 = var68.field_1351 - var5.field_1351;
               class_2338 var96 = this.mc.field_1724.method_24515();
               int var98 = Integer.compare(var65.method_10263(), var96.method_10263());
               int var101 = Integer.compare(var65.method_10260(), var96.method_10260());
               class_2338 var103 = var98 == 0 && var101 == 0 ? var96.method_10093(this.mc.field_1724.method_5735()) : var96.method_10069(var98, 0, var101);
               boolean var106 = PathFinder.d(this.mc.field_1687, var103.method_10086(1))
                  && PathFinder.d(this.mc.field_1687, var103.method_10086(2))
                  && PathFinder.d(this.mc.field_1687, var96.method_10086(2));
               if (var98 != 0 && var101 != 0) {
                  var106 = var106 && PathFinder.d(this.mc.field_1687, var96.method_10069(var98, 1, 0)) && PathFinder.d(this.mc.field_1687, var96.method_10069(0, 1, var101));
               }

               if (var91 <= 1.25 && var106) {
                  this.shouldJump = true;
                  if (!var86) {
                     this.shouldSprint = false;
                     this.mc.field_1724.method_5728(false);
                     this.shouldForward = true;
                  }
               }
            }

            boolean var92 = this.mc.field_1724.method_6059(class_1294.field_5904);
            if (!var92
               && var77
               && !var2
               && !var4
               && !var3
               && this.shouldForward
               && this.shouldSprint
               && this.mc.field_1724.method_24828()
               && var64.getType() != MovementType.FALL_DOWN) {
               this.shouldJump = true;
            }

            if (var4 || var3) {
               this.shouldJump = false;
            }
         }
      } else {
         this.shouldForward = false;
         this.shouldJump = false;
         this.shouldSprint = false;
         if (var1 != null) {
            var1.b();
         }
      }
   }

   private boolean a(class_243 var1, class_243 var2) {
      if (this.mc.field_1687 == null) {
         return false;
      }

      class_3965 var3 = this.mc.field_1687.method_17742(new class_3959(var1, var2, class_3960.field_17558, class_242.field_1348, this.mc.field_1724));
      return var3 == null || var3.method_17783() == class_240.field_1333;
   }

   private boolean a(class_2338 var1) {
      return this.mc.field_1687 != null && var1 != null ? PathFinder.f(this.mc.field_1687, var1) : false;
   }

   private boolean b(class_243 var1, class_243 var2) {
      if (this.mc.field_1687 == null) {
         return false;
      }

      double var3 = var2.field_1352 - var1.field_1352;
      double var5 = var2.field_1350 - var1.field_1350;
      double var7 = Math.hypot(var3, var5);
      if (var7 < 0.5) {
         return true;
      }

      int var9 = (int)Math.ceil(var7 / 0.4);

      for (int var10 = 1; var10 <= var9; var10++) {
         double var11 = (double)var10 / var9;
         double var13 = var1.field_1352 + var3 * var11;
         double var15 = var1.field_1350 + var5 * var11;
         double var17 = var1.field_1351 + (var2.field_1351 - var1.field_1351) * var11;
         class_2338 var19 = class_2338.method_49637(var13, var17, var15);
         if (!PathFinder.d(this.mc.field_1687, var19)) {
            if (!PathFinder.g(this.mc.field_1687, var19) || !PathFinder.d(this.mc.field_1687, var19.method_10086(1)) || !PathFinder.d(this.mc.field_1687, var19.method_10086(2))) {
               return false;
            }
         } else if (!PathFinder.d(this.mc.field_1687, var19.method_10084())) {
            return false;
         }

         if (!PathFinder.e(this.mc.field_1687, var19.method_10087(1))
            && !PathFinder.e(this.mc.field_1687, var19.method_10087(2))
            && !PathFinder.e(this.mc.field_1687, var19.method_10087(3))
            && !PathFinder.h(this.mc.field_1687, var19)
            && !PathFinder.h(this.mc.field_1687, var19.method_10087(1))
            && !PathFinder.b(this.mc.field_1687, var19)
            && !PathFinder.b(this.mc.field_1687, var19.method_10087(1))) {
            return false;
         }
      }

      return true;
   }

   private class_243 a(class_243 var1) {
      if (this.currentPath != null && !this.currentPath.isEmpty() && this.currentIndex < this.currentPath.size()) {
         PathNode var2 = this.currentPath.get(this.currentIndex);
         class_2338 var3 = var2.getPos();
         boolean var4 = this.mc.field_1724 != null && this.mc.field_1724.method_5799();
         double var5 = var4 ? 0.5 : 1.5;
         if (!this.c() && !PathFinder.h(this.mc.field_1687, var3)) {
            if (this.currentIndex == this.currentPath.size() - 1) {
               return new class_243(var3.method_10263() + 0.5, var3.method_10264() + var5, var3.method_10260() + 0.5);
            }

            if (var2.getType() == MovementType.JUMP_UP) {
               return new class_243(var3.method_10263() + 0.5, var3.method_10264() + 1.2, var3.method_10260() + 0.5);
            }

            if (this.a(var3)) {
               if (this.currentIndex + 1 < this.currentPath.size()) {
                  PathNode var26 = this.currentPath.get(this.currentIndex + 1);
                  double var8 = var3.method_10263() + 0.5 - var1.field_1352;
                  double var28 = var3.method_10260() + 0.5 - var1.field_1350;
                  double var30 = Math.hypot(var8, var28);
                  if (var30 < 1.0) {
                     double var31 = class_3532.method_15350(1.0 - var30, 0.0, 1.0);
                     double var34 = (var3.method_10263() + 0.5) * (1.0 - var31) + (var26.getPos().method_10263() + 0.5) * var31;
                     double var36 = (var3.method_10264() + var5) * (1.0 - var31) + (var26.getPos().method_10264() + var5) * var31;
                     double var38 = (var3.method_10260() + 0.5) * (1.0 - var31) + (var26.getPos().method_10260() + 0.5) * var31;
                     return new class_243(var34, var36, var38);
                  }
               }

               return new class_243(var3.method_10263() + 0.5, var3.method_10264() + var5, var3.method_10260() + 0.5);
            } else {
               double var7 = 0.0;
               if (this.currentIndex + 1 < this.currentPath.size()) {
                  PathNode var9 = this.currentPath.get(this.currentIndex + 1);
                  double var10 = var9.getPos().method_10263() + 0.5 - (var3.method_10263() + 0.5);
                  double var12 = var9.getPos().method_10260() + 0.5 - (var3.method_10260() + 0.5);
                  double var14 = var10 * var10 + var12 * var12;
                  if (var14 > 0.01) {
                     double var16 = var1.field_1352 - (var3.method_10263() + 0.5);
                     double var18 = var1.field_1350 - (var3.method_10260() + 0.5);
                     var7 = class_3532.method_15350((var16 * var10 + var18 * var12) / var14, 0.0, 1.0);
                  }
               }

               double var27 = this.currentIndex + var7;
               class_243 var11 = this.mc.field_1724 != null ? this.mc.field_1724.method_33571() : var1.method_1031(0.0, 1.6, 0.0);
               class_243 var29 = var1.method_1031(0.0, 0.8, 0.0);
               if (var4 && !PathFinder.b(this.mc.field_1687, var3)) {
                  return new class_243(var3.method_10263() + 0.5, var3.method_10264() + 0.8, var3.method_10260() + 0.5);
               }

               double var13 = 2.2;

               for (double var15 = var13; var15 >= 0.5; var15 -= 0.5) {
                  double var35 = Math.min(var27 + var15, this.currentPath.size() - 1);
                  class_243 var37 = PathCurve.a(this.currentPath, var35, this.mc.field_1687, this.pathSeed);
                  class_243 var20 = var37.method_1031(0.0, var5, 0.0);
                  class_243 var40 = var37.method_1031(0.0, var4 ? 0.3 : 0.8, 0.0);
                  if (this.a(var11, var20) && this.a(var29, var40) && (var4 || this.b(var1, var37))) {
                     return var20;
                  }
               }

               int var32 = Math.min(this.currentIndex + 1, this.currentPath.size() - 1);
               class_2338 var33 = this.currentPath.get(var32).getPos();
               double var17 = var33.method_10263() + 0.5 - var1.field_1352;
               double var19 = var33.method_10260() + 0.5 - var1.field_1350;
               if (var32 + 1 < this.currentPath.size()) {
                  PathNode var21 = this.currentPath.get(var32 + 1);
                  double var22 = var21.getPos().method_10263() + 0.5 - (var33.method_10263() + 0.5);
                  double var24 = var21.getPos().method_10260() + 0.5 - (var33.method_10260() + 0.5);
                  if (var17 * var22 + var19 * var24 < 0.0) {
                     var33 = this.currentPath.get(++var32).getPos();
                  }
               }

               double var39 = var4 && PathFinder.b(this.mc.field_1687, var33) ? 0.5 : 1.5;
               return PathCurve.a(this.currentPath, var32, this.mc.field_1687, this.pathSeed).method_1031(0.0, var39, 0.0);
            }
         } else {
            return new class_243(var3.method_10263() + 0.5, var3.method_10264() + 1.2, var3.method_10260() + 0.5);
         }
      } else {
         return var1.method_1031(0.0, 1.5, 0.0);
      }
   }

   public class_2338 b() {
      if (this.mc.field_1724 == null) {
         return null;
      }

      class_2338 var1 = this.mc.field_1724.method_24515();
      if (this.currentPath != null && this.currentIndex < this.currentPath.size()) {
         class_2338 var2 = this.currentPath.get(this.currentIndex).getPos();
         int var3 = Integer.compare(var2.method_10263(), var1.method_10263());
         int var4 = Integer.compare(var2.method_10260(), var1.method_10260());
         if (var3 != 0 || var4 != 0) {
            class_2338 var5 = var1.method_10069(var3, 0, var4);
            if (this.mc.field_1687 != null && !PathFinder.d(this.mc.field_1687, var5)) {
               return var5;
            }

            class_2338 var6 = var5.method_10084();
            if (this.mc.field_1687 != null && !PathFinder.d(this.mc.field_1687, var6)) {
               return var6;
            }

            class_2338 var7 = var1.method_10069(var3, 0, 0);
            if (this.mc.field_1687 != null && !PathFinder.d(this.mc.field_1687, var7)) {
               return var7;
            }

            class_2338 var8 = var1.method_10069(0, 0, var4);
            return this.mc.field_1687 != null && !PathFinder.d(this.mc.field_1687, var8) ? var8 : var5;
         }
      }

      return this.mc.field_1724.field_5976 ? var1.method_10093(this.mc.field_1724.method_5735()) : var1;
   }

   public void a(EventMoveInput var1) {
      if (this.active && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (this.c()) {
            var1.setSprint(false);
            var1.setJump(false);
            var1.setSneak(false);
            var1.setForward(1.0F);
            var1.setStrafe(0.0F);
         } else {
            if (this.shouldForward) {
               var1.setForward(1.0F);
            } else {
               var1.setForward(0.0F);
            }

            if (this.strafe != 0.0F) {
               var1.setStrafe(this.strafe);
            }

            boolean var2 = this.d();
            if (this.shouldJump && !var2) {
               var1.setJump(true);
            }

            if (this.shouldSprint) {
               var1.setSprint(true);
            } else {
               var1.setSprint(false);
            }

            if (!var2
               && this.mc.field_1724.method_24828()
               && !this.mc.field_1724.method_5799()
               && this.currentPath != null
               && this.currentIndex < this.currentPath.size()) {
               PathNode var3 = this.currentPath.get(this.currentIndex);
               if (var3.getType() != MovementType.FALL_DOWN && var3.getType() != MovementType.JUMP_UP) {
                  float var4 = this.mc.field_1724.method_36454();
                  NavRotationController var5 = NavigationManager.getInstance().getRotationController();
                  if (var5 != null && var5.isActive()) {
                     var4 = var5.f();
                  }

                  if (var1.getForward() != 0.0F || var1.getStrafe() != 0.0F) {
                     if (var1.getForward() == 0.0F) {
                        var4 += var1.getStrafe() > 0.0F ? -90.0F : 90.0F;
                     } else if (var1.getForward() < 0.0F) {
                        var4 += 180.0F;
                        if (var1.getStrafe() != 0.0F) {
                           var4 += var1.getStrafe() > 0.0F ? 45.0F : -45.0F;
                        }
                     } else if (var1.getStrafe() != 0.0F) {
                        var4 += var1.getStrafe() > 0.0F ? -45.0F : 45.0F;
                     }

                     double var6 = Math.toRadians(var4);
                     double var8 = -Math.sin(var6);
                     double var10 = Math.cos(var6);
                     class_243 var12 = this.mc.field_1724.method_73189();
                     class_2338 var13 = class_2338.method_49637(var12.field_1352 + var8 * 0.5, var12.field_1351, var12.field_1350 + var10 * 0.5);
                     boolean var14 = PathFinder.e(this.mc.field_1687, var13)
                        || PathFinder.e(this.mc.field_1687, var13.method_10087(1))
                        || PathFinder.e(this.mc.field_1687, var13.method_10087(2))
                        || PathFinder.e(this.mc.field_1687, var13.method_10087(3))
                        || PathFinder.g(this.mc.field_1687, var13)
                        || PathFinder.g(this.mc.field_1687, var13.method_10087(1))
                        || PathFinder.h(this.mc.field_1687, var13)
                        || PathFinder.h(this.mc.field_1687, var13.method_10087(1))
                        || PathFinder.b(this.mc.field_1687, var13)
                        || PathFinder.b(this.mc.field_1687, var13.method_10087(1))
                        || PathFinder.b(this.mc.field_1687, var13.method_10087(2))
                        || PathFinder.b(this.mc.field_1687, var13.method_10087(3));
                     if (!var14) {
                        var1.setSneak(true);
                        var1.setSprint(false);
                        var1.setJump(false);
                        var1.setForward(0.0F);
                        if (this.mc.field_1724.method_5624()) {
                           this.mc.field_1724.method_5728(false);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public boolean c() {
      if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
         return false;
      }

      if (this.mc.field_1724.method_6101()) {
         return true;
      }

      class_2338 var1 = this.mc.field_1724.method_24515();
      class_2338 var2 = class_2338.method_49637(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
      return PathFinder.h(this.mc.field_1687, var1)
         || PathFinder.h(this.mc.field_1687, var1.method_10084())
         || PathFinder.h(this.mc.field_1687, var2)
         || PathFinder.h(this.mc.field_1687, var2.method_10084());
   }

   public boolean d() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_238 var1 = this.mc.field_1724.method_5829().method_1009(0.2, 0.4, 0.2);
         int var2 = class_3532.method_15357(var1.field_1323);
         int var3 = class_3532.method_15357(var1.field_1320);
         int var4 = class_3532.method_15357(var1.field_1322 - 0.6);
         int var5 = class_3532.method_15357(var1.field_1325);
         int var6 = class_3532.method_15357(var1.field_1321);
         int var7 = class_3532.method_15357(var1.field_1324);

         for (int var8 = var2; var8 <= var3; var8++) {
            for (int var9 = var4; var9 <= var5; var9++) {
               for (int var10 = var6; var10 <= var7; var10++) {
                  class_2338 var11 = new class_2338(var8, var9, var10);
                  if (PathFinder.g(this.mc.field_1687, var11)) {
                     return true;
                  }
               }
            }
         }

         float var20 = this.mc.field_1724.method_36454();
         NavRotationController var21 = NavigationManager.getInstance().getRotationController();
         if (var21 != null && var21.isActive()) {
            var20 = var21.f();
         }

         double var22 = Math.toRadians(var20);
         double var12 = -Math.sin(var22) * 0.7;
         double var14 = Math.cos(var22) * 0.7;
         class_243 var16 = this.mc.field_1724.method_73189();

         for (double var17 = -0.5; var17 <= 1.0; var17 += 0.5) {
            class_2338 var19 = class_2338.method_49637(var16.field_1352 + var12, var16.field_1351 + var17, var16.field_1350 + var14);
            if (PathFinder.g(this.mc.field_1687, var19)) {
               return true;
            }
         }

         if (this.currentPath != null && this.currentIndex < this.currentPath.size()) {
            class_2338 var23 = this.currentPath.get(this.currentIndex).getPos();
            if (PathFinder.g(this.mc.field_1687, var23) || PathFinder.g(this.mc.field_1687, var23.method_10074())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean isStuck() {
      return this.stuck;
   }

   public void g() {
      this.stuck = false;
      this.stuckTicks = 0;
      this.nodeTicks = 0;
   }

   public int getCurrentIndex() {
      return this.currentIndex;
   }

   public PathNode i() {
      return this.currentPath != null && this.currentIndex >= 0 && this.currentIndex < this.currentPath.size() ? this.currentPath.get(this.currentIndex) : null;
   }

   public List<PathNode> getCurrentPath() {
      return this.currentPath;
   }
}
