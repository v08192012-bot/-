package brokke.cc.nav;

import brokke.cc.rotation.Rotation2;
import brokke.cc.rotation.RotationStorage;
import brokke.cc.util.GCDUtil2;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class NavRotationController {
   private final class_310 mc = class_310.method_1551();
   private float targetYaw;
   private float targetPitch;
   private float currentYaw;
   private float currentPitch;
   private float velYaw;
   private float velPitch;
   private boolean active;
   private boolean initialized;
   private int rotTicks;

   public void a(class_243 var1) {
      if (this.mc.field_1724 != null && var1 != null) {
         class_243 var2 = this.mc.field_1724.method_33571();
         double var3 = var1.field_1352 - var2.field_1352;
         double var5 = var1.field_1351 - var2.field_1351;
         double var7 = var1.field_1350 - var2.field_1350;
         double var9 = Math.hypot(var3, var7);
         float var11 = var9 > 0.15 ? (float)Math.toDegrees(Math.atan2(var7, var3)) - 90.0F : (this.initialized ? this.currentYaw : this.targetYaw);
         float var12 = (float)(-Math.toDegrees(Math.atan2(var5, Math.max(var9, 0.001))));
         this.a(var11, var12);
      }
   }

   public void a(float var1, float var2) {
      this.targetYaw = class_3532.method_15393(var1);
      this.targetPitch = class_3532.method_15363(var2, -89.0F, 89.0F);
      this.active = true;
   }

   public void a() {
      if (this.active && this.mc.field_1724 != null) {
         this.rotTicks++;
         if (!this.initialized) {
            this.currentYaw = this.mc.field_1724.method_36454();
            this.currentPitch = this.mc.field_1724.method_36455();
            this.velYaw = 0.0F;
            this.velPitch = 0.0F;
            this.initialized = true;
         }

         float var1 = class_3532.method_15393(this.targetYaw - this.currentYaw);
         float var2 = this.targetPitch - this.currentPitch;
         float var3 = (float)Math.hypot(var1, var2);
         if (var3 < 0.1F) {
            this.currentYaw = this.targetYaw;
            this.currentPitch = this.targetPitch;
            this.velYaw = 0.0F;
            this.velPitch = 0.0F;
            this.mc.field_1724.method_36456(this.currentYaw);
            this.mc.field_1724.method_36457(this.currentPitch);
         } else {
            float var4 = var1 / var3;
            float var5 = var2 / var3;
            float var6;
            if (var3 > 80.0F) {
               var6 = Math.min(var3 * 0.9F, 105.0F);
            } else if (var3 > 35.0F) {
               var6 = Math.min(var3 * 0.8F, 75.0F);
            } else if (var3 > 12.0F) {
               var6 = var3 * 0.65F;
            } else {
               var6 = Math.max(2.5F, var3 * 0.5F);
            }

            float var7 = var4 * Math.min(var6, Math.abs(var1));
            float var8 = var5 * Math.min(var6, Math.abs(var2));
            float var9 = GCDUtil2.a(var7);
            float var10 = GCDUtil2.a(var8);
            if (Math.abs(var9) > Math.abs(var1)) {
               var9 = GCDUtil2.a(var1);
            }

            if (Math.abs(var10) > Math.abs(var2)) {
               var10 = GCDUtil2.a(var2);
            }

            this.currentYaw += var9;
            this.currentPitch = class_3532.method_15363(this.currentPitch + var10, -89.0F, 89.0F);
            this.mc.field_1724.method_36456(this.currentYaw);
            this.mc.field_1724.method_36457(this.currentPitch);
            RotationStorage.a(new Rotation2(this.currentYaw, this.currentPitch), 360.0F, 360.0F, 360.0F, 360.0F, 2, 1, true);
         }
      }
   }

   public void a(float var1) {
      this.a();
   }

   public void b() {
      this.active = false;
      this.initialized = false;
      this.velYaw = 0.0F;
      this.velPitch = 0.0F;
      this.rotTicks = 0;
      if (RotationStorage.instance != null && RotationStorage.instance.k()) {
         RotationStorage.a().j();
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public float getTargetYaw() {
      return this.targetYaw;
   }

   public float getTargetPitch() {
      return this.targetPitch;
   }

   public float f() {
      return this.initialized ? this.currentYaw : (this.mc.field_1724 != null ? this.mc.field_1724.method_36454() : this.targetYaw);
   }

   public float g() {
      return this.initialized ? this.currentPitch : (this.mc.field_1724 != null ? this.mc.field_1724.method_36455() : this.targetPitch);
   }
}
