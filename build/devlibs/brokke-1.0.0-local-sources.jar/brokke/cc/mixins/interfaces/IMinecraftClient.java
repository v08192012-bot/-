package brokke.cc.mixins.interfaces;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface IMinecraftClient {
   @Accessor("itemUseCooldown")
   void setItemUseCooldown(int var1);

   @Mutable
   @Accessor("session")
   void setSession(Session var1);
}
