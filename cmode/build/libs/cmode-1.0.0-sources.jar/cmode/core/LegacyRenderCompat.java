package cmode.core;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.util.function.Consumer;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_11661;
import net.minecraft.class_11684;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_4618;
import net.minecraft.class_898;
import net.minecraft.class_9799;

public final class LegacyRenderCompat {
   private LegacyRenderCompat() {
   }

   public static void a(
      class_898 var0, class_1297 var1, float var2, double var3, double var5, double var7, class_4587 var9, class_4597 var10
   ) {
      class_10017 var11 = var0.method_72977(var1, var2);
      var11.field_61822 = 0.0F;
      a(
         var10,
         var9xx -> var0.method_72976(var11, class_310.method_1551().field_1773.method_72912().field_63082, var3, var5, var7, var9, var9xx)
      );
   }

   public static void a(class_4597 var0, Consumer<class_11659> var1) {
      class_310 var2 = class_310.method_1551();
      class_11661 var3 = new class_11661();
      LegacyRenderCompat.a var4 = var0 instanceof class_4598 var5 ? null : new LegacyRenderCompat.a(var0);
      class_4598 var10 = var4 == null ? (class_4598)var0 : var4;
      class_11684 var6 = new class_11684(
         var3, var2.method_1541(), var10, var2.method_72703(), new class_4618(), var10, var2.field_1772
      );

      try {
         var1.accept(var3);
         var6.method_73002();
         var6.method_74817();
      } finally {
         var6.close();
         if (var4 != null) {
            var4.a();
         }
      }
   }

   static final class a extends class_4598 {
      private final class_4597 delegate;

      a(class_4597 var1) {
         super(new class_9799(256), new Object2ObjectLinkedOpenHashMap());
         this.delegate = var1;
      }

      @Override
      public class_4588 method_73477(class_1921 layer) {
         return this.delegate.method_73477(layer);
      }

      @Override
      public void method_37104() {
      }

      @Override
      public void method_22993() {
      }

      @Override
      public void method_22994(class_1921 layer) {
      }

      void a() {
         this.field_52156.close();
      }
   }
}
