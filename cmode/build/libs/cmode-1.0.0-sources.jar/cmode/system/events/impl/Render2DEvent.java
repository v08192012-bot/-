package cmode.system.events.impl;

import cmode.system.events.Event;
import net.minecraft.class_9779;

public class Render2DEvent extends Event {
   public static final Render2DEvent INSTANCE = new Render2DEvent(null);
   private class_9779 tickCounter;

   public Render2DEvent(class_9779 var1) {
      this.tickCounter = var1;
   }

   public static Render2DEvent get(class_9779 var0) {
      INSTANCE.setCancelled(false);
      INSTANCE.tickCounter = var0;
      return INSTANCE;
   }

   public class_9779 getTickCounter() {
      return this.tickCounter;
   }

   public void setTickCounter(class_9779 var1) {
      this.tickCounter = var1;
   }
}
