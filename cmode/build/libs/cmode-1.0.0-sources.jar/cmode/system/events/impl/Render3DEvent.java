package cmode.system.events.impl;

import cmode.system.events.Event;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public class Render3DEvent extends Event {
   private final class_4587 matrices;
   private final float tickDelta;
   private final class_4184 camera;

   public Render3DEvent(class_4587 var1, float var2, class_4184 var3) {
      this.matrices = var1;
      this.tickDelta = var2;
      this.camera = var3;
   }

   public class_4587 getMatrices() {
      return this.matrices;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public class_4184 getCamera() {
      return this.camera;
   }
}
