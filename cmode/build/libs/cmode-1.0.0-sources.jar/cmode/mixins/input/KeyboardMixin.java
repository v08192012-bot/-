package cmode.mixins.input;

import cmode.ui.ClickGui;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin {
   @Inject(method = "onKey(JILnet/minecraft/client/input/KeyInput;)V", at = @At("HEAD"), cancellable = true)
   private void cmodeOnKey(long var1, int var3, class_11908 var4, CallbackInfo var5) {
      class_310 var6 = class_310.method_1551();
      if (var3 == 1 && var4.comp_4795() == GLFW.GLFW_KEY_SLASH && var6.field_1755 == null) {
         var6.method_1507(ClickGui.INSTANCE);
         var5.cancel();
      }
   }
}
