package cmode.mixins.network;

import cmode.manager.CommandManager;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {
   @Inject(method = "sendChatMessage(Ljava/lang/String;)V", at = @At("HEAD"), cancellable = true)
   private void cmodeOnSendChatMessage(String var1, CallbackInfo var2) {
      if (CommandManager.handle(var1)) {
         var2.cancel();
      }
   }
}
