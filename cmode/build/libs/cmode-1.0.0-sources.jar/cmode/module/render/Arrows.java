package cmode.module.render;

import cmode.manager.FriendManager;
import cmode.module.Category;
import cmode.module.Function;
import cmode.module.NewFunction;
import cmode.render.RenderUtil;
import cmode.render.TexturePipeline;
import cmode.setting.BooleanSetting;
import cmode.setting.NumberSetting;
import cmode.system.events.EventHandler;
import cmode.system.events.EventPriority;
import cmode.system.events.impl.Render2DEvent;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import net.minecraft.class_1044;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import org.joml.Matrix4f;

@NewFunction(name = "Arrows", description = "Зелёные стрелки, указывающие направление на друзей", category = Category.RENDER)
public class Arrows extends Function {
   private static final class_2960 POINTER_TEX = class_2960.method_60655("cmode", "textures/pointer.png");
   private static final Color FRIEND_COLOR = new Color(85, 255, 85);
   private final NumberSetting arrowSize = new NumberSetting("Размер стрелки", 7.0, 5.0, 15.0, 1.0);
   private final NumberSetting centerOffset = new NumberSetting("Отступ от центра", 30.0, 20.0, 50.0, 1.0);
   private final BooleanSetting glow = new BooleanSetting("Свечение", true);
   private float smoothedYaw;
   private long lastFrameTime = System.currentTimeMillis();

   public Arrows() {
      this.addSettings(this.arrowSize, this.centerOffset, this.glow);
   }

   private static int a(int var0, float var1) {
      int var2 = (int)((var0 >> 24 & 0xFF) * var1);
      var2 = Math.clamp(var2, 0, 255);
      return var2 << 24 | var0 & 16777215;
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onRender2D(Render2DEvent var1) {
      if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1690.field_1842) {
         return;
      }

      class_1044 var2 = mc.method_1531().method_4619(POINTER_TEX);
      if (var2 == null) {
         return;
      }

      GpuTextureView var3 = var2.method_71659();
      if (var3 == null) {
         return;
      }

      long var4 = System.currentTimeMillis();
      float var6 = Math.min(100.0F, Math.max(1.0F, (float)(var4 - this.lastFrameTime))) / 1000.0F;
      this.lastFrameTime = var4;
      this.smoothedYaw = this.smoothedYaw + class_3532.method_15393(mc.field_1724.method_36454() - this.smoothedYaw) * (1.0F - (float)Math.exp(-15.0F * var6));
      float var7 = var1.getTickCounter().method_60637(true);
      class_243 var8 = mc.field_1724.method_30950(var7);
      float var9 = RenderUtil.a() / 2.0F;
      float var10 = RenderUtil.b() / 2.0F;
      float var11 = (float)this.centerOffset.getValue();
      float var12 = (float)this.arrowSize.getValue();
      Matrix4f var13 = RenderUtil.c();
      int var14 = FRIEND_COLOR.getRGB();

      for (class_1657 var15 : mc.field_1687.method_18456()) {
         if (var15 != mc.field_1724 && var15.method_5805() && FriendManager.a(var15.method_5477().getString())) {
            class_243 var16 = var15.method_30950(var7);
            float var17 = class_3532.method_15393((float)Math.toDegrees(Math.atan2(var16.field_1352 - var8.field_1352, var8.field_1350 - var16.field_1350)) - this.smoothedYaw);
            float var18 = (float)Math.toRadians(var17);
            float var19 = var9 + (float)Math.sin(var18) * var11;
            float var20 = var10 - (float)Math.cos(var18) * var11;

            if (this.glow.isToggled()) {
               int var21 = a(var14, 1.0F);
               float var22 = var12 * 1.65F;
               float var23 = var12 * 1.35F;
               float var24 = var12 * 1.1F;
               TexturePipeline.d(var13, var19 - var22 / 2.0F, var20 - var22 / 2.0F, var22, var22, var3, a(var21, 0.35F), 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var18);
               TexturePipeline.d(var13, var19 - var23 / 2.0F, var20 - var23 / 2.0F, var23, var23, var3, a(var21, 0.65F), 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var18);
               TexturePipeline.d(var13, var19 - var24 / 2.0F, var20 - var24 / 2.0F, var24, var24, var3, var21, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var18);
            } else {
               TexturePipeline.c(var13, var19 - var12 / 2.0F, var20 - var12 / 2.0F, var12, var12, var3, var14, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var18);
            }
         }
      }
   }
}
